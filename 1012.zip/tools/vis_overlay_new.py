#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Standalone RoadNetwork visualization (overlay-style), independent from tools/vis.py.

This script reads:
- A config file (to obtain grid_conf and bz_grid_conf)
- A results JSON produced by NuScenesReachMetric (results_nusc.json)
- Optionally the dataset pkl (ann_file) to fetch GT for the same tokens

It renders a BEV overlay image per sample: GT (green) and Prediction (blue/purple) on the same canvas.
It also provides diagnostic options to highlight boundary nodes/edges, draw straight lines
instead of Bezier for comparison, and to clip control points away from the BEV boundary for display only.

Example usage:

PYTHONPATH=. python tools/vis_overlay_new.py \
  --config configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py \
  --results /path/to/work_dir/results/results_nusc.json \
  --tag overlay_new \
  --limit 50 \
  --overlay-scale 10 \
  --highlight-boundary --boundary-margin 1 \
  --draw-straight --no-arrows

Notes:
- Requires package `bezier` (already used elsewhere in the project). If missing, install it.
- Output images will be saved under vis/<tag>/ as PNG files named <idx>_<token>_overlay.png
"""

import os
import sys
import json
import argparse
from typing import Dict, Any, Optional, List, Tuple

import numpy as np
import cv2
from mmengine import Config
from mmengine.fileio import load as mm_load
import bezier

# Try import from projects path first, then local rntr package, else add parent path
try:
    from projects.RoadNetwork.rntr.core.centerline import EvalMapBzGraph, convert_coeff_coord, seq2bznodelist  # type: ignore
    from projects.RoadNetwork.rntr.transforms.loading import LoadNusOrderedBzCenterline, TransformOrderedBzLane2Graph  # type: ignore
    from projects.RoadNetwork.rntr.transforms.roadnet_reach_dist_eval import node_match  # type: ignore
except Exception:
    try:
        from rntr.core.centerline import EvalMapBzGraph, convert_coeff_coord, seq2bznodelist  # type: ignore
        from rntr.transforms.loading import LoadNusOrderedBzCenterline, TransformOrderedBzLane2Graph  # type: ignore
        from rntr.transforms.roadnet_reach_dist_eval import node_match  # type: ignore
    except Exception:
        _root = os.path.dirname(os.path.dirname(__file__))
        if _root not in sys.path:
            sys.path.append(_root)
        from rntr.core.centerline import EvalMapBzGraph, convert_coeff_coord, seq2bznodelist  # type: ignore
        from rntr.transforms.loading import LoadNusOrderedBzCenterline, TransformOrderedBzLane2Graph  # type: ignore
        from rntr.transforms.roadnet_reach_dist_eval import node_match  # type: ignore


# -------------------- grid utils --------------------

def gen_dx_bx(xbound, ybound, zbound):
    dx = np.array([row[2] for row in [xbound, ybound, zbound]])
    bx = np.array([row[0] + row[2] / 2.0 for row in [xbound, ybound, zbound]])
    nx = np.floor(np.array([(row[1] - row[0]) / row[2] for row in [xbound, ybound, zbound]]))
    return dx, bx, nx


def get_range(grid_conf):
    dx, bx, nx = gen_dx_bx(grid_conf['xbound'], grid_conf['ybound'], grid_conf['zbound'])
    pc_range = np.concatenate((bx - dx / 2., bx - dx / 2. + nx * dx))
    return dx, bx, nx, pc_range


# -------------------- dataset ann resolve --------------------

def resolve_dataset_ann(cfg: Config, data_root_override: Optional[str] = None, ann_file_override: Optional[str] = None) -> str:
    # Try val_dataloader first, fallback to test_dataloader
    ds_cfg: Dict[str, Any] = None
    if 'val_dataloader' in cfg:
        ds_cfg = cfg.val_dataloader.get('dataset', cfg.val_dataloader)
    elif 'test_dataloader' in cfg:
        ds_cfg = cfg.test_dataloader.get('dataset', cfg.test_dataloader)
    else:
        raise RuntimeError('No val_dataloader or test_dataloader found in config.')

    base_root = data_root_override if data_root_override is not None else ds_cfg.get('data_root', cfg.get('data_root', ''))
    if ann_file_override is not None:
        if os.path.isabs(ann_file_override):
            return ann_file_override
        return os.path.join(base_root, ann_file_override)

    ann_file = ds_cfg.get('ann_file')
    if ann_file is None:
        raise RuntimeError('ann_file not found in dataloader dataset config.')
    if os.path.isabs(ann_file):
        return ann_file
    return os.path.join(base_root, ann_file)


# -------------------- drawing helpers --------------------

def is_boundary_grid(pt_grid: np.ndarray, nx: np.ndarray, margin: int = 0) -> bool:
    x, y = int(pt_grid[0]), int(pt_grid[1])
    max_x = int(nx[0]) - 1
    max_y = int(nx[1]) - 1
    return (x <= margin) or (x >= max_x - margin) or (y <= margin) or (y >= max_y - margin)


def draw_bezier(image: np.ndarray,
                p0: np.ndarray,
                c: np.ndarray,
                p1: np.ndarray,
                color: Tuple[int, int, int],
                thickness: int = 3,
                add_arrows: bool = True) -> None:
    """Draw a quadratic Bezier curve from p0->p1 with control point c on image."""
    fin_res = np.stack((p0, c, p1))
    curve = bezier.Curve(fin_res.T, degree=2)
    s_vals = np.linspace(0.0, 1.0, 50)
    data_b = curve.evaluate_multi(s_vals).T
    pts = data_b.astype(np.int32)
    if pts.shape[0] >= 2:
        cv2.polylines(image, [pts], False, color=color, thickness=thickness)
        if add_arrows and pts.shape[0] > 26:
            arrowline = pts[24:26, :].copy()
            diff = arrowline[1] - arrowline[0]
            if not np.all(arrowline[1] == arrowline[0]):
                norm = np.linalg.norm(diff) + 1e-6
                diff = (diff / norm) * max(2, thickness * 2)
                arrowline[1] = arrowline[0] + diff.astype(np.int32)
                cv2.arrowedLine(image, tuple(arrowline[0]), tuple(arrowline[1]), color=color, thickness=thickness, tipLength=0.4)


def draw_graph_overlay(canvas: np.ndarray,
                        graph: EvalMapBzGraph,
                        nx: np.ndarray,
                        scale: int,
                        node_color: Tuple[int, int, int],
                        edge_color_continue: Tuple[int, int, int],
                        edge_color_fork: Tuple[int, int, int],
                        *,
                        highlight_boundary: bool = False,
                        boundary_margin: int = 0,
                        clip_control_margin: int = 0,
                        draw_mode: str = 'bezier',  # 'bezier' | 'straight'
                        no_arrows: bool = False,
                        thickness: int = 3,
                        roi_grid: Optional[Tuple[int, int, int, int]] = None,
                        skip_boundary_edges: bool = False,
                        max_edge_length: Optional[float] = None,
                        boundary_first: bool = True,
                        node_overrides: Optional[Dict[int, Tuple[int, int, int]]] = None) -> Dict[str, int]:
    """Draw nodes and edges of a graph on the canvas using given colors and options."""
    boundary_col = (180, 180, 180)

    def _inside_roi(pt_grid: np.ndarray) -> bool:
        if roi_grid is None:
            return True
        xmin, xmax, ymin, ymax = roi_grid
        x, y = float(pt_grid[0]), float(pt_grid[1])
        return (x >= xmin) and (x <= xmax) and (y >= ymin) and (y <= ymax)

    stats_nodes_drawn = 0
    # nodes
    for node in graph.graph_nodelist:
        if node is None:
            continue
        coord_grid = np.array(node.coord)
        if not _inside_roi(coord_grid):
            continue
        coord = (coord_grid * scale).astype(np.int32)
        coord_tp = (int(coord[0]), int(coord[1]))
        col = node_color
        if node_overrides is not None:
            # key by id(node)
            col = node_overrides.get(id(node), col)
        if highlight_boundary and is_boundary_grid(coord_grid, nx, boundary_margin):
            col = boundary_col
        r = int(max(2, scale ** 1.2))
        cv2.circle(canvas, coord_tp, r, col, thickness=-1)
        cv2.circle(canvas, coord_tp, r, (0, 0, 0), thickness=2)
        stats_nodes_drawn += 1

    # edges (collect, then draw in two passes to keep boundary under other edges)
    edges = []  # list of dicts
    for node in graph.graph_nodelist:
        if node is None:
            continue
        p0_grid = np.array(node.coord)
        if not _inside_roi(p0_grid):
            continue
        for cnode, coeff in node.childs:
            p1_grid = np.array(cnode.coord)
            if not _inside_roi(p1_grid):
                continue
            # filter by length in grid units (straight distance)
            if max_edge_length is not None:
                if float(np.linalg.norm(p1_grid - p0_grid)) > float(max_edge_length):
                    continue
            c_grid = np.array(coeff)
            if clip_control_margin > 0:
                c_grid[0] = np.clip(c_grid[0], clip_control_margin, int(nx[0]) - 1 - clip_control_margin)
                c_grid[1] = np.clip(c_grid[1], clip_control_margin, int(nx[1]) - 1 - clip_control_margin)
            base_color = edge_color_continue if (len(node.childs) == 1 and len(cnode.parents) == 1) else edge_color_fork
            is_bnd = (is_boundary_grid(p0_grid, nx, boundary_margin) or is_boundary_grid(p1_grid, nx, boundary_margin))
            edges.append({
                'p0_grid': p0_grid, 'p1_grid': p1_grid, 'c_grid': c_grid,
                'base_color': base_color, 'is_bnd': is_bnd
            })

    def _draw_edge_item(item, use_thickness):
        p0 = (item['p0_grid'] * scale).astype(np.int32)
        p1 = (item['p1_grid'] * scale).astype(np.int32)
        cpt = (item['c_grid'] * scale).astype(np.int32)
        color = item['base_color']
        if highlight_boundary and item['is_bnd']:
            color = boundary_col
        if draw_mode == 'straight':
            cv2.line(canvas, tuple(p0), tuple(p1), color=color, thickness=use_thickness)
        else:
            draw_bezier(canvas, p0, cpt, p1, color=color, thickness=use_thickness, add_arrows=(not no_arrows))

    # draw
    boundary_th = max(1, thickness - 1)
    if boundary_first:
        for it in edges:
            if skip_boundary_edges and it['is_bnd']:
                continue
            if it['is_bnd']:
                _draw_edge_item(it, boundary_th)
        for it in edges:
            if it['is_bnd']:
                continue
            _draw_edge_item(it, thickness)
    else:
        for it in edges:
            if it['is_bnd']:
                continue
            _draw_edge_item(it, thickness)
        for it in edges:
            if skip_boundary_edges and it['is_bnd']:
                continue
            if it['is_bnd']:
                _draw_edge_item(it, boundary_th)

    # stats
    stats = {
        'nodes_drawn': stats_nodes_drawn,
        'edges_total': len(edges),
        'edges_boundary': int(sum(1 for e in edges if e['is_bnd']))
    }
    return stats


# -------------------- main pipeline --------------------

def main():
    parser = argparse.ArgumentParser(description='Standalone overlay visualization for RoadNetwork (GT vs Prediction).')
    parser.add_argument('--config', type=str, required=True, help='Path to config file used in evaluation (must match).')
    parser.add_argument('--results', type=str, required=True, help='Path to results_nusc.json produced by NuScenesReachMetric.')
    parser.add_argument('--tag', type=str, default='overlay_new', help='Subfolder under vis/ to save images')
    parser.add_argument('--limit', type=int, default=-1, help='Max number of samples to visualize (-1 for all)')
    parser.add_argument('--data-root', type=str, default=None, help='Override data root (e.g., /mmdetection3d/data/nuscenes)')
    parser.add_argument('--ann-file', type=str, default=None, help='Override ann_file (pkl). If relative, will be joined with data-root')
    parser.add_argument('--overlay-scale', type=int, default=10, help='Scale factor (pixels per BEV grid cell)')
    parser.add_argument('--draw-mode', type=str, default='bezier', choices=['bezier', 'straight'], help='Edge rendering mode')
    parser.add_argument('--no-arrows', action='store_true', help='Disable arrowheads along edges for Bezier mode')
    parser.add_argument('--highlight-boundary', action='store_true', help='Highlight nodes/edges near BEV boundary')
    parser.add_argument('--boundary-margin', type=int, default=0, help='How many BEV grid cells are considered boundary margin')
    parser.add_argument('--clip-control-margin', type=int, default=0, help='Clamp control points away from boundary for display only')
    parser.add_argument('--skip-boundary-edges', action='store_true', help='Skip drawing edges that touch the BEV boundary')
    parser.add_argument('--roi-grid', type=str, default=None, help='ROI in grid cells: xmin,xmax,ymin,ymax (e.g., "10,180,20,100")')
    parser.add_argument('--max-edge-length', type=float, default=None, help='Max edge length (grid units) to draw; longer edges are skipped')
    parser.add_argument('--no-boundary-first', action='store_true', help='Do not draw boundary edges first as thin underlay')
    parser.add_argument('--draw-landmark-match', action='store_true', help='Color-code predicted/GT nodes by TP/FP/FN using landmark matching')
    parser.add_argument('--landmark-thres', type=float, default=5.0, help='Landmark matching threshold (grid units)')
    parser.add_argument('--stats-card', action='store_true', help='Draw a small stats card (nodes/edges counts)')
    args = parser.parse_args()

    cfg = Config.fromfile(args.config)

    # Grid conf
    grid_conf = cfg.get('grid_conf', None)
    bz_grid_conf = cfg.get('bz_grid_conf', None)
    if grid_conf is None:
        grid_conf = cfg.model.get('grid_conf')
    if bz_grid_conf is None:
        bz_grid_conf = cfg.get('bz_grid_conf', None)
        if bz_grid_conf is None:
            raise RuntimeError('bz_grid_conf not found in config.')

    dx, bx, nx, pc_range = get_range(grid_conf)
    bz_dx, bz_bx, bz_nx, bz_pc_range = get_range(bz_grid_conf)

    out_dir = os.path.join('vis', args.tag)
    os.makedirs(out_dir, exist_ok=True)

    # Load results JSON
    if not os.path.isfile(args.results):
        raise FileNotFoundError(f'results JSON not found: {args.results}')
    with open(args.results, 'r') as f:
        data = json.load(f)
    results: Dict[str, Any] = data['results'] if isinstance(data, dict) and 'results' in data else data

    # Optionally load dataset pkl for token order and GT
    try:
        ann_path = resolve_dataset_ann(cfg, args.data_root, args.ann_file)
        ann_data = mm_load(ann_path)
        val_infos = ann_data.get('infos', [])
        token_order = [info['token'] for info in val_infos]
        token2info = {info['token']: info for info in val_infos}
        ordered = [t for t in token_order if t in results]
        pred_items = [(t, results[t]) for t in ordered]
    except Exception:
        pred_items = list(results.items())
        token2info = {}

    if args.limit is not None and args.limit > 0:
        pred_items = pred_items[:args.limit]

    # Prepare GT processors
    centerline_loader = LoadNusOrderedBzCenterline(grid_conf, bz_grid_conf)
    centerline_transform = TransformOrderedBzLane2Graph(n_control=3, orderedDFS=True)

    # Colors (BGR)
    gt_node_col = (60, 200, 60)
    gt_edge_cont = (60, 220, 60)
    gt_edge_fork = (80, 180, 80)
    pred_node_col = (60, 60, 220)
    pred_edge_cont = (40, 40, 240)
    pred_edge_fork = (120, 120, 255)

    # Parse ROI
    roi_tuple = None
    if args.roi_grid is not None:
        try:
            parts = [p.strip() for p in args.roi_grid.split(',')]
            if len(parts) == 4:
                xmin, xmax, ymin, ymax = map(float, parts)
                roi_tuple = (xmin, xmax, ymin, ymax)
            else:
                print('[WARN] --roi-grid expects 4 comma-separated numbers: xmin,xmax,ymin,ymax; ignoring.')
        except Exception:
            print('[WARN] failed to parse --roi-grid; ignoring.')

    count = 0
    for token, node_list in pred_items:
        try:
            # Convert prediction coeff to main grid coords
            node_list_conv = convert_coeff_coord(node_list, pc_range, dx, bz_pc_range, bz_dx)
            pred_graph = EvalMapBzGraph(token, node_list_conv)

            # Build GT graph if available
            gt_graph = None
            if token in token2info:
                info = token2info[token]
                info = centerline_loader(info)
                info = centerline_transform(info)
                gt_sequence = np.array(info['centerline_sequence'])
                gt_nodes = seq2bznodelist(gt_sequence, 3)
                gt_nodes = convert_coeff_coord(gt_nodes, pc_range, dx, bz_pc_range, bz_dx)
                gt_graph = EvalMapBzGraph(token, gt_nodes)

            # Create empty canvas
            H = int(nx[1]) * args.overlay_scale
            W = int(nx[0]) * args.overlay_scale
            canvas = np.zeros((H, W, 3), dtype=np.uint8)

            # Optional landmark matching to color-code nodes
            pred_node_overrides = None
            gt_node_overrides = None
            landmark_stats_text = None
            if args.draw_landmark_match and (gt_graph is not None):
                try:
                    gt_sup_nodes = gt_graph.get_nodechains_dpt(1)
                    pred_sup_nodes = pred_graph.get_nodechains_dpt(1)
                    gt_ind, pred_ind = node_match(gt_sup_nodes, pred_sup_nodes, args.landmark_thres)
                    # Build sets
                    pred_objs_all = [sn.nodechain[0][0] for sn in pred_sup_nodes]
                    gt_objs_all = [sn.nodechain[0][0] for sn in gt_sup_nodes]
                    pred_tp_objs = set(pred_ind.keys())
                    gt_tp_objs = set(gt_ind.keys())
                    pred_fp_objs = set(pred_objs_all) - pred_tp_objs
                    gt_fn_objs = set(gt_objs_all) - gt_tp_objs
                    # Colors (BGR)
                    col_tp_pred = (0, 165, 255)   # orange for pred TP
                    col_fp_pred = (0, 0, 255)     # red for pred FP
                    col_tp_gt = (0, 200, 0)       # green for gt TP (same as node base)
                    col_fn_gt = (0, 255, 255)     # yellow for gt FN
                    # Map to overrides by id(node)
                    pred_node_overrides = {id(n): col_tp_pred for n in pred_tp_objs}
                    pred_node_overrides.update({id(n): col_fp_pred for n in pred_fp_objs})
                    gt_node_overrides = {id(n): col_tp_gt for n in gt_tp_objs}
                    gt_node_overrides.update({id(n): col_fn_gt for n in gt_fn_objs})
                    landmark_stats_text = f"LM tp={len(pred_tp_objs)} fp={len(pred_fp_objs)} fn={len(gt_fn_objs)}"
                except Exception as e:
                    print(f"[WARN] landmark match failed for token={token}: {e}")

            # Draw GT then Pred
            if gt_graph is not None:
                stats_gt = draw_graph_overlay(canvas, gt_graph, nx, args.overlay_scale,
                                   node_color=gt_node_col,
                                   edge_color_continue=gt_edge_cont,
                                   edge_color_fork=gt_edge_fork,
                                   highlight_boundary=args.highlight_boundary,
                                   boundary_margin=args.boundary_margin,
                                   clip_control_margin=args.clip_control_margin,
                                   draw_mode=args.draw_mode,
                                   no_arrows=args.no_arrows,
                                   thickness=4,
                                   roi_grid=roi_tuple,
                                   skip_boundary_edges=args.skip_boundary_edges,
                                   max_edge_length=args.max_edge_length,
                                   boundary_first=(not args.no_boundary_first),
                                   node_overrides=gt_node_overrides)
            if pred_graph is not None:
                stats_pred = draw_graph_overlay(canvas, pred_graph, nx, args.overlay_scale,
                                   node_color=pred_node_col,
                                   edge_color_continue=pred_edge_cont,
                                   edge_color_fork=pred_edge_fork,
                                   highlight_boundary=args.highlight_boundary,
                                   boundary_margin=args.boundary_margin,
                                   clip_control_margin=args.clip_control_margin,
                                   draw_mode=args.draw_mode,
                                   no_arrows=args.no_arrows,
                                   thickness=3,
                                   roi_grid=roi_tuple,
                                   skip_boundary_edges=args.skip_boundary_edges,
                                   max_edge_length=args.max_edge_length,
                                   boundary_first=(not args.no_boundary_first),
                                   node_overrides=pred_node_overrides)

            # Token label
            cv2.putText(canvas, f'Token: {token}', (20, H - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (220, 220, 220), 2, cv2.LINE_AA)

            # Legend
            def draw_legend(img: np.ndarray, entries: List[Tuple[Tuple[int, int, int], str]], origin=(20, 20)):
                x0, y0 = origin
                pad = 10
                line_h = 24
                box_w = 280
                box_h = pad * 2 + line_h * len(entries)
                cv2.rectangle(img, (x0, y0), (x0 + box_w, y0 + box_h), (245, 245, 245), thickness=-1)
                cv2.rectangle(img, (x0, y0), (x0 + box_w, y0 + box_h), (0, 0, 0), thickness=1)
                for i, (color, text) in enumerate(entries):
                    y = y0 + pad + i * line_h + 14
                    cv2.line(img, (x0 + 10, y), (x0 + 50, y), color, thickness=3)
                    cv2.putText(img, text, (x0 + 60, y + 5), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (10, 10, 10), 1, cv2.LINE_AA)

            legend_entries = [
                (gt_edge_cont, 'GT (edge)'),
                (pred_edge_cont, 'Prediction (edge)'),
            ]
            draw_legend(canvas, legend_entries, origin=(20, 20))

            # Optional stats card
            if args.stats_card:
                stats_lines = []
                if gt_graph is not None:
                    stats_lines.append(f"GT: nodes={stats_gt['nodes_drawn']} edges={stats_gt['edges_total']} bnd={stats_gt['edges_boundary']}")
                stats_lines.append(f"PR: nodes={stats_pred['nodes_drawn']} edges={stats_pred['edges_total']} bnd={stats_pred['edges_boundary']}")
                if landmark_stats_text is not None:
                    stats_lines.append(landmark_stats_text)
                # draw a small box under legend
                x0, y0 = 20, 20 + 24*len(legend_entries) + 20
                pad = 8
                line_h = 20
                box_w = 420
                box_h = pad*2 + line_h*len(stats_lines)
                cv2.rectangle(canvas, (x0, y0), (x0+box_w, y0+box_h), (245,245,245), thickness=-1)
                cv2.rectangle(canvas, (x0, y0), (x0+box_w, y0+box_h), (0,0,0), thickness=1)
                for i, text in enumerate(stats_lines):
                    y = y0 + pad + i*line_h + 14
                    cv2.putText(canvas, text, (x0+10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (10,10,10), 1, cv2.LINE_AA)

            out_path = os.path.join(out_dir, f'{count:06d}_{token}_overlay.png')
            cv2.imwrite(out_path, canvas)
            count += 1
        except Exception as e:
            print(f'[WARN] failed to visualize token={token}: {e}')

    print(f'Done. Saved {count} images to: {out_dir}')


if __name__ == '__main__':
    main()
