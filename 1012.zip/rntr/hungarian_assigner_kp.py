# ------------------------------------------------------------------------
# Keypoint Hungarian Assigner for SAR keypoint branch
# Computes one-to-one matching between predicted keypoints and GT keypoints
# using classification probability cost and L1 coordinate cost.
# ------------------------------------------------------------------------
import torch
import torch.nn.functional as F

try:
    from scipy.optimize import linear_sum_assignment
except Exception:
    linear_sum_assignment = None

from mmdet.models.task_modules import AssignResult, BaseAssigner

# Try to import multiple registries for maximum compatibility across versions
try:
    from mmdet3d.registry import TASK_UTILS as M3D_TASK_UTILS
except Exception:
    M3D_TASK_UTILS = None
try:
    from mmdet3d.registry import MODELS as M3D_MODELS
except Exception:
    M3D_MODELS = None
try:
    from mmdet.registry import TASK_UTILS as MDET_TASK_UTILS
except Exception:
    MDET_TASK_UTILS = None
try:
    from mmdet.registry import MODELS as MDET_MODELS
except Exception:
    MDET_MODELS = None


class HungarianAssigner_KP(BaseAssigner):
    """Hungarian assigner for keypoints.

    Args:
        cls_cost (dict|float): If dict, expects {'weight': float}. Weight for classification cost.
        reg_cost (dict|float): If dict, expects {'weight': float}. Weight for L1 coord cost.
        iou_cost (dict|float): Ignored; kept for cfg compatibility.
    """

    def __init__(self,
                 cls_cost=dict(type='ClassificationCost', weight=1.0),
                 reg_cost=dict(type='BBoxL1Cost', weight=5.0),
                 iou_cost=dict(type='IoUCost', iou_mode='giou', weight=0.0)):
        self.cls_weight = float(cls_cost.get('weight', 1.0)) if isinstance(cls_cost, dict) else float(cls_cost)
        self.reg_weight = float(reg_cost.get('weight', 1.0)) if isinstance(reg_cost, dict) else float(reg_cost)
        # iou cost is not used for keypoints, but accept it for config compatibility

    def assign(self,
               pred_coords_norm: torch.Tensor,   # [Q, 2] in [0,1], (y_norm, x_norm)
               pred_cls_logits: torch.Tensor,    # [Q, C]
               gt_coords_yx: torch.Tensor,       # [N, 2] in pixel (y, x)
               gt_labels: torch.Tensor,          # [N]
               meta: dict = None,
               eps: float = 1e-7) -> AssignResult:
        """Compute matching between predictions and ground-truth.

        meta should contain img_shape=(H, W) to normalize GT coords to [0,1].
        """
        device = pred_cls_logits.device
        Q = int(pred_cls_logits.shape[0])
        N = int(gt_labels.shape[0]) if gt_labels is not None else 0

        # Defaults: all to background when empty
        assigned_gt_inds = pred_cls_logits.new_full((Q,), -1, dtype=torch.long)
        assigned_labels = pred_cls_logits.new_full((Q,), -1, dtype=torch.long)
        if N == 0 or Q == 0:
            if Q > 0:
                assigned_gt_inds[:] = 0
            return AssignResult(N, assigned_gt_inds, None, labels=assigned_labels)

        # Normalize GT coords to [0,1] using H,W from meta
        H, W = 1, 1
        try:
            if isinstance(meta, dict) and 'img_shape' in meta:
                H, W = int(meta['img_shape'][0]), int(meta['img_shape'][1])
        except Exception:
            pass
        denom_y = max(H - 1, 1)
        denom_x = max(W - 1, 1)
        gt_norm = gt_coords_yx.to(device).float().clone()
        gt_norm[:, 0] = gt_norm[:, 0] / float(denom_y)  # y
        gt_norm[:, 1] = gt_norm[:, 1] / float(denom_x)  # x
        gt_norm = gt_norm.clamp(0, 1)

        # Pairwise L1 cost between predictions and gt
        # pred_coords_norm: [Q,2], gt_norm: [N,2] -> [Q,N]
        reg_cost = torch.cdist(pred_coords_norm.float(), gt_norm.float(), p=1)

        # Classification cost: negative probability of gt class
        # prob: [Q,C], labels: [N] -> gather per gt -> [Q,N]
        prob = F.softmax(pred_cls_logits.float(), dim=-1)
        # Advanced indexing to get probability for each GT class across all Q
        cls_prob = prob[:, gt_labels.long()]
        cls_cost = -cls_prob

        # Total cost
        cost = self.cls_weight * cls_cost + self.reg_weight * reg_cost
        cost = torch.nan_to_num(cost, nan=100.0, posinf=100.0, neginf=-100.0)

        # Hungarian matching on CPU
        if linear_sum_assignment is None:
            raise ImportError('Please install scipy: pip install scipy')
        cost_cpu = cost.detach().cpu()
        row_ind, col_ind = linear_sum_assignment(cost_cpu)
        row_ind = torch.as_tensor(row_ind, device=device, dtype=torch.long)
        col_ind = torch.as_tensor(col_ind, device=device, dtype=torch.long)

        # Fill assignment results
        assigned_gt_inds[:] = 0
        assigned_gt_inds[row_ind] = col_ind + 1  # 1-based
        assigned_labels[row_ind] = gt_labels[col_ind].to(device)
        return AssignResult(N, assigned_gt_inds, None, labels=assigned_labels)


# Register into multiple registries for broad compatibility
try:
    if M3D_TASK_UTILS is not None:
        M3D_TASK_UTILS.register_module(name='HungarianAssigner_KP')(HungarianAssigner_KP)
except Exception:
    pass
try:
    if M3D_MODELS is not None:
        M3D_MODELS.register_module(name='HungarianAssigner_KP')(HungarianAssigner_KP)
except Exception:
    pass
try:
    if MDET_TASK_UTILS is not None:
        MDET_TASK_UTILS.register_module(name='HungarianAssigner_KP')(HungarianAssigner_KP)
except Exception:
    pass
try:
    if MDET_MODELS is not None:
        MDET_MODELS.register_module(name='HungarianAssigner_KP')(HungarianAssigner_KP)
except Exception:
    pass

# Legacy MMDet v2 registry path (rare but safer):
try:
    from mmdet.core.bbox.builder import BBOX_ASSIGNERS as LEGACY_BBOX_ASSIGNERS
    try:
        LEGACY_BBOX_ASSIGNERS.register_module(name='HungarianAssigner_KP')(HungarianAssigner_KP)
    except Exception:
        pass
except Exception:
    pass
