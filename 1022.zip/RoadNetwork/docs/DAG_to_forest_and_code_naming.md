# DAG转Directed Forest与代码命名详解

本文档解答以下几个核心问题：
1. 为什么要把 DAG 转换成 directed forest？
2. 代码中的命名规则（Pl, Pry, MLM等）
3. 当前代码的 SAR/NAR 实现情况

---

## 1. DAG 转 Directed Forest 的原因

### 你的理解是正确的！核心问题确实是"边的表达歧义"

### 问题分析

#### 场景 1：Fork 节点（一个父节点，多个子节点）

```
       p (父节点)
      / \
     /   \
    c1   c2 (子节点)
```

**如果边表达为 `(父节点, ex, ey)`**：
- 边1: `(p, ex1, ey1)` → c1
- 边2: `(p, ex2, ey2)` → c2
- ✅ 没有歧义，因为通过不同的 `(ex, ey)` 可以区分去往不同子节点的边

**如果边表达为 `(子节点, ex, ey)`**：
- 边1: `(c1, ex1, ey1)` ← p
- 边2: `(c2, ex2, ey2)` ← p
- ✅ 也没有歧义，因为子节点本身就不同

#### 场景 2：Merge 节点（多个父节点，一个子节点）- **问题所在！**

```
    p1    p2 (父节点)
      \  /
       \/
       c (子节点)
```

**如果边表达为 `(父节点, ex, ey)`**：
- 边1: `(p1, ex1, ey1)` → c
- 边2: `(p2, ex2, ey2)` → c
- ✅ 没有歧义，通过不同的父节点 `p1/p2` 区分

**如果边表达为 `(子节点, ex, ey)` - 论文采用的方式**：
- 边1: `(c, ex1, ey1)` ← p1
- 边2: `(c, ex2, ey2)` ← p2
- ❌ **歧义！** 两条边都是 `(c, ?, ?)` 的形式，无法在序列中明确区分

### 为什么论文选择 `(子节点, ex, ey)` 而不是 `(父节点, ex, ey)`？

**关键：序列生成的顺序性约束**

论文的序列是**从根节点（root）出发，沿着图遍历生成的**：

```
序列生成过程（DFS/BFS）：
START → 访问节点1 → 访问节点2 → 访问节点3 → ...
```

在生成到某个节点时：
- **已知信息**：当前节点的位置（父节点已经被访问过）
- **需要表达**：从当前节点到下一个节点的连接

如果用 `(父节点, ex, ey)` 表达：
- 需要在序列中"回溯"到父节点的信息
- 这与自回归/半自回归的生成方式不匹配（无法引用"未来"的子节点）

如果用 `(子节点, ex, ey)` 表达：
- 当访问到子节点时，直接编码 `(当前子节点, ex, ey)` 来表达"我是从哪来的"
- ✅ 符合生成式模型的顺序约束

### 解决方案：把 DAG 转成 Directed Forest

**核心思想：消除多父节点**

1. **识别 merge 节点**（有多个父节点的节点）
2. **复制 merge 节点**：为每个父节点创建一个独立的副本
3. **结果**：每个节点最多只有一个父节点 → 形成树（tree）或森林（forest）

#### 转换示例

**原始 DAG**：
```
    p1    p2
      \  /
       \/
       c
       |
       d
```

**转换后的 Forest**：
```
Tree 1:        Tree 2:
  p1             p2
   |              |
   c1             c2
   |              |
   d1             d2
```

**序列表达**：
- Tree 1: `[START, p1, (c1, ex1, ey1), (d1, ex3, ey3)]`
- Tree 2: `[START, p2, (c2, ex2, ey2), (d2, ex4, ey4)]`

现在每条边都是 `(子节点, ex, ey)`，且**每个节点只有一个父节点**，不再有歧义！

### 代码中的实现

在 `rntr/core/centerline/structures/ljc_bz_centerline.py` 中可以看到：

```python
# Merge 节点的处理
if nodelist[i]['sque_type'] == 'merge':
    node.childs.append((graph_nodelist[node.merge_with], nodelist[i]['coeff']))
    graph_nodelist[node.merge_with].parents.append((node, nodelist[i]['coeff']))
    # 通过 subgraph_split() 将有多个父节点的结构拆分成多个子图（树）
```

这个 `subgraph_split()` 操作就是在做"DAG → Forest"的转换！

---

## 2. 代码命名规则详解

### 2.1 `Pry` = 作者名字缩写

你的猜测**完全正确**！

- `Pry` 确实指的是作者 **Peng Renyuan（彭任远）**
- 这是代码库中的惯例，用作者名字标记某些模块的贡献者

**相关类**：
- `PryDecoderEmbeddings`：Peng Renyuan 实现的 Decoder Embedding
- `PlPryLineTransformerDecoderLayer`：Parallel + Pry 的 Decoder Layer
- `PlPrySeqLineTransformer`：Parallel + Pry 的 Transformer

### 2.2 `Pl` = Parallel（并行）

- `Pl` 表示 **Parallel-seq**（并行序列）
- 这是针对"解耦序列"（decoupled sequence）的实现
- 与论文中的 `vertex-seq` 和 `edge-seq` 分离对应

**关键类**：
- `LssPlPrySeqLineTransformer`
  - `Lss`：可能是项目代号或数据集名
  - `Pl`：Parallel（并行/解耦）
  - `Pry`：作者名
  - `Seq`：Sequence
  - `Line`：道路线

### 2.3 `MLM` = Masked Language Model

你的理解**完全正确**！

- `MLM` 就是 **Masked Language Model**（掩码语言模型）
- 受 BERT 启发的训练方式
- 特征：使用全可见的 attention mask（`torch.zeros`）

**关键代码**：`LssMLMPlPrySeqLineTransformer`

```python
# rntr/rntr_transformer.py:525
tgt_mask = torch.zeros(tgt.shape[2], tgt.shape[2]).to(tgt.device)
# 全0 = 全可见，任何位置都可以 attend 到任何位置
```

这与 BERT 的 MLM 预训练思路一致：
- 随机 mask 一些 token
- 用上下文（包括左右两侧）预测被 mask 的 token
- 通过全可见的 attention 实现

### 2.4 `SAR` = Semi-AutoRegressive

- `SAR`：半自回归
- 使用块级因果 mask（block-causal mask）
- 块内并行，块间因果

### 2.5 `NAR` = Non-AutoRegressive  

- `NAR`：非自回归
- 使用全可见 mask + 迭代重掩码
- 完全并行

---

## 3. 当前代码的 SAR/NAR 实现情况

### 你的疑问："代码里没有现成的 semi-AR，也没有现成的 mask BERT"

**这个结论不完全准确，让我们逐一分析：**

### 3.1 ✅ Semi-AR（SAR）已经实现

**实现位置**：`rntr/sar_rntr_head.py` 中的 `SARRNTRHead`

**关键证据**：

```python
# rntr/sar_rntr_head.py:304
block_len = clause_length * self.sar_group_clauses

# 构建块级因果 mask
if use_meta_groups:
    tgt_mask = _build_group_mask_from_ids(...)
else:
    tgt_mask = _build_block_causal_mask(T, block_len, device)
```

**使用的 Transformer**：
- `LssSARPrmSeqLineTransformer`（支持外部 `tgt_mask`）
- 位置：`rntr/rntr_transformer.py:130`

```python
def forward(self, tgt, x, tgt_mask, mask, query_embed, pos_embed, prompt=None, prompt_pos=None):
    # 接受外部传入的 tgt_mask
    attn_mask = tgt_mask if tgt_mask is not None else generate_square_subsequent_mask(len(tgt))
    out_dec = self.decoder(..., attn_masks=[attn_mask, None])
```

**支持 Prompt（SD-Map/Keypoint）**：
```python
# rntr/sar_rntr_head.py:403
sd_prompt, sd_prompt_pos = self._gather_sd_prompt(img_metas, ...)
outs_dec, _ = self.transformer(tgt, x, tgt_mask, masks, query_embed, pos_embed, sd_prompt, sd_prompt_pos)
```

**结论**：✅ Semi-AR 已经完整实现，并支持 prompt！

### 3.2 ⚠️ Mask BERT（MLM）风格的实现情况

#### 已有的 MLM Transformer

**类名**：`LssMLMPlPrySeqLineTransformer`

**特点**：
- 使用全可见 mask：`torch.zeros(T, T)`
- 支持 prompt cross-attention

**问题**：
- 这个 Transformer 需要 4D 输入 `tgt` 的形状：`[B, S, N, C]`（注意第二维 `S`）
- 而 `SARRNTRHead` 提供的是 3D：`[B, T, D]`

**代码证据**：
```python
# rntr/rntr_transformer.py:515
bs, s, n, c = tgt.shape  # 期望 4D
tgt = tgt.squeeze(1)     # [B, 1, T, D] -> [B, T, D]
```

#### 当前 SARRNTRHead 的 MLM 模式

**开关**：`nar_mlm_train=True`

**实现**：
```python
# rntr/sar_rntr_head.py:395
if getattr(self, 'nar_mlm_train', False):
    tgt_mask = torch.zeros_like(tgt_mask)  # 改成全可见
```

**使用的 Transformer**：
- 还是 `LssSARPrmSeqLineTransformer`（不是专门的 MLM 版本）
- 只是把 mask 改成全可见而已

**结论**：⚠️ 有"简化版"的 MLM（通过改 mask 实现），但没有用专门的 `LssMLMPlPrySeqLineTransformer`

### 3.3 为什么 `LssMLMPlPrySeqLineTransformer` 没被用？

**原因 1：输入形状不匹配**

```python
# SARRNTRHead 提供的输入
tgt = self.embedding(input_seqs.long())  # [B, T, D] - 3D

# LssMLMPlPrySeqLineTransformer 期望的输入
bs, s, n, c = tgt.shape  # [B, S, N, C] - 4D
```

需要在外面包装一层 `unsqueeze(1)` 才能用。

**原因 2：不同的序列格式**

- `LssMLMPlPrySeqLineTransformer` 可能是为**解耦序列**（vertex-seq + edge-seq）设计的
- `SARRNTRHead` 使用的是**统一序列**（unified sequence）

**原因 3：历史迭代**

- `LssMLMPlPrySeqLineTransformer` 可能是早期实验版本
- 最新版本统一到 `LssSARPrmSeqLineTransformer`，通过外部 mask 控制行为

---

## 4. 代码架构总结

### Head 层级

| Head 类名 | 用途 | Transformer | Prompt支持 | Mask类型 |
|----------|------|-------------|-----------|---------|
| `ARRNTRHead` | 自回归（AR） | `LssSeqLineTransformer` | ❌ | 因果（内部生成） |
| `SARRNTRHead` | 半自回归（SAR）/非自回归（NAR） | `LssSARPrmSeqLineTransformer` | ✅ SD-Map/KP | 块级因果/全可见（外部传入） |
| `ARLanegraph2seqHead` | 自回归（LaneGraph2Seq风格） | `LssSeqLineTransformer` | ❌ | 因果 |
| `DECRNTRHead` | 解耦序列（NAR） | - | ❌ | 全可见 |

### Transformer 层级

| Transformer 类名 | Mask | Prompt | Decoder Layer |
|-----------------|------|--------|---------------|
| `LssSeqLineTransformer` | 因果（内部） | ❌ | 标准 DETR Layer |
| `LssSARPrmSeqLineTransformer` | 外部传入 | ✅ Cross-attn | 标准 DETR Layer |
| `LssPlPrySeqLineTransformer` | 因果（内部） | ✅ Cross-attn | `PlPryLineTransformerDecoderLayer` |
| `LssMLMPlPrySeqLineTransformer` | 全可见（内部） | ✅ Cross-attn | `PlPryLineTransformerDecoderLayer` |

### Decoder Layer 层级

| Layer 类名 | Prompt 支持 | 特点 |
|-----------|------------|-----|
| 标准 DETR Layer | ❌ | self-attn + cross-attn |
| `PlPryLineTransformerDecoderLayer` | ✅ | 3个 attn（self + cross + prompt） |

**核心代码**：
```python
# rntr/rntr_transformer.py:1978
def _forward(self,
            query,
            key=None,
            value=None,
            prompt=None,           # ← Prompt 支持
            query_pos=None,
            key_pos=None,
            prompt_pos=None,       # ← Prompt 位置编码
            ...):
```

---

## 5. 澄清你的理解

### ✅ 正确的理解

1. **DAG → Forest 的原因**：消除 merge 节点的多父节点歧义 ✓
2. **Pry 是作者名字**：Peng Renyuan ✓
3. **Pl 是 Parallel**：并行序列/解耦序列 ✓
4. **MLM 是 Masked Language Model**：使用全可见 mask ✓

### ❌ 需要修正的理解

1. **"代码里没有现成的 semi-AR"**
   - ❌ 不对，`SARRNTRHead` 就是完整的 Semi-AR 实现
   - 它使用 `LssSARPrmSeqLineTransformer` + 外部 `tgt_mask`

2. **"没有现成的 mask BERT"**
   - ⚠️ 部分正确：
     - 有 `LssMLMPlPrySeqLineTransformer`（专门的 MLM Transformer）
     - 但它没被 `SARRNTRHead` 使用
     - `SARRNTRHead` 通过 `nar_mlm_train=True` 实现简化版 MLM（改 mask 为全可见）

3. **"self.transformer(...) 缺少 prompt"**
   - ❌ 不对，`LssSARPrmSeqLineTransformer` **支持** prompt：
     ```python
     def forward(self, tgt, x, tgt_mask, mask, query_embed, pos_embed, 
                 prompt=None, prompt_pos=None):  # ← 有 prompt 参数
     ```
   - `SARRNTRHead` 会传入 SD-Map 或 Keypoint prompt

---

## 6. 实际使用建议

### 使用 SAR（推荐）

```python
bbox_head = dict(
    type='SARRNTRHead',
    transformer=dict(
        type='LssSARPrmSeqLineTransformer',  # 支持 prompt 和外部 mask
        decoder=dict(...)
    ),
    sar_group_clauses=1,        # 块大小
    sar_intra_group_mlm=True,   # 组内全可见
    sd_prompt_enable=True,       # 启用 SD-Map prompt
)
```

### 使用 NAR

```python
bbox_head = dict(
    type='SARRNTRHead',
    transformer=dict(
        type='LssSARPrmSeqLineTransformer',
        decoder=dict(...)
    ),
    nar_infer=True,             # NAR 推理
    nar_iters=3,                # 迭代轮数
    nar_mlm_train=False,        # 训练时还是用 SAR mask
)
```

### 使用 MLM 风格训练

```python
bbox_head = dict(
    type='SARRNTRHead',
    transformer=dict(
        type='LssSARPrmSeqLineTransformer',
        decoder=dict(...)
    ),
    nar_mlm_train=True,         # 训练时用全可见 mask（MLM 风格）
)
```

---

## 7. 总结

| 问题 | 答案 |
|------|------|
| 为什么 DAG → Forest？ | 消除 merge 节点的多父节点歧义，使边的表达 `(子节点, ex, ey)` 唯一 |
| Pry 是什么？ | 作者 Peng Renyuan 的名字缩写 |
| Pl 是什么？ | Parallel（并行/解耦序列） |
| MLM 是什么？ | Masked Language Model（全可见 mask） |
| 代码有 SAR 吗？ | ✅ 有，`SARRNTRHead` + `LssSARPrmSeqLineTransformer` |
| 代码有 prompt 吗？ | ✅ 有，支持 SD-Map 和 Keypoint prompt |
| 代码有 MLM 吗？ | ⚠️ 有简化版（通过 `nar_mlm_train=True` 改 mask），但专门的 `LssMLMPlPrySeqLineTransformer` 未被使用 |

---

**参考代码位置**：
- DAG → Forest：`rntr/core/centerline/structures/ljc_bz_centerline.py`
- SAR 实现：`rntr/sar_rntr_head.py`（`SARRNTRHead`）
- Transformer：`rntr/rntr_transformer.py`
  - `LssSARPrmSeqLineTransformer`（SAR/NAR 通用）
  - `LssMLMPlPrySeqLineTransformer`（专门的 MLM，未被 Head 使用）
- Decoder Layer：`rntr/rntr_transformer.py`（`PlPryLineTransformerDecoderLayer`）
