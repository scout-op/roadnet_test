# Mask（掩码）通俗讲解

> 本文用最简单的语言和例子，解释 RoadNetTransformer 中的 mask 是什么、怎么用。

---

## 1. 什么是 Mask？用考试来类比

想象你在参加考试，有 5 道题（题1、题2、题3、题4、题5）：

### 场景 A：开卷考试（完全可见）
- 你可以看所有题目的答案，互相参考
- 这就像 **NAR 的全可见 mask**

### 场景 B：按顺序答题（只能看前面）
- 做题1时：只能看题1
- 做题2时：可以看题1和题2
- 做题3时：可以看题1、题2、题3
- ...
- 这就像 **AR 的因果 mask**

### 场景 C：分组考试（组内互看，组间有顺序）
- 题1-2是第一组，题3-4是第二组，题5是第三组
- 做第一组时：题1和题2可以互相看
- 做第二组时：可以看第一组（题1-2）和自己组（题3-4）
- 做第三组时：可以看前面所有组
- 这就像 **SAR 的块级 mask**

**Mask 就是告诉模型："哪些题目可以互相看，哪些不能看"的规则表。**

---

## 2. Mask 在代码中长什么样？

Mask 是一个矩阵，用数字表示"能不能看"：
- **0** = 可以看 ✓
- **-inf**（负无穷）= 不能看 ✗

### 例子：5 个位置的序列

假设我们有 5 个 token 的序列：`[START, x1, x2, x3, x4]`

#### AR 因果 Mask（只能看过去）

```
       看→  0   1   2   3   4
做↓    [START x1  x2  x3  x4]
0 [START]  0  -inf -inf -inf -inf
1 [x1]     0   0   -inf -inf -inf
2 [x2]     0   0    0   -inf -inf
3 [x3]     0   0    0    0   -inf
4 [x4]     0   0    0    0    0
```

**解读**：
- 位置 0（START）：只能看自己
- 位置 1（x1）：能看 0 和 1
- 位置 2（x2）：能看 0、1、2
- 依此类推...

**这就是"下三角矩阵"，上面全是 -inf（看不见未来）**

#### SAR 块级 Mask（组内全看，组间因果）

假设每 2 个位置是一组：
- 组1：位置 0-1
- 组2：位置 2-3  
- 组3：位置 4

```
       看→  0   1   2   3   4
做↓    [START x1  x2  x3  x4]
0 [START]  0   0  -inf -inf -inf   ← 组1内互看
1 [x1]     0   0  -inf -inf -inf   ← 组1内互看
2 [x2]     0   0   0    0   -inf   ← 能看组1和组2
3 [x3]     0   0   0    0   -inf   ← 能看组1和组2
4 [x4]     0   0   0    0    0     ← 能看所有
```

**解读**：
- 位置 0 和 1 在同一组，可以互相看
- 位置 2 和 3 在同一组，可以看自己组 + 前面的组1
- 位置 4 是单独一组，可以看所有

#### NAR 全可见 Mask（全部可看）

```
       看→  0   1   2   3   4
做↓    [START x1  x2  x3  x4]
0 [START]  0   0   0   0   0
1 [x1]     0   0   0   0   0
2 [x2]     0   0   0   0   0
3 [x3]     0   0   0   0   0
4 [x4]     0   0   0   0   0
```

**解读**：所有位置都能看所有位置，完全并行！

---

## 3. 代码中怎么构造这些 Mask？

### AR 的因果 Mask

```python
# 文件：rntr/rntr_transformer.py
def generate_square_subsequent_mask(sz):
    """生成 AR 因果掩码"""
    # 创建上三角矩阵（上面是 1，下面是 0）
    mask = (torch.triu(torch.ones(sz, sz)) == 1).transpose(0, 1)
    # 把 0 的地方填 -inf，1 的地方填 0
    mask = mask.float().masked_fill(mask == 0, float('-inf')).masked_fill(mask == 1, float(0.0))
    return mask

# 使用
T = 5
tgt_mask = generate_square_subsequent_mask(T)
# 结果就是上面例子中的下三角矩阵
```

### SAR 的块级 Mask

```python
# 文件：rntr/sar_rntr_head.py
def _build_block_causal_mask(T: int, block_len: int, device) -> torch.Tensor:
    """构造 SAR 块级因果掩码
    
    Args:
        T: 序列总长度（比如 5）
        block_len: 块大小（比如 2，表示每 2 个位置一组）
    """
    # 先全填 -inf（都看不见）
    mask = torch.full((T, T), float('-inf'), device=device)
    
    # 计算有多少个块
    num_blocks = math.ceil(T / max(block_len, 1))
    
    # 对每个块
    for b in range(num_blocks):
        start = b * block_len
        end = min((b + 1) * block_len, T)
        # 这个块内的所有位置，可以看到"从开始到当前块结束"的所有位置
        mask[start:end, :end] = 0.0
    
    return mask

# 使用
T = 5
block_len = 2  # 每 2 个位置一组
tgt_mask = _build_block_causal_mask(T, block_len, device='cuda')
```

### NAR 的全可见 Mask

```python
# 文件：rntr/sar_rntr_head.py（推理分支）
T = 5
tgt_mask = torch.zeros(T, T, device=device)
# 就这么简单！全是 0 = 全部可见
```

---

## 4. 训练和推理时的 Mask 选择

### 训练时（`self.training = True`）

在 `SARRNTRHead.forward()` 中：

```python
if self.training:
    # 1. 正常情况：根据策略选 SAR mask
    if use_meta_groups:
        # 基于数据的 group_ids 构造
        tgt_mask = _build_group_mask_from_ids(...)
    else:
        # 使用固定块大小的 block mask
        tgt_mask = _build_block_causal_mask(T, block_len, device)
    
    # 2. 如果开启 NAR-MLM 训练模式
    if self.nar_mlm_train:
        tgt_mask = torch.zeros_like(tgt_mask)  # 改成全可见
    
    # 3. 传给 transformer
    outs_dec, _ = self.transformer(tgt, x, tgt_mask, ...)
```

**通俗解释**：
- 默认用 SAR（分组考试）
- 如果配置了 `nar_mlm_train=True`，就改成 NAR（开卷考试）

### 推理时（`self.training = False`）

#### 情况 1：NAR 推理（`nar_infer=True`）

```python
if self.nar_infer:
    # 使用全可见 mask
    T = ...
    tgt_mask_zero = torch.zeros(T, T, device=device)
    
    # 多轮迭代
    for iteration in range(self.nar_iters):
        outs_dec, _ = self.transformer(tgt, x, tgt_mask_zero, ...)
        # ... 预测、置信度筛选、重掩码 ...
```

#### 情况 2：AR 推理（默认）

```python
else:
    # 逐个位置解码，每次只预测最后一个位置
    for step in range(max_steps):
        tgt = embedding(seq)  # seq 逐步增长
        # transformer 内部会用因果 mask
        outs_dec, _ = self.transformer(tgt, x, ...)
        next_token = outs_dec[-1, :, -1, :].argmax(-1)
        seq = torch.cat([seq, next_token], dim=-1)
```

---

## 5. NAR 的"重掩码"是什么？

**注意**：这不是注意力层的 mask，而是"输入 token 的掩码"！

### 类比：考试的"草稿纸策略"

- 第一轮：所有答案先都写"不知道"（`NO_KNOWN`）
- 第二轮：模型看着全部题目，给出答案和"确定度"
  - 确定度 > 0.5 的答案：保留
  - 确定度 < 0.5 的答案：继续写"不知道"
- 第三轮：再看一遍，继续填充...
- 最后一轮：不管确定度，全部接受

### 代码实现

```python
# 初始化：全填 NO_KNOWN，只有第一个是 START
seq = torch.full((B, T), int(self.no_known), device=device)
seq[:, 0] = int(self.start)  # [START, NO_KNOWN, NO_KNOWN, ...]

for iteration in range(self.nar_iters):
    # 1. 用当前 seq 做一次全可见解码
    tgt = self.embedding(seq)
    outs_dec, _ = self.transformer(tgt, x, tgt_mask_zero, ...)
    
    # 2. 预测和置信度
    logits = self.vocab_embed(outs_dec[-1])  # [B, T, V]
    probs = logits.softmax(-1)
    confidence, tokens = probs.max(dim=-1)  # [B, T], [B, T]
    
    # 3. 如果不是最后一轮，做重掩码
    if iteration < self.nar_iters - 1:
        keep_mask = (confidence >= self.nar_conf_thresh)  # 置信度高的保留
        keep_mask[:, 0] = True  # START 必须保留
        
        # 重置不确定的位置
        seq = torch.where(
            keep_mask, 
            tokens,  # 保留：用预测的 token
            torch.full_like(tokens, int(self.no_known))  # 不保留：改回 NO_KNOWN
        )
    else:
        # 最后一轮：全部接受
        seq = tokens
```

### 可视化例子

假设 `nar_iters=3`，`nar_conf_thresh=0.5`：

```
初始化:
seq = [START, NO_KNOWN, NO_KNOWN, NO_KNOWN, NO_KNOWN]

第 1 轮预测:
预测 = [START,   x1,      x2,     x3,      x4]
置信度 = [1.0,   0.8,     0.3,    0.9,     0.4]
保留 =  [✓,      ✓(>0.5), ✗,      ✓(>0.5), ✗]
seq = [START, x1, NO_KNOWN, x3, NO_KNOWN]

第 2 轮预测:
预测 = [START,   x1,      x2',    x3,      x4']
置信度 = [1.0,   0.8,     0.6,    0.9,     0.7]
保留 =  [✓,      ✓,       ✓(>0.5), ✓,      ✓(>0.5)]
seq = [START, x1, x2', x3, x4']

第 3 轮（最后一轮）:
预测 = [START,   x1,      x2'',   x3,      x4'']
全部接受
seq = [START, x1, x2'', x3, x4'']  ← 最终输出
```

**关键理解**：
- 注意力 mask（全可见）让模型"看全部"
- 重掩码策略让模型"分步确定"，避免一次性预测太多导致错误累积

---

## 6. 三种模式的总结表

| 模式 | 注意力 Mask | 解码方式 | 速度 | 精度 | 适用场景 |
|------|------------|---------|------|------|---------|
| **AR** | 因果（下三角） | 逐个位置 | 慢 | 高 | 需要严格时序依赖 |
| **SAR** | 块级因果 | 块内并行，块间因果 | 中 | 中 | 平衡速度和精度 |
| **NAR** | 全可见（全0） | 全并行 + 迭代重掩码 | 快 | 中（取决于迭代） | 需要快速推理 |

---

## 7. 如何选择和调试？

### 选择建议

- **训练阶段**：
  - 默认用 SAR（`nar_mlm_train=False`）
  - 如果想试验 NAR 预训练，设置 `nar_mlm_train=True`

- **推理阶段**：
  - 如果要精度优先：用 AR（不设置 `nar_infer`）
  - 如果要速度优先：用 NAR（`nar_infer=True`）

### 调试技巧

1. **打印 mask 的形状和统计**：
```python
print(f"tgt_mask shape: {tgt_mask.shape}")
allow_count = (tgt_mask == 0).sum().item()
total = tgt_mask.numel()
print(f"Allow ratio: {allow_count}/{total} = {allow_count/total:.2%}")
```

2. **可视化 mask**（用热力图）：
```python
import matplotlib.pyplot as plt
plt.imshow(tgt_mask.cpu().numpy(), cmap='RdYlGn', vmin=-10, vmax=0)
plt.colorbar()
plt.title('Attention Mask (0=allow, -inf=block)')
plt.show()
```

3. **NAR 迭代日志**：
```python
for it in range(self.nar_iters):
    # ...
    print(f"Iter {it}: NO_KNOWN count = {(seq == self.no_known).sum().item()}/{seq.numel()}")
    print(f"Iter {it}: Keep ratio = {keep_mask.float().mean().item():.2%}")
```

---

## 8. 常见误区

### 误区 1：Mask 是"遮住图像的某部分"
❌ **错误**：Mask 不是遮图像，而是控制"注意力"中"谁能看谁"。

✅ **正确**：Mask 是告诉 self-attention 层，计算注意力分数时哪些位置不能参与。

### 误区 2：NAR 的"重掩码"就是注意力 mask
❌ **错误**：重掩码是把输入 token 改成 `NO_KNOWN`，不是注意力层的 mask。

✅ **正确**：NAR 有两层"mask"：
- 注意力层：全可见（`zeros`）
- 输入层：迭代重掩码（改 token 值）

### 误区 3：Mask 全是 0 就是"没有 mask"
❌ **错误**：全 0 是"全部允许"的 mask，依然是一种 mask。

✅ **正确**：
- 全 0 = 全可见（NAR）
- 全 -inf = 全遮挡（不合理）
- 下三角 0 = 因果（AR）

---

## 9. 快速上手检查清单

想用 NAR？检查这些配置：

- [ ] `nar_infer=True`（推理用 NAR）
- [ ] `nar_iters=3`（迭代次数，2-5 合理）
- [ ] `nar_conf_thresh=0.5`（置信度阈值）
- [ ] `nar_keep_ratio=0.1`（可选，Top-K 保留）
- [ ] 特殊 token ID 正确（`start=574`, `no_known=575`）
- [ ] Transformer 类型支持外部 `tgt_mask`（如 `LssSARPrmSeqLineTransformer`）

推理时看日志：
- [ ] 每轮 `NO_KNOWN` 数量在减少
- [ ] 最后一轮 `NO_KNOWN` 接近 0
- [ ] 迭代次数合理（过多收益递减）

---

## 10. 总结

- **Mask 是一个矩阵**，告诉模型"哪些位置可以互相看"
- **0 = 允许，-inf = 禁止**
- **AR = 因果（下三角），SAR = 块级因果，NAR = 全可见（全0）**
- **NAR 的重掩码** 是另一个概念，是迭代时改输入 token 值
- 用具体例子和打印来理解和调试，远比看公式直观

---

**参考代码位置**：
- `rntr/sar_rntr_head.py`：`SARRNTRHead.forward()`（训练和推理入口）
- `rntr/rntr_transformer.py`：
  - `generate_square_subsequent_mask()`（AR 因果 mask）
  - `_build_block_causal_mask()`（SAR 块级 mask）
  - `LssSARPrmSeqLineTransformer.forward()`（mask 透传）

希望这份文档能让你彻底理解 mask！🎉
