# ------------------------------------------------------------------------
# Decoupled Sequence Head for RoadNetTransformer
# Token-level language modeling over a flattened sequence:
# [START] + (x,y)*N + <EOV> + [CONNECT, coeff_x, coeff_y, ... , <Split>]*M + <EOE>
# ------------------------------------------------------------------------
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmdet3d.registry import MODELS

# Reuse utilities from ARRNTRHead
from .ar_rntr_head import PryDecoderEmbeddings, MLP


@MODELS.register_module()
class DECRNTRHead(nn.Module):
    """Minimal token-level head for decoupled sequence.

    Responsibilities:
    - Embed input token ids
    - Run transformer decoder over BEV features
    - Project to vocabulary logits (num_center_classes)
    - Compute CE loss vs. next-token labels
    """

    def __init__(self,
                 in_channels=256,
                 embed_dims=256,
                 num_center_classes=576,
                 max_len=1200,
                 transformer=None,
                 bev_positional_encoding=dict(
                     type='PositionEmbeddingSineBEV', num_feats=128, normalize=True),
                 ) -> None:
        super().__init__()
        self.in_channels = in_channels
        self.embed_dims = embed_dims
        self.vocab_size = num_center_classes
        self.max_len = int(max_len)

        # build transformer and pos enc
        self.transformer = MODELS.build(transformer)
        self.bev_position_encoding = MODELS.build(bev_positional_encoding)

        # projection for BEV channels if needed
        if self.in_channels != self.embed_dims:
            self.bev_proj = nn.Conv2d(self.in_channels, self.embed_dims, kernel_size=1)
        else:
            self.bev_proj = nn.Identity()

        # token embedding and classifier
        self.embedding = PryDecoderEmbeddings(self.vocab_size, self.embed_dims, self.max_len)
        self.vocab_embed = MLP(self.embed_dims, self.embed_dims, self.vocab_size, 3)

        # loss
        self.loss_ce = MODELS.build(dict(type='mmdet.CrossEntropyLoss'))

    def init_weights(self):
        if hasattr(self.transformer, 'init_weights'):
            self.transformer.init_weights()

    def forward(self, bev_feats: torch.Tensor, input_tokens: torch.Tensor, img_metas):
        """Forward
        Args:
            bev_feats: [B, C, H, W]
            input_tokens: [B, T] token ids
        Returns:
            logits_all_layers: [L, B, T, V]
        """
        x = self.bev_proj(bev_feats)
        pos_embed = self.bev_position_encoding(x)
        B, _, H, W = x.shape
        masks = torch.zeros(B, H, W, dtype=torch.bool, device=x.device)

        tgt = self.embedding(input_tokens.long())  # [B, T, D]
        query_embed = self.embedding.position_embeddings.weight  # [T_max, D]
        outs_dec, _ = self.transformer(tgt, x, masks, query_embed, pos_embed)
        outs_dec = torch.nan_to_num(outs_dec)
        logits = self.vocab_embed(outs_dec)  # [L, B, T, V]
        return logits

    def loss_by_token(self, logits: torch.Tensor, target: torch.Tensor):
        """Compute token CE loss on the last decoder layer.
        Args:
            logits: [L, B, T, V]
            target: [B, T]
        Returns: dict with 'loss_token'
        """
        last = logits[-1]  # [B, T, V]
        # flatten for CE
        B, T, V = last.shape
        last = last.reshape(B * T, V)
        tgt = target.reshape(B * T)
        loss = self.loss_ce(last, tgt)
        return dict(loss_token=loss)

    @torch.no_grad()
    def greedy_decode(self, bev_feats: torch.Tensor, img_metas, start_id: int, end_id: int, max_len: int = None):
        x = self.bev_proj(bev_feats)
        pos_embed = self.bev_position_encoding(x)
        B, _, H, W = x.shape
        masks = torch.zeros(B, H, W, dtype=torch.bool, device=x.device)
        Tm = self.max_len if max_len is None else max_len
        seq = torch.full((B, 1), int(start_id), device=x.device, dtype=torch.long)
        values = []
        for _ in range(Tm - 1):
            tgt = self.embedding(seq.long())
            query_embed = self.embedding.position_embeddings.weight
            outs_dec, _ = self.transformer(tgt, x, masks, query_embed, pos_embed)
            step = torch.nan_to_num(outs_dec)[-1, :, -1, :]
            logit = self.vocab_embed(step)
            prob = logit.softmax(-1)
            val, tok = prob.topk(k=1, dim=-1)
            seq = torch.cat([seq, tok], dim=-1)
            values.append(val)
            # early stop if all end
            if (tok.view(-1) == end_id).all():
                break
        if values:
            values = torch.cat(values, dim=-1)
        else:
            values = torch.zeros((B, 0), device=x.device)
        return seq, values
