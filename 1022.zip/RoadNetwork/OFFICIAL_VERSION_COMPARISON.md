# 官方代码版本对比：RoadNetwork-1.8.1 vs 2.0.1

## 版本概述

| 版本 | Torch版本 | 文件行数 | 发布说明 | 路径 |
|------|----------|---------|---------|------|
| **1.8.1** | Torch < 2.0 | **494行** | **稳定版本**（2024年4月） | `RoadNetwork-1.8.1/projects/mmdet3d_plugin/models/detectors/` |
| **2.0.1** | Torch >= 2.1 | **342行** | **高效版本** | `RoadNetwork-2.0.1/rntr/` |

---

## 主要差异对比

### 1. **MMDetection 版本依赖** ⭐⭐⭐

#### 1.8.1 版本（基于 MMDetection 2.x）
```python
# Line 6-16
import mmcv
from mmcv.parallel import DataContainer as DC
from mmcv.runner import force_fp32, auto_fp16
from mmdet.models import DETECTORS
from mmdet3d.core import bbox3d2result
from mmcv.cnn import ConvModule
from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector

@DETECTORS.register_module()  # 旧的装饰器
class AR_RNTR(MVXTwoStageDetector):
```

**特点**：
- 使用 `mmcv` 和 `mmdet` 2.x API
- 使用 `@force_fp32` 装饰器（旧式混合精度）
- 数据格式：`DataContainer`

---

#### 2.0.1 版本（基于 MMDetection 3.x / MMEngine）
```python
# Line 6-17
from mmengine.structures import InstanceData
from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector
from mmdet3d.registry import MODELS
from mmdet3d.structures.ops import bbox3d2result

@MODELS.register_module()  # 新的装饰器
class AR_RNTR(MVXTwoStageDetector):
```

**特点**：
- 使用 **MMEngine** API（MMDet 3.x 新架构）
- 不再需要 `@force_fp32`（原生支持混合精度）
- 数据格式：`InstanceData`, `Det3DDataSample`
- 更简洁的导入依赖

**优势**：
- ✅ **原生 FP16 训练支持**（无需额外装饰器）
- ✅ **更快的训练速度**（MMEngine 优化）
- ✅ 代码更简洁

---

### 2. **训练接口（Training API）** ⭐⭐⭐

#### 1.8.1 版本（旧式 `forward_train`）
```python
# Line 264-277
@force_fp32(apply_to=('img', 'points'))
def forward(self, return_loss=True, **kwargs):
    if return_loss:
        return self.forward_train(**kwargs)
    else:
        return self.forward_test(**kwargs)

def forward_train(self,
                  points=None,
                  img_metas=None,
                  gt_bboxes_3d=None,
                  gt_labels_3d=None,
                  gt_labels=None,
                  gt_bboxes=None,
                  img=None,
                  proposals=None,
                  gt_bboxes_ignore=None,
                  img_depth=None,
                  img_mask=None):
    # 从 kwargs 中手动提取数据
    img = kwargs['img']
    img_metas = kwargs['img_metas']
    # ...
```

**特点**：
- `forward()` 根据 `return_loss` 分派
- `forward_train()` 接收**多个独立参数**
- 需要 `@force_fp32` 装饰器
- 数据格式不统一

---

#### 2.0.1 版本（新式 `loss` / `predict`）
```python
# Line 242-270
def loss(self, inputs, data_samples=None, **kwargs):
    """Forward training function.
    
    Args:
        inputs (dict): Input images, keys: ['img']
        data_samples (list[Det3DDataSample]): Batch data samples
    """
    img = inputs['img']
    img_metas = [ds.metainfo for ds in data_samples]
    
    bev_feats = self.extract_feat(img=img, img_metas=img_metas)
    losses = dict()
    gt_lines_coords = [img_meta['centerline_coord'] for img_meta in img_metas]
    gt_lines_labels = [img_meta['centerline_label'] for img_meta in img_metas]
    # ...
    return losses

def predict(self, batch_inputs_dict, batch_data_samples, **kwargs):
    """Forward of testing."""
    batch_input_metas = [item.metainfo for item in batch_data_samples]
    batch_input_imgs = batch_inputs_dict['img']
    return self.simple_test(batch_input_metas[:1], batch_input_imgs[:1])
```

**特点**：
- **MMEngine 标准接口**：`loss()` 训练，`predict()` 推理
- 统一数据格式：`inputs` (dict) + `data_samples` (list[Det3DDataSample])
- 无需装饰器
- 自动支持混合精度

**优势**：
- ✅ **接口更清晰**（训练/推理分离）
- ✅ **数据流更标准化**
- ✅ **更易于扩展**

---

### 3. **初始化参数** ⭐

#### 1.8.1 版本
```python
def __init__(self,
             use_grid_mask=False,
             pts_voxel_layer=None,
             pts_voxel_encoder=None,  # 1.8.1 独有
             pts_middle_encoder=None,
             pts_fusion_layer=None,
             # ...
             lidar_pretrain=False,    # 1.8.1 独有
             epsilon=2,
             max_box_num=100,
             # 没有 init_cfg, data_preprocessor
             ):
```

**特点**：
- 包含 LiDAR 相关参数（`pts_voxel_encoder`, `lidar_pretrain`）
- 无 `init_cfg`, `data_preprocessor`（旧架构）

---

#### 2.0.1 版本
```python
def __init__(self,
             use_grid_mask=False,
             pts_voxel_layer=None,
             # 移除了 pts_voxel_encoder
             pts_middle_encoder=None,
             pts_fusion_layer=None,
             # ...
             epsilon=2,
             max_box_num=100,
             init_cfg=None,            # 新增
             data_preprocessor=None,   # 新增
             ):
```

**特点**：
- **移除了 LiDAR 编码器参数**（纯视觉方法）
- 添加 `init_cfg`, `data_preprocessor`（MMEngine 新架构）

---

### 4. **LiftSplatShoot 导入** ⭐

#### 1.8.1 版本
```python
# Line 18-20
from ..utils.LiftSplatShoot import LiftSplatShoot, LiftSplatShootEgo, Up, GTDepthLiftSplatShoot
from ..utils.LiftSplatShoot_sync import LiftSplatShootEgoSyncBN
from projects.mmdet3d_plugin.core import seq2bznodelist, seq2plbznodelist
```

**特点**：
- 导入**5个类**（包括带SyncBN的版本）
- 相对复杂的路径导入

---

#### 2.0.1 版本
```python
# Line 13-14
from .LiftSplatShoot import LiftSplatShootEgo
from .core import seq2nodelist, seq2bznodelist, seq2plbznodelist, av2seq2bznodelist
```

**特点**：
- 只导入 **1个类** `LiftSplatShootEgo`
- 更简洁的导入
- 添加了 `av2seq2bznodelist` 支持

---

### 5. **推理接口（Inference API）** ⭐⭐

#### 1.8.1 版本
```python
# Line 350-356
def forward_test(self, img_metas, img=None, **kwargs):
    for var, name in [(img_metas, 'img_metas')]:
        if not isinstance(var, list):
            raise TypeError('{} must be a list, but got {}'.format(
                    name, type(var)))
    img = [img] if img is None else img
    return self.simple_test(img_metas[0], img[0], **kwargs)
```

**特点**：
- `forward_test()` 旧式接口
- 手动类型检查
- 手动切片数据

---

#### 2.0.1 版本
```python
# Line 272-299
def predict(self, batch_inputs_dict, batch_data_samples, **kwargs):
    """Forward of testing.
    
    Returns:
        list[:obj:`Det3DDataSample`]: Detection results
    """
    batch_input_metas = [item.metainfo for item in batch_data_samples]
    batch_input_imgs = batch_inputs_dict['img']
    return self.simple_test(batch_input_metas[:1], batch_input_imgs[:1])
```

**特点**：
- **MMEngine 标准接口** `predict()`
- 统一数据格式
- 自动类型检查
- 更清晰的文档

---

### 6. **代码复杂度**

| 维度 | 1.8.1 | 2.0.1 | 差异 |
|------|-------|-------|------|
| **总行数** | 494 | 342 | **减少152行（-31%）** |
| **导入语句** | 22行 | 14行 | **减少8行** |
| **装饰器** | `@force_fp32` | 无 | **更简洁** |
| **参数数量** | 19个 | 17个 | **减少2个** |
| **核心逻辑** | 相同 | 相同 | **一致** |

---

### 7. **核心训练逻辑（相同！）** ⭐⭐⭐

#### 负样本构造（两版本完全一致）

**1.8.1 版本 (Line 207)**：
```python
output_na = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known  # [92,3]
```

**2.0.1 版本 (Line 192)**：
```python
output_na = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known  # [92,3]
```

**⚠️ 两版本都有相同的 Bug**：
- 代码创建了 `(N, 1)` 维度
- 注释写的是 `[92,3]`
- **应该是 `(N, 2)` 维度**（x, y 各1列）

---

### 8. **混合精度训练** ⭐⭐⭐

#### 1.8.1 版本
```python
# 需要手动装饰器
@force_fp32(apply_to=('img', 'points'))
def forward(self, return_loss=True, **kwargs):
    # ...
```

**特点**：
- 使用 `@force_fp32` 装饰器
- 需要手动指定哪些输入使用 FP32
- 可能有精度问题

---

#### 2.0.1 版本
```python
# 无需装饰器，原生支持
def loss(self, inputs, data_samples=None, **kwargs):
    # 自动处理混合精度
```

**特点**：
- **原生 FP16/BF16 支持**（Torch 2.x + MMEngine）
- 自动混合精度（AMP）
- 更稳定、更快

**优势**：
- ✅ 训练速度更快（官方说明：解决了 dataloader 慢的问题）
- ✅ 显存占用更少

---

### 9. **文件路径结构**

#### 1.8.1 版本
```
RoadNetwork-1.8.1/
└── projects/
    └── mmdet3d_plugin/
        └── models/
            └── detectors/
                └── ar_rntr.py  (494行)
```

**特点**：
- 深层嵌套路径
- `projects/mmdet3d_plugin` 作为插件

---

#### 2.0.1 版本
```
RoadNetwork-2.0.1/
└── rntr/
    └── ar_rntr.py  (342行)
```

**特点**：
- **扁平化路径**
- 更简洁的组织结构

---

## 核心功能对比表

| 功能 | 1.8.1 版本 | 2.0.1 版本 | 说明 |
|------|-----------|-----------|------|
| **Torch版本** | < 2.0 | >= 2.1 | 2.0.1 需要新版Torch |
| **MMDet版本** | 2.x | 3.x (MMEngine) | 架构升级 |
| **训练接口** | `forward_train()` | `loss()` | 新接口更标准 |
| **推理接口** | `forward_test()` | `predict()` | 新接口更清晰 |
| **混合精度** | `@force_fp32` | 原生支持 | 2.0.1 更高效 |
| **数据格式** | `DataContainer` | `Det3DDataSample` | 新格式更统一 |
| **代码行数** | 494 | 342 | 2.0.1 更简洁 |
| **LiDAR支持** | ✅ 有 | ❌ 移除 | 2.0.1 纯视觉 |
| **核心逻辑** | ✅ 一致 | ✅ 一致 | **算法相同** |
| **负样本Bug** | ❌ 有 | ❌ 有 | **两版本都有** |

---

## 性能对比（官方说明）

### 1.8.1 版本
- ✅ **稳定版本**（经过充分测试）
- ⚠️ Dataloader 较慢
- ⚠️ Transformer 效率较低（Torch 1.x）
- ⚠️ 显存占用较大
- **平均训练时间**: 约4天

### 2.0.1 版本
- ✅ **高效版本**
- ✅ 解决了 dataloader 慢的问题
- ✅ Transformer 效率高（Torch 2.x 原生优化）
- ✅ 支持 FP16 训练
- ✅ 显存占用更少
- **平均训练时间**: < 4天（官方未明确，但应该更快）

---

## 兼容性对比

| 环境 | 1.8.1 版本 | 2.0.1 版本 |
|------|-----------|-----------|
| **Torch 1.8-1.13** | ✅ 兼容 | ❌ 不兼容 |
| **Torch 2.0+** | ⚠️ 部分兼容 | ✅ 完全兼容 |
| **MMDet 2.x** | ✅ 兼容 | ❌ 不兼容 |
| **MMDet 3.x** | ❌ 不兼容 | ✅ 兼容 |
| **CUDA 10.x** | ✅ 兼容 | ⚠️ 建议11.x+ |
| **CUDA 11.x+** | ✅ 兼容 | ✅ 兼容 |

---

## 你的代码基于哪个版本？

查看你的代码 `/home/subobo/ro/1020/RoadNetwork/rntr/ar_rntr.py`：

```python
# Line 6-10
from mmengine.structures import InstanceData
from mmdet3d.registry import MODELS

@MODELS.register_module()
def loss(self, inputs, data_samples=None, **kwargs):
```

**结论**：你的代码**基于 2.0.1 版本**（Torch >= 2.1 + MMEngine）

---

## 迁移指南（如果需要从 1.8.1 迁移到 2.0.1）

### 1. 更新依赖
```bash
# 卸载旧版本
pip uninstall mmcv mmcv-full mmdet mmdet3d

# 安装新版本
pip install torch>=2.1 torchvision
pip install mmengine
pip install mmdet>=3.0
pip install mmdet3d>=1.3
```

### 2. 修改代码

| 旧代码 (1.8.1) | 新代码 (2.0.1) |
|---------------|---------------|
| `from mmdet.models import DETECTORS` | `from mmdet3d.registry import MODELS` |
| `@DETECTORS.register_module()` | `@MODELS.register_module()` |
| `def forward_train(...)` | `def loss(self, inputs, data_samples, ...)` |
| `def forward_test(...)` | `def predict(self, batch_inputs_dict, batch_data_samples, ...)` |
| `@force_fp32(...)` | （删除装饰器） |
| `kwargs['img']` | `inputs['img']` |
| `kwargs['img_metas']` | `[ds.metainfo for ds in data_samples]` |

### 3. 更新配置文件
```python
# 旧配置 (1.8.1)
custom_imports = dict(imports=['projects.mmdet3d_plugin'])

# 新配置 (2.0.1)
custom_imports = dict(imports=['projects.RoadNetwork.rntr'])
```

---

## 推荐使用哪个版本？

### 使用 **1.8.1** 如果：
- ✅ 你的环境只能用 Torch 1.x
- ✅ 你的服务器 CUDA 版本较老
- ✅ 你需要最稳定的版本
- ✅ 你不在意训练时间

### 使用 **2.0.1** 如果（推荐！）：
- ✅ 你的环境支持 Torch 2.1+
- ✅ 你想要更快的训练速度
- ✅ 你想要更少的显存占用
- ✅ 你想要 FP16 训练
- ✅ 你想要更简洁的代码

**你的代码已经基于 2.0.1，这是正确的选择！** ✅

---

## 总结

| 维度 | 1.8.1 | 2.0.1 | 谁更好 |
|------|-------|-------|--------|
| **代码简洁性** | 494行 | 342行 | **2.0.1** ✅ |
| **训练速度** | 较慢 | 快 | **2.0.1** ✅ |
| **显存占用** | 较大 | 小 | **2.0.1** ✅ |
| **兼容性** | 广泛 | Torch 2.x | **1.8.1** ✅ |
| **稳定性** | 高 | 中等 | **1.8.1** ✅ |
| **核心算法** | ✅ | ✅ | **相同** |
| **负样本Bug** | ❌ | ❌ | **都有** |

**核心结论**：
1. ✅ **核心算法完全一致**（负样本构造、损失计算、推理逻辑）
2. ✅ **2.0.1 在工程上更优**（代码简洁、速度快、显存小）
3. ⚠️ **两版本都有负样本维度 Bug**（你的代码已修复）
4. ✅ **你的代码基于 2.0.1 是正确选择**

你的改进（槽位约束、后处理、容量提升）适用于两个版本，因为核心逻辑一致！
