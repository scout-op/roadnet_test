# AR-RNTR 可视化功能 - 快速开始

## ✅ 已完成的修改

### 1. 添加了可视化函数
在 `rntr/ar_rntr.py` 中添加了两个函数：
- ✅ `vis_linepts()` - 节点点可视化
- ✅ `vis_from_nodelist()` - **拓扑图可视化（推荐）**

### 2. 添加了推理时的自动调用
在 `simple_test_pts()` 函数结束时（line 832-840）：
```python
# Optional visualization (controlled by vis_cfg in config)
if self.vis_cfg is not None:
    for bi, line_result in enumerate(line_results):
        pred_node_list = line_result['pred_node_lists']
        self.vis_from_nodelist(pred_node_list, img_metas[bi], 
                               self.vis_cfg['path'], 'pred')
```

### 3. 创建了配置文件
- ✅ `configs/rntr_ar_roadseq/lss_ar_rntr_val_with_vis.py` - 启用可视化的验证配置
- ✅ `configs/rntr_ar_roadseq/VISUALIZATION_GUIDE.md` - 详细使用指南

---

## 🚀 如何使用

### 方法1: 使用专门的可视化配置（推荐）

```bash
cd /home/subobo/ro/1020/RoadNetwork

# 使用启用可视化的配置文件
python tools/test.py \
    configs/rntr_ar_roadseq/lss_ar_rntr_val_with_vis.py \
    work_dirs/lss_ar_rntr_changeloss_test_fp16_torch2/epoch_60.pth \
    --launcher pytorch
```

**输出**：
- 评测指标会打印在终端
- 可视化图像保存在：`vis/val_epoch60_debug/*.png`

---

### 方法2: 修改现有配置文件

编辑 `configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py`：

```python
model = dict(
    type='AR_RNTR',
    # ... 其他配置 ...
    
    # 取消注释并修改这一行（line 79）
    vis_cfg=dict(path='val_debug'),  # 原来是注释掉的
    
    # ... 其他配置 ...
)
```

然后正常运行验证：
```bash
python tools/test.py \
    configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py \
    work_dirs/lss_ar_rntr_changeloss_test_fp16_torch2/epoch_60.pth \
    --launcher pytorch
```

---

### 方法3: 只验证少量样本（快速调试）

修改 `lss_ar_rntr_val_with_vis.py` 的最后几行：

```python
# 取消注释
val_dataloader = dict(
    batch_size=1,
    dataset=dict(
        # 只验证前10个样本
        indices=range(10),
    )
)
```

然后运行（几分钟内完成）：
```bash
python tools/test.py \
    configs/rntr_ar_roadseq/lss_ar_rntr_val_with_vis.py \
    work_dirs/lss_ar_rntr_changeloss_test_fp16_torch2/epoch_60.pth \
    --launcher pytorch
```

---

## 📊 查看可视化结果

### 1. 查看生成的文件

```bash
# 列出所有可视化图像
ls -lh vis/val_epoch60_debug/

# 输出示例：
# scene_0001_pred.png
# scene_0002_pred.png
# scene_0003_pred.png
# ...
```

### 2. 打开图像查看

```bash
# Linux
eog vis/val_epoch60_debug/scene_0001_pred.png

# macOS
open vis/val_epoch60_debug/scene_0001_pred.png

# 或用你喜欢的图像查看器
```

### 3. 理解可视化图像

**图像信息**：
- **尺寸**: 200x200 像素
- **BEV范围**: x, y ∈ [-50m, 50m]
- **分辨率**: 0.5m/像素

**颜色含义**：
- 🔴 **红色节点** (无箭头) → **start** - 新道路起点
- 🟡 **黄色节点 + 黄色箭头** → **continue** - 道路延续（连接前一个节点）
- 🟢 **绿色节点 + 绿色箭头** → **fork** - 道路分叉（从某个历史节点分叉）
- 🔵 **蓝色节点 + 蓝色箭头** → **merge** - 道路合并（与某个历史节点合并）

---

## 🐛 用可视化调试 Reachable Recall

### 问题1: 节点被预测但没有连接（孤立节点）

**现象**：
- 看到红色节点（start），但后面没有任何箭头连接其他节点
- 或者有节点但没有箭头指向它

**原因**：
- 连接预测错误
- 可能是 `connect` 槽位预测了非法 token

**解决**：
- ✅ 已添加槽位约束（防止预测非法 token）
- ✅ 已添加后处理连接修复

---

### 问题2: 箭头指向错误的节点

**现象**：
- fork/merge 箭头指向了错误的节点
- 箭头跨越了很多节点（不合理的长连接）

**原因**：
- `fork_from` 或 `merge_with` 索引预测错误
- 可能指向了"未来节点"（索引 > 当前索引）

**解决**：
- ✅ 已添加后处理连接约束（只允许连接历史节点）

---

### 问题3: 拓扑图不完整

**现象**：
- GT有100个节点，预测只有50个
- 长链被截断

**原因**：
- 序列容量不足（`max_center_len` 太小）

**解决**：
- ✅ 已提升容量：`max_box_num=180`, `max_center_len=1201`

---

### 问题4: 节点位置准确，但连接混乱

**现象**：
- 节点位置看起来对（Landmark Recall 中等）
- 但箭头方向很混乱（Reachable Recall 低）

**原因**：
- 推理时没有槽位约束，`connect` 槽位可能预测了任意 token

**解决**：
- ✅ 已添加推理槽位约束（`_apply_slot_constraints_step`）

---

## 🔧 开关总结

| 开关方式 | 配置位置 | 效果 |
|---------|---------|------|
| **启用可视化** | `model.vis_cfg=dict(path='目录名')` | 推理时自动生成拓扑图 |
| **禁用可视化** | `model.vis_cfg=None` 或注释掉 | 不生成图像（默认） |
| **限制样本数** | `val_dataloader.dataset.indices=range(10)` | 只验证前N个样本（快速调试） |

---

## 📝 下一步

### 1. 验证当前模型（epoch 60）
```bash
python tools/test.py \
    configs/rntr_ar_roadseq/lss_ar_rntr_val_with_vis.py \
    work_dirs/lss_ar_rntr_changeloss_test_fp16_torch2/epoch_60.pth \
    --launcher pytorch
```

### 2. 查看可视化结果
```bash
ls vis/val_epoch60_debug/
# 随机挑选几张图像查看拓扑连接是否正确
```

### 3. 分析问题
对比可视化图像，识别：
- ❌ 断链（没有连接）
- ❌ 错误连接（箭头指向错误）
- ❌ 非法箭头（指向"未来"）

### 4. 验证改进效果
在改进代码后（槽位约束、后处理、容量提升），重新跑验证：
```bash
# 使用新代码训练或直接用现有权重验证
python tools/test.py \
    configs/rntr_ar_roadseq/lss_ar_rntr_val_with_vis.py \
    work_dirs/lss_ar_rntr_changeloss_test_fp16_torch2/epoch_60.pth \
    --launcher pytorch

# 对比可视化结果
diff vis/val_epoch60_debug/ vis/val_epoch60_with_fixes/
```

预期 Reachable Recall 从 0.04 提升到 0.2-0.3+

---

## 📚 相关文档

- **详细指南**: `configs/rntr_ar_roadseq/VISUALIZATION_GUIDE.md`
- **代码对比**: `AR_RNTR_CODE_COMPARISON.md`
- **官方代码优点**: `OFFICIAL_VS_MINE_STRENGTHS.md`

---

## ✅ 总结

**已添加**：
1. ✅ 两个可视化函数（与官方完全一致）
2. ✅ 推理时自动调用（通过 `vis_cfg` 开关控制）
3. ✅ 配置文件示例

**使用方法**：
1. 在配置中设置 `vis_cfg=dict(path='目录名')`
2. 运行验证
3. 查看 `vis/目录名/*.png`

**调试目标**：
- 用可视化找出 Reachable Recall 低的原因
- 对比改进前后的拓扑连接质量

🎯 **立即开始**：运行上面的命令，查看你的模型拓扑预测效果！
