# SAR训练Collapse问题修复总结

## 📅 修改时间
2025-10-21 10:35

## 🎯 问题诊断

### 发现的问题
从epoch 40的验证输出发现严重的训练collapse：

1. **坐标collapse**：
   - X坐标全是0（应该0-95分布）
   - Y坐标集中在0和56（应该0-63分布）

2. **类型collapse**：
   - 99-100%节点预测为'start'类型
   - 几乎没有'continue'、'fork'、'merge'

3. **拓扑collapse**：
   - 没有fork/merge节点
   - Reachability F1 = 0.001（几乎为0）

4. **Loss异常**：
   - loss_labels: 0.0016（应该0.5-2.0）
   - loss_connects: 0.0017（应该0.8-2.0）
   - 模型找到了"作弊策略"来最小化loss

## 🔧 修复内容

### 1. 代码层面修复

#### A. `rntr/sar_rntr_head.py`
- ❌ **移除**：`forward()`开头的统计数组重置（会导致只统计最后一个batch）
- ✅ **改进**：`_collect_pred_stats()`添加防御性初始化
- ✅ **保留**：`print_prediction_distribution()`末尾的清空逻辑

#### B. `tools/test_with_stats.py`
- ✅ **修改**：`TestHook`继承`mmengine.hooks.Hook`
- ✅ **新增**：`before_test_epoch()`方法，在测试开始时初始化统计数组
- ✅ **改进**：`after_test_epoch()`调用打印方法

#### C. `tools/analyze_predictions.py`
- ✅ **新增**：在加载模型后显式初始化统计数组

### 2. 配置层面修复

#### 新文件：`configs/rntr_sar_roadseq/lss_sar_pretrain_fixed.py`

**核心修改**：

| 参数 | 原值 | 新值 | 原因 |
|------|------|------|------|
| `label_class_weight[201]` | 0.2 | 0.5 | 避免过度抑制continue类 |
| `connect_class_weight[250]` | 0.2 | 0.5 | 避免过度抑制连接 |
| `loss_coords.loss_weight` | 1.0 | 2.0 | 强制学习坐标 |
| `loss_labels.loss_weight` | 2.0 | 4.0 | 强制学习类型 |
| `loss_connects.loss_weight` | 3.0 | 6.0 | 强制学习拓扑 |
| `loss_coeffs.loss_weight` | 1.5 | 3.0 | 强制学习系数 |
| `learning_rate` | 2e-4 | 1e-4 | 更稳定训练 |
| `warmup_iters` | 500 | 1000 | 更长的预热 |
| `gradient_clipping` | 无 | max_norm=35 | 防止梯度爆炸 |
| `val_interval` | 30 | 10 | 更频繁验证 |

## 📊 验证方法

### 方法1：快速抽样验证（推荐先用这个）

```bash
cd /home/subobo/ro/1020/RoadNetwork

# 测试5-10个batch，非常快（约1-2分钟）
python tools/analyze_predictions.py \
  projects/RoadNetwork/configs/rntr_sar_roadseq/lss_sar_pretrain_fixed.py \
  ./work_dirs/sar_fixed/epoch_10.pth \
  --samples 10
```

**预期输出（正常）**：
```
Label Distribution:
  continue     (token=201):   550 (55.0%)  ✓ 应该40-60%
  start        (token=200):   150 (15.0%)  ✓ 不应该>80%
  fork         (token=202):   180 (18.0%)  ✓
  merge        (token=203):   120 (12.0%)  ✓

Connect Distribution:
  connect=  0 (token=250):   450 (45.0%)  ✓ 应该30-50%
  connect=  1 (token=251):   280 (28.0%)  ✓
  connect=  2 (token=252):   150 (15.0%)  ✓
  
✅ No obvious collapse detected
```

**异常输出（collapse）**：
```
Label Distribution:
  start        (token=200):   990 (99.0%)  ❌ collapse!
  
Connect Distribution:
  connect=  0 (token=250):   980 (98.0%)  ❌ collapse!

⚠️  WARNING: 'start' label dominates (99.0%)
⚠️  WARNING: connect=0 dominates (98.0%)
```

### 方法2：完整验证集测试

```bash
# 测试整个验证集（较慢，约15-20分钟）
CUDA_VISIBLE_DEVICES=0,1,2,3 \
python tools/test_with_stats.py \
  projects/RoadNetwork/configs/rntr_sar_roadseq/lss_sar_pretrain_fixed.py \
  ./work_dirs/sar_fixed/epoch_10.pth \
  --work-dir ./work_dirs/sar_fixed_test \
  --cfg-options \
    data_root=./data/nuscenes \
    test_dataloader.dataset.data_root=./data/nuscenes \
    test_dataloader.dataset.ann_file=nuscenes_centerline_infos_pon_val.pkl \
    test_evaluator.ann_file=./data/nuscenes/nuscenes_centerline_infos_pon_val.pkl
```

## 🎯 训练验收标准

### 短期目标（Epoch 1-10）

**Epoch 1-2**：
- ✅ loss_labels: 1.0-3.0（不是0.001！）
- ✅ loss_connects: 1.5-3.0（不是0.001！）
- ✅ loss_coords: 6.0-7.0

**Epoch 5-10（快速抽样）**：
- ✅ Label分布：start < 30%, continue 40-60%
- ✅ Connect分布：connect=0 < 60%
- ✅ 坐标分布：X范围覆盖0-80, Y范围覆盖0-50

### 中期目标（Epoch 40）

- ✅ Landmark F1 @ 2.5m: > 0.15
- ✅ Reachability F1 @ 2.5m: > 0.05
- ✅ loss_labels: 0.3-0.8
- ✅ loss_connects: 0.5-1.0

### 长期目标（Epoch 300）

- ✅ Landmark F1 @ 2.5m: > 0.50
- ✅ Reachability F1 @ 2.5m: > 0.60

## 🚀 训练命令

```bash
cd /home/subobo/ro/1020/RoadNetwork

# 清空旧的训练（如果需要）
rm -rf work_dirs/sar_new

# 用修复的配置开始训练
SWANLAB_ENABLE=1 \
./tools/dist_train.sh \
  projects/RoadNetwork/configs/rntr_sar_roadseq/lss_sar_pretrain_fixed.py 4 \
  --work-dir ./work_dirs/sar_fixed \
  --cfg-options \
    data_root=./data/nuscenes \
    train_dataloader.dataset.data_root=./data/nuscenes \
    train_dataloader.dataset.ann_file=nuscenes_centerline_infos_pon_train.pkl \
    val_dataloader.dataset.data_root=./data/nuscenes \
    val_dataloader.dataset.ann_file=nuscenes_centerline_infos_pon_val.pkl \
    test_dataloader.dataset.data_root=./data/nuscenes \
    test_dataloader.dataset.ann_file=nuscenes_centerline_infos_pon_val.pkl \
    val_evaluator.ann_file=./data/nuscenes/nuscenes_centerline_infos_pon_val.pkl \
    test_evaluator.ann_file=./data/nuscenes/nuscenes_centerline_infos_pon_val.pkl \
    train_dataloader.batch_size=2 \
    train_dataloader.num_workers=8
```

## ⚠️ 关键监控点

### 训练过程中每10个epoch检查：

1. **Loss值检查**（从日志）：
   ```bash
   tail -f work_dirs/sar_fixed/*/vis_data/scalars.json | grep loss_labels
   ```
   - 如果loss_labels或loss_connects持续<0.01，立即停止

2. **快速分布检查**（每10 epochs）：
   ```bash
   python tools/analyze_predictions.py \
     projects/RoadNetwork/configs/rntr_sar_roadseq/lss_sar_pretrain_fixed.py \
     ./work_dirs/sar_fixed/epoch_10.pth \
     --samples 5
   ```

3. **如果仍然collapse**：
   - 进一步提高loss_labels/loss_connects权重到5.0/8.0
   - 或者尝试移除class_weight（全设为1.0）

## 📝 修改文件清单

1. ✅ `rntr/sar_rntr_head.py`（已修改）
2. ✅ `tools/test_with_stats.py`（已修改）
3. ✅ `tools/analyze_predictions.py`（已修改）
4. ✅ `configs/rntr_sar_roadseq/lss_sar_pretrain_fixed.py`（新建）

## 🎓 技术总结

### 为什么会collapse？

1. **Class weight过低**：continue和connect=0权重0.2过小
2. **Loss不平衡**：坐标loss压制了label/connect loss
3. **模型找到捷径**：全预测start+connect=0，loss很小但无效

### 为什么这些修复有效？

1. **提高关键loss权重**：强制模型关注类型和拓扑
2. **降低学习率**：避免快速收敛到坏解
3. **梯度裁剪**：防止训练不稳定
4. **更频繁验证**：及早发现问题

### SAR逻辑本身正确吗？

✅ **是的！** SAR的mask构建、group生成、Transformer实现都是正确的。
问题出在训练配置，而不是模型架构。
