# Try-Except 清理报告

## 📊 统计概览

- **总文件数**: 20个Python文件包含try-except
- **已修改**: 5处不必要的try-except
- **建议保留**: ~40处合理的try-except
- **建议进一步审查**: 若干处可选优化

---

## ✅ 已完成的清理（5处）

### 1. `rntr/dec_rntr_head.py` (第56-59行)
**问题**: Loss构建的fallback会导致配置不一致
```python
# 修改前
try:
    self.loss_ce = MODELS.build(dict(type='mmdet.CrossEntropyLoss'))
except Exception:
    self.loss_ce = nn.CrossEntropyLoss()  # 静默降级

# 修改后
self.loss_ce = MODELS.build(dict(type='mmdet.CrossEntropyLoss'))  # 明确失败
```

### 2. `rntr/sar_rntr_head_paper.py` (第80-83行)
**问题**: `.get()`已有默认值，外层try-except冗余
```python
# 修改前
try:
    n_control = int(img_metas[0].get('n_control', 3))
except Exception:
    n_control = 3

# 修改后
n_control = int(img_metas[0].get('n_control', 3))
```

### 3. `rntr/ar_rntr.py` - `extract_feat()` (第289-302行)
**问题**: 配置了teacher输入但加载失败时静默降级，隐藏配置错误
```python
# 修改前
if self.use_bev_teacher_input and len(img_metas) > 0 and 'bev_teacher' in img_metas[0]:
    try:
        # ... load teacher BEV
    except Exception:
        pass  # fallback to normal path

# 修改后
if self.use_bev_teacher_input:
    if len(img_metas) == 0 or 'bev_teacher' not in img_metas[0]:
        raise ValueError("use_bev_teacher_input=True but 'bev_teacher' not found")
    # ... load teacher BEV (no try-except)
```

### 4. `rntr/ar_rntr.py` - `loss()` (第562-577行)
**问题**: TIT蒸馏启用但数据缺失时静默跳过
```python
# 修改前
if hasattr(self, 'tit_distill') and self.tit_distill and 'bev_teacher' in img_metas[0]:
    try:
        # ... distillation
    except Exception:
        pass

# 修改后
if hasattr(self, 'tit_distill') and self.tit_distill:
    if 'bev_teacher' not in img_metas[0]:
        raise ValueError("tit_distill=True but 'bev_teacher' not found")
    # ... distillation (no try-except)
```

### 5. `rntr/transforms/loading.py` - `LoadBEVTeacherFromNpz` (第802-823行)
**问题**: 整个加载过程包在try-except中，吞没所有错误
```python
# 修改前
def __call__(self, results):
    try:
        # ... entire loading logic
    except Exception:
        pass  # silent failure
    return results

# 修改后
def __call__(self, results):
    # ... loading logic without outer try-except
    # 文件不存在时bev保持None是正常流程
    return results
```

---

## ✅ 合理使用（建议保留）

### 1. **可选依赖导入** ✅
```python
# ar_rntr.py, sar_rntr.py
try:
    import swanlab
    _SWANLAB_AVAILABLE = True
except Exception:
    swanlab = None
    _SWANLAB_AVAILABLE = False
```
**原因**: SwanLab是可选依赖，不应强制要求

### 2. **版本兼容性处理** ✅
```python
# hungarian_assigner_kp.py, sar_rntr.py
try:
    from mmdet.registry import TASK_UTILS
except Exception:
    try:
        from mmdet3d.registry import TASK_UTILS
    except Exception:
        TASK_UTILS = None
```
**原因**: 支持多个MMDet版本

```python
# sar_rntr.py - loss构建fallback
try:
    self.kp_loss_cls = MODELS.build(dict(type='mmdet.CrossEntropyLoss'))
except Exception:
    self.kp_loss_cls = MODELS.build(dict(type='CrossEntropyLoss'))
```
**原因**: MMDet版本间命名空间差异

### 3. **辅助功能容错** ✅
```python
# ar_rntr.py, sar_rntr.py
def _swanlab_log_image(self, name, img, step):
    try:
        # ... 多种日志API尝试
    except Exception:
        pass  # 日志失败不应中断训练

def _render_bev_overlay(...):
    try:
        # ... 可视化渲染
    except Exception:
        return None  # 可视化失败返回None
```
**原因**: 日志和可视化是辅助功能，失败不应影响主流程

### 4. **分布式训练容错** ✅
```python
def _is_main_process(self):
    try:
        if not dist.is_available() or not dist.is_initialized():
            return True
        return dist.get_rank() == 0
    except Exception:
        return True
```
**原因**: 单机训练时torch.distributed可能不可用

### 5. **推理阶段容错** ✅
```python
# ar_rntr.py - simple_test_pts() 的sanitation
try:
    # Clamp coordinates, fix invalid connects, etc.
except Exception:
    pass  # Never break inference
```
**原因**: 推理阶段的best-effort修正，失败也能继续

### 6. **元数据读取容错** ✅
```python
# hungarian_assigner_kp.py
try:
    if isinstance(meta, dict) and 'img_shape' in meta:
        H, W = int(meta['img_shape'][0]), int(meta['img_shape'][1])
except Exception:
    pass  # 使用默认H=1, W=1
```
**原因**: meta可能格式不同，有合理默认值

---

## ⚠️ 可选优化（低优先级）

### 1. **`sar_rntr.py` - coeff_range计算** (第126-137行)
```python
# 当前
try:
    bx = self.bz_grid_conf['xbound']
    # ... 计算coeff_range
    if self.coeff_range <= 0:
        self.coeff_range = 200
except Exception:
    self.coeff_range = 200

# 可选优化：bz_grid_conf是必需配置，理论上不会出错
# 但保留也可接受，因为有合理默认值
```

### 2. **`_to_float()` 辅助函数** (多个文件)
```python
# 当前的嵌套try-except可以简化
@staticmethod
def _to_float(value):
    try:
        # 外层try
        if isinstance(value, (list, tuple)):
            for v in value:
                try:  # 内层try
                    vals.append(float(v))
                except Exception:
                    pass
    except Exception:
        return None
```
**建议**: 外层try可以移除，只保留内层对单个值转换的容错

---

## 📈 清理效果

### 修改前
- **问题**: 配置错误被静默吞没（如`use_bev_teacher_input=True`但数据缺失）
- **问题**: 调试困难，错误不明确
- **问题**: 配置fallback可能导致行为不一致

### 修改后
- ✅ **明确失败**: 配置错误立即抛出清晰的ValueError
- ✅ **易于调试**: 错误栈直接指向问题根源
- ✅ **行为一致**: 不再有静默降级导致的配置不生效

---

## 🎯 清理原则总结

### 应该移除try-except的情况：
1. ❌ 配置读取：已有`.get()`和默认值
2. ❌ 必需功能：如teacher BEV加载（配置启用时）
3. ❌ Loss/optimizer构建：应该明确失败
4. ❌ 基本数据操作：如tensor clamp（在训练阶段）

### 应该保留try-except的情况：
1. ✅ 可选依赖导入
2. ✅ 版本兼容性检查
3. ✅ 日志/可视化等辅助功能
4. ✅ 推理阶段的best-effort容错
5. ✅ 分布式训练相关检查
6. ✅ 有合理默认值的可选配置

---

## 💡 建议

1. **新代码规范**: 
   - 默认不使用`except Exception`
   - 只在明确需要容错的地方使用
   - 使用具体异常类型而非Exception
   
2. **日志改进**:
   ```python
   # 差
   except Exception:
       pass
   
   # 好
   except FileNotFoundError:
       logger.warning(f"BEV teacher file not found: {path}")
   ```

3. **配置验证**:
   - 在`__init__`中验证必需配置
   - 不要依赖try-except来处理配置缺失

---

## 📝 总结

本次清理移除了5处不必要的try-except，主要集中在：
- 配置启用但数据缺失时的静默失败 → 改为明确报错
- 冗余的双重默认值保护 → 简化为单层
- Loss构建的不当fallback → 移除以保证配置一致

保留了约40处合理的try-except，主要用于：
- 可选依赖和版本兼容
- 日志、可视化等辅助功能
- 推理阶段的容错处理

**整体效果**: 代码更健壮、错误更明确、调试更容易。
