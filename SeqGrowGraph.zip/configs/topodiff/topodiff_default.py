"""
Default configuration for TopoDiff
Minimal Viable Product (MVP) setup: K=8, T_trunc=20, T_infer=2
"""

_base_ = [
    '../_base_/datasets/nus-3d.py',
    '../_base_/default_runtime.py'
]

# Model
model = dict(
    type='TopoDiff',
    # Anchor library
    num_anchors=8,  # Start small for MVP
    max_nodes=20,
    n_control=3,  # Quadratic Bezier
    anchor_library_path='work_dirs/topodiff/anchor_library_k8.pkl',
    
    # BEV encoder (reuse from SeqGrowGraph)
    bev_encoder=dict(
        type='LiftSplatShootEgo',
        grid_conf=dict(
            xbound=[-48.0, 48.0, 0.5],
            ybound=[-32.0, 32.0, 0.5],
            zbound=[-10.0, 10.0, 20.0],
            dbound=[1.0, 60.0, 1.0],
        ),
        data_aug_conf=dict(
            resize_lim=(0.386, 0.55),
            final_dim=(256, 704),
            rot_lim=(-5.4, 5.4),
            H=900, W=1600,
            rand_flip=True,
            bot_pct_lim=(0.0, 0.0),
            cams=['CAM_FRONT_LEFT', 'CAM_FRONT', 'CAM_FRONT_RIGHT',
                  'CAM_BACK_LEFT', 'CAM_BACK', 'CAM_BACK_RIGHT'],
            Ncams=6,
        ),
        img_backbone=dict(
            type='ResNet',
            depth=50,
            num_stages=4,
            out_indices=(0, 1, 2, 3),
            frozen_stages=1,
            norm_cfg=dict(type='BN', requires_grad=False),
            norm_eval=True,
            style='pytorch',
            with_cp=True,
        ),
        img_neck=dict(
            type='CPFPN',
            in_channels=[256, 512, 1024, 2048],
            out_channels=256,
            num_outs=1
        ),
        downsample=8,
        camC=64,
        frustum_size=(16, 44, 88),
    ),
    bev_channels=256,
    bev_h=128,
    bev_w=192,
    
    # Truncated diffusion (optimized following DiffusionDrive)
    T_trunc=50,        # Truncated forward steps during training
    T_infer_init=8,    # Initial noise timestep for inference (much smaller!)
    T_infer_steps=2,   # Number of denoising steps
    
    # Decoder
    embed_dims=256,
    num_decoder_layers=4,  # Cascade layers
    num_heads=8,
    
    # Loss weights (following DiffusionDrive Eq. 100)
    lambda_cls=1.0,      # Classification loss
    lambda_geom=1.0,     # Geometry loss (V, M) - M权重在losses.py中降低
    lambda_topo=1.5,     # Topology loss (A) - higher weight for critical structure
    lambda_M_factor=0.1, # M控制点的损失因子（初期降低，优先训练V和A）
    
    # SwanLab logging (网页可视化)
    use_swanlab=True,  # 启用SwanLab (pip install swanlab)
    swanlab_project='TopoDiff',  # 项目名称
    swanlab_experiment='mvp_default',  # 实验名称（可自定义）
)

# Dataset
dataset_type = 'CenterlineNuScenesDataset'
data_root = 'data/nuscenes/'
file_client_args = dict(backend='disk')

# Data pipeline
train_pipeline = [
    dict(
        type='LoadNusOrderedBzCenterline',
        n_control=3,
        n_points_per_line=20,
        data_root=data_root,
        xbound=[-48.0, 48.0],
        ybound=[-32.0, 32.0],
    ),
    dict(type='LoadMultiViewImageFromFiles', to_float32=True),
    dict(type='CenterlineFlip', flip_ratio=0.5),
    dict(
        type='CenterlineRotateScale',
        rot_range=[-0.3925, 0.3925],
        scale_range=[0.95, 1.05],
    ),
    # Convert to graph format for TopoDiff
    dict(
        type='TransformGraph2Dict',  # New transform
        max_nodes=20,
        n_control=3,
    ),
    dict(type='DefaultFormatBundle3D', class_names=None),
    dict(
        type='Collect3D',
        keys=['img', 'gt_graphs'],
        meta_keys=['lidar2img', 'intrinsics', 'extrinsics']
    ),
]

test_pipeline = [
    dict(
        type='LoadNusOrderedBzCenterline',
        n_control=3,
        n_points_per_line=20,
        data_root=data_root,
        xbound=[-48.0, 48.0],
        ybound=[-32.0, 32.0],
    ),
    dict(type='LoadMultiViewImageFromFiles', to_float32=True),
    dict(
        type='TransformGraph2Dict',
        max_nodes=20,
        n_control=3,
    ),
    dict(type='DefaultFormatBundle3D', class_names=None),
    dict(
        type='Collect3D',
        keys=['img', 'gt_graphs'],
        meta_keys=['lidar2img', 'intrinsics', 'extrinsics', 'token']
    ),
]

data = dict(
    samples_per_gpu=4,  # Batch size (reduce if OOM)
    workers_per_gpu=4,
    train=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file=data_root + 'nuscenes_centerline_infos_train.pkl',
        pipeline=train_pipeline,
        test_mode=False,
    ),
    val=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file=data_root + 'nuscenes_centerline_infos_val.pkl',
        pipeline=test_pipeline,
        test_mode=True,
    ),
    test=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file=data_root + 'nuscenes_centerline_infos_val.pkl',
        pipeline=test_pipeline,
        test_mode=True,
    ),
)

# Optimizer
optimizer = dict(
    type='AdamW',
    lr=2e-4,
    weight_decay=0.01,
)

optimizer_config = dict(grad_clip=dict(max_norm=35, norm_type=2))

# Learning rate schedule
lr_config = dict(
    policy='CosineAnnealing',
    warmup='linear',
    warmup_iters=500,
    warmup_ratio=1.0 / 3,
    min_lr_ratio=1e-3,
)

# Runtime
total_epochs = 24
checkpoint_config = dict(interval=1)
log_config = dict(
    interval=50,
    hooks=[
        dict(type='TextLoggerHook'),
        dict(type='TensorboardLoggerHook')
    ]
)

# Evaluation
evaluation = dict(
    interval=1,
    pipeline=test_pipeline,
    metric='nus_reach',  # Use same metric as SeqGrowGraph
)

# Load pretrained BEV encoder (from road segmentation)
load_from = 'ckpts/lss_roadseg_48x32_b4x8_resnet_adam_24e_default.pth'
resume_from = None
workflow = [('train', 1)]

# FP16 training (optional, for speed)
fp16 = dict(loss_scale=512.)

# Work directory
work_dir = './work_dirs/topodiff_default'
