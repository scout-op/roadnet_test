# SwanLab 集成指南

SwanLab已集成到TopoDiff，支持在网页端实时查看训练指标、损失曲线和图像可视化。

---

## 安装

```bash
pip install swanlab
```

---

## 快速开始

### 1. 在模型初始化时启用SwanLab

```python
from seq_grow_graph.topodiff import TopoDiff

model = TopoDiff(
    num_anchors=8,
    max_nodes=20,
    # ... 其他参数
    
    # SwanLab配置
    use_swanlab=True,  # 启用SwanLab
    swanlab_project="TopoDiff",  # 项目名称
    swanlab_experiment="exp_001",  # 实验名称（可选）
)
```

### 2. 训练时自动记录指标

训练脚本中，SwanLab会自动记录：

```python
# 训练示例
for epoch in range(num_epochs):
    for batch in train_loader:
        outputs = model(batch)  # 自动记录loss等指标
        loss = outputs['losses']['loss']
        loss.backward()
        optimizer.step()
```

### 3. 查看网页端可视化

启动训练后，终端会显示：
```
✓ SwanLab initialized: TopoDiff/exp_001
SwanLab: View your experiment at https://swanlab.cn/@yourname/TopoDiff/runs/xxx
```

访问链接即可在网页端查看实时指标。

---

## 记录的指标

### 训练指标 (train/*)
- `train/loss` - 总损失
- `train/loss_cls` - 分类损失（锚点选择）
- `train/loss_geom` - 几何损失（节点坐标V + 控制点M）
- `train/loss_topo` - 拓扑损失（邻接矩阵A）
- `train/loss_reg` - 正则化损失（度约束+曲率）
- `train/lr` - 学习率
- `train/epoch` - 当前epoch

### 验证指标 (val/*)
- `val/loss`, `val/loss_cls`, `val/loss_geom`, `val/loss_topo`, `val/loss_reg`
- `val/Landmark_Precision`, `val/Landmark_Recall` （需实现评估）
- `val/Reach_Precision`, `val/Reach_Recall`

### 锚点统计 (anchor/*)
- `anchor/entropy` - 锚点选择的熵（衡量锚点使用分布）
- `anchor/max_score_mean` - 最高锚点得分的均值
- `anchor/score_gap_mean` - 最高得分与平均得分的差距

### 系统指标 (system/*)
- `system/gpu_memory_mb` - GPU显存使用（MB）
- `system/iteration_time_ms` - 每次迭代耗时（ms）

### 可视化 (visualization/*)
- `visualization/graph_comparison` - GT vs Pred 图对比
  - 左侧：Ground Truth
  - 右侧：Prediction
  - 红点：节点，蓝线：边

---

## 使用训练脚本

提供的训练脚本 `tools/train_topodiff_swanlab.py` 已集成SwanLab：

```bash
python tools/train_topodiff_swanlab.py \
    --config configs/topodiff/topodiff_default.py \
    --anchor-lib work_dirs/anchors_k8.pkl \
    --data-root /path/to/nuscenes \
    --swanlab-project TopoDiff \
    --swanlab-experiment mvp_test \
    --epochs 24 \
    --batch-size 4 \
    --lr 2e-4 \
    --log-freq 10 \
    --vis-freq 100
```

### 参数说明
- `--swanlab-project`: SwanLab项目名称
- `--swanlab-experiment`: 实验名称（留空自动生成）
- `--no-swanlab`: 禁用SwanLab（用于调试）
- `--log-freq`: 每N次迭代记录指标（默认10）
- `--vis-freq`: 每N次迭代可视化图（默认100）

---

## 高级用法

### 手动记录自定义指标

```python
from seq_grow_graph.topodiff.swanlab_logger import SwanLabLogger

# 创建logger
logger = SwanLabLogger(
    project_name="TopoDiff",
    experiment_name="custom_exp",
    config={'lr': 1e-4, 'batch_size': 4},
)

# 记录训练指标
logger.log_train_metrics(
    losses={'loss': loss_tensor, 'loss_cls': cls_loss, ...},
    lr=current_lr,
    epoch=epoch,
    iteration=iter,
)

# 记录锚点统计
logger.log_anchor_stats(
    positive_labels=pos_labels,  # [B, K]
    scores=scores,  # [B, K]
    iteration=iter,
)

# 记录图可视化
logger.log_graph_visualization(
    gt_graph={'V': V_gt, 'A': A_gt, 'num_nodes': num_nodes},
    pred_graph={'V': V_pred, 'A': A_pred},
    iteration=iter,
)

# 记录系统指标
logger.log_system_metrics(
    gpu_memory_mb=torch.cuda.max_memory_allocated() / 1024**2,
    iteration_time_ms=iter_time_ms,
    iteration=iter,
)

# 完成后关闭
logger.finish()
```

---

## 与现有训练流程集成

### 方式1：在模型内启用（推荐）

```python
model = TopoDiff(
    ...,
    use_swanlab=True,
    swanlab_project="TopoDiff",
)

# 训练循环中自动记录
outputs = model(batch_dict)  # SwanLab自动记录
```

### 方式2：独立使用logger

```python
from seq_grow_graph.topodiff.swanlab_logger import SwanLabLogger

logger = SwanLabLogger(project_name="TopoDiff")

# 训练循环
for batch in dataloader:
    outputs = model(batch)
    
    # 手动记录
    logger.log_train_metrics(
        losses=outputs['losses'],
        lr=optimizer.param_groups[0]['lr'],
        epoch=epoch,
        iteration=iter,
    )
```

---

## 网页端功能

### 1. 实时指标监控
- Loss曲线（总损失+各分项）
- 学习率曲线
- 锚点统计分布

### 2. 图像可视化
- GT vs Pred 对比图
- 支持缩放、下载

### 3. 超参数记录
- 自动记录所有超参数
- 方便对比不同实验

### 4. 实验对比
- 多实验并行对比
- 曲线叠加显示

### 5. 系统监控
- GPU显存使用
- 迭代速度

---

## 配置选项

### SwanLabLogger参数

```python
SwanLabLogger(
    project_name="TopoDiff",      # 项目名
    experiment_name="exp_001",    # 实验名（可选）
    config={'lr': 1e-4, ...},     # 超参数
    enabled=True,                 # 启用开关
    log_freq=10,                  # 记录频率
    vis_freq=100,                 # 可视化频率
)
```

---

## 示例输出

训练时终端输出：
```
✓ SwanLab initialized: TopoDiff/mvp_test
Epoch [0] Iter [0/1000] Loss: 2.3456 LR: 0.000200 Time: 125.3ms
Epoch [0] Iter [10/1000] Loss: 2.1234 LR: 0.000200 Time: 123.1ms
...
```

网页端显示：
- 📈 Loss曲线实时更新
- 🖼️ 每100 iter可视化一次图
- 📊 锚点选择熵、得分等统计
- ⚙️ GPU显存、速度监控

---

## 最佳实践

### 1. 命名规范
- 项目名：`TopoDiff`
- 实验名：`mvp_v1`, `ablation_k8`, `full_train`

### 2. 记录频率
- 训练指标：每10 iter（快速反馈）
- 可视化：每100 iter（避免过多图像）
- 验证：每1 epoch

### 3. 多实验对比
```bash
# 实验1: K=8
python train_topodiff_swanlab.py --swanlab-experiment k8_baseline

# 实验2: K=16
python train_topodiff_swanlab.py --swanlab-experiment k16_test

# 网页端选择多个实验对比
```

### 4. 调试模式
```bash
# 禁用SwanLab以加速调试
python train_topodiff_swanlab.py --no-swanlab
```

---

## 故障排查

### Q: ImportError: No module named 'swanlab'
```bash
pip install swanlab
```

### Q: 无法访问网页
- 检查网络连接
- 确认SwanLab账号登录状态
- 查看终端输出的URL

### Q: 指标未显示
- 确认 `use_swanlab=True`
- 检查 `log_freq` 是否过大
- 查看终端是否有报错

### Q: 可视化不更新
- 确认 `vis_freq` 设置合理
- 检查 `gt_graphs` 是否正确传入
- 验证图数据形状是否匹配

---

## 完整示例

```python
import torch
from seq_grow_graph.topodiff import TopoDiff

# 1. 创建模型（启用SwanLab）
model = TopoDiff(
    num_anchors=8,
    use_swanlab=True,
    swanlab_project="TopoDiff",
    swanlab_experiment="mvp_experiment",
)

# 2. 训练循环
optimizer = torch.optim.AdamW(model.parameters(), lr=2e-4)

for epoch in range(24):
    for iteration, batch_dict in enumerate(train_loader):
        # Forward
        outputs = model(batch_dict)
        loss = outputs['losses']['loss']
        
        # Backward
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        # SwanLab自动记录（无需手动调用）
        # 内部会记录loss、lr、anchor stats等
    
    # 验证（可选手动记录）
    if epoch % 5 == 0:
        val_outputs = validate(model, val_loader)
        if model.swanlab_logger:
            model.swanlab_logger.log_val_metrics(
                losses=val_outputs['losses'],
                metrics={'Precision': 0.75, 'Recall': 0.68},
                epoch=epoch,
            )

# 3. 完成
if model.swanlab_logger:
    model.swanlab_logger.finish()
```

---

## 注意事项

1. **首次使用需登录SwanLab账号**（终端会提示）
2. **可视化占用带宽**，建议 `vis_freq` 不低于100
3. **多GPU训练时**，只在主进程记录（避免重复）
4. **长时间训练**，定期检查网页端是否正常显示

---

## 下一步

- 查看 `tools/train_topodiff_swanlab.py` 了解完整训练流程
- 访问 [SwanLab文档](https://docs.swanlab.cn/) 了解更多功能
- 在网页端创建自定义图表和对比

✅ SwanLab集成完成，祝训练顺利！
