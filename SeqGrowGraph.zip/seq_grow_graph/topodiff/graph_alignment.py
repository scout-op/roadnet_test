"""
Graph Alignment: Hungarian matching + Procrustes alignment
For finding closest anchor and computing alignment between graphs
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, Tuple, Optional
from scipy.optimize import linear_sum_assignment


class GraphAlignment:
    """
    Align graphs using:
    1. Procrustes for global similarity transform (translation, rotation, scale)
    2. Hungarian algorithm for node correspondence
    3. Graph edit distance for topology matching
    """
    
    def __init__(
        self,
        max_nodes: int = 20,
        geometric_weight: float = 1.0,
        topology_weight: float = 0.5,
    ):
        """
        Args:
            max_nodes: Maximum nodes in graph
            geometric_weight: Weight for geometric distance in matching
            topology_weight: Weight for topology (degree, connectivity) distance
        """
        self.max_nodes = max_nodes
        self.geometric_weight = geometric_weight
        self.topology_weight = topology_weight
    
    def find_closest_anchor(
        self,
        gt_graph: Dict[str, torch.Tensor],
        anchor_graphs: Dict[str, torch.Tensor],
    ) -> Tuple[int, torch.Tensor]:
        """
        Find the closest anchor to ground truth graph.
        
        Args:
            gt_graph: Dict with 'A', 'V', 'M', 'num_nodes'
            anchor_graphs: Dict with batched anchors [K, ...]
            
        Returns:
            best_k: Index of closest anchor
            assignment: Node assignment matrix [N, N] (permutation)
        """
        K = anchor_graphs['A'].shape[0]
        device = gt_graph['A'].device
        
        # Compute distance to each anchor
        distances = []
        assignments = []
        
        for k in range(K):
            anchor_k = {
                'A': anchor_graphs['A'][k],
                'V': anchor_graphs['V'][k],
                'num_nodes': anchor_graphs['num_nodes'][k]
            }
            
            dist, assignment = self.compute_graph_distance(gt_graph, anchor_k)
            distances.append(dist.item())
            assignments.append(assignment)
        
        best_k = np.argmin(distances)
        return best_k, assignments[best_k]
    
    def compute_graph_distance(
        self,
        graph1: Dict[str, torch.Tensor],
        graph2: Dict[str, torch.Tensor],
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Compute distance between two graphs.
        
        Returns:
            distance: Scalar distance
            assignment: [N, N] permutation matrix for node correspondence
        """
        A1 = graph1['A']  # [N, N]
        V1 = graph1['V']  # [N, 2]
        n1 = graph1['num_nodes'].item() if isinstance(graph1['num_nodes'], torch.Tensor) else graph1['num_nodes']
        
        A2 = graph2['A']  # [N, N]
        V2 = graph2['V']  # [N, 2]
        n2 = graph2['num_nodes'].item() if isinstance(graph2['num_nodes'], torch.Tensor) else graph2['num_nodes']
        
        device = A1.device
        N = A1.shape[0]
        
        # Handle empty graphs
        if n1 == 0 or n2 == 0:
            return torch.tensor(float('inf'), device=device), torch.eye(N, device=device)
        
        # Build cost matrix for Hungarian algorithm
        # Cost combines geometric + topological distances
        cost_matrix = torch.zeros(N, N, device=device)
        
        # 1. Geometric cost: pairwise distance between nodes
        V1_valid = V1[:n1]  # [n1, 2]
        V2_valid = V2[:n2]  # [n2, 2]
        
        # Pairwise L2 distance
        geom_cost = torch.cdist(V1_valid, V2_valid, p=2)  # [n1, n2]
        cost_matrix[:n1, :n2] = geom_cost * self.geometric_weight
        
        # 2. Topological cost: degree difference
        degree1_in = A1.sum(dim=0)[:n1]  # [n1]
        degree1_out = A1.sum(dim=1)[:n1]  # [n1]
        degree2_in = A2.sum(dim=0)[:n2]  # [n2]
        degree2_out = A2.sum(dim=1)[:n2]  # [n2]
        
        degree_diff = torch.abs(degree1_in.unsqueeze(1) - degree2_in.unsqueeze(0)) + \
                      torch.abs(degree1_out.unsqueeze(1) - degree2_out.unsqueeze(0))  # [n1, n2]
        cost_matrix[:n1, :n2] += degree_diff * self.topology_weight
        
        # Penalize unmatched nodes
        cost_matrix[:n1, n2:] = 1000.0
        cost_matrix[n1:, :n2] = 1000.0
        cost_matrix[n1:, n2:] = 0.0
        
        # Run Hungarian algorithm
        cost_np = cost_matrix.detach().cpu().numpy()
        row_ind, col_ind = linear_sum_assignment(cost_np)
        
        # Build assignment matrix
        assignment = torch.zeros(N, N, device=device)
        assignment[row_ind, col_ind] = 1.0
        
        # Compute total distance
        total_cost = cost_matrix[row_ind, col_ind].sum()
        
        # Add topology mismatch cost (edges not matching after alignment)
        A1_aligned = self._permute_adjacency(A1, assignment)
        topology_diff = torch.abs(A1_aligned - A2).sum()
        total_distance = total_cost + topology_diff * 0.1
        
        return total_distance, assignment
    
    def _permute_adjacency(
        self, 
        A: torch.Tensor, 
        perm: torch.Tensor
    ) -> torch.Tensor:
        """
        Permute adjacency matrix according to assignment.
        A_aligned[i,j] = A[perm[i], perm[j]]
        """
        # perm is [N, N] binary matrix
        # A_aligned = P @ A @ P^T
        A_aligned = perm @ A @ perm.T
        return A_aligned
    
    def align_graph_to_anchor(
        self,
        graph: Dict[str, torch.Tensor],
        anchor: Dict[str, torch.Tensor],
        assignment: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Apply alignment transform to align graph to anchor.
        
        Args:
            graph: Graph to align
            anchor: Reference anchor
            assignment: [N, N] permutation matrix
            
        Returns:
            Aligned graph with permuted nodes
        """
        # Permute node coordinates
        V_aligned = assignment @ graph['V']
        
        # Permute adjacency matrix
        A_aligned = self._permute_adjacency(graph['A'], assignment)
        
        # For edge features M, we need to reindex edges
        # This is complex - for MVP, we skip M alignment
        M_aligned = graph['M']  # TODO: implement edge reindexing
        
        return {
            'A': A_aligned,
            'V': V_aligned,
            'M': M_aligned,
            'num_nodes': graph['num_nodes'],
            'num_edges': graph['num_edges'],
        }
    
    def batch_find_positive_anchors(
        self,
        gt_graphs: Dict[str, torch.Tensor],
        anchor_graphs: Dict[str, torch.Tensor],
    ) -> Tuple[torch.Tensor, list]:
        """
        Batch version: find closest anchor for each GT graph.
        
        Args:
            gt_graphs: Batch of GT graphs [B, ...]
            anchor_graphs: Anchor library [K, ...]
            
        Returns:
            positive_labels: [B, K] one-hot labels
            assignments: List of [N, N] assignment matrices
        """
        B = gt_graphs['A'].shape[0]
        K = anchor_graphs['A'].shape[0]
        device = gt_graphs['A'].device
        
        positive_labels = torch.zeros(B, K, device=device)
        assignments = []
        
        for b in range(B):
            gt_graph_b = {
                'A': gt_graphs['A'][b],
                'V': gt_graphs['V'][b],
                'M': gt_graphs['M'][b],
                'num_nodes': gt_graphs['num_nodes'][b],
            }
            
            best_k, assignment = self.find_closest_anchor(gt_graph_b, anchor_graphs)
            positive_labels[b, best_k] = 1.0
            assignments.append(assignment)
        
        return positive_labels, assignments
