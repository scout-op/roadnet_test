"""
Truncated Noise Scheduler for Diffusion
Implements truncated diffusion schedule following DiffusionDrive
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, Tuple


class TruncatedNoiseScheduler:
    """
    Truncated diffusion noise scheduler.
    Unlike vanilla DDIM (T=1000 steps), we only use T_trunc (e.g., 20) steps
    to add noise around anchors, creating "anchored Gaussian distribution".
    """
    
    def __init__(
        self,
        T_trunc: int = 20,
        T_infer: int = 2,
        beta_schedule: str = 'linear',
        beta_start: float = 0.0001,
        beta_end: float = 0.02,
        # For discrete adjacency matrix A
        adjacency_mask_prob: float = 0.15,  # Masking probability at T_trunc
        adjacency_flip_prob: float = 0.05,  # Structured flip probability
    ):
        """
        Args:
            T_trunc: Truncated forward steps (training)
            T_infer: Denoising steps (inference)
            beta_schedule: Noise schedule type
            beta_start, beta_end: Noise schedule range
            adjacency_mask_prob: Probability to mask edges in A (MaskGIT style)
            adjacency_flip_prob: Probability to flip edges (structured)
        """
        self.T_trunc = T_trunc
        self.T_infer = T_infer
        self.adjacency_mask_prob = adjacency_mask_prob
        self.adjacency_flip_prob = adjacency_flip_prob
        
        # Build noise schedule
        if beta_schedule == 'linear':
            betas = np.linspace(beta_start, beta_end, T_trunc)
        elif beta_schedule == 'cosine':
            timesteps = np.arange(T_trunc + 1) / T_trunc
            alphas = np.cos((timesteps + 0.008) / 1.008 * np.pi / 2) ** 2
            alphas = alphas / alphas[0]
            betas = 1 - alphas[1:] / alphas[:-1]
            betas = np.clip(betas, beta_start, beta_end)
        else:
            raise ValueError(f"Unknown schedule: {beta_schedule}")
        
        # Precompute constants
        alphas = 1.0 - betas
        alphas_cumprod = np.cumprod(alphas)
        
        self.register_buffers(betas, alphas, alphas_cumprod)
    
    def register_buffers(self, betas, alphas, alphas_cumprod):
        """Register as numpy arrays (will convert to torch when needed)."""
        self.betas = betas
        self.alphas = alphas
        self.alphas_cumprod = alphas_cumprod
    
    def add_noise_to_anchors(
        self,
        anchors: Dict[str, torch.Tensor],
        timestep: int,
        device: str = 'cuda'
    ) -> Dict[str, torch.Tensor]:
        """
        Add truncated noise to anchor graphs (forward process).
        
        Args:
            anchors: Dict with 'A' [K,N,N], 'V' [K,N,2], 'M' [K,E,nc-2,2]
            timestep: Diffusion timestep t in [1, T_trunc]
            
        Returns:
            Noisy graphs with same structure
        """
        if timestep > self.T_trunc or timestep < 1:
            raise ValueError(f"Timestep {timestep} out of range [1, {self.T_trunc}]")
        
        alpha_bar = torch.tensor(
            self.alphas_cumprod[timestep - 1], 
            dtype=torch.float32, 
            device=device
        )
        
        # 1. Continuous data: V, M (Gaussian noise)
        V_clean = anchors['V']  # [K, N, 2]
        M_clean = anchors['M']  # [K, E, nc-2, 2]
        
        epsilon_V = torch.randn_like(V_clean)
        epsilon_M = torch.randn_like(M_clean)
        
        # q(V^t | V^0) = sqrt(alpha_bar) * V^0 + sqrt(1 - alpha_bar) * epsilon
        V_noisy = torch.sqrt(alpha_bar) * V_clean + torch.sqrt(1 - alpha_bar) * epsilon_V
        M_noisy = torch.sqrt(alpha_bar) * M_clean + torch.sqrt(1 - alpha_bar) * epsilon_M
        
        # 2. Discrete data: A (structured masking + flipping)
        A_clean = anchors['A']  # [K, N, N]
        A_noisy = self._add_structured_noise_to_adjacency(
            A_clean, 
            timestep, 
            anchors['num_nodes']
        )
        
        return {
            'A': A_noisy,
            'V': V_noisy,
            'M': M_noisy,
            'num_nodes': anchors['num_nodes'],
            'num_edges': anchors['num_edges'],
            'timestep': torch.full((len(A_clean),), timestep, device=device, dtype=torch.long)
        }
    
    def _add_structured_noise_to_adjacency(
        self,
        A: torch.Tensor,
        timestep: int,
        num_nodes: torch.Tensor
    ) -> torch.Tensor:
        """
        Add structured noise to adjacency matrix.
        
        Strategy:
        1. Mask random edges (MaskGIT style)
        2. Structured flip: only flip edges between geometrically close nodes
        
        Args:
            A: [K, N, N] adjacency matrix
            timestep: Current timestep
            num_nodes: [K] actual number of nodes per graph
        """
        K, N, _ = A.shape
        device = A.device
        
        # Scale noise by timestep (more noise at larger t)
        mask_prob = self.adjacency_mask_prob * (timestep / self.T_trunc)
        flip_prob = self.adjacency_flip_prob * (timestep / self.T_trunc)
        
        A_noisy = A.clone()
        
        for k in range(K):
            n = num_nodes[k].item()
            if n == 0:
                continue
            
            # Create valid region mask (only within actual nodes)
            valid_mask = torch.zeros(N, N, device=device, dtype=torch.bool)
            valid_mask[:n, :n] = True
            
            # 1. Random masking (set to 0.5, indicating uncertainty)
            mask = (torch.rand(N, N, device=device) < mask_prob) & valid_mask
            A_noisy[k][mask] = 0.5
            
            # 2. Structured flip (only flip existing/non-existing edges)
            flip_mask = (torch.rand(N, N, device=device) < flip_prob) & valid_mask
            A_noisy[k][flip_mask] = 1.0 - A_noisy[k][flip_mask]
        
        return A_noisy
    
    def ddim_step(
        self,
        x_t: torch.Tensor,
        x_0_pred: torch.Tensor,
        t: int,
        t_prev: int
    ) -> torch.Tensor:
        """
        DDIM sampling step for continuous data (V, M).
        
        x_{t-1} = sqrt(alpha_{t-1}) * x_0_pred + sqrt(1 - alpha_{t-1}) * epsilon_pred
        
        Args:
            x_t: Current noisy data [*, D]
            x_0_pred: Predicted clean data [*, D]
            t: Current timestep
            t_prev: Previous timestep
        """
        device = x_t.device
        
        if t_prev < 0:
            return x_0_pred
        
        alpha_bar_t = torch.tensor(
            self.alphas_cumprod[t - 1], 
            dtype=torch.float32, 
            device=device
        )
        
        if t_prev == 0:
            alpha_bar_t_prev = torch.tensor(1.0, device=device)
        else:
            alpha_bar_t_prev = torch.tensor(
                self.alphas_cumprod[t_prev - 1],
                dtype=torch.float32,
                device=device
            )
        
        # Predict noise from x_t and x_0_pred
        epsilon_pred = (x_t - torch.sqrt(alpha_bar_t) * x_0_pred) / torch.sqrt(1 - alpha_bar_t + 1e-8)
        
        # Sample x_{t-1}
        x_t_prev = torch.sqrt(alpha_bar_t_prev) * x_0_pred + \
                   torch.sqrt(1 - alpha_bar_t_prev) * epsilon_pred
        
        return x_t_prev
    
    def get_inference_timesteps(self) -> list:
        """
        Get timestep schedule for inference.
        For T_infer=2, typically use [T_trunc, T_trunc//2, 0]
        """
        if self.T_infer == 1:
            return [self.T_trunc, 0]
        elif self.T_infer == 2:
            return [self.T_trunc, self.T_trunc // 2, 0]
        elif self.T_infer == 3:
            return [self.T_trunc, 2 * self.T_trunc // 3, self.T_trunc // 3, 0]
        else:
            # Uniform spacing
            step = self.T_trunc // self.T_infer
            return list(range(self.T_trunc, 0, -step)) + [0]
