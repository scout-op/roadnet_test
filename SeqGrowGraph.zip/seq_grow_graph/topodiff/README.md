# TopoDiff: Topology-Anchored Truncated Diffusion

基于 DiffusionDrive 思想的车道拓扑生成扩散模型。

## 核心创新

1. **锚点库 (Anchor Library)**: 从训练集聚类得到 K 个拓扑原型，作为先验知识
2. **截断扩散 (Truncated Diffusion)**: 只使用 T_trunc=20 步加噪，从"锚定高斯分布"而非纯噪声开始
3. **少步去噪 (Few-Step Denoising)**: 推理时仅需 2-3 步即可收敛，相比自回归大幅提速
4. **级联图解码器 (Cascade Graph Decoder)**: 图Transformer + 可变形跨注意力到BEV特征

## 代码结构

```
seq_grow_graph/topodiff/
├── __init__.py                    # 模块入口
├── anchor_library.py              # 锚点库构建与管理
├── truncated_noise.py             # 截断噪声调度器
├── graph_alignment.py             # 图对齐（Hungarian匹配）
├── cascade_graph_decoder.py       # 级联图Transformer解码器
├── losses.py                      # 损失函数
├── topodiff_model.py             # 主模型
└── README.md                      # 本文件

configs/topodiff/
└── topodiff_default.py            # 默认配置（MVP: K=8, T_trunc=20, T_infer=2）

tools/
└── build_anchor_library.py        # 锚点库构建脚本
```

## 快速开始

### 1. 构建锚点库

训练前必须先从训练集构建锚点库：

```bash
python tools/build_anchor_library.py \
    --config configs/topodiff/topodiff_default.py \
    --num-anchors 8 \
    --max-nodes 20 \
    --output work_dirs/topodiff/anchor_library_k8.pkl
```

**参数说明**:
- `num-anchors`: 锚点数量 K（MVP用8，完整版可用50-100）
- `max-nodes`: 图的最大节点数
- `output`: 锚点库保存路径

### 2. 训练

复用 SeqGrowGraph 的 BEV 编码器预训练权重：

```bash
# 确保已下载 BEV 预训练权重
# ckpts/lss_roadseg_48x32_b4x8_resnet_adam_24e_default.pth

# 训练（单卡）
python tools/train.py configs/topodiff/topodiff_default.py

# 训练（多卡）
bash tools/dist_train.sh configs/topodiff/topodiff_default.py 4
```

### 3. 测试

```bash
# 测试
python tools/test.py \
    configs/topodiff/topodiff_default.py \
    work_dirs/topodiff_default/epoch_24.pth \
    --eval nus_reach
```

### 4. 推理与可视化

```python
import torch
from seq_grow_graph.topodiff import TopoDiff

# 加载模型
model = TopoDiff(...)
model.load_state_dict(torch.load('path/to/checkpoint.pth'))
model.eval()

# 推理
with torch.no_grad():
    predictions = model.inference(batch_dict)

# 结果
A_pred = predictions['A']  # [B, N, N] 邻接矩阵
V_pred = predictions['V']  # [B, N, 2] 节点坐标
M_pred = predictions['M']  # [B, E, nc-2, 2] Bezier控制点
scores = predictions['scores']  # [B, K] 各锚点置信度
```

## 配置说明

关键配置项（`configs/topodiff/topodiff_default.py`）:

```python
model = dict(
    type='TopoDiff',
    num_anchors=8,        # 锚点数量 K
    max_nodes=20,         # 最大节点数
    T_trunc=20,           # 截断扩散步数（训练）
    T_infer=2,            # 推理去噪步数（2步足够）
    embed_dims=256,       # 特征维度
    num_decoder_layers=4, # 级联层数
    
    # 损失权重（参考 DiffusionDrive）
    lambda_cls=1.0,       # 分类损失（选择正确锚点）
    lambda_geom=1.0,      # 几何损失（V, M）
    lambda_topo=1.5,      # 拓扑损失（A，更高权重）
)
```

## 与 SeqGrowGraph 对比

| 指标 | SeqGrowGraph | TopoDiff (预期) |
|------|-------------|----------------|
| 推理方式 | 自回归串行 | 并行精炼 |
| 推理延迟 | 基线 | **-40%** |
| Reach-F | 基线 | 90-100% |
| 多样性 | 单一输出 | K个候选 |
| 模式崩溃 | N/A | ✓ 避免 |

## 实现细节

### 锚点构建
- **特征提取**: 结构特征（度分布、连通性）+ 几何特征（尺度、分布）
- **聚类算法**: K-Means，选择每簇的 medoid（最具代表性样本）
- **归一化**: Procrustes 对齐（平移/旋转/尺度）

### 噪声设计
- **连续数据 (V, M)**: 高斯噪声，DDIM 调度
- **离散数据 (A)**: 结构化掩码/翻转（仅在几何邻近、角度合理的候选边上操作）

### 对齐与匹配
- **Hungarian 算法**: 基于几何距离 + 拓扑相似度（度差异）的代价矩阵
- **正锚点选择**: 训练时硬分配（仅最近锚点为正样本），参考 DiffusionDrive

### 损失函数
```python
# 分类损失：所有锚点
L_cls = BCE(scores, positive_labels)

# 重建损失：仅正锚点
L_geom = L1(V_pred, V_gt) + L1(M_pred, M_gt)
L_topo = FocalLoss(A_pred, A_gt)  # 处理极端不平衡

# 正则化
L_reg = degree_constraint + curvature_smoothness

# 总损失
L = λ_cls * L_cls + λ_geom * L_geom + λ_topo * L_topo + λ_reg * L_reg
```

## 消融实验建议

- **锚点数量**: K ∈ {4, 8, 16, 32, 50}
- **截断步数**: T_trunc ∈ {10, 20, 30, 50}
- **推理步数**: T_infer ∈ {1, 2, 3, 5}
- **噪声类型**: 随机翻转 vs 结构化掩码
- **对齐开关**: Hungarian 对齐 vs 无对齐

## 常见问题

### Q1: 锚点库覆盖度不足怎么办？
A: 增大 K（如 50-100），或采用分层锚点（宏拓扑+微几何）

### Q2: 推理时遇到 OOD 拓扑怎么办？
A: 监控置信度阈值，低于阈值时回退到 SeqGrowGraph 自回归

### Q3: A 的损失不收敛？
A: 使用 Focal Loss + 候选边掩码（只在几何合理的位置预测边）

### Q4: 内存不足？
A: 减小 batch_size、K、或用门控机制先筛选 Top-M（M=3-5）

## 参考文献

- DiffusionDrive (CVPR 2024): Truncated diffusion policy for trajectory planning
- SeqGrowGraph (ICCV 2025): Autoregressive lane graph generation
- DiGress (ICLR 2023): Discrete denoising diffusion for graphs
- MaskGIT (CVPR 2022): Masked generative image transformer

## TODO

- [x] 基础架构实现
- [x] 锚点库构建
- [x] 截断噪声调度器
- [x] 级联图解码器
- [x] 损失函数
- [ ] 变长图处理（节点生/死操作）
- [ ] 门控/检索机制（Top-M筛选）
- [ ] 与现有代码完全集成
- [ ] nuScenes 数据集端到端测试
- [ ] 消融实验
- [ ] 论文与可视化
