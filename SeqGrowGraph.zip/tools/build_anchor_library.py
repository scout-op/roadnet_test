"""
Script to build anchor library from training dataset.
Run this before training TopoDiff.

Usage:
    python tools/build_anchor_library.py \
        --config configs/topodiff/topodiff_default.py \
        --num-anchors 8 \
        --output work_dirs/topodiff/anchor_library_k8.pkl
"""

import argparse
import pickle
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import torch
import numpy as np
from mmcv import Config
from mmdet3d.datasets import build_dataset

from seq_grow_graph.topodiff.anchor_library import AnchorLibrary


def parse_args():
    parser = argparse.ArgumentParser(description='Build TopoDiff anchor library')
    parser.add_argument('--config', required=True, help='Config file')
    parser.add_argument('--num-anchors', type=int, default=8, 
                       help='Number of anchor prototypes')
    parser.add_argument('--max-nodes', type=int, default=20,
                       help='Maximum nodes per graph')
    parser.add_argument('--output', required=True,
                       help='Output path for anchor library')
    parser.add_argument('--max-samples', type=int, default=10000,
                       help='Maximum training samples to use for clustering')
    args = parser.parse_args()
    return args


def extract_graphs_from_dataset(dataset, max_samples=10000):
    """
    Extract graph data (A, V, M) from dataset samples.
    """
    print(f"Extracting graphs from dataset (max {max_samples} samples)...")
    
    graphs = []
    num_samples = min(len(dataset), max_samples)
    
    for i in range(num_samples):
        if i % 1000 == 0:
            print(f"Processing {i}/{num_samples}...")
        
        try:
            data = dataset[i]
            
            # Extract centerline data
            if 'center_lines' in data:
                center_lines = data['center_lines']
                
                # Convert to graph format (A, V, M)
                # This depends on your data format from CenterlineNuScenesDataset
                graph = convert_centerlines_to_graph(center_lines)
                
                if graph is not None and graph['A'].shape[0] > 0:
                    graphs.append(graph)
                    
        except Exception as e:
            print(f"Warning: Failed to process sample {i}: {e}")
            continue
    
    print(f"Extracted {len(graphs)} valid graphs")
    return graphs


def convert_centerlines_to_graph(center_lines):
    """
    Convert centerline format to graph (A, V, M).
    
    This is a simplified version. You need to adapt based on your actual
    centerline format from the dataset.
    """
    if not center_lines or len(center_lines) == 0:
        return None
    
    # Extract nodes (vertices) - start/end points of centerlines
    nodes = []
    node_to_idx = {}
    edges = []
    edge_controls = []
    
    def add_node(coord):
        """Add node if not exists, return index."""
        coord_tuple = tuple(coord.round(decimals=2))
        if coord_tuple not in node_to_idx:
            node_to_idx[coord_tuple] = len(nodes)
            nodes.append(coord)
        return node_to_idx[coord_tuple]
    
    for line in center_lines:
        if 'points' not in line:
            continue
        
        points = line['points']  # [N, 2] or [N, 3]
        if len(points) < 2:
            continue
        
        # Start and end nodes
        start_coord = points[0, :2]
        end_coord = points[-1, :2]
        
        start_idx = add_node(start_coord)
        end_idx = add_node(end_coord)
        
        # Add edge
        if start_idx != end_idx:
            edges.append((start_idx, end_idx))
            
            # Control point: middle point for quadratic Bezier
            if len(points) > 2:
                mid_idx = len(points) // 2
                control = points[mid_idx, :2] - (start_coord + end_coord) / 2
            else:
                control = np.zeros(2)
            
            edge_controls.append(control)
    
    if len(nodes) == 0:
        return None
    
    # Build adjacency matrix
    num_nodes = len(nodes)
    A = np.zeros((num_nodes, num_nodes), dtype=np.float32)
    for i, j in edges:
        A[i, j] = 1.0
    
    # Node coordinates
    V = np.array(nodes, dtype=np.float32)
    
    # Edge control points
    M = np.array(edge_controls, dtype=np.float32).reshape(-1, 1, 2)  # [E, 1, 2]
    
    return {
        'A': A,
        'V': V,
        'M': M,
    }


def main():
    args = parse_args()
    
    # Load config
    cfg = Config.fromfile(args.config)
    
    # Build training dataset
    print("Building training dataset...")
    dataset = build_dataset(cfg.data.train)
    
    # Extract graphs
    graphs = extract_graphs_from_dataset(dataset, args.max_samples)
    
    if len(graphs) == 0:
        print("Error: No valid graphs extracted!")
        return
    
    # Build anchor library
    print(f"\nBuilding anchor library with K={args.num_anchors}...")
    anchor_lib = AnchorLibrary(
        num_anchors=args.num_anchors,
        max_nodes=args.max_nodes,
        n_control=3,
    )
    
    anchor_lib.build_from_dataset(graphs, save_path=args.output)
    
    print(f"\n✓ Anchor library saved to {args.output}")
    print(f"  - Number of anchors: {args.num_anchors}")
    print(f"  - Max nodes: {args.max_nodes}")
    print(f"  - Built from {len(graphs)} training graphs")
    
    # Verify by loading
    print("\nVerifying saved library...")
    anchor_lib_test = AnchorLibrary(num_anchors=args.num_anchors, max_nodes=args.max_nodes)
    anchor_lib_test.load(args.output)
    print("✓ Verification successful!")


if __name__ == '__main__':
    main()
