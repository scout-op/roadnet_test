"""
Simple test script to verify TopoDiff implementation
Tests all components with dummy data before running on real dataset
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import torch
import numpy as np

# Check diffusers installation
try:
    import diffusers
    print(f"✓ diffusers {diffusers.__version__} installed")
except ImportError:
    print("✗ diffusers not installed. Please run: pip install diffusers")
    sys.exit(1)

from seq_grow_graph.topodiff import (
    TopoDiff,
    AnchorLibrary,
    TopoDiffScheduler,
    GraphAlignment,
    CascadeGraphDecoder,
    TopoDiffLoss,
)


def test_anchor_library():
    """Test anchor library construction."""
    print("\n=== Testing Anchor Library ===")
    
    # Create dummy graphs
    dummy_graphs = []
    for i in range(50):
        num_nodes = np.random.randint(5, 15)
        A = np.random.rand(num_nodes, num_nodes) > 0.7
        A = A.astype(np.float32)
        V = np.random.randn(num_nodes, 2).astype(np.float32)
        M = np.random.randn(int(A.sum()), 1, 2).astype(np.float32)
        
        dummy_graphs.append({'A': A, 'V': V, 'M': M})
    
    # Build anchor library
    anchor_lib = AnchorLibrary(num_anchors=8, max_nodes=20)
    anchor_lib.build_from_dataset(dummy_graphs)
    
    # Get as tensors
    anchors = anchor_lib.get_anchors_as_tensors(device='cpu')
    print(f"✓ Anchor library created: {len(anchor_lib.anchors)} anchors")
    print(f"  Shapes: A={anchors['A'].shape}, V={anchors['V'].shape}")
    
    return anchor_lib


def test_noise_scheduler():
    """Test truncated noise scheduler."""
    print("\n=== Testing Noise Scheduler ===")
    
    scheduler = TopoDiffScheduler(T_trunc=50, T_infer_init=8, T_infer_steps=2)
    
    # Dummy anchor
    K, N = 8, 10
    anchors = {
        'A': torch.rand(K, N, N),
        'V': torch.randn(K, N, 2),
        'M': torch.randn(K, N*N, 1, 2),
        'num_nodes': torch.randint(5, N, (K,)),
        'num_edges': torch.randint(5, 20, (K,)),
    }
    
    # Add noise to graphs
    noisy = scheduler.add_noise_to_graphs(anchors, timesteps=torch.tensor([10]*K), device='cpu')
    print(f"✓ Noise added at t=10")
    print(f"  Noisy V range: [{noisy['V'].min():.2f}, {noisy['V'].max():.2f}]")
    
    # Test coordinate normalization
    V_test = torch.randn(5, 10, 2) * 30  # Random coordinates
    V_norm = scheduler.normalize_coords(V_test)
    V_denorm = scheduler.denormalize_coords(V_norm)
    print(f"✓ Coordinate normalization test passed")
    print(f"  Max denorm error: {(V_test - V_denorm).abs().max():.6f}")
    
    return scheduler


def test_graph_alignment():
    """Test graph alignment."""
    print("\n=== Testing Graph Alignment ===")
    
    aligner = GraphAlignment(max_nodes=20)
    
    # Two dummy graphs
    N = 10
    graph1 = {
        'A': torch.rand(N, N) > 0.8,
        'V': torch.randn(N, 2),
        'num_nodes': torch.tensor(8),
    }
    
    graph2 = {
        'A': torch.rand(N, N) > 0.8,
        'V': torch.randn(N, 2),
        'num_nodes': torch.tensor(7),
    }
    
    # Compute distance
    dist, assignment = aligner.compute_graph_distance(graph1, graph2)
    print(f"✓ Graph distance computed: {dist.item():.2f}")
    print(f"  Assignment shape: {assignment.shape}")
    
    return aligner


def test_cascade_decoder():
    """Test cascade graph decoder."""
    print("\n=== Testing Cascade Decoder ===")
    
    decoder = CascadeGraphDecoder(
        embed_dims=128,
        num_layers=2,
        num_heads=4,
        num_anchors=8,
        max_nodes=20,
    )
    
    # Dummy input
    B, K, N = 2, 8, 10
    graphs = {
        'A': torch.rand(B, K, N, N),
        'V': torch.randn(B, K, N, 2),
        'M': torch.randn(B, K, N*N, 1, 2),
        'num_nodes': torch.randint(5, N, (B, K)),
    }
    
    timestep = torch.randint(1, 21, (B*K,))
    bev_features = torch.randn(B, 128, 64, 96)
    
    # Forward
    output = decoder(graphs, timestep, bev_features)
    
    print(f"✓ Decoder forward pass")
    print(f"  Output shapes:")
    print(f"    A_pred: {output['A_pred'].shape}")
    print(f"    V_pred: {output['V_pred'].shape}")
    print(f"    scores: {output['scores'].shape}")
    
    return decoder


def test_loss_function():
    """Test loss function."""
    print("\n=== Testing Loss Function ===")
    
    loss_fn = TopoDiffLoss()
    
    # Dummy predictions
    B, K, N = 2, 8, 10
    predictions = {
        'scores': torch.randn(B, K),
        'A_pred': torch.rand(B, K, N, N),
        'V_pred': torch.randn(B, K, N, 2),
        'M_pred': torch.randn(B, K, N*N, 1, 2),
    }
    
    # Dummy targets
    targets = {
        'A': torch.rand(B, N, N) > 0.8,
        'V': torch.randn(B, N, 2),
        'M': torch.randn(B, 20, 1, 2),
        'num_nodes': torch.tensor([8, 7]),
    }
    
    # Positive labels (one-hot)
    positive_labels = torch.zeros(B, K)
    positive_labels[0, 2] = 1.0
    positive_labels[1, 5] = 1.0
    
    # Compute loss
    losses = loss_fn(predictions, targets, positive_labels)
    
    print(f"✓ Loss computed:")
    print(f"  Total: {losses['loss'].item():.4f}")
    print(f"  Classification: {losses['loss_cls'].item():.4f}")
    print(f"  Geometry: {losses['loss_geom'].item():.4f}")
    print(f"  Topology: {losses['loss_topo'].item():.4f}")
    
    return loss_fn


def test_topodiff_model():
    """Test full TopoDiff model."""
    print("\n=== Testing TopoDiff Model ===")
    
    # Build a simple anchor library first
    anchor_lib = AnchorLibrary(num_anchors=8, max_nodes=20)
    dummy_graphs = []
    for i in range(30):
        num_nodes = np.random.randint(5, 12)
        A = (np.random.rand(num_nodes, num_nodes) > 0.7).astype(np.float32)
        V = np.random.randn(num_nodes, 2).astype(np.float32)
        M = np.random.randn(int(A.sum()), 1, 2).astype(np.float32)
        dummy_graphs.append({'A': A, 'V': V, 'M': M})
    
    anchor_lib.build_from_dataset(dummy_graphs)
    
    # Create model (without BEV encoder for testing)
    model = TopoDiff(
        num_anchors=8,
        max_nodes=20,
        bev_encoder=None,  # Use dummy BEV
        T_trunc=50,
        T_infer_init=8,
        T_infer_steps=2,
        embed_dims=128,
        num_decoder_layers=2,
    )
    
    # Inject anchor library
    model.anchor_library = anchor_lib
    
    # Dummy batch
    B = 2
    batch_dict = {
        'img': torch.randn(B, 6, 3, 256, 704),  # [B, 6 cams, C, H, W]
        'gt_graphs': {
            'A': torch.rand(B, 20, 20) > 0.8,
            'V': torch.randn(B, 20, 2),
            'M': torch.randn(B, 50, 1, 2),
            'num_nodes': torch.tensor([10, 8]),
            'num_edges': torch.tensor([15, 12]),
        }
    }
    
    # Training forward
    model.train()
    output = model(batch_dict)
    
    print(f"✓ Training forward pass")
    print(f"  Loss: {output['losses']['loss'].item():.4f}")
    print(f"  Positive labels: {output['positive_labels'].argmax(dim=1)}")
    
    # Inference
    model.eval()
    with torch.no_grad():
        predictions = model.inference(batch_dict)
    
    print(f"✓ Inference pass")
    print(f"  Best anchor indices: {predictions['best_indices']}")
    print(f"  Output A shape: {predictions['A'].shape}")
    print(f"  Output V shape: {predictions['V'].shape}")
    
    return model


def main():
    """Run all tests."""
    print("=" * 60)
    print("TopoDiff Component Tests")
    print("=" * 60)
    
    try:
        test_anchor_library()
        test_noise_scheduler()
        test_graph_alignment()
        test_cascade_decoder()
        test_loss_function()
        test_topodiff_model()
        
        print("\n" + "=" * 60)
        print("✓ All tests passed!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n✗ Test failed with error:")
        print(f"  {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == '__main__':
    exit(main())
