"""
Cascade Graph Decoder: Multi-layer graph transformer with BEV interaction
Inspired by DiffusionDrive's cascade diffusion decoder
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional, Tuple
import math


class CascadeGraphDecoder(nn.Module):
    """
    Cascade graph transformer decoder for denoising lane topology graphs.
    Improved with DiffusionDrive's best practices:
    1. Each layer outputs prediction (deep supervision)
    2. FiLM (Feature-wise Linear Modulation) for timestep conditioning
    3. Next layer uses previous layer's output as input
    4. Deformable cross-attention to BEV features
    5. Cross-attention with perception queries
    """
    
    def __init__(
        self,
        embed_dims: int = 256,
        num_layers: int = 4,
        num_heads: int = 8,
        num_anchors: int = 8,
        max_nodes: int = 20,
        n_control: int = 3,
        dropout: float = 0.1,
        # BEV interaction
        num_bev_samples: int = 8,
        bev_h: int = 128,
        bev_w: int = 192,
        # Perception queries
        num_agent_queries: int = 100,
        num_map_queries: int = 50,
    ):
        super().__init__()
        
        self.embed_dims = embed_dims
        self.num_layers = num_layers
        self.num_heads = num_heads
        self.num_anchors = num_anchors
        self.max_nodes = max_nodes
        self.n_control = n_control
        self.num_bev_samples = num_bev_samples
        
        # Input embeddings
        self.node_coord_embed = nn.Linear(2, embed_dims)
        self.edge_control_embed = nn.Linear((n_control - 2) * 2, embed_dims)
        
        # Timestep embedding (sinusoidal)
        self.time_embed = nn.Sequential(
            nn.Linear(embed_dims, embed_dims),
            nn.SiLU(),
            nn.Linear(embed_dims, embed_dims)
        )
        
        # Cascade decoder layers
        self.decoder_layers = nn.ModuleList([
            GraphDecoderLayer(
                embed_dims=embed_dims,
                num_heads=num_heads,
                num_bev_samples=num_bev_samples,
                dropout=dropout,
                max_nodes=max_nodes,
                n_control=n_control,
            )
            for _ in range(num_layers)
        ])
        
        # FiLM timestep modulation for each layer
        self.time_modulations = nn.ModuleList([
            FiLMLayer(embed_dims, embed_dims)
            for _ in range(num_layers)
        ])
        
        # Output heads (shared across all cascade layers)
        # Following DiffusionDrive: each layer predicts, reuse same heads
        self.output_head = GraphOutputHead(
            embed_dims=embed_dims,
            max_nodes=max_nodes,
            n_control=n_control,
        )
        
    def forward(
        self,
        graphs: Dict[str, torch.Tensor],
        timestep: torch.Tensor,
        bev_features: torch.Tensor,
        perception_queries: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass with deep supervision (each layer outputs prediction).
        
        Args:
            graphs: Dict with noisy graphs
                'A': [B, K, N, N] adjacency matrices
                'V': [B, K, N, 2] node coordinates
                'M': [B, K, E, nc-2, 2] edge control points
                'num_nodes': [B, K] actual node counts
            timestep: [B*K] or [B, K] timestep indices
            bev_features: [B, C, H, W] BEV feature map
            perception_queries: Optional [B, Q, C] agent/map queries
            
        Returns:
            predictions: Dict with lists of predictions per layer
                'A_pred_list': List of [B, K, N, N] per layer
                'V_pred_list': List of [B, K, N, 2] per layer
                'M_pred_list': List of [B, K, E, nc-2, 2] per layer
                'scores_list': List of [B, K] per layer
                'A_pred': Final layer [B, K, N, N]
                'V_pred': Final layer [B, K, N, 2]
                'M_pred': Final layer [B, K, E, nc-2, 2]
                'scores': Final layer [B, K]
        """
        B, K, N = graphs['V'].shape[:3]
        device = graphs['V'].device
        
        # Reshape to [B*K, N, ...] for batch processing
        V_current = graphs['V'].reshape(B * K, N, 2)  # [B*K, N, 2]
        A_current = graphs['A'].reshape(B * K, N, N)  # [B*K, N, N]
        
        # Embed node coordinates
        node_feats = self.node_coord_embed(V_current)  # [B*K, N, C]
        
        # Timestep embedding - handle dimension expansion
        if timestep.dim() == 1:
            if timestep.numel() == B:
                # Expand [B] to [B*K] (repeat for each anchor)
                timestep = timestep.repeat_interleave(K)
            elif timestep.numel() == B * K:
                # Already correct size
                pass
            else:
                raise ValueError(f"Unexpected timestep size: {timestep.shape}, expected [B]={B} or [B*K]={B*K}")
        elif timestep.dim() == 2:
            # [B, K] -> [B*K]
            timestep = timestep.reshape(-1)
        
        time_emb = self._timestep_embedding(timestep)  # [B*K, C]
        time_emb = self.time_embed(time_emb)
        
        # Repeat BEV features for each anchor
        bev_features = bev_features.unsqueeze(1).repeat(1, K, 1, 1, 1)  # [B, K, C, H, W]
        bev_features = bev_features.reshape(B * K, -1, bev_features.shape[-2], bev_features.shape[-1])
        
        # Prepare num_nodes mask flattened to [B*K]
        num_nodes_flat = None
        if 'num_nodes' in graphs and graphs['num_nodes'] is not None:
            nnodes = graphs['num_nodes']
            if nnodes.dim() == 2 and nnodes.shape[0] == B and nnodes.shape[1] == K:
                num_nodes_flat = nnodes.reshape(-1)
            elif nnodes.dim() == 1 and nnodes.shape[0] == B * K:
                num_nodes_flat = nnodes
            else:
                raise ValueError(f"Unexpected num_nodes shape: {nnodes.shape}, expected [B,K] or [B*K]")

        # Collect predictions from each layer
        A_pred_list = []
        V_pred_list = []
        M_pred_list = []
        scores_list = []
        
        # Cascade through decoder layers (each layer predicts)
        for layer_idx, (layer, time_mod) in enumerate(zip(self.decoder_layers, self.time_modulations)):
            # Graph transformer layer
            node_feats = layer(
                node_feats=node_feats,
                node_coords=V_current,
                adjacency=A_current,
                bev_features=bev_features,
                num_nodes=num_nodes_flat,
                perception_queries=perception_queries,
                time_emb=time_emb
            )
            
            # FiLM time modulation
            node_feats = time_mod(node_feats, time_emb)
            
            # Predict from current layer
            layer_output = self.output_head(
                node_feats=node_feats,
                node_coords=V_current,
                num_nodes=num_nodes_flat,
                n_control=self.n_control,
            )
            
            A_pred_list.append(layer_output['A_pred'].reshape(B, K, N, N))
            V_pred_list.append(layer_output['V_pred'].reshape(B, K, N, 2))
            M_pred_list.append(layer_output['M_pred'].reshape(B, K, -1, self.n_control - 2, 2))
            scores_list.append(layer_output['scores'].reshape(B, K))
            
            # Update coordinates for next layer (detach to avoid BP through cascade)
            V_current = layer_output['V_pred'].detach()
            # Use soft adjacency (probabilities) without threshold for richer signal
            A_current = layer_output['A_pred'].detach()
        
        return {
            # Lists for deep supervision
            'A_pred_list': A_pred_list,
            'V_pred_list': V_pred_list,
            'M_pred_list': M_pred_list,
            'scores_list': scores_list,
            # Final layer predictions
            'A_pred': A_pred_list[-1],
            'V_pred': V_pred_list[-1],
            'M_pred': M_pred_list[-1],
            'scores': scores_list[-1],
        }
    
    def _timestep_embedding(self, timesteps: torch.Tensor, max_period: int = 10000):
        """
        Sinusoidal timestep embedding (like in Transformer).
        """
        half_dim = self.embed_dims // 2
        freqs = torch.exp(
            -math.log(max_period) * torch.arange(half_dim, device=timesteps.device) / half_dim
        )
        args = timesteps[:, None].float() * freqs[None, :]
        embedding = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
        if self.embed_dims % 2:
            embedding = torch.cat([embedding, torch.zeros_like(embedding[:, :1])], dim=-1)
        return embedding


class GraphDecoderLayer(nn.Module):
    """
    Single layer of graph decoder with:
    1. Graph self-attention (message passing via adjacency)
    2. Deformable cross-attention to BEV
    3. Cross-attention to perception queries
    4. FFN with timestep modulation
    """
    
    def __init__(
        self,
        embed_dims: int = 256,
        num_heads: int = 8,
        num_bev_samples: int = 8,
        dropout: float = 0.1,
        max_nodes: int = 20,
        n_control: int = 3,
    ):
        super().__init__()
        
        self.embed_dims = embed_dims
        self.dropout = nn.Dropout(dropout)
        
        # 1. Graph self-attention (GNN-style)
        self.graph_attn = nn.MultiheadAttention(
            embed_dims, num_heads, dropout=dropout, batch_first=True
        )
        self.norm1 = nn.LayerNorm(embed_dims)
        
        # 2. Deformable cross-attention to BEV
        # Simplified: sample BEV at node coordinates + learned offsets
        self.bev_cross_attn = DeformableCrossAttention(
            embed_dims, num_heads, num_samples=num_bev_samples
        )
        self.norm2 = nn.LayerNorm(embed_dims)
        
        # 3. FFN with timestep modulation
        self.ffn = nn.Sequential(
            nn.Linear(embed_dims, embed_dims * 4),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dims * 4, embed_dims),
            nn.Dropout(dropout)
        )
        self.norm3 = nn.LayerNorm(embed_dims)
        
        # Topology-guided aggregation (GNN-style message passing)
        self.topo_proj = nn.Linear(embed_dims, embed_dims)
        self.topo_gate = nn.Sequential(
            nn.Linear(embed_dims * 2, embed_dims),
            nn.Sigmoid()
        )
        
    def forward(
        self,
        node_feats: torch.Tensor,
        node_coords: torch.Tensor,
        adjacency: torch.Tensor,
        bev_features: torch.Tensor,
        num_nodes: Optional[torch.Tensor] = None,
        perception_queries: Optional[torch.Tensor] = None,
        time_emb: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Args:
            node_feats: [B, N, C]
            node_coords: [B, N, 2]
            adjacency: [B, N, N]
            bev_features: [B, C, H, W]
            time_emb: [B, C]
        """
        # 1. Graph self-attention (message passing) with padding mask
        B, N, C = node_feats.shape
        
        # Create key_padding_mask for invalid nodes
        if num_nodes is not None:
            key_padding_mask = torch.zeros(B, N, dtype=torch.bool, device=node_feats.device)
            for i in range(B):
                n_val = int(num_nodes[i].item()) if isinstance(num_nodes[i], torch.Tensor) else int(num_nodes[i])
                if n_val < N:
                    key_padding_mask[i, n_val:] = True
        else:
            key_padding_mask = None
        
        # Standard self-attention
        attn_out = self.dropout(self.graph_attn(
            node_feats, node_feats, node_feats,
            key_padding_mask=key_padding_mask
        )[0])
        
        # Topology-guided aggregation (GNN-style)
        # Mask adjacency to valid nodes only if num_nodes is provided
        if num_nodes is not None:
            device = adjacency.device
            idx = torch.arange(N, device=device).unsqueeze(0)  # [1, N]
            valid_nodes = (idx < num_nodes.unsqueeze(1)).float()  # [B, N]
            valid_mat = valid_nodes.unsqueeze(2) * valid_nodes.unsqueeze(1)  # [B, N, N]
            adjacency = adjacency * valid_mat
        # Normalize adjacency row-wise; avoid adding constant to every entry
        row_sum = adjacency.sum(dim=-1, keepdim=True).clamp_min(1e-6)
        A_norm = adjacency / row_sum  # [B, N, N]
        
        # Aggregate neighbor features: topo_agg = A @ node_feats
        topo_agg = torch.bmm(A_norm, node_feats)  # [B, N, C]
        topo_agg = self.topo_proj(topo_agg)
        
        # Gating mechanism: combine attn_out and topo_agg
        combined = torch.cat([attn_out, topo_agg], dim=-1)  # [B, N, 2C]
        gate = self.topo_gate(combined)  # [B, N, C]
        
        # Gated fusion
        fused = gate * attn_out + (1 - gate) * topo_agg
        node_feats = node_feats + fused
        node_feats = self.norm1(node_feats)
        
        # 2. BEV cross-attention
        residual = node_feats
        bev_out = self.bev_cross_attn(node_feats, node_coords, bev_features)
        node_feats = self.norm2(residual + bev_out)
        
        # 3. FFN
        residual = node_feats
        ffn_out = self.ffn(node_feats)
        node_feats = self.norm3(residual + ffn_out)
        
        return node_feats


class DeformableCrossAttention(nn.Module):
    """
    Simplified deformable cross-attention to BEV features.
    Sample BEV at node coordinates + learned offset positions.
    """
    
    def __init__(
        self,
        embed_dims: int = 256,
        num_heads: int = 8,
        num_samples: int = 8,
        x_bound: tuple = (-48.0, 48.0),
        y_bound: tuple = (-32.0, 32.0),
    ):
        super().__init__()
        
        self.embed_dims = embed_dims
        self.num_heads = num_heads
        self.num_samples = num_samples
        self.x_bound = x_bound
        self.y_bound = y_bound
        
        # Learn sampling offsets
        self.sampling_offsets = nn.Linear(embed_dims, num_samples * 2)
        
        # Attention weights
        self.attention_weights = nn.Linear(embed_dims, num_heads * num_samples)
        
        # Output projection
        self.output_proj = nn.Linear(embed_dims, embed_dims)
        
    def forward(
        self,
        query: torch.Tensor,
        reference_points: torch.Tensor,
        value: torch.Tensor,
    ):
        """
        Args:
            query: [B, N, C] node features
            reference_points: [B, N, 2] node coordinates (x, y in meters)
            value: [B, C, H, W] BEV features
            
        Returns:
            output: [B, N, C]
        """
        B, N, C = query.shape
        _, _, H, W = value.shape
        
        # Normalize coordinates to [-1, 1] for grid_sample
        # Use configured bounds (matches diffusion_scheduler)
        x_range = self.x_bound[1] - self.x_bound[0]
        y_range = self.y_bound[1] - self.y_bound[0]
        ref_x = 2 * (reference_points[..., 0] - self.x_bound[0]) / x_range - 1
        ref_y = 2 * (reference_points[..., 1] - self.y_bound[0]) / y_range - 1
        ref_normalized = torch.stack([ref_x, ref_y], dim=-1)  # [B, N, 2]
        
        # Predict sampling offsets (in normalized space)
        offsets = self.sampling_offsets(query)  # [B, N, num_samples*2]
        offsets = offsets.view(B, N, self.num_samples, 2)  # [B, N, K, 2]
        offsets = torch.tanh(offsets) * 0.1  # Small offsets
        
        # Sample locations
        sampling_locations = ref_normalized.unsqueeze(2) + offsets  # [B, N, K, 2]
        
        # Sample from BEV
        sampling_locations_flat = sampling_locations.reshape(B, N * self.num_samples, 2)
        sampled_features = F.grid_sample(
            value,
            sampling_locations_flat.unsqueeze(1),  # [B, 1, N*K, 2]
            mode='bilinear',
            padding_mode='zeros',
            align_corners=False
        )  # [B, C, 1, N*K]
        
        sampled_features = sampled_features.squeeze(2).permute(0, 2, 1)  # [B, N*K, C]
        sampled_features = sampled_features.reshape(B, N, self.num_samples, C)
        
        # Attention weights
        attn_weights = self.attention_weights(query)  # [B, N, H*K]
        attn_weights = attn_weights.view(B, N, self.num_heads, self.num_samples)
        attn_weights = F.softmax(attn_weights, dim=-1)  # [B, N, H, K]
        
        # Aggregate (simplified: average over heads)
        attn_weights = attn_weights.mean(dim=2)  # [B, N, K]
        output = torch.einsum('bnk,bnkc->bnc', attn_weights, sampled_features)
        
        output = self.output_proj(output)
        return output


class FiLMLayer(nn.Module):
    """
    Feature-wise Linear Modulation (FiLM) for timestep conditioning.
    Following DiffusionDrive's implementation.
    """
    
    def __init__(self, embed_dims: int, condition_dims: int):
        super().__init__()
        self.embed_dims = embed_dims
        
        self.scale_shift_mlp = nn.Sequential(
            nn.Mish(),
            nn.Linear(condition_dims, embed_dims * 2),
        )
    
    def forward(self, features: torch.Tensor, time_embed: torch.Tensor):
        """
        Args:
            features: [B, N, C] node features
            time_embed: [B, C] or [B, 1, C] time embedding
        """
        if time_embed.dim() == 2:
            time_embed = time_embed.unsqueeze(1)  # [B, 1, C]
        
        scale_shift = self.scale_shift_mlp(time_embed)  # [B, 1, 2C]
        scale, shift = scale_shift.chunk(2, dim=-1)  # [B, 1, C], [B, 1, C]
        
        # FiLM: feature * (1 + scale) + shift
        modulated = features * (1 + scale) + shift
        return modulated


class GraphOutputHead(nn.Module):
    """
    Output head for graph predictions.
    Shared across all cascade layers for parameter efficiency.
    """
    
    def __init__(
        self,
        embed_dims: int = 256,
        max_nodes: int = 20,
        n_control: int = 3,
    ):
        super().__init__()
        self.embed_dims = embed_dims
        self.max_nodes = max_nodes
        self.n_control = n_control
        
        # Node coordinate offset head
        self.node_coord_head = nn.Sequential(
            nn.Linear(embed_dims, embed_dims),
            nn.ReLU(),
            nn.Linear(embed_dims, 2)  # Predict (x, y) offset
        )
        
        # Edge control points head (pairwise-based)
        # Input: concatenation of two node features [2*embed_dims]
        # Output: control point offsets [(n_control-2)*2]
        self.edge_control_head = nn.Sequential(
            nn.Linear(embed_dims * 2, embed_dims),
            nn.ReLU(),
            nn.Linear(embed_dims, (n_control - 2) * 2)
        )
        
        # Adjacency head (pairwise)
        self.adjacency_head = nn.Sequential(
            nn.Linear(embed_dims * 2, embed_dims),
            nn.ReLU(),
            nn.Linear(embed_dims, 1)
        )
        
        # Confidence score head (per anchor)
        self.confidence_head = nn.Sequential(
            nn.Linear(embed_dims, embed_dims),
            nn.ReLU(),
            nn.Linear(embed_dims, 1)
        )
    
    def forward(
        self,
        node_feats: torch.Tensor,
        node_coords: torch.Tensor,
        num_nodes: Optional[torch.Tensor],
        n_control: int,
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            node_feats: [B, N, C]
            node_coords: [B, N, 2]
            num_nodes: Maximum nodes
            n_control: Number of control points
        """
        B, N, C = node_feats.shape
        
        # 1. Node coordinates (predict offset)
        V_offset = self.node_coord_head(node_feats)  # [B, N, 2]
        V_pred = node_coords + V_offset
        
        # 2. Adjacency matrix (pairwise)
        node_feats_i = node_feats.unsqueeze(2).repeat(1, 1, N, 1)  # [B, N, N, C]
        node_feats_j = node_feats.unsqueeze(1).repeat(1, N, 1, 1)  # [B, N, N, C]
        edge_feats = torch.cat([node_feats_i, node_feats_j], dim=-1)  # [B, N, N, 2C]
        A_logits = self.adjacency_head(edge_feats).squeeze(-1)  # [B, N, N]
        A_pred = torch.sigmoid(A_logits)
        
        # 3. Edge control points (pairwise-based regression)
        # Use pairwise features (same as adjacency) to predict control point offsets
        M_offset = self.edge_control_head(edge_feats)  # [B, N, N, (nc-2)*2]
        M_offset = M_offset.view(B, N, N, n_control - 2, 2)  # [B, N, N, nc-2, 2]
        
        # Base point: midpoint between two nodes
        node_i = node_coords.unsqueeze(2).expand(-1, -1, N, -1)  # [B, N, N, 2]
        node_j = node_coords.unsqueeze(1).expand(-1, N, -1, -1)  # [B, N, N, 2]
        midpoint = (node_i + node_j) / 2.0  # [B, N, N, 2]
        
        # Add offset to midpoint for each control point
        M_base = midpoint.unsqueeze(3).expand(-1, -1, -1, n_control - 2, -1)  # [B, N, N, nc-2, 2]
        M_pred_full = M_base + M_offset  # [B, N, N, nc-2, 2]
        
        # Flatten to [B, N*N, nc-2, 2] for compatibility with loss
        M_pred = M_pred_full.view(B, N * N, n_control - 2, 2)
        
        # 4. Confidence scores (masked global pooling over valid nodes)
        if num_nodes is not None and isinstance(num_nodes, torch.Tensor) and num_nodes.numel() == B:
            device = node_feats.device
            idx = torch.arange(N, device=device).unsqueeze(0)  # [1, N]
            valid = (idx < num_nodes.unsqueeze(1)).float().unsqueeze(-1)  # [B, N, 1]
            pooled = (node_feats * valid).sum(dim=1) / valid.sum(dim=1).clamp_min(1.0)
        else:
            pooled = node_feats.mean(dim=1)
        scores = self.confidence_head(pooled).squeeze(-1)  # [B]
        
        return {
            'A_pred': A_pred,
            'V_pred': V_pred,
            'M_pred': M_pred,
            'scores': scores,
        }
