"""
Anchor Library: Build and manage topology anchor prototypes
Inspired by DiffusionDrive's anchor-based truncated diffusion
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List, Tuple, Optional
from sklearn.cluster import KMeans
from scipy.optimize import linear_sum_assignment
import pickle
import os


class AnchorLibrary:
    """
    Construct and manage K topology anchor prototypes from training data.
    Each anchor is a representative graph (A, V, M).
    """
    
    def __init__(
        self,
        num_anchors: int = 8,
        max_nodes: int = 20,
        n_control: int = 3,
        grid_size: float = 0.5,
        x_bound: Tuple[float, float] = (-48, 48),
        y_bound: Tuple[float, float] = (-32, 32),
    ):
        """
        Args:
            num_anchors: Number of anchor prototypes (K)
            max_nodes: Maximum number of nodes in graph
            n_control: Number of Bezier control points (3 for quadratic)
            grid_size: Grid resolution for coordinate discretization
            x_bound, y_bound: Coordinate bounds
        """
        self.num_anchors = num_anchors
        self.max_nodes = max_nodes
        self.n_control = n_control
        self.grid_size = grid_size
        self.x_bound = x_bound
        self.y_bound = y_bound
        
        # Anchor storage: List[Dict] with keys 'A', 'V', 'M', 'num_nodes'
        self.anchors: Optional[List[Dict]] = None
        self.anchor_features: Optional[np.ndarray] = None  # For clustering
        
    def build_from_dataset(
        self,
        graph_list: List[Dict],
        save_path: Optional[str] = None
    ):
        """
        Build anchor library by clustering graphs from training dataset.
        
        Args:
            graph_list: List of dict with 'A', 'V', 'M' (ground truth graphs)
            save_path: Optional path to save anchor library
        """
        print(f"Building anchor library from {len(graph_list)} graphs...")
        
        # Step 1: Extract graph features for clustering
        features = []
        valid_graphs = []
        
        for graph in graph_list:
            # Normalize and extract features
            feat = self._extract_graph_features(graph)
            if feat is not None:
                features.append(feat)
                valid_graphs.append(graph)
        
        features = np.array(features)
        print(f"Extracted features shape: {features.shape}")
        
        # Step 2: K-Means clustering
        kmeans = KMeans(n_clusters=self.num_anchors, random_state=42, n_init=10)
        labels = kmeans.fit_predict(features)
        
        # Step 3: Select medoid (most representative graph) in each cluster
        self.anchors = []
        for k in range(self.num_anchors):
            cluster_indices = np.where(labels == k)[0]
            if len(cluster_indices) == 0:
                continue
                
            # Find graph closest to cluster center
            cluster_features = features[cluster_indices]
            center = kmeans.cluster_centers_[k]
            distances = np.linalg.norm(cluster_features - center, axis=1)
            medoid_idx = cluster_indices[np.argmin(distances)]
            
            # Normalize and pad the medoid graph
            anchor_graph = self._normalize_graph(valid_graphs[medoid_idx])
            self.anchors.append(anchor_graph)
        
        self.anchor_features = kmeans.cluster_centers_
        
        print(f"Built {len(self.anchors)} anchors")
        self._print_anchor_statistics()
        
        if save_path:
            self.save(save_path)
            
    def _extract_graph_features(self, graph: Dict) -> Optional[np.ndarray]:
        """
        Extract structural and geometric features from a graph.
        Combines topology (degree, connectivity) and geometry (spatial layout).
        """
        A = graph['A']  # [N, N]
        V = graph['V']  # [N, 2]
        
        num_nodes = A.shape[0]
        if num_nodes == 0 or num_nodes > self.max_nodes:
            return None
            
        features = []
        
        # 1. Structural features
        in_degree = A.sum(axis=0)  # [N]
        out_degree = A.sum(axis=1)  # [N]
        
        # Degree statistics
        features.extend([
            num_nodes,
            in_degree.mean(),
            in_degree.std(),
            out_degree.mean(),
            out_degree.std(),
            A.sum(),  # Total edges
        ])
        
        # Degree distribution histogram (bins: 0, 1, 2, 3+)
        for max_deg in [0, 1, 2, 3]:
            features.append((in_degree == max_deg).sum())
            features.append((out_degree == max_deg).sum())
        
        # 2. Geometric features (translation/rotation invariant)
        # Centroid
        centroid = V.mean(axis=0)
        V_centered = V - centroid
        
        # Scale (mean distance from centroid)
        scale = np.linalg.norm(V_centered, axis=1).mean()
        features.append(scale)
        
        # Spread (std of distances)
        features.append(np.linalg.norm(V_centered, axis=1).std())
        
        # 3. Graph connectivity patterns
        # Path length, connected components (simplified)
        features.append((A @ A).sum())  # 2-hop connections
        
        return np.array(features, dtype=np.float32)
    
    def _normalize_graph(self, graph: Dict) -> Dict:
        """
        Normalize and pad graph to max_nodes size with Procrustes alignment.
        """
        A = graph['A'].copy()  # [N, N]
        V = graph['V'].copy()  # [N, 2]
        M = graph.get('M', np.zeros((int(A.sum()), self.n_control - 2, 2), dtype=np.float32))  # [E, n_control-2, 2]
        
        num_nodes = A.shape[0]
        
        # Procrustes normalization: center + scale
        centroid = V.mean(axis=0)
        V_centered = V - centroid
        # Use mean node distance from centroid as scale (robust to N)
        scale = np.linalg.norm(V_centered, axis=1).mean() + 1e-6
        V_normalized = V_centered / scale
        M_normalized = M / scale if M.size > 0 else M
        
        # Pad to max_nodes
        A_padded = np.zeros((self.max_nodes, self.max_nodes), dtype=np.float32)
        V_padded = np.zeros((self.max_nodes, 2), dtype=np.float32)
        
        A_padded[:num_nodes, :num_nodes] = A
        V_padded[:num_nodes] = V_normalized
        
        # Edge matrix: pad to max possible edges (max_nodes * max_nodes)
        num_edges = int(A.sum())
        max_edges = self.max_nodes * self.max_nodes
        M_padded = np.zeros((max_edges, self.n_control - 2, 2), dtype=np.float32)
        if num_edges > 0 and M.size > 0:
            M_padded[:num_edges] = M_normalized
        
        return {
            'A': A_padded,
            'V': V_padded,
            'M': M_padded,
            'num_nodes': num_nodes,
            'num_edges': num_edges,
            'scale': scale,
            'centroid': centroid
        }
    
    def _print_anchor_statistics(self):
        """Print statistics of anchor library."""
        if self.anchors is None:
            return
            
        node_counts = [a['num_nodes'] for a in self.anchors]
        edge_counts = [a['num_edges'] for a in self.anchors]
        
        print(f"Anchor Statistics:")
        print(f"  Nodes: min={min(node_counts)}, max={max(node_counts)}, "
              f"mean={np.mean(node_counts):.1f}")
        print(f"  Edges: min={min(edge_counts)}, max={max(edge_counts)}, "
              f"mean={np.mean(edge_counts):.1f}")
    
    def save(self, path: str):
        """Save anchor library to file."""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        data = {
            'anchors': self.anchors,
            'anchor_features': self.anchor_features,
            'config': {
                'num_anchors': self.num_anchors,
                'max_nodes': self.max_nodes,
                'n_control': self.n_control,
            }
        }
        with open(path, 'wb') as f:
            pickle.dump(data, f)
        print(f"Saved anchor library to {path}")
    
    def load(self, path: str):
        """Load anchor library from file."""
        with open(path, 'rb') as f:
            data = pickle.load(f)
        self.anchors = data['anchors']
        self.anchor_features = data['anchor_features']
        print(f"Loaded {len(self.anchors)} anchors from {path}")
        self._print_anchor_statistics()
    
    def get_anchors_as_tensors(self, device='cuda') -> Dict[str, torch.Tensor]:
        """
        Get all anchors as batched tensors for training/inference.
        
        Returns:
            Dict with keys:
                'A': [K, N, N]
                'V': [K, N, 2]
                'M': [K, E_max, n_control-2, 2]
                'num_nodes': [K]
                'num_edges': [K]
        """
        if self.anchors is None:
            raise ValueError("Anchors not built yet. Call build_from_dataset() first.")
        
        K = len(self.anchors)
        N = self.max_nodes
        E_max = N * N
        
        A_batch = np.stack([a['A'] for a in self.anchors])  # [K, N, N]
        V_batch = np.stack([a['V'] for a in self.anchors])  # [K, N, 2]
        M_batch = np.stack([a['M'] for a in self.anchors])  # [K, E_max, nc-2, 2]
        num_nodes = np.array([a['num_nodes'] for a in self.anchors])  # [K]
        num_edges = np.array([a['num_edges'] for a in self.anchors])  # [K]
        
        return {
            'A': torch.from_numpy(A_batch).to(device),
            'V': torch.from_numpy(V_batch).to(device),
            'M': torch.from_numpy(M_batch).to(device),
            'num_nodes': torch.from_numpy(num_nodes).long().to(device),
            'num_edges': torch.from_numpy(num_edges).long().to(device),
        }
