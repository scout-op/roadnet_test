"""
TopoDiff: Topology-Anchored Truncated Diffusion for Lane Graph Generation

Core components:
- TopoDiff: Main model
- CascadeGraphDecoder: Graph transformer decoder with deep supervision
- TopoDiffScheduler: Diffusion scheduler (wraps diffusers.DDIMScheduler)
- AnchorLibrary: Anchor prototype management
- GraphAlignment: Graph matching and alignment
- TopoDiffLoss: Loss functions with deep supervision support

Optimized with DiffusionDrive's best practices:
- Standard DDIM scheduler for stability
- FiLM time modulation
- Cascade layers with deep supervision
- Optimized inference (init_noise=8, steps=2)
"""

from .topodiff_model import TopoDiff
from .cascade_graph_decoder import (
    CascadeGraphDecoder,
    FiLMLayer,
    GraphOutputHead,
)
from .diffusion_scheduler import TopoDiffScheduler
from .anchor_library import AnchorLibrary
from .graph_alignment import GraphAlignment
from .losses import TopoDiffLoss

# Legacy import for backward compatibility
from .truncated_noise import TruncatedNoiseScheduler

__all__ = [
    'TopoDiff',
    'CascadeGraphDecoder',
    'FiLMLayer',
    'GraphOutputHead',
    'TopoDiffScheduler',
    'TruncatedNoiseScheduler',  # Legacy
    'AnchorLibrary',
    'GraphAlignment',
    'TopoDiffLoss',
]
