"""
Loss Functions for TopoDiff
Following DiffusionDrive: classification + reconstruction loss
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional


class TopoDiffLoss(nn.Module):
    """
    Combined loss for TopoDiff training.
    Following DiffusionDrive Eq. 100:
    L = Σ_k [ y_k * L_rec(pred_k, gt) + λ * BCE(score_k, y_k) ]
    
    Components:
    1. Classification loss: BCE for anchor confidence scores
    2. Reconstruction loss (only on positive anchor):
       - Geometry: L1 for V (nodes) and M (Bezier control points)
       - Topology: Weighted BCE/Focal for A (adjacency matrix)
    3. Regularization: degree constraint, connectivity, etc.
    """
    
    def __init__(
        self,
        lambda_cls: float = 1.0,
        lambda_geom: float = 1.0,
        lambda_topo: float = 1.5,
        lambda_reg: float = 0.1,
        lambda_M_factor: float = 0.1,  # M控制点损失降权因子
        # Focal loss for adjacency (handle extreme imbalance)
        use_focal_loss: bool = True,
        focal_alpha: float = 0.75,
        focal_gamma: float = 2.0,
        # Regularization
        degree_reg_weight: float = 0.05,
        curvature_reg_weight: float = 0.05,
    ):
        super().__init__()
        
        self.lambda_cls = lambda_cls
        self.lambda_geom = lambda_geom
        self.lambda_topo = lambda_topo
        self.lambda_reg = lambda_reg
        self.lambda_M_factor = lambda_M_factor
        
        self.use_focal_loss = use_focal_loss
        self.focal_alpha = focal_alpha
        self.focal_gamma = focal_gamma
        
        self.degree_reg_weight = degree_reg_weight
        self.curvature_reg_weight = curvature_reg_weight
    
    def forward(
        self,
        predictions: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
        positive_labels: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute total loss with deep supervision.
        
        Args:
            predictions: Dict with
                'scores_list': List of [B, K] confidence scores per layer
                'A_pred_list': List of [B, K, N, N] predicted adjacency per layer
                'V_pred_list': List of [B, K, N, 2] predicted coordinates per layer
                'M_pred_list': List of [B, K, E, nc-2, 2] predicted control points per layer
                OR single predictions (backward compatible):
                'scores': [B, K] confidence scores
                'A_pred': [B, K, N, N] predicted adjacency
                'V_pred': [B, K, N, 2] predicted coordinates
                'M_pred': [B, K, E, nc-2, 2] predicted control points
            targets: Dict with
                'A': [B, N, N] ground truth adjacency
                'V': [B, N, 2] ground truth coordinates
                'M': [B, E, nc-2, 2] ground truth control points
                'num_nodes': [B] actual node counts
            positive_labels: [B, K] one-hot labels for positive anchor
            
        Returns:
            Dict with loss components and total loss
        """
        device = targets['A'].device
        
        # Check if deep supervision (list of predictions per layer)
        is_deep_supervision = 'scores_list' in predictions
        
        if is_deep_supervision:
            # Deep supervision: accumulate loss from all layers
            num_layers = len(predictions['scores_list'])
            total_loss_cls = 0.0
            total_loss_geom = 0.0
            total_loss_topo = 0.0
            total_loss_reg = 0.0
            
            for layer_idx in range(num_layers):
                layer_preds = {
                    'scores': predictions['scores_list'][layer_idx],
                    'A_pred': predictions['A_pred_list'][layer_idx],
                    'V_pred': predictions['V_pred_list'][layer_idx],
                    'M_pred': predictions['M_pred_list'][layer_idx],
                }
                
                # Compute loss for this layer
                layer_losses = self._compute_single_layer_loss(
                    layer_preds, targets, positive_labels
                )
                
                total_loss_cls += layer_losses['loss_cls']
                total_loss_geom += layer_losses['loss_geom']
                total_loss_topo += layer_losses['loss_topo']
                total_loss_reg += layer_losses['loss_reg']
            
            # Average over layers
            loss_cls = total_loss_cls / num_layers
            loss_geom = total_loss_geom / num_layers
            loss_topo = total_loss_topo / num_layers
            loss_reg = total_loss_reg / num_layers
            
        else:
            # Single prediction (backward compatible)
            layer_losses = self._compute_single_layer_loss(
                predictions, targets, positive_labels
            )
            loss_cls = layer_losses['loss_cls']
            loss_geom = layer_losses['loss_geom']
            loss_topo = layer_losses['loss_topo']
            loss_reg = layer_losses['loss_reg']
        
        # Total loss
        total_loss = (
            self.lambda_cls * loss_cls +
            self.lambda_geom * loss_geom +
            self.lambda_topo * loss_topo +
            self.lambda_reg * loss_reg
        )
        
        return {
            'loss': total_loss,
            'loss_cls': loss_cls,
            'loss_geom': loss_geom,
            'loss_topo': loss_topo,
            'loss_reg': loss_reg,
        }
    
    def _compute_single_layer_loss(
        self,
        predictions: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
        positive_labels: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute loss for a single layer.
        """
        device = predictions['scores'].device
        B, K = predictions['scores'].shape
        
        # 1. Classification loss (all anchors)
        loss_cls = F.binary_cross_entropy_with_logits(
            predictions['scores'],
            positive_labels,
            reduction='mean'
        )
        
        # 2. Reconstruction loss (only positive anchors)
        # Find positive anchor indices
        pos_indices = positive_labels.argmax(dim=1)  # [B]
        
        loss_geom = 0.0
        loss_topo = 0.0
        loss_reg = 0.0
        
        for b in range(B):
            k_pos = pos_indices[b].item()
            
            # Extract predictions for positive anchor
            A_pred_pos = predictions['A_pred'][b, k_pos]  # [N, N]
            V_pred_pos = predictions['V_pred'][b, k_pos]  # [N, 2]
            M_pred_pos = predictions['M_pred'][b, k_pos]  # [E, nc-2, 2]
            
            # Extract ground truth
            A_gt = targets['A'][b]  # [N, N]
            V_gt = targets['V'][b]  # [N, 2]
            M_gt = targets['M'][b]  # [E, nc-2, 2]
            num_nodes = targets['num_nodes'][b].item()
            
            if num_nodes == 0:
                continue
            
            # 2.1 Geometry loss (L1 on valid nodes)
            V_pred_valid = V_pred_pos[:num_nodes]
            V_gt_valid = V_gt[:num_nodes]
            loss_geom += F.l1_loss(V_pred_valid, V_gt_valid)
            
            # Control points M (edge-level, masked by adjacency)
            # M_pred_pos: [N*N, nc-2, 2], M_gt: [E, nc-2, 2]
            # Use A_gt as mask to only supervise edges that exist
            A_gt_valid = A_gt[:num_nodes, :num_nodes]
            edge_mask = A_gt_valid.reshape(-1) > 0.5  # [N*N] binary mask
            
            if edge_mask.sum() > 0:
                # Reshape M_pred to [N*N, nc-2, 2] and apply mask
                M_pred_masked = M_pred_pos[:num_nodes * num_nodes][edge_mask]  # [num_edges, nc-2, 2]
                
                # M_gt should match the number of edges
                num_edges_gt = int(edge_mask.sum().item())
                if M_gt.shape[0] >= num_edges_gt:
                    M_gt_masked = M_gt[:num_edges_gt]
                    # Apply M weight factor (can be increased after V/A converge)
                    loss_geom += F.l1_loss(M_pred_masked, M_gt_masked) * self.lambda_M_factor
                
                # Curvature regularization on predicted control points
                if self.curvature_reg_weight > 0 and M_pred_masked.shape[0] > 0:
                    loss_reg += self._curvature_regularization(M_pred_masked)
            
            # 2.2 Topology loss (Focal BCE on adjacency matrix)
            A_pred_valid = A_pred_pos[:num_nodes, :num_nodes]
            A_gt_valid = A_gt[:num_nodes, :num_nodes]
            
            if self.use_focal_loss:
                loss_topo += self._focal_loss(A_pred_valid, A_gt_valid)
            else:
                # Weighted BCE on probabilities (A_pred_valid already sigmoid)
                # Create per-element weights: pos=10, neg=1
                pos_w = torch.tensor(10.0, device=device)
                neg_w = torch.tensor(1.0, device=device)
                weight = torch.where(A_gt_valid > 0.5, pos_w, neg_w)
                loss_topo += F.binary_cross_entropy(
                    A_pred_valid, A_gt_valid,
                    weight=weight,
                    reduction='mean'
                )
            
            # 2.3 Regularization (directed graph)
            A_pred_valid_full = A_pred_pos[:num_nodes, :num_nodes]
            # Self-loop constraint only (no symmetry regularization for directed graphs)
            self_loop_loss = torch.abs(torch.diag(A_pred_valid_full)).mean()
            loss_reg += self_loop_loss * 0.1
            
            # Degree constraint: penalize unreasonable degree distributions
            if self.degree_reg_weight > 0:
                loss_reg += self._degree_regularization(A_pred_pos, num_nodes)
            
            # Curvature regularization is already applied on masked edges above
        
        # Average over batch
        loss_geom /= B
        loss_topo /= B
        loss_reg /= B
        
        return {
            'loss_cls': loss_cls,
            'loss_geom': loss_geom,
            'loss_topo': loss_topo,
            'loss_reg': loss_reg,
        }
    
    def _focal_loss(
        self,
        pred: torch.Tensor,
        target: torch.Tensor,
    ) -> torch.Tensor:
        """
        Focal loss for binary classification (handle class imbalance).
        FL(p_t) = -alpha * (1 - p_t)^gamma * log(p_t)
        """
        pred = torch.clamp(pred, min=1e-7, max=1-1e-7)
        target = target.float()
        
        # Binary cross entropy
        bce = -target * torch.log(pred) - (1 - target) * torch.log(1 - pred)
        
        # Focal modulation
        p_t = torch.where(target == 1, pred, 1 - pred)
        focal_weight = (1 - p_t) ** self.focal_gamma
        
        # Class balance (alpha)
        alpha_t = torch.where(target == 1, self.focal_alpha, 1 - self.focal_alpha)
        
        focal_loss = alpha_t * focal_weight * bce
        return focal_loss.mean()
    
    def _degree_regularization(
        self,
        A_pred: torch.Tensor,
        num_nodes: int,
    ) -> torch.Tensor:
        """
        Regularize node degrees to be reasonable (not too many edges).
        Penalize nodes with degree > 4 (typical for road intersections).
        """
        A_valid = A_pred[:num_nodes, :num_nodes]
        
        # Out-degree and in-degree
        out_degree = A_valid.sum(dim=1)  # [num_nodes]
        in_degree = A_valid.sum(dim=0)  # [num_nodes]
        
        # Penalize degrees > 4
        max_degree = 4.0
        degree_penalty = (
            F.relu(out_degree - max_degree).sum() +
            F.relu(in_degree - max_degree).sum()
        )
        
        return degree_penalty * self.degree_reg_weight
    
    def _curvature_regularization(
        self,
        M_pred: torch.Tensor,
    ) -> torch.Tensor:
        """
        Penalize high-curvature Bezier curves (smoothness prior).
        Compute second derivative approximation.
        """
        if M_pred.numel() == 0:
            return torch.tensor(0.0, device=M_pred.device)
        
        M_valid = M_pred  # [num_edges, nc-2, 2]
        
        # For quadratic Bezier (nc=3), control point M represents the middle
        # Simple smoothness: penalize large deviation from straight line
        # (This is a simplified version; more accurate would compute actual curvature)
        curvature = torch.norm(M_valid, dim=-1).mean()
        
        return curvature * self.curvature_reg_weight


class DiversityLoss(nn.Module):
    """
    Optional: Encourage diversity among predicted anchors.
    Penalize if all anchors predict the same graph.
    """
    
    def __init__(self, lambda_div: float = 0.1):
        super().__init__()
        self.lambda_div = lambda_div
    
    def forward(self, predictions: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Compute diversity loss: negative of pairwise distance between anchors.
        """
        V_pred = predictions['V_pred']  # [B, K, N, 2]
        B, K, N, _ = V_pred.shape
        
        # Flatten to [B, K, N*2]
        V_flat = V_pred.reshape(B, K, -1)
        
        # Pairwise L2 distance between anchors
        diversity = 0.0
        for b in range(B):
            dists = torch.cdist(V_flat[b], V_flat[b], p=2)  # [K, K]
            # Average distance (exclude diagonal)
            mask = ~torch.eye(K, device=dists.device, dtype=torch.bool)
            diversity += dists[mask].mean()
        
        diversity /= B
        
        # Negative diversity as loss (encourage larger distance)
        return -diversity * self.lambda_div
