# TopoDiff 架构与代码全面审查报告

**审查日期**: 2025-11-04  
**审查范围**: 完整架构、数据流、潜在bug

---

## 一、完整模型架构

### 1.1 模块组成（7大核心模块）

```
TopoDiff (topodiff_model.py)
├── AnchorLibrary (anchor_library.py)
│   ├── K=8个拓扑原型
│   ├── KMeans聚类构建
│   └── 图特征提取（结构+几何）
│
├── BEV Encoder (复用SeqGrowGraph)
│   ├── ResNet50 + FPN骨干
│   ├── LSS/GKT投影到BEV
│   └── 输出: [B, 256, 128, 192]
│
├── TopoDiffScheduler (diffusion_scheduler.py)
│   ├── 封装diffusers.DDIMScheduler
│   ├── 连续V/M: DDIM高斯噪声（归一化域）
│   ├── 离散A: mask+flip结构化噪声
│   └── 推理时间步: [8, 4, 0]
│
├── CascadeGraphDecoder (cascade_graph_decoder.py)
│   ├── 4层级联Transformer
│   ├── 每层: 图自注意 + BEV跨注意 + FiLM + FFN
│   ├── GraphOutputHead（共享跨层）
│   └── 深度监督：每层输出预测
│
├── GraphAlignment (graph_alignment.py)
│   ├── Hungarian匹配找最近锚点
│   ├── Procrustes对齐（未实装）
│   └── 图编辑距离（几何+拓扑）
│
├── TopoDiffLoss (losses.py)
│   ├── 分类损失: BCE(scores, positive_labels)
│   ├── 几何损失: L1(V) + L1(M)*0.5*0.1
│   ├── 拓扑损失: FocalBCE(A) or WeightedBCE
│   └── 正则: 度约束 + 曲率平滑
│
└── SwanLabLogger (swanlab_logger.py)
    └── 可视化训练/验证指标（可选）
```

---

## 二、数据流详细追踪

### 2.1 训练阶段（forward）

```
输入: batch_dict
    ├── 'img': [B, 6, 3, H, W] 多视角图像
    ├── 'gt_graphs': {A, V, M, num_nodes} GT图
    └── 'lidar2img': 相机标定

步骤1: BEV编码
    img [B,6,3,H,W] → BEV Encoder → bev_features [B,256,128,192]

步骤2: 获取锚点
    AnchorLibrary.get_anchors_as_tensors(device)
    → anchor_graphs: {A[K,N,N], V[K,N,2], M[K,E,nc-2,2], num_nodes[K]}

步骤3: 采样训练时间步
    TopoDiffScheduler.get_train_timesteps(B, device)
    → timesteps [B] in [0, T_trunc=50]

步骤4: 加噪（批量+锚点扩展）
    _add_noise_batch(anchor_graphs, timesteps, device)
    │
    ├─ anchor_graphs [K,...] → expand → [B,K,...]
    ├─ timesteps [B] → expand → [B,K] → flatten → [B*K]
    │
    ├─ 连续V/M:
    │   ├─ normalize到[-1,1]: V_norm = 2*(V-x_min)/(x_max-x_min) - 1
    │   ├─ DDIM加噪: V_noisy_norm = scheduler.add_noise(V_norm, noise, t)
    │   └─ denormalize回米: V_noisy = (V_norm+1)/2*(x_max-x_min) + x_min
    │
    └─ 离散A:
        ├─ mask_prob = 0.15 * t/T_trunc (随t线性增强)
        ├─ flip_prob = 0.05 * t/T_trunc
        ├─ 仅在[:num_nodes,:num_nodes]区域操作
        └─ mask→0.5, flip→1-A

    → noisy_graphs: {A,V,M,num_nodes}[B,K,...]

步骤5: 级联解码器（深度监督）
    CascadeGraphDecoder(noisy_graphs, timesteps, bev_features)
    │
    ├─ 输入reshape: [B,K,N,...] → [B*K,N,...]
    ├─ timesteps [B] → expand → [B*K]
    ├─ bev_features [B,...] → repeat → [B*K,...]
    │
    ├─ Layer 1:
    │   ├─ node_feats = embed(V_noisy) [B*K,N,256]
    │   ├─ time_emb = sin_cos(t) → MLP [B*K,256]
    │   ├─ Graph Self-Attn + padding_mask
    │   ├─ BEV Cross-Attn (Deformable采样)
    │   ├─ FiLM(time_emb): feats*(1+scale)+shift
    │   ├─ FFN
    │   └─ OutputHead:
    │       ├─ V_pred_1 = V_noisy + offset [B*K,N,2]
    │       ├─ A_pred_1 = sigmoid(pairwise_MLP) [B*K,N,N]
    │       ├─ M_pred_1 = zeros [B*K,E,nc-2,2] ⚠️占位
    │       └─ scores_1 = MLP(global_pool) [B*K]
    │
    ├─ Layer 2: 输入V_pred_1.detach(), A_pred_1.detach()
    ├─ Layer 3: ...
    └─ Layer 4: ...

    → predictions: {
        V_pred_list: [4层] × [B,K,N,2],
        A_pred_list: [4层] × [B,K,N,N],
        M_pred_list: [4层] × [B,K,E,nc-2,2],
        scores_list: [4层] × [B,K]
      }

步骤6: 图对齐（找正锚点）
    GraphAlignment.batch_find_positive_anchors(gt_graphs, anchor_graphs)
    │
    └─ For each b in B:
        ├─ 计算cost_matrix[N,N]: 几何距离+度差异
        ├─ Hungarian匹配: linear_sum_assignment
        ├─ 拓扑mismatch惩罚: |A_aligned - A_gt|
        └─ 选最近k: argmin(distance)

    → positive_labels [B,K] one-hot

步骤7: 计算损失（深度监督）
    TopoDiffLoss(predictions, gt_graphs, positive_labels)
    │
    └─ For each layer l in [1,2,3,4]:
        ├─ loss_cls_l = BCEWithLogits(scores_l, positive_labels)
        │
        └─ For each b in B:
            ├─ k_pos = positive_labels[b].argmax()
            ├─ 取正锚点预测: A/V/M_pred[b,k_pos]
            │
            ├─ loss_geom = L1(V_pred[:n], V_gt[:n])
            │            + L1(M_pred[:e], M_gt[:e]) * 0.5 * 0.1
            │
            ├─ loss_topo = FocalBCE(A_pred[:n,:n], A_gt[:n,:n])
            │            or WeightedBCE(pos_w=10, neg_w=1)
            │
            └─ loss_reg = degree_penalty(度>4)
                        + curvature(|M|平滑)

    平均4层 → 总损失: λ_cls*cls + λ_geom*geom + λ_topo*topo + λ_reg*reg

返回: {predictions, losses, positive_labels}
```

---

### 2.2 推理阶段（inference）

```
输入: batch_dict (同训练)

步骤1-2: BEV编码 + 获取锚点（同训练）

步骤3: 获取推理时间步
    TopoDiffScheduler.get_inference_timesteps()
    → [T_infer_init=8, 4, 0]

步骤4: 初始化小噪声
    init_timestep = torch.full((B,), 8)
    current_graphs = _add_noise_batch(anchor_graphs, init_timestep)
    V_norm = normalize_coords(current_graphs['V']) [B,K,N,2]

步骤5: 迭代去噪（2步DDIM）
    For t in [8, 4]:  # t=0不去噪
        │
        ├─ current_graphs['V'] = denormalize(V_norm)  # 解码器输入米制
        │
        ├─ predictions = decoder(current_graphs, t, bev_features)
        │   → V_pred [B,K,N,2] 米制
        │   → A_pred [B,K,N,N] 概率
        │
        ├─ V_pred_norm = normalize(V_pred)
        ├─ V_norm_flat = V_norm.reshape(B*K, N*2)
        ├─ V_pred_norm_flat = V_pred_norm.reshape(B*K, N*2)
        │
        ├─ DDIM step（归一化域）:
        │   V_prev_norm_flat = scheduler.step(
        │       model_output=V_pred_norm_flat,
        │       timestep=t,
        │       sample=V_norm_flat
        │   ).prev_sample
        │
        ├─ V_norm = V_prev_norm_flat.reshape(B,K,N,2)
        └─ A_current = (A_pred > 0.5).float()

步骤6: 最终解码（t=0）
    current_graphs['V'] = denormalize(V_norm)
    final_predictions = decoder(current_graphs, t=0, bev_features)

步骤7: 选择最佳锚点
    scores = final_predictions['scores'] [B,K]
    best_k = scores.argmax(dim=1) [B]
    best_predictions = {A[b,best_k], V[b,best_k], M[b,best_k]}

返回: best_predictions 或 final_predictions（所有K个）
```

---

## 三、潜在Bug与问题

### 🔴 高优先级问题

#### 1. GraphOutputHead: M_pred为占位零张量
**位置**: `cascade_graph_decoder.py` Line 520-523
```python
M_pred = torch.zeros(B, N * N, n_control - 2, 2, device=node_feats.device)
```
**问题**: 边级控制点未实现，几何细节无法学习
**影响**: 曲线平滑度、形状精度上限受限
**修复**: 实现边级回归头（基于pairwise特征），仅对A=1的边监督

#### 2. 推理时scheduler.timesteps未初始化可能导致DDIM step错误
**位置**: `topodiff_model.py` Line 222
```python
self.noise_scheduler.scheduler.timesteps = inference_timesteps
```
**问题**: 直接赋值绕过scheduler内部状态初始化，可能在某些diffusers版本不兼容
**影响**: DDIM step内部查找prev_timestep可能失败
**修复建议**: 在推理前显式调用一次`scheduler.set_timesteps(1000)`确保内部状态齐备；或在step调用时传入显式prev_timestep

#### 3. A的离散噪声未强制对称与零对角
**位置**: `diffusion_scheduler.py` Line 165-218
**问题**: mask/flip后可能产生A[i,j]≠A[j,i]或A[i,i]≠0
**影响**: 训练时见到非对称/有自环的噪声图，推理易产生结构错误
**修复**: 加噪后强制`A_noisy = (A_noisy + A_noisy.T)/2; A_noisy[diag]=0`

---

### ⚠️ 中优先级问题

#### 4. 图自注意力未使用拓扑稀疏性
**位置**: `cascade_graph_decoder.py` GraphDecoderLayer.forward
**问题**: 全连接MHA（仅padding mask），未用A_current或KNN作稀疏掩码
**影响**: 与"拓扑去噪"主张耦合度不够，O(N²)复杂度，可解释性弱
**优化**: 增加拓扑门控聚合分支`topo_agg = A @ node_feats`或稀疏attention_mask

#### 5. 锚点选择为硬匹配（不可微）
**位置**: `losses.py` Line 170, `graph_alignment.py`
**问题**: one-hot positive_labels通过Hungarian算法确定，梯度无法流入锚点选择
**影响**: 早期训练可能不稳，对锚点库偏置敏感
**优化**: 软分配`softmax(scores/τ)`对K个锚点加权损失；或温度退火策略

#### 6. BEV跨注意力采样偏移较小
**位置**: `cascade_graph_decoder.py` Line 385
```python
offsets = torch.tanh(offsets) * 0.1  # 小偏移
```
**问题**: 偏移范围受限（归一化域±0.1），可能覆盖不足
**优化**: 引入可学习的偏移范围或多尺度BEV采样

#### 7. 置信度head与max_nodes强绑定
**位置**: `cascade_graph_decoder.py` Line 488
```python
self.confidence_head = nn.Sequential(
    nn.Linear(embed_dims * max_nodes, embed_dims),
    ...
)
```
**问题**: 输入必须是`N*C`，当前N=20固定，变长图支持差
**优化**: 改为对节点维度做mean/max pooling再MLP

---

### 📝 低优先级 / 改进建议

#### 8. 损失函数M降权过低可能导致无梯度
**位置**: `losses.py` Line 204
```python
loss_geom += F.l1_loss(M_pred_valid, M_gt_valid) * 0.5 * 0.1
```
**说明**: 0.5 * lambda_M_factor=0.1 → 实际权重0.05，配合M_pred=zeros，实际梯度为0
**状态**: 符合MVP设计（先学V/A），但后续需提高权重

#### 9. 曲率正则为简化版本
**位置**: `losses.py` Line 311
```python
curvature = torch.norm(M_valid, dim=-1).mean()
```
**问题**: 仅计算控制点范数，非真实曲率（二阶导数）
**优化**: 实现Bezier曲线的可微二阶导数近似

#### 10. 锚点库构建依赖sklearn，未实现在线更新
**位置**: `anchor_library.py`
**问题**: 预训练一次固定，无法适应数据分布漂移
**优化**: 支持训练时动态调整锚点（如EMA更新）

#### 11. 推理未做多次采样稳定化
**位置**: `topodiff_model.py` inference
**优化**: 对初始噪声做2-3次不同随机采样，V/A概率平均（借鉴LaneDiffusion）

#### 12. 缺少A的后处理（推理时）
**优化**: 推理后强制对称、零对角、连通性检查、度阈值裁剪

---

## 四、数据维度一致性检查

### 关键张量形状追踪（无错误）

| 位置 | 张量 | 形状 | 说明 |
|------|------|------|------|
| BEV编码 | bev_features | [B,256,128,192] | ✓ 正确 |
| 锚点库 | anchor_graphs['A'] | [K,N,N] | ✓ K=8, N=20 |
| 加噪后 | noisy_graphs['V'] | [B,K,N,2] | ✓ 批量+锚点扩展 |
| 解码器输入 | V_noisy | [B*K,N,2] | ✓ reshape到批量 |
| 时间步 | timesteps训练 | [B] → [B*K] | ✓ 扩展正确 |
| 时间步 | timesteps推理 | [B*K] | ✓ torch.full生成 |
| 输出 | V_pred_list[i] | [B,K,N,2] | ✓ reshape回 |
| DDIM步 | V_norm_flat | [B*K, N*2] | ✓ 配合scheduler |
| 损失 | positive_labels | [B,K] | ✓ one-hot |

**未发现维度不匹配的bug**

---

## 五、代码完整性评估

### ✅ 已完整实现
- BEV编码与复用接口
- 锚点库构建（KMeans聚类+特征提取）
- 混合噪声（连续DDIM + 离散mask/flip）
- 级联图Transformer（4层+FiLM+深度监督）
- BEV变形跨注意力
- 图对齐与正锚点匹配
- 损失函数（分类+几何+拓扑+正则）
- 推理2步DDIM去噪
- SwanLab可视化集成

### ⚠️ 占位/简化实现
- M控制点预测（zeros占位）
- A的结构化约束（未强制对称/连通）
- 图自注意力稀疏性（全连接）
- 锚点软分配（硬one-hot）
- 变长图支持（固定max_nodes padding）

### ❌ 未实现
- Procrustes对齐（`graph_alignment.py` 标注TODO）
- 边特征M的对齐/重索引（标注TODO）
- 节点birth/death操作（变长生成）
- 多尺度BEV融合
- 推理多次采样集成

---

## 六、与LaneDiffusion对比总结

| 维度 | TopoDiff | LaneDiffusion |
|------|----------|---------------|
| 扩散域 | 图结构（V/M/A） | BEV特征 |
| 先验形式 | K=8锚点库 | LPIM先验注入BEV |
| 去噪步数 | 2步（t=8→4→0） | 15步 + 3次采样 |
| 训练范式 | 单阶段端到端 | 三阶段（LPIM→LPDM→Decoder） |
| 创新点 | 图域扩散+极限截断+锚点 | BEV特征级生成+ResShift |
| 速度 | 极快（2步） | 慢（45次UNet前向） |
| 当前精度 | 未验证（有短板） | 已验证（+4~6点） |
| 工程复杂度 | 低（代码简洁） | 高（三阶段+多模块） |

---

## 七、优先改进路线图

### Phase 1: 修复关键短板（1-2周）
1. ✅ 实现边级M回归（替换zeros）
2. ✅ A的对称/零对角约束（加噪后+损失）
3. ✅ 推理多次采样稳定化（2-3次）
4. ✅ 拓扑门控聚合分支（简易稀疏注意）

### Phase 2: nuScenes完整实验（2-3周）
5. ⏳ 锚点库构建与验证
6. ⏳ 完整训练24 epoch
7. ⏳ 评测GEO F1/TOPO F1/IoU等指标
8. ⏳ 与CGNet/LaneDiffusion对比

### Phase 3: 精度提升（可选）
9. ⏳ 锚点软分配/门控
10. ⏳ BEV先验分支（借鉴LPIM思想）
11. ⏳ 结构化拓扑约束（连通性/无交叉）
12. ⏳ 系统消融（K/T/步数/FiLM/深度监督）

---

## 八、结论

### 代码质量
- **架构清晰**：模块化设计，接口规范
- **实现完整**：核心训练/推理链路可用
- **工程友好**：单阶段训练，2步推理，速度优势明显

### 关键风险
- M占位影响几何精度
- A结构约束弱导致拓扑错误
- 缺少实验验证

### 推荐行动
优先修复Phase 1的4项（工作量小、收益大），立即启动nuScenes实验，以实验结果驱动后续优化方向。
