"""
SwanLab Logger for TopoDiff
Tracks training metrics, losses, and visualizations
"""

import torch
import numpy as np
from typing import Dict, Optional, Any
import matplotlib.pyplot as plt
import io
from PIL import Image

try:
    import swanlab
    SWANLAB_AVAILABLE = True
except ImportError:
    SWANLAB_AVAILABLE = False
    print("Warning: swanlab not installed. Install: pip install swanlab")


class SwanLabLogger:
    """
    SwanLab logger for TopoDiff training and evaluation.
    
    Logs:
    - Training/validation losses (total, cls, geom, topo, reg)
    - Learning rate
    - Anchor selection statistics
    - Graph topology visualizations
    - Hyperparameters
    """
    
    def __init__(
        self,
        project_name: str = "TopoDiff",
        experiment_name: Optional[str] = None,
        config: Optional[Dict] = None,
        enabled: bool = True,
        log_freq: int = 10,
        vis_freq: int = 100,
    ):
        """
        Args:
            project_name: SwanLab project name
            experiment_name: Experiment name (run name)
            config: Hyperparameters dict to log
            enabled: Whether to enable logging
            log_freq: Log metrics every N iterations
            vis_freq: Visualize graphs every N iterations
        """
        self.enabled = enabled and SWANLAB_AVAILABLE
        self.log_freq = log_freq
        self.vis_freq = vis_freq
        self.step = 0
        
        if self.enabled:
            # Initialize SwanLab
            swanlab.init(
                project=project_name,
                experiment_name=experiment_name,
                config=config,
            )
            print(f"✓ SwanLab initialized: {project_name}/{experiment_name}")
        else:
            if not SWANLAB_AVAILABLE:
                print("⚠ SwanLab not available. Metrics will not be logged.")
            else:
                print("⚠ SwanLab disabled.")
    
    def log_train_metrics(
        self,
        losses: Dict[str, torch.Tensor],
        lr: float,
        epoch: int,
        iteration: int,
        prefix: str = "train"
    ):
        """
        Log training metrics.
        
        Args:
            losses: Dict with loss components
            lr: Current learning rate
            epoch: Current epoch
            iteration: Current iteration
            prefix: Metric prefix (e.g., 'train', 'val')
        """
        if not self.enabled or iteration % self.log_freq != 0:
            return
        
        metrics = {
            f"{prefix}/loss": losses['loss'].item(),
            f"{prefix}/loss_cls": losses['loss_cls'].item(),
            f"{prefix}/loss_geom": losses['loss_geom'].item(),
            f"{prefix}/loss_topo": losses['loss_topo'].item(),
            f"{prefix}/loss_reg": losses['loss_reg'].item(),
            f"{prefix}/lr": lr,
            f"{prefix}/epoch": epoch,
        }
        
        swanlab.log(metrics, step=self.step)
        self.step += 1
    
    def log_val_metrics(
        self,
        losses: Dict[str, torch.Tensor],
        metrics: Dict[str, float],
        epoch: int,
    ):
        """
        Log validation metrics.
        
        Args:
            losses: Dict with loss components
            metrics: Dict with evaluation metrics (Precision, Recall, etc.)
            epoch: Current epoch
        """
        if not self.enabled:
            return
        
        log_dict = {
            "val/loss": losses['loss'].item(),
            "val/loss_cls": losses['loss_cls'].item(),
            "val/loss_geom": losses['loss_geom'].item(),
            "val/loss_topo": losses['loss_topo'].item(),
            "val/loss_reg": losses['loss_reg'].item(),
            "val/epoch": epoch,
        }
        
        # Add evaluation metrics
        for key, value in metrics.items():
            log_dict[f"val/{key}"] = value
        
        swanlab.log(log_dict, step=self.step)
    
    def log_anchor_stats(
        self,
        positive_labels: torch.Tensor,
        scores: torch.Tensor,
        iteration: int,
    ):
        """
        Log anchor selection statistics.
        
        Args:
            positive_labels: [B, K] positive anchor labels
            scores: [B, K] anchor confidence scores
            iteration: Current iteration
        """
        if not self.enabled or iteration % self.log_freq != 0:
            return
        
        # Anchor distribution (which anchors are selected)
        anchor_indices = positive_labels.argmax(dim=1).cpu().numpy()
        anchor_counts = np.bincount(anchor_indices, minlength=positive_labels.shape[1])
        
        # Score statistics
        scores_np = scores.detach().cpu().numpy()
        max_scores = scores_np.max(axis=1)
        score_gaps = scores_np.max(axis=1) - scores_np.mean(axis=1)
        
        metrics = {
            "anchor/entropy": -np.sum(anchor_counts / anchor_counts.sum() * 
                                     np.log(anchor_counts / anchor_counts.sum() + 1e-8)),
            "anchor/max_score_mean": max_scores.mean(),
            "anchor/score_gap_mean": score_gaps.mean(),
        }
        
        swanlab.log(metrics, step=self.step)
    
    def log_graph_visualization(
        self,
        gt_graph: Dict[str, torch.Tensor],
        pred_graph: Dict[str, torch.Tensor],
        iteration: int,
        num_samples: int = 4,
    ):
        """
        Visualize ground truth vs predicted graphs.
        
        Args:
            gt_graph: Ground truth graph dict
            pred_graph: Predicted graph dict
            iteration: Current iteration
            num_samples: Number of samples to visualize
        """
        if not self.enabled or iteration % self.vis_freq != 0:
            return
        
        # Create visualization
        fig = self._create_graph_comparison(gt_graph, pred_graph, num_samples)
        
        # Convert to image
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=100, bbox_inches='tight')
        buf.seek(0)
        img = Image.open(buf)
        
        swanlab.log({
            "visualization/graph_comparison": swanlab.Image(img)
        }, step=self.step)
        
        plt.close(fig)
        buf.close()
    
    def _create_graph_comparison(
        self,
        gt_graph: Dict[str, torch.Tensor],
        pred_graph: Dict[str, torch.Tensor],
        num_samples: int = 4,
    ):
        """
        Create side-by-side comparison of GT and predicted graphs.
        """
        B = min(num_samples, gt_graph['V'].shape[0])
        fig, axes = plt.subplots(B, 2, figsize=(12, 3*B))
        
        if B == 1:
            axes = axes.reshape(1, -1)
        
        for b in range(B):
            # Ground truth
            self._plot_single_graph(
                axes[b, 0],
                gt_graph['V'][b].cpu().numpy(),
                gt_graph['A'][b].cpu().numpy(),
                gt_graph['num_nodes'][b].item() if 'num_nodes' in gt_graph else None,
                title=f"GT Sample {b}"
            )
            
            # Prediction
            self._plot_single_graph(
                axes[b, 1],
                pred_graph['V'][b].cpu().numpy(),
                pred_graph['A'][b].cpu().numpy() if pred_graph['A'][b].dim() == 2 
                    else pred_graph['A'][b, 0].cpu().numpy(),  # Handle [B, K, N, N]
                pred_graph.get('num_nodes', [None])[b].item() if 'num_nodes' in pred_graph else None,
                title=f"Pred Sample {b}"
            )
        
        plt.tight_layout()
        return fig
    
    def _plot_single_graph(
        self,
        ax,
        V: np.ndarray,
        A: np.ndarray,
        num_nodes: Optional[int],
        title: str,
    ):
        """
        Plot a single graph (nodes + edges).
        """
        N = num_nodes if num_nodes is not None else V.shape[0]
        
        # Plot edges
        for i in range(N):
            for j in range(N):
                if A[i, j] > 0.5:
                    ax.plot([V[i, 0], V[j, 0]], [V[i, 1], V[j, 1]], 
                           'b-', alpha=0.5, linewidth=1)
        
        # Plot nodes
        ax.scatter(V[:N, 0], V[:N, 1], c='red', s=50, zorder=5)
        
        ax.set_xlim(-50, 50)
        ax.set_ylim(-35, 35)
        ax.set_aspect('equal')
        ax.grid(True, alpha=0.3)
        ax.set_title(title)
        ax.set_xlabel('X (m)')
        ax.set_ylabel('Y (m)')
    
    def log_hyperparameters(self, hparams: Dict[str, Any]):
        """Log hyperparameters."""
        if not self.enabled:
            return
        swanlab.config.update(hparams)
    
    def log_system_metrics(
        self,
        gpu_memory_mb: float,
        iteration_time_ms: float,
        iteration: int,
    ):
        """
        Log system metrics (GPU, timing).
        
        Args:
            gpu_memory_mb: GPU memory usage in MB
            iteration_time_ms: Time per iteration in ms
            iteration: Current iteration
        """
        if not self.enabled or iteration % self.log_freq != 0:
            return
        
        swanlab.log({
            "system/gpu_memory_mb": gpu_memory_mb,
            "system/iteration_time_ms": iteration_time_ms,
        }, step=self.step)
    
    def finish(self):
        """Finish logging and close SwanLab."""
        if self.enabled:
            swanlab.finish()
            print("✓ SwanLab logging finished.")
