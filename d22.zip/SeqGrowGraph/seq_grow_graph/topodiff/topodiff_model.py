"""
TopoDiff: Main model integrating all components
Truncated Diffusion for Lane Topology Generation
"""

import torch
import torch.nn as nn
from typing import Dict, List, Optional, Tuple
import numpy as np

from .anchor_library import AnchorLibrary
from .diffusion_scheduler import TopoDiffScheduler
from .cascade_graph_decoder import CascadeGraphDecoder
from .graph_alignment import GraphAlignment
from .losses import TopoDiffLoss
from .swanlab_logger import SwanLabLogger


class TopoDiff(nn.Module):
    """
    TopoDiff: Topology-Anchored Truncated Diffusion Model
    
    Inspired by DiffusionDrive's truncated diffusion policy:
    1. Build anchor library of K representative topology prototypes
    2. Add truncated noise to anchors (T_trunc << T)
    3. Learn to denoise in 2-3 steps with cascade graph decoder
    4. Select best anchor via classification + refinement
    """
    
    def __init__(
        self,
        # Anchor library
        num_anchors: int = 8,
        max_nodes: int = 20,
        n_control: int = 3,
        anchor_library_path: Optional[str] = None,
        
        # BEV encoder (reuse from SeqGrowGraph)
        bev_encoder: Optional[nn.Module] = None,
        bev_channels: int = 256,
        bev_h: int = 128,
        bev_w: int = 192,
        
        # Truncated diffusion (following DiffusionDrive)
        T_trunc: int = 50,  # Truncated forward steps
        T_infer_init: int = 8,  # Initial noise timestep for inference
        T_infer_steps: int = 2,  # Number of denoising steps
        
        # Decoder
        embed_dims: int = 256,
        num_decoder_layers: int = 4,
        num_heads: int = 8,
        
        # Loss
        lambda_cls: float = 1.0,
        lambda_geom: float = 1.0,
        lambda_topo: float = 1.5,
        lambda_reg: float = 0.1,
        lambda_M_factor: float = 0.1,
        
        # SwanLab logging
        use_swanlab: bool = False,
        swanlab_project: str = "TopoDiff",
        swanlab_experiment: Optional[str] = None,
    ):
        super().__init__()
        
        self.num_anchors = num_anchors
        self.max_nodes = max_nodes
        self.n_control = n_control
        self.T_trunc = T_trunc
        self.T_infer_init = T_infer_init
        self.T_infer_steps = T_infer_steps
        
        # 1. Anchor library
        self.anchor_library = AnchorLibrary(
            num_anchors=num_anchors,
            max_nodes=max_nodes,
            n_control=n_control,
        )
        if anchor_library_path:
            self.anchor_library.load(anchor_library_path)
        
        # 2. BEV encoder (reuse from SeqGrowGraph)
        self.bev_encoder = bev_encoder
        
        # 3. Diffusion scheduler (using diffusers.DDIMScheduler)
        self.noise_scheduler = TopoDiffScheduler(
            num_train_timesteps=1000,
            T_trunc=T_trunc,
            T_infer_init=T_infer_init,
            T_infer_steps=T_infer_steps,
        )
        
        # 4. Cascade graph decoder
        self.decoder = CascadeGraphDecoder(
            embed_dims=embed_dims,
            num_layers=num_decoder_layers,
            num_heads=num_heads,
            num_anchors=num_anchors,
            max_nodes=max_nodes,
            n_control=n_control,
            bev_h=bev_h,
            bev_w=bev_w,
        )
        
        # 5. Graph alignment (for finding positive anchor)
        self.graph_aligner = GraphAlignment(max_nodes=max_nodes)
        
        # 6. Loss function
        self.loss_fn = TopoDiffLoss(
            lambda_cls=lambda_cls,
            lambda_geom=lambda_geom,
            lambda_topo=lambda_topo,
            lambda_reg=lambda_reg,
            lambda_M_factor=lambda_M_factor,
        )
        
        # 7. SwanLab logger (optional)
        self.swanlab_logger = None
        if use_swanlab:
            config = {
                'num_anchors': num_anchors,
                'max_nodes': max_nodes,
                'T_trunc': T_trunc,
                'T_infer_init': T_infer_init,
                'T_infer_steps': T_infer_steps,
                'embed_dims': embed_dims,
                'num_decoder_layers': num_decoder_layers,
                'lambda_cls': lambda_cls,
                'lambda_geom': lambda_geom,
                'lambda_topo': lambda_topo,
                'lambda_M_factor': lambda_M_factor,
            }
            self.swanlab_logger = SwanLabLogger(
                project_name=swanlab_project,
                experiment_name=swanlab_experiment,
                config=config,
                enabled=True,
            )
        
    def forward(self, batch_dict: Dict) -> Dict:
        """
        Forward pass for training.
        
        Args:
            batch_dict: Dict with
                'img': Multi-view images for BEV encoding
                'gt_graphs': Ground truth graphs (A, V, M, num_nodes)
                'lidar2img': Camera calibration
                ... (other data needed by BEV encoder)
        
        Returns:
            Dict with predictions and losses
        """
        device = batch_dict['img'].device
        B = batch_dict['img'].shape[0]
        
        # 1. Encode BEV features (reuse from SeqGrowGraph)
        bev_features = self._encode_bev(batch_dict)  # [B, C, H, W]
        
        # 2. Get anchor graphs as tensors
        anchor_graphs = self.anchor_library.get_anchors_as_tensors(device)  # [K, ...]
        
        # 3. Sample random timesteps for training
        timesteps = self.noise_scheduler.get_train_timesteps(B, device)
        
        # 4. Add noise to anchors (broadcast for batch)
        noisy_graphs = self._add_noise_batch(anchor_graphs, timesteps, device)  # [B, K, ...]
        
        # 5. Forward through decoder
        predictions = self.decoder(
            graphs=noisy_graphs,
            timestep=timesteps,
            bev_features=bev_features,
        )
        
        # 6. Find positive anchors (closest to GT)
        gt_graphs = batch_dict['gt_graphs']
        positive_labels, _ = self.graph_aligner.batch_find_positive_anchors(
            gt_graphs, anchor_graphs
        )
        
        # 7. Compute loss
        losses = self.loss_fn(predictions, gt_graphs, positive_labels)
        
        return {
            'predictions': predictions,
            'losses': losses,
            'positive_labels': positive_labels,
        }
    
    def inference(
        self,
        batch_dict: Dict,
        return_all_anchors: bool = False,
        num_samples: int = 1,  # Number of sampling runs (1=deterministic, 2-3=ensemble)
    ) -> Dict:
        """
        Inference with truncated denoising (following DiffusionDrive).
        Supports multi-sampling for stability (inspired by LaneDiffusion).
        
        Args:
            batch_dict: Same as forward
            return_all_anchors: If True, return all K predictions; else only best
            num_samples: Number of sampling runs to average (1=single, 2-3=ensemble)
            
        Returns:
            Dict with final predictions
        """
        device = batch_dict['img'].device
        B = batch_dict['img'].shape[0]
        
        # 1. Encode BEV (once for all samples)
        bev_features = self._encode_bev(batch_dict)
        
        # 2. Get anchors
        anchor_graphs = self.anchor_library.get_anchors_as_tensors(device)
        K = anchor_graphs['A'].shape[0]
        
        # 3. Get inference timesteps (e.g., [8, 4, 0])
        inference_timesteps = self.noise_scheduler.get_inference_timesteps(device)
        # Initialize scheduler state for compatibility
        self.noise_scheduler.scheduler.set_timesteps(max(self.T_trunc, len(inference_timesteps)))
        # Override with custom truncated schedule
        self.noise_scheduler.scheduler.timesteps = inference_timesteps
        
        # Multi-sampling ensemble (for stability)
        all_V_preds = []
        all_A_preds = []
        all_M_preds = []
        all_scores = []
        
        for sample_idx in range(num_samples):
        
            # 4. Initialize with truncated noise (different random seed per sample)
            # Following DiffusionDrive: much smaller initial noise than training
            init_timestep = torch.full((B,), self.T_infer_init, device=device, dtype=torch.long)
            current_graphs = self._add_noise_batch(anchor_graphs, init_timestep, device)
        
            # Maintain normalized trajectory for DDIM stepping
            V_norm = self.noise_scheduler.normalize_coords(current_graphs['V'])  # [B, K, N, 2]
            
            # 5. Iterative denoising (operate in normalized coord space)
            for timestep in inference_timesteps:
                # Ensure scalar int for comparisons and torch.full
                t_int = int(timestep.item()) if isinstance(timestep, torch.Tensor) else int(timestep)
                if t_int == 0:
                    break  # Don't denoise at t=0
                
                # Denormalize current V for decoder input (decoder operates in meters)
                current_graphs['V'] = self.noise_scheduler.denormalize_coords(V_norm)
                
                # Predict clean graphs at time t
                predictions = self.decoder(
                    graphs=current_graphs,
                    timestep=torch.full((B * K,), t_int, device=device),
                    bev_features=bev_features,
                )
                
                # Use final layer predictions
                V_pred = predictions['V_pred']  # [B, K, N, 2] in meters
                A_pred = predictions['A_pred']  # [B, K, N, N]
                
                # Normalize predicted x0 for DDIM step
                V_pred_norm = self.noise_scheduler.normalize_coords(V_pred)  # [B, K, N, 2]
                V_norm_flat = V_norm.reshape(B * K, -1)  # [B*K, N*2] for scheduler
                V_pred_norm_flat = V_pred_norm.reshape(B * K, -1)  # [B*K, N*2]
                
                # Apply one DDIM step in normalized domain
                V_prev_norm_flat = self.noise_scheduler.step(
                    model_output=V_pred_norm_flat,
                    timestep=timestep,
                    sample=V_norm_flat
                ).prev_sample
                
                # Reshape back to [B, K, N, 2]
                N = V_norm.shape[2]
                V_norm = V_prev_norm_flat.reshape(B, K, N, 2)
                # Keep soft adjacency for the next step to preserve uncertainty
                current_graphs['A'] = A_pred
        
            # 6. Final prediction at t=0 (denormalize for decoder)
            current_graphs['V'] = self.noise_scheduler.denormalize_coords(V_norm)
            final_predictions = self.decoder(
                graphs=current_graphs,
                timestep=torch.zeros(B * K, device=device, dtype=torch.long),
                bev_features=bev_features,
            )
            
            # Post-process A_pred: zero diagonal only (directed graph)
            A_pred_final = final_predictions['A_pred']  # [B, K, N, N]
            A_pred_clean = A_pred_final.clone()
            for b in range(B):
                for k in range(K):
                    A_pred_clean[b, k].fill_diagonal_(0.0)
            
            # Store predictions from this sample
            all_V_preds.append(final_predictions['V_pred'])
            all_A_preds.append(A_pred_clean)
            all_M_preds.append(final_predictions['M_pred'])
            all_scores.append(final_predictions['scores'])
        
        # 7. Ensemble: average predictions across samples
        V_pred_ensemble = torch.stack(all_V_preds).mean(dim=0)  # [B, K, N, 2]
        A_pred_ensemble = torch.stack(all_A_preds).mean(dim=0)  # [B, K, N, N] (probabilities)
        M_pred_ensemble = torch.stack(all_M_preds).mean(dim=0)  # [B, K, E, nc-2, 2]
        scores_ensemble = torch.stack(all_scores).mean(dim=0)  # [B, K]
        
        # Zero diagonal only after averaging (directed graph)
        for b in range(B):
            for k in range(K):
                A_pred_ensemble[b, k].fill_diagonal_(0.0)
        
        # Construct ensemble predictions
        ensemble_predictions = {
            'V_pred': V_pred_ensemble,
            'A_pred': A_pred_ensemble,
            'M_pred': M_pred_ensemble,
            'scores': scores_ensemble,
        }
        
        # 8. Select best anchor (highest score)
        best_indices = scores_ensemble.argmax(dim=1)  # [B]
        
        if return_all_anchors:
            return ensemble_predictions
        else:
            # Extract best prediction per batch
            best_predictions = {
                'A': torch.stack([ensemble_predictions['A_pred'][b, best_indices[b]] 
                                 for b in range(B)]),
                'V': torch.stack([ensemble_predictions['V_pred'][b, best_indices[b]] 
                                 for b in range(B)]),
                'M': torch.stack([ensemble_predictions['M_pred'][b, best_indices[b]] 
                                 for b in range(B)]),
                'scores': scores_ensemble,
                'best_indices': best_indices,
            }
            return best_predictions
    
    def _encode_bev(self, batch_dict: Dict) -> torch.Tensor:
        """
        Encode BEV features using provided encoder.
        If no encoder, return dummy features for testing.
        """
        if self.bev_encoder is not None:
            return self.bev_encoder(batch_dict)
        else:
            # Dummy BEV for testing
            B = batch_dict['img'].shape[0]
            device = batch_dict['img'].device
            return torch.randn(B, 256, 128, 192, device=device)
    
    def _add_noise_batch(
        self,
        anchor_graphs: Dict[str, torch.Tensor],
        timesteps: torch.Tensor,
        device: str = 'cuda',
    ) -> Dict[str, torch.Tensor]:
        """
        Add noise to anchors for a batch.
        Anchor_graphs: [K, ...], timesteps: [B]
        Output: [B, K, ...]
        """
        B = timesteps.shape[0]
        K = anchor_graphs['A'].shape[0]
        
        # Expand anchors to batch [B, K, ...]
        anchor_graphs_batch = {
            k: v.unsqueeze(0).repeat(B, 1, *([1] * (v.dim() - 1)))
            for k, v in anchor_graphs.items()
        }
        
        # Expand timesteps to [B, K] (same timestep for all anchors in a batch)
        timesteps_expanded = timesteps.unsqueeze(1).repeat(1, K)  # [B, K]
        timesteps_flat = timesteps_expanded.reshape(-1)  # [B*K]
        
        # Flatten to [B*K, ...] for noise addition
        graphs_flat = {
            'A': anchor_graphs_batch['A'].reshape(B * K, *anchor_graphs_batch['A'].shape[2:]),
            'V': anchor_graphs_batch['V'].reshape(B * K, *anchor_graphs_batch['V'].shape[2:]),
            'M': anchor_graphs_batch['M'].reshape(B * K, *anchor_graphs_batch['M'].shape[2:]),
            'num_nodes': anchor_graphs_batch['num_nodes'].reshape(B * K),
            'num_edges': anchor_graphs_batch['num_edges'].reshape(B * K),
        }
        
        # Add noise
        noisy_flat = self.noise_scheduler.add_noise_to_graphs(
            graphs_flat,
            timesteps_flat,
            device=device
        )
        
        # Reshape back to [B, K, ...]
        noisy_batch = {
            'A': noisy_flat['A'].reshape(B, K, *noisy_flat['A'].shape[1:]),
            'V': noisy_flat['V'].reshape(B, K, *noisy_flat['V'].shape[1:]),
            'M': noisy_flat['M'].reshape(B, K, *noisy_flat['M'].shape[1:]),
            'num_nodes': noisy_flat['num_nodes'].reshape(B, K),
            'num_edges': noisy_flat['num_edges'].reshape(B, K),
        }
        
        return noisy_batch
    
    def build_anchor_library(
        self,
        dataset: List[Dict],
        save_path: str,
    ):
        """
        Build anchor library from training dataset.
        Should be called before training.
        """
        print("Building anchor library...")
        self.anchor_library.build_from_dataset(dataset, save_path)
        print(f"Anchor library saved to {save_path}")
