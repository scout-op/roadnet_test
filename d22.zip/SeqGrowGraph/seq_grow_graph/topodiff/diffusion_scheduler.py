"""
Diffusion Scheduler wrapper for TopoDiff
Uses standard diffusers.DDIMScheduler for better stability
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, Optional

try:
    from diffusers.schedulers import DDIMScheduler
    DIFFUSERS_AVAILABLE = True
except ImportError:
    DIFFUSERS_AVAILABLE = False
    print("Warning: diffusers not installed. Please install: pip install diffusers")


class TopoDiffScheduler:
    """
    Wrapper around diffusers.DDIMScheduler for TopoDiff.
    Handles mixed continuous (V, M) and discrete (A) data.
    """
    
    def __init__(
        self,
        num_train_timesteps: int = 1000,
        T_trunc: int = 50,  # Truncated steps (following DiffusionDrive)
        T_infer_init: int = 8,  # Initial noise timestep for inference
        T_infer_steps: int = 2,  # Number of denoising steps
        beta_schedule: str = "scaled_linear",
        beta_start: float = 0.0001,
        beta_end: float = 0.02,
        # Discrete adjacency matrix A
        adjacency_mask_prob: float = 0.15,
        adjacency_flip_prob: float = 0.05,
    ):
        """
        Args:
            num_train_timesteps: Total diffusion steps (DDIM standard: 1000)
            T_trunc: Truncated steps for training (0-50)
            T_infer_init: Initial timestep for inference (e.g., 8)
            T_infer_steps: Number of denoising steps (e.g., 2)
            beta_schedule: 'linear' or 'scaled_linear'
            adjacency_mask_prob: Masking probability for adjacency matrix
            adjacency_flip_prob: Flip probability for edges
        """
        if not DIFFUSERS_AVAILABLE:
            raise ImportError("diffusers is required. Install: pip install diffusers")
        
        self.num_train_timesteps = num_train_timesteps
        self.T_trunc = T_trunc
        self.T_infer_init = T_infer_init
        self.T_infer_steps = T_infer_steps
        self.adjacency_mask_prob = adjacency_mask_prob
        self.adjacency_flip_prob = adjacency_flip_prob
        
        # BEV coordinate bounds for normalization (following DiffusionDrive)
        # x: [-48, 48], y: [-32, 32]
        self.x_bound = [-48.0, 48.0]
        self.y_bound = [-32.0, 32.0]
        
        # Initialize DDIM scheduler
        self.scheduler = DDIMScheduler(
            num_train_timesteps=num_train_timesteps,
            beta_start=beta_start,
            beta_end=beta_end,
            beta_schedule=beta_schedule,
            prediction_type="sample",  # Predict x0 directly
            clip_sample=False,  # Don't clip (we handle ourselves)
        )
    
    def normalize_coords(self, coords: torch.Tensor) -> torch.Tensor:
        """
        Normalize coordinates to [-1, 1] for stable diffusion.
        Args:
            coords: [..., 2] with (x, y) in meters
        Returns:
            normalized: [..., 2] in [-1, 1]
        """
        x = coords[..., 0:1]
        y = coords[..., 1:2]
        
        # Normalize to [-1, 1]
        x_norm = 2 * (x - self.x_bound[0]) / (self.x_bound[1] - self.x_bound[0]) - 1
        y_norm = 2 * (y - self.y_bound[0]) / (self.y_bound[1] - self.y_bound[0]) - 1
        
        return torch.cat([x_norm, y_norm], dim=-1)
    
    def denormalize_coords(self, coords_norm: torch.Tensor) -> torch.Tensor:
        """
        Denormalize coordinates from [-1, 1] back to meters.
        Args:
            coords_norm: [..., 2] in [-1, 1]
        Returns:
            coords: [..., 2] in meters
        """
        x_norm = coords_norm[..., 0:1]
        y_norm = coords_norm[..., 1:2]
        
        # Denormalize from [-1, 1]
        x = (x_norm + 1) / 2 * (self.x_bound[1] - self.x_bound[0]) + self.x_bound[0]
        y = (y_norm + 1) / 2 * (self.y_bound[1] - self.y_bound[0]) + self.y_bound[0]
        
        return torch.cat([x, y], dim=-1)
    
    def add_noise(
        self,
        original_samples: torch.Tensor,
        noise: torch.Tensor,
        timesteps: torch.Tensor,
    ) -> torch.Tensor:
        """
        Add noise using DDIM forward process.
        For continuous data (V, M).
        """
        return self.scheduler.add_noise(original_samples, noise, timesteps)
    
    def add_noise_to_graphs(
        self,
        graphs: Dict[str, torch.Tensor],
        timesteps: torch.Tensor,
        device: str = 'cuda'
    ) -> Dict[str, torch.Tensor]:
        """
        Add truncated noise to graphs (training).
        
        Args:
            graphs: Dict with 'A', 'V', 'M', 'num_nodes', 'num_edges'
            timesteps: [B] or [B*K] timesteps in [0, T_trunc]
        """
        # Continuous: V, M
        V_clean = graphs['V']
        M_clean = graphs['M']
        
        # Normalize coordinates to [-1, 1] before adding noise
        V_clean_norm = self.normalize_coords(V_clean)
        M_clean_norm = self.normalize_coords(M_clean)
        
        noise_V = torch.randn_like(V_clean_norm)
        noise_M = torch.randn_like(M_clean_norm)
        
        V_noisy_norm = self.scheduler.add_noise(V_clean_norm, noise_V, timesteps)
        M_noisy_norm = self.scheduler.add_noise(M_clean_norm, noise_M, timesteps)
        
        # Denormalize back to meters
        V_noisy = self.denormalize_coords(V_noisy_norm)
        M_noisy = self.denormalize_coords(M_noisy_norm)
        
        # Discrete: A (structured noise)
        A_noisy = self._add_discrete_noise(
            graphs['A'],
            timesteps,
            graphs['num_nodes']
        )
        
        return {
            'A': A_noisy,
            'V': V_noisy,
            'M': M_noisy,
            'num_nodes': graphs['num_nodes'],
            'num_edges': graphs['num_edges'],
        }
    
    def _add_discrete_noise(
        self,
        A: torch.Tensor,
        timesteps: torch.Tensor,
        num_nodes: torch.Tensor,
    ) -> torch.Tensor:
        """
        Add structured noise to adjacency matrix.
        Noise level scales with timestep.
        """
        device = A.device
        shape = A.shape
        
        # Flatten if batched with anchors [B, K, N, N] -> [B*K, N, N]
        if A.dim() == 4:
            B, K, N, _ = A.shape
            A = A.reshape(B * K, N, N)
            num_nodes = num_nodes.reshape(-1)
            is_batched_anchors = True
        else:
            B, N, _ = A.shape
            is_batched_anchors = False
        
        A_noisy = A.clone()
        
        # Scale noise by timestep (normalized to [0, 1])
        t_normalized = timesteps.float() / self.T_trunc
        
        for i in range(len(A_noisy)):
            n = num_nodes[i].item()
            if n == 0:
                continue
            
            t_scale = t_normalized[i].item()
            mask_prob = self.adjacency_mask_prob * t_scale
            flip_prob = self.adjacency_flip_prob * t_scale
            
            # Valid region mask
            valid_mask = torch.zeros(N, N, device=device, dtype=torch.bool)
            valid_mask[:n, :n] = True
            
            # Masking (set to 0.5 for uncertainty)
            mask = (torch.rand(N, N, device=device) < mask_prob) & valid_mask
            A_noisy[i][mask] = 0.5
            
            # Structured flip
            flip_mask = (torch.rand(N, N, device=device) < flip_prob) & valid_mask
            A_noisy[i][flip_mask] = 1.0 - A_noisy[i][flip_mask]
        
        # Enforce zero diagonal (no self-loops) after noise (directed graph)
        for i in range(len(A_noisy)):
            A_noisy[i].fill_diagonal_(0.0)
        
        # Reshape back if needed
        if is_batched_anchors:
            A_noisy = A_noisy.reshape(B, K, N, N)
        
        return A_noisy
    
    def step(
        self,
        model_output: torch.Tensor,
        timestep: int,
        sample: torch.Tensor,
    ):
        """
        DDIM denoising step for continuous data.
        """
        return self.scheduler.step(model_output, timestep, sample)
    
    def get_inference_timesteps(self, device='cuda'):
        """
        Get timestep schedule for inference.
        Following DiffusionDrive: start from T_infer_init, denoise T_infer_steps times.
        
        Example: T_infer_init=8, T_infer_steps=2 -> [8, 4, 0]
        """
        # Note: we don't rely on scheduler.timesteps for custom truncated schedule
        step_size = self.T_infer_init / max(self.T_infer_steps, 1)
        values = [max(int(round(self.T_infer_init - i * step_size)), 0) for i in range(self.T_infer_steps + 1)]
        # Ensure starts at T_infer_init and ends with 0
        if values[0] != int(self.T_infer_init):
            values[0] = int(self.T_infer_init)
        if values[-1] != 0:
            values[-1] = 0
        return torch.tensor(values, device=device, dtype=torch.long)
    
    def get_train_timesteps(self, batch_size: int, device='cuda'):
        """
        Sample random timesteps for training (0 to T_trunc).
        """
        return torch.randint(0, self.T_trunc, (batch_size,), device=device, dtype=torch.long)
