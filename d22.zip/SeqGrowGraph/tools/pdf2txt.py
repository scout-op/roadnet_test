import sys
import fitz  # PyMuPDF


def main():
    if len(sys.argv) < 2:
        print("Usage: python tools/pdf2txt.py <pdf_path> [out_txt]")
        sys.exit(1)
    pdf_path = sys.argv[1]
    out_path = sys.argv[2] if len(sys.argv) > 2 else pdf_path + ".txt"

    doc = fitz.open(pdf_path)
    with open(out_path, "w", encoding="utf-8") as f:
        for i, page in enumerate(doc):
            text = page.get_text("text")
            f.write(f"\n\n===== Page {i+1} =====\n")
            f.write(text)
    print(f"Saved text to {out_path}")


if __name__ == "__main__":
    main()
