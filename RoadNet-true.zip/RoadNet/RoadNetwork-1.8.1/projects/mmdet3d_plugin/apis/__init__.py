# Copyright (c) OpenMMLab. All rights reserved.
from .train import train_model

__all__ = [
    'train_model'
]
