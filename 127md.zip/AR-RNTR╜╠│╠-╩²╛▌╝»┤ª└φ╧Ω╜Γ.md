# AR-RNTR数据集处理详解 🗂️

> 从原始标注到训练序列的完整流程

---

## 目录
1. 数据集整体架构
2. 数据加载流程
3. 道路网络标注格式
4. 序列转换过程
5. 数据增强策略
6. 实际代码示例

---

## 1. 数据集整体架构

### 1.1 数据集类

```python
# centerline_nuscenes_dataset.py L16-57

@DATASETS.register_module()
class CenterlineNuScenesDataset(BaseDataset):
    """nuScenes道路中心线数据集
    
    继承自MMEngine的BaseDataset，添加：
    - 相机内外参数
    - 道路网络标注
    - BEV网格配置
    """
    
    def __init__(self,
                 ann_file,              # 标注文件路径
                 pipeline=None,         # 数据处理流水线
                 data_root=None,        # 数据根目录
                 grid_conf=None,        # BEV网格配置
                 bz_grid_conf=None,     # 贝塞尔曲线网格配置
                 landmark_thresholds=[1, 3, 5, 8, 10],
                 reach_thresholds=[1, 2, 3, 4, 5],
                 **kwargs):
        
        # 网格配置（用于坐标离散化）
        self.grid_conf = grid_conf
        self.bz_grid_conf = bz_grid_conf
        self.interval = grid_conf['xbound'][-1]  # 分辨率0.5米
        
        # 评估阈值
        self.landmark_thresholds = landmark_thresholds
        self.reach_thresholds = reach_thresholds
```

**关键参数**：
- `grid_conf`：定义BEV网格范围和分辨率
- `bz_grid_conf`：定义贝塞尔曲线的坐标范围
- `pipeline`：定义数据处理步骤（见下文）

---

## 2. 数据加载流程

### 2.1 Pipeline（数据处理流水线）

```python
# 配置文件中的pipeline定义

train_pipeline = [
    # Step 1: 加载多视角图片
    dict(
        type='OrgLoadMultiViewImageFromFiles',
        to_float32=False,
        color_type='color'
    ),
    
    # Step 2: 加载道路中心线标注
    dict(
        type='LoadNusOrderedBzCenterline',  # 加载有序的贝塞尔中心线
        data_root='data/nuscenes/',
        xbound=[-55.0, 55.0, 0.5],  # BEV范围
        ybound=[-55.0, 55.0, 0.5],
        n_control=3,  # 贝塞尔控制点数（3=二次曲线）
        n_seg=20      # 每条线段采样点数
    ),
    
    # Step 3: 数据增强
    dict(
        type='GlobalRotScaleTrans',
        resize_lim=(0.9, 1.1),
        rot_lim=(-45, 45),
        trans_lim=0.0
    ),
    
    # Step 4: 格式化为模型输入
    dict(
        type='PackDetInputs',
        keys=['img', 'centerline_coord', 'centerline_label', 
              'centerline_connect', 'centerline_coeff']
    )
]
```

### 2.2 数据流图解

```
原始数据（pkl文件）
    ↓
┌────────────────────────────────┐
│ load_data_list()               │
│ 读取所有样本元信息              │
└────────────┬───────────────────┘
             ↓
┌────────────────────────────────┐
│ Pipeline Transform 1           │
│ LoadMultiViewImageFromFiles    │
│ 加载6个相机图片                 │
└────────────┬───────────────────┘
             ↓
       results['img'] = [img1, img2, ..., img6]
             ↓
┌────────────────────────────────┐
│ Pipeline Transform 2           │
│ LoadNusOrderedBzCenterline     │
│ 加载道路网络标注                │
└────────────┬───────────────────┘
             ↓
       results['centerline_coord'] = [[x1,y1], [x2,y2], ...]
       results['centerline_label'] = [0, 1, 1, ...]
       results['centerline_connect'] = [0, 0, 1, ...]
       results['centerline_coeff'] = [[cx1,cy1], ...]
             ↓
┌────────────────────────────────┐
│ Pipeline Transform 3           │
│ GlobalRotScaleTrans (数据增强) │
└────────────┬───────────────────┘
             ↓
       增强后的坐标和图片
             ↓
┌────────────────────────────────┐
│ Pipeline Transform 4           │
│ PackDetInputs (打包)           │
└────────────┬───────────────────┘
             ↓
       batch_data (送入模型)
```

---

## 3. 道路网络标注格式

### 3.1 原始标注（JSON格式）

```json
{
  "token": "scene_000123",
  "centerlines": [
    {
      "node_id": 0,
      "position": [10.5, 20.3],
      "type": "Start",           // 起点
      "parents": [],
      "children": [1],
      "control_point": null
    },
    {
      "node_id": 1,
      "position": [15.2, 30.1],
      "type": "Continue",         // 延续点
      "parents": [0],
      "children": [2, 3],         // 两个子节点（分叉）
      "control_point": [12.8, 25.2]  // 贝塞尔控制点
    },
    {
      "node_id": 2,
      "position": [20.0, 40.0],
      "type": "Continue",
      "parents": [1],
      "children": [],
      "control_point": [17.5, 35.0]
    },
    {
      "node_id": 3,
      "position": [18.0, 25.0],
      "type": "Fork",             // 分叉点
      "parents": [1],
      "children": [],
      "control_point": [16.5, 27.5]
    }
  ]
}
```

### 3.2 图结构表示

```
原始图（DAG）：
    Node0 (10.5, 20.3) [Start]
      ↓ control=(12.8, 25.2)
    Node1 (15.2, 30.1) [Continue]
     ↙  ↘
   /      \
  ↓        ↓ control=(16.5, 27.5)
Node2     Node3 (18.0, 25.0) [Fork]
(20,40)
```

---

## 4. 序列转换过程

### 4.1 DAG → 有向森林（树）

**问题**：图可能有merge-point（多个父节点）

**解决**：
1. DFS遍历图
2. 遇到merge-point时，复制节点
3. 标记为Clone类型

```python
# centerline_utils.py 中的核心逻辑

class LaneGraph:
    def __sequelize__(self):
        """将DAG转换成序列"""
        start_nodes = self.find_start_nodes()
        visited = [False] * len(self.nodes_list)
        visit_count = [0] * len(self.nodes_list)
        
        result = []
        for start_node in start_nodes:
            result += self.dfs_sequelize(
                start_node, visited, visit_count
            )
        return result
    
    def dfs_sequelize(self, node_idx, visited, visit_count):
        """DFS生成序列"""
        node = self.nodes_list[node_idx]
        visit_count[node_idx] += 1
        
        # 第一次访问：标记为正常类型
        if visit_count[node_idx] == 1:
            node_type = self.get_node_type(node_idx)
        # 第二次访问：标记为Clone
        else:
            node_type = 'Clone'
        
        # 记录节点信息
        seq_node = {
            'sque_index': len(result) + 1,
            'coord': node.position,
            'sque_type': node_type,
            'fork_from': self.get_fork_from(node_idx),
            'merge_with': self.get_merge_with(node_idx),
            'coeff': self.get_control_point(node_idx)
        }
        
        result = [seq_node]
        
        # 递归处理子节点
        for child_idx in node.children:
            result += self.dfs_sequelize(
                child_idx, visited, visit_count
            )
        
        return result
```

### 4.2 节点序列 → 整数序列

```python
# loading.py L1461+ 中的LoadNusOrderedBzCenterline

@TRANSFORMS.register_module()
class LoadNusOrderedBzCenterline:
    def __call__(self, results):
        """加载并转换道路中心线"""
        # Step 1: 读取标注文件
        token = results['sample_idx']
        ann_path = os.path.join(
            self.data_root, 
            f'maps/{token}_centerline.json'
        )
        with open(ann_path, 'r') as f:
            centerline_data = json.load(f)
        
        # Step 2: 构建图结构
        lane_graph = self.build_lane_graph(centerline_data)
        
        # Step 3: 转换成有序序列
        ordered_graph = NusOrederedBzCenterLine(
            lane_graph,
            self.xbound,
            self.ybound,
            self.n_control
        )
        
        # Step 4: 生成整数序列
        seq = ordered_graph.get_seq()
        # seq格式: [node1_6ints, node2_6ints, ...]
        
        # Step 5: 拆分成不同的字段
        centerline_coord = []
        centerline_label = []
        centerline_connect = []
        centerline_coeff = []
        
        for i in range(0, len(seq), 6):
            x, y, label, connect, coeff_x, coeff_y = seq[i:i+6]
            
            centerline_coord.append([x, y])
            centerline_label.append(label)
            centerline_connect.append(connect)
            centerline_coeff.append([coeff_x, coeff_y])
        
        # Step 6: 存入results
        results['centerline_coord'] = centerline_coord
        results['centerline_label'] = centerline_label
        results['centerline_connect'] = centerline_connect
        results['centerline_coeff'] = centerline_coeff
        results['n_control'] = self.n_control
        
        return results
```

### 4.3 坐标离散化

```python
def discretize_coordinates(coord, xbound, ybound):
    """将真实坐标离散化到整数网格
    
    Args:
        coord: [x, y] 真实坐标（米）
        xbound: [min, max, resolution]
        ybound: [min, max, resolution]
    
    Returns:
        [x_int, y_int] 整数坐标 [0, 199]
    """
    x_real, y_real = coord
    
    # 计算网格索引
    x_min, x_max, x_res = xbound
    y_min, y_max, y_res = ybound
    
    x_int = int((x_real - x_min) / x_res)
    y_int = int((y_real - y_min) / y_res)
    
    # 限制范围
    x_int = np.clip(x_int, 0, int((x_max - x_min) / x_res) - 1)
    y_int = np.clip(y_int, 0, int((y_max - y_min) / y_res) - 1)
    
    return [x_int, y_int]

# 示例
xbound = [-55.0, 55.0, 0.5]  # -55到55米，分辨率0.5米
ybound = [-55.0, 55.0, 0.5]

# 真实坐标 (10.7m, 20.3m)
coord_real = [10.7, 20.3]

# 离散化
coord_int = discretize_coordinates(coord_real, xbound, ybound)
# 结果: [131, 150]
# 因为: (10.7 - (-55)) / 0.5 = 131.4 → 131
#       (20.3 - (-55)) / 0.5 = 150.6 → 150
```

### 4.4 完整示例

```
原始标注：
  Node0: pos=(10.7, 20.3), type=Start
  Node1: pos=(15.2, 30.1), type=Continue, parent=0, ctrl=(12.8, 25.2)
  Node2: pos=(20.0, 40.0), type=Continue, parent=1, ctrl=(17.5, 35.0)

Step 1: 坐标离散化
  Node0: [131, 150]  # (10.7+55)/0.5, (20.3+55)/0.5
  Node1: [140, 170]
  Node2: [150, 190]
  ctrl1: [135, 160]
  ctrl2: [145, 180]

Step 2: 类型编码
  Start=0 → 200
  Continue=1 → 201

Step 3: 连接索引
  Node0: 无父节点 → 0 → 250
  Node1: 连接Node0 → 0 → 250
  Node2: 连接Node1 → 1 → 251

Step 4: 系数编码（加10避免负数）
  ctrl1: [135, 160] → [145, 170] → [495, 520]  # +10 +350
  ctrl2: [145, 180] → [155, 190] → [505, 540]

Step 5: 组装序列
  [131, 150, 200, 250, 0, 0,       ← Node0（Start无系数）
   140, 170, 201, 250, 495, 520,   ← Node1
   150, 190, 201, 251, 505, 540]   ← Node2
```

---

## 5. 数据增强策略

### 5.1 几何变换

```python
@TRANSFORMS.register_module()
class GlobalRotScaleTrans:
    """全局旋转、缩放、平移增强"""
    
    def __call__(self, results):
        # 随机旋转角度
        rot_angle = np.random.uniform(
            self.rot_lim[0], self.rot_lim[1]
        )  # 例如：-45° to 45°
        
        # 随机缩放比例
        scale = np.random.uniform(
            self.resize_lim[0], self.resize_lim[1]
        )  # 例如：0.9 to 1.1
        
        # 应用到坐标
        coords = np.array(results['centerline_coord'])
        
        # 旋转
        rot_matrix = np.array([
            [np.cos(rot_angle), -np.sin(rot_angle)],
            [np.sin(rot_angle),  np.cos(rot_angle)]
        ])
        coords = coords @ rot_matrix.T
        
        # 缩放
        coords = coords * scale
        
        # 更新results
        results['centerline_coord'] = coords.tolist()
        
        # 同样应用到贝塞尔系数
        coeffs = np.array(results['centerline_coeff'])
        coeffs = (coeffs @ rot_matrix.T) * scale
        results['centerline_coeff'] = coeffs.tolist()
        
        return results
```

### 5.2 序列噪声填充（Synthetic Noise Objects）

```python
# 在ar_rntr.py的forward_pts_train中

# 真实节点数
num_real_nodes = len(gt_lines_coords[bi])

# 填充到固定长度
num_box = max(num_real_nodes + 2, self.max_box_num)  # 180

# 生成噪声节点
num_noise = num_box - num_real_nodes

random_coords = torch.rand(num_noise, 2) * 199
random_labels = torch.randint(0, 4, (num_noise,)) + 200
random_connects = torch.randint(0, num_box, (num_noise,)) + 250
random_coeffs = torch.rand(num_noise, 2) * 199 + 350

# 拼接：[真实节点] + [噪声节点]
input_seq = torch.cat([real_nodes, noise_nodes], dim=0)
```

---

## 6. 实际代码示例

### 6.1 完整的数据加载示例

```python
from mmdet3d.datasets import build_dataset

# 数据集配置
dataset_config = dict(
    type='CenterlineNuScenesDataset',
    data_root='data/nuscenes/',
    ann_file='data/nuscenes/nuscenes_infos_train.pkl',
    pipeline=[
        dict(type='OrgLoadMultiViewImageFromFiles'),
        dict(
            type='LoadNusOrderedBzCenterline',
            xbound=[-55.0, 55.0, 0.5],
            ybound=[-55.0, 55.0, 0.5],
            n_control=3
        ),
        dict(
            type='GlobalRotScaleTrans',
            rot_lim=(-45, 45),
            resize_lim=(0.9, 1.1)
        ),
        dict(
            type='PackDetInputs',
            keys=['img', 'centerline_coord', 'centerline_label',
                  'centerline_connect', 'centerline_coeff']
        )
    ],
    test_mode=False
)

# 构建数据集
dataset = build_dataset(dataset_config)

# 获取一个样本
data = dataset[0]

print(f"图片数量: {len(data['img'])}")
print(f"节点坐标: {data['centerline_coord'][:3]}")  # 前3个节点
print(f"节点类型: {data['centerline_label'][:3]}")
print(f"连接索引: {data['centerline_connect'][:3]}")
print(f"曲线系数: {data['centerline_coeff'][:3]}")
```

### 6.2 数据统计分析

```python
# 分析数据集的节点类型分布

from collections import Counter

all_labels = []
for i in range(len(dataset)):
    data = dataset[i]
    all_labels.extend(data['centerline_label'])

label_counts = Counter(all_labels)
total = len(all_labels)

print("节点类型分布:")
print(f"  Ancestor (0): {label_counts[0]} ({100*label_counts[0]/total:.1f}%)")
print(f"  Lineal   (1): {label_counts[1]} ({100*label_counts[1]/total:.1f}%)")
print(f"  Offshoot (2): {label_counts[2]} ({100*label_counts[2]/total:.1f}%)")
print(f"  Clone    (3): {label_counts[3]} ({100*label_counts[3]/total:.1f}%)")

# 输出示例:
# 节点类型分布:
#   Ancestor (0): 1860 (18.6%)
#   Lineal   (1): 6030 (60.3%)
#   Offshoot (2):  640 ( 6.4%)
#   Clone    (3): 1470 (14.7%)
```

---

## 7. 数据格式总结

### 7.1 输入输出对照表

| 阶段 | 格式 | 示例 |
|------|------|------|
| **原始标注** | JSON图结构 | `{nodes: [...], edges: [...]}` |
| **加载后** | Python列表 | `coord=[[10,20], [15,30]]` |
| **离散化后** | 整数列表 | `coord=[[131,150], [140,170]]` |
| **训练输入** | Tensor | `coord=tensor([[131,150], ...])` |
| **模型输入序列** | 1D Tensor | `[572, 131, 150, 200, ...]` |

### 7.2 关键转换公式

```python
# 坐标离散化
x_int = int((x_real - x_min) / resolution)

# 类型编码
token_type = type_id + 200  # 0-3 → 200-203

# 连接编码
token_connect = parent_idx + 250  # 索引 → 250+

# 系数编码
token_coeff = int(coeff_real + 10) + 350  # 加10避免负数
```

---

## 小结

✅ **数据集类**：继承BaseDataset，管理标注加载  
✅ **Pipeline**：多步骤数据处理流水线  
✅ **DAG转换**：图 → 树 → 序列  
✅ **离散化**：实数坐标 → 整数网格  
✅ **数据增强**：旋转、缩放、噪声填充  
✅ **4种类型**：通过DFS遍历自动标注

这套数据处理流程保证了：
1. 道路网络的拓扑结构不丢失
2. 坐标精度满足需求（0.5米分辨率）
3. 序列长度可控（填充到固定长度）
4. 训练更稳定（数据增强+类别平衡）
