# AR-RNTR算法教程 - 第4部分：实战指南 🚀

## 目录
1. 环境配置
2. 运行训练
3. 运行推理
4. 可视化结果
5. 常见问题

---

## 1. 环境配置

### 1.1 依赖安装

```bash
# 基础环境
conda create -n ar-rntr python=3.8
conda activate ar-rntr

# PyTorch (CUDA 11.3)
pip install torch==1.12.0+cu113 torchvision==0.13.0+cu113 -f https://download.pytorch.org/whl/torch_stable.html

# MMDetection3D
pip install openmim
mim install mmcv-full==1.6.0
mim install mmdet==2.28.0
mim install mmsegmentation==0.30.0
pip install mmdet3d==1.0.0rc6

# 其他依赖
pip install numpy scipy opencv-python pillow bezier
```

### 1.2 项目结构

```
RoadNetwork/
├── rntr/                    # 核心代码
│   ├── ar_rntr.py          # AR-RNTR模型
│   ├── ar_rntr_head.py     # 解码头
│   ├── core/               # 核心组件
│   │   └── centerline/     # 序列处理
│   ├── transforms/         # 数据变换
│   └── ...
├── configs/                 # 配置文件
│   └── rntr_ar_roadseq/
│       └── lss_ar_rntr_*.py
├── tools/                   # 工具脚本
└── data/                    # 数据目录
    └── nuscenes/
```

---

## 2. 运行训练

### 2.1 数据准备

```bash
# nuScenes数据集结构
data/nuscenes/
├── maps/
├── samples/
├── sweeps/
├── v1.0-trainval/
└── nuscenes_infos_train.pkl
```

### 2.2 训练命令

```bash
# 单GPU训练
python tools/train.py \
    configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py \
    --work-dir work_dirs/ar_rntr_exp1

# 多GPU训练（推荐）
bash tools/dist_train.sh \
    configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py \
    8  # 8个GPU
```

### 2.3 关键配置解读

```python
# configs/rntr_ar_roadseq/lss_ar_rntr_*.py

# 预训练权重
load_from = 'ckpts/lss_roadseg_48x32_b4x8_resnet_adam_24e_clean.pth'

# BEV配置
grid_conf = dict(
    xbound=[-48.0, 48.0, 0.5],  # X: 96米范围，0.5米分辨率
    ybound=[-32.0, 32.0, 0.5],  # Y: 64米范围
)

# 序列长度
max_center_len = 1201  # 最大序列长度
max_box_num = 180      # 最大节点数

# 训练参数（在schedules中配置）
max_epochs = 300
lr = 2e-4
batch_size = 2  # 每GPU
```

### 2.4 训练监控

```python
# 训练日志示例
Epoch [1/300]  Step [1/11]
  loss_coords: 3.452
  loss_labels: 2.187
  loss_connects: 1.923
  loss_coeffs: 2.634
  total_loss: 10.196

# 查看TensorBoard
tensorboard --logdir work_dirs/ar_rntr_exp1
```

---

## 3. 运行推理

### 3.1 推理命令

```bash
# 验证集推理
python tools/test.py \
    configs/rntr_ar_roadseq/lss_ar_rntr_val_with_vis.py \
    work_dirs/ar_rntr_exp1/epoch_300.pth \
    --eval \
    --show-dir work_dirs/ar_rntr_exp1/vis

# 单样本测试
python tools/test.py \
    configs/rntr_ar_roadseq/lss_ar_rntr_val_with_vis.py \
    work_dirs/ar_rntr_exp1/epoch_300.pth \
    --show \
    --show-dir vis_results
```

### 3.2 推理过程分析

```python
# simple_test_pts函数流程

# Step 1: 初始化序列
input_seqs = torch.tensor([[572]])  # [START]

# Step 2: BEV特征提取
bev_feats = self.extract_feat(img, img_metas)
# [1, 256, 200, 200]

# Step 3: 自回归生成（最多1200次）
for t in range(1200):
    # Transformer预测
    logits = self.pts_bbox_head(bev_feats, input_seqs, img_metas)
    
    # 应用约束
    logits = apply_constraints(logits, t)
    
    # 采样
    next_token = logits.argmax(dim=-1)
    
    # 添加到序列
    input_seqs = torch.cat([input_seqs, next_token], dim=-1)
    
    # 检查EOS
    if next_token == 571:
        break

# Step 4: 后处理
output_seqs, values = outs
pred_line_seq = output_seqs[0, 1:]  # 去掉START

# 找到EOS位置
if (pred_line_seq == 571).any():
    stop_idx = (pred_line_seq == 571).nonzero()[0][0]
else:
    stop_idx = len(pred_line_seq)

# 对齐到完整节点
clause_length = 6
stop_idx = stop_idx // clause_length * clause_length
pred_line_seq = pred_line_seq[:stop_idx]

# 解码token
pred_line_seq[2::6] -= 200  # 类型: 200-203 → 0-3
pred_line_seq[3::6] -= 250  # 连接: 250+ → 索引
pred_line_seq[4::6] -= 350  # 系数x
pred_line_seq[5::6] -= 350  # 系数y
```

### 3.3 序列解析

```python
# 从序列恢复图结构
from rntr.core import seq2bznodelist, EvalMapBzGraph

# 序列 → 节点列表
nodelist = seq2bznodelist(
    pred_line_seq.cpu().numpy(),
    n_control=3
)

# 节点列表 → 图
graph = EvalMapBzGraph(
    map_token='sample_token',
    nodelist=nodelist,
    bezier_keys=50
)

# 访问图信息
print(f"节点数: {len(graph.nodes)}")
print(f"边数: {len(graph.edges)}")
print(f"根节点: {graph.roots}")
```

---

## 4. 可视化结果

### 4.1 拓扑图可视化

```python
# topology_visualizer.py中的函数

def render_topology_graph(pred_tokens, clause_length, 
                         box_range=200, canvas_size=500):
    """渲染道路拓扑图"""
    canvas = np.zeros((canvas_size, canvas_size, 3), dtype=np.uint8)
    
    # 解析节点
    num_nodes = len(pred_tokens) // clause_length
    nodes = []
    for i in range(num_nodes):
        idx = i * clause_length
        x = pred_tokens[idx]
        y = pred_tokens[idx + 1]
        label = pred_tokens[idx + 2] - 200
        connect = pred_tokens[idx + 3] - 250
        
        nodes.append({
            'coord': (x, y),
            'label': label,
            'connect': connect
        })
    
    # 绘制边（连接线）
    for i, node in enumerate(nodes):
        if node['connect'] >= 0 and node['connect'] < i:
            parent = nodes[node['connect']]
            cv2.line(
                canvas,
                (int(node['coord'][0] * canvas_size / box_range),
                 int(node['coord'][1] * canvas_size / box_range)),
                (int(parent['coord'][0] * canvas_size / box_range),
                 int(parent['coord'][1] * canvas_size / box_range)),
                (0, 255, 0),  # 绿色
                2
            )
    
    # 绘制节点
    for node in nodes:
        x = int(node['coord'][0] * canvas_size / box_range)
        y = int(node['coord'][1] * canvas_size / box_range)
        
        # 根据类型选择颜色
        colors = {
            0: (255, 0, 0),    # Ancestor - 红色
            1: (0, 255, 255),  # Lineal - 青色
            2: (255, 255, 0),  # Offshoot - 黄色
            3: (255, 0, 255),  # Clone - 品红
        }
        color = colors.get(node['label'], (255, 255, 255))
        
        cv2.circle(canvas, (x, y), 5, color, -1)
    
    return canvas
```

### 4.2 BEV叠加可视化

```python
def render_bev_overlay(gt_coords, pred_tokens, clause_length):
    """GT和预测的BEV叠加图"""
    canvas = np.zeros((200, 200, 3), dtype=np.uint8)
    
    # 绘制GT（绿色）
    for coord in gt_coords:
        x, y = int(coord[0]), int(coord[1])
        if 0 <= x < 200 and 0 <= y < 200:
            cv2.circle(canvas, (x, y), 2, (0, 255, 0), -1)
    
    # 绘制预测（红色）
    num_nodes = len(pred_tokens) // clause_length
    for i in range(num_nodes):
        idx = i * clause_length
        x = int(pred_tokens[idx])
        y = int(pred_tokens[idx + 1])
        if 0 <= x < 200 and 0 <= y < 200:
            cv2.circle(canvas, (x, y), 2, (0, 0, 255), -1)
    
    # 添加图例
    cv2.putText(canvas, 'GT: green', (5, 15), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)
    cv2.putText(canvas, 'Pred: red', (5, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1)
    
    return canvas
```

---

## 5. 常见问题

### 5.1 OOM (Out of Memory)

**问题**：训练时显存不足

**解决方案**：

```python
# 1. 减小batch size
batch_size = 1  # 从2减到1

# 2. 减小序列长度
max_center_len = 601  # 从1201减到601
max_box_num = 100     # 从180减到100

# 3. 使用梯度检查点
with_cp = True  # 在transformerlayers中

# 4. 使用FP16训练
fp16 = dict(loss_scale='dynamic')
```

### 5.2 生成序列过长/过短

**问题**：模型生成太多/太少节点

**解决方案**：

```python
# 1. 调整噪声节点数量
max_box_num = 150  # 增加/减少

# 2. 调整EOS权重
end_token_weight = 2.0  # 鼓励更早停止

# 3. 检查约束机制
self.inference_constraints = dict(
    clamp_coords=True,
    clamp_classes=True,
    clamp_coeffs=True,
    clamp_connect=True,  # 确保开启
)
```

### 5.3 连接关系混乱

**问题**：生成的拓扑结构不合理

**解决方案**：

```python
# 1. 增加连接损失权重
loss_connects_weight = 2.0  # 默认1.0

# 2. 使用更严格的约束
force_lineal_prev=True  # Lineal必须连接到i-1

# 3. 检查GT数据
# 确保标注正确：
# - Ancestor的connect应该是0
# - Lineal的connect应该是i-1
# - Offshoot的connect应该显式标注
```

### 5.4 类别预测不准

**问题**：Offshoot/Clone识别率低

**解决方案**：

```python
# 1. 提高稀有类别权重
label_class_weight[202] = 5.0  # Offshoot
label_class_weight[203] = 3.0  # Clone

# 2. 数据增强
# 增加包含分叉的样本

# 3. 检查数据分布
# 运行代码中的GT统计功能
```

### 5.5 推理速度慢

**问题**：生成一个场景需要很长时间

**优化方案**：

```python
# 1. 减小max_iteration
max_iteration = 600  # 从1200减少

# 2. 使用批量推理
batch_size = 4  # 同时处理多个样本

# 3. 考虑SAR-RNTR或NAR-RNTR
# 它们分别提供6×和47×加速
```

---

## 6. 性能对比

### 6.1 论文报告的结果

**nuScenes数据集（PON split）**：

| 模型 | Landmark F1 | Reachability F1 | 速度 |
|------|-------------|-----------------|------|
| STSU | 28.5 | 31.2 | - |
| TPLR | 32.7 | 35.8 | - |
| **AR-RNTR** | **42.3** | **45.6** | 1× |
| SAR-RNTR | 46.8 | 51.2 | 6× |
| NAR-RNTR | 45.1 | 49.3 | 47× |

### 6.2 不同变体对比

| 特性 | AR-RNTR | SAR-RNTR | NAR-RNTR |
|------|---------|----------|----------|
| 生成方式 | 自回归 | 半自回归 | 非自回归 |
| Transformer层数 | 6 | 6+3 | 6+3 |
| 推理速度 | 慢 | 中等 | 快 |
| 精度 | 中等 | **最高** | 较高 |
| 适用场景 | 基线 | 精度优先 | 速度优先 |

### 6.3 消融实验

**不同组件的贡献**：

| 配置 | Landmark F1 | Δ |
|------|-------------|---|
| 基线（无约束） | 38.2 | - |
| + 槽位约束 | 40.5 | +2.3 |
| + 噪声对象 | 41.8 | +1.3 |
| + 类别权重 | 42.3 | +0.5 |

---

## 7. 调试技巧

### 7.1 启用调试日志

```python
# ar_rntr.py中有详细的DEBUG输出

# 查看GT分布
[GT LABEL DISTRIBUTION] Epoch 1
  Ancestor:  186 (18.6%)
  Lineal:    603 (60.3%)
  Offshoot:   64 ( 6.4%)
  Clone:     147 (14.7%)

# 查看损失细节
[ARRNTRHead DEBUG] Step 7: Loss Calculation
  loss_coords: 2.341
  loss_labels: 1.892
  loss_connects: 1.654
  loss_coeffs: 2.103
```

### 7.2 可视化中间结果

```python
# 保存BEV特征
bev_feat_np = bev_feats[0].detach().cpu().numpy()
np.save('bev_feat.npy', bev_feat_np)

# 保存预测序列
pred_seq_np = output_seqs[0].detach().cpu().numpy()
np.save('pred_seq.npy', pred_seq_np)
```

### 7.3 单步调试

```python
# 在关键位置设置断点
import pdb; pdb.set_trace()

# 或使用条件断点
if loss_coords > 10.0:
    import pdb; pdb.set_trace()
```

---

## 小结

✅ **环境配置**：PyTorch + MMDetection3D
✅ **训练命令**：支持单/多GPU训练
✅ **推理流程**：自回归生成 + 后处理
✅ **可视化**：拓扑图、BEV叠加
✅ **常见问题**：OOM、连接混乱、速度优化

**恭喜！** 你已经掌握了AR-RNTR的所有核心知识！🎉
