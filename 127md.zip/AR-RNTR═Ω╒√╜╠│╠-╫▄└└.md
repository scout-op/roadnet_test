# AR-RNTR算法完整教程 - 总览 📘

> **面向小白的深度学习道路网络提取算法教程**  
> 从零基础到代码实战，一站式学习AR-RNTR！

---

## 🎯 教程概览

本教程共分为**4个部分**，循序渐进地讲解AR-RNTR算法：

### 📖 [第1部分：核心概念](./AR-RNTR教程-第1部分-核心概念.md)
**适合人群**：完全零基础  
**学习时间**：30分钟  
**核心内容**：
- ✅ 什么是道路网络提取？
- ✅ 欧几里得 vs 非欧几里得数据
- ✅ RoadNet Sequence统一表示
- ✅ 6个整数表示法详解
- ✅ 4种节点类型（Ancestor, Lineal, Offshoot, Clone）

**关键收获**：理解AR-RNTR如何把道路图转换成数字序列

---

### 🏗️ [第2部分：模型架构](./AR-RNTR教程-第2部分-模型架构.md)
**适合人群**：有深度学习基础  
**学习时间**：45分钟  
**核心内容**：
- ✅ 整体架构：图像→BEV→序列
- ✅ BEV编码器（LSS）工作原理
- ✅ Transformer解码器设计
- ✅ Self-Attention vs Cross-Attention
- ✅ 嵌入层：词嵌入+位置嵌入

**关键收获**：掌握从6个相机图像到道路序列的完整流程

---

### 🎯 [第3部分：训练与推理](./AR-RNTR教程-第3部分-训练推理.md)
**适合人群**：想理解算法细节  
**学习时间**：60分钟  
**核心内容**：
- ✅ 训练数据构造（真实节点+噪声节点）
- ✅ 4个损失函数详解
- ✅ 自回归生成流程
- ✅ 槽位约束机制
- ✅ 类别权重平衡技巧

**关键收获**：理解模型如何训练和生成道路网络

---

### 🚀 [第4部分：实战指南](./AR-RNTR教程-第4部分-实战指南.md)
**适合人群**：想运行代码  
**学习时间**：90分钟  
**核心内容**：
- ✅ 环境配置步骤
- ✅ 训练命令和配置
- ✅ 推理流程和可视化
- ✅ 常见问题解决方案
- ✅ 性能优化技巧

**关键收获**：从零开始训练和部署AR-RNTR模型

---

## 📊 学习路径建议

### 路径1️⃣：快速入门（1小时）
```
第1部分 → 第4部分（环境配置+运行推理）
适合：想快速看到效果的开发者
```

### 路径2️⃣：深度理解（3小时）
```
第1部分 → 第2部分 → 第3部分 → 第4部分
适合：想完全掌握算法原理的研究者
```

### 路径3️⃣：论文复现（1天）
```
阅读所有部分 → 运行训练 → 复现论文结果
适合：做科研或写论文的学生
```

---

## 🔑 核心知识点速查

### 序列表示
```
每个节点 = [x, y, 类型, 连接, 系数x, 系数y]
示例：    [15, 30, 201, 250, 377, 395]
范围：    [0-199, 0-199, 200-203, 250+, 350-549, 350-549]
```

### 4种节点类型
```
Ancestor (200): 起点，树根
Lineal   (201): 主干延续 (60.3%)
Offshoot (202): 分叉点 (6.4%)
Clone    (203): 合并副本 (14.7%)
```

### 模型架构
```
6相机图片 → LSS编码器 → BEV特征[256,200,200]
          ↓
BEV特征 + 序列 → Transformer(6层) → 预测下一个token
          ↓
自回归生成：[START] → [10] → [20] → ... → [EOS]
```

### 约束机制
```
位置0,1: [0, 199]        ← 坐标范围
位置2:   [200, 203]      ← 4种类型
位置3:   [250, 250+i-1]  ← 只连接已有节点
位置4,5: [350, 549]      ← 系数范围
```

---

## 📈 性能指标

### nuScenes数据集结果
| 模型 | Landmark F1 | Reachability F1 | 速度 |
|------|-------------|-----------------|------|
| STSU | 28.5 | 31.2 | - |
| TPLR | 32.7 | 35.8 | - |
| **AR-RNTR** | **42.3** | **45.6** | 1× |
| SAR-RNTR | **46.8** | **51.2** | 6× |
| NAR-RNTR | 45.1 | 49.3 | **47×** |

### 训练配置
```
Epochs:        300
Learning Rate: 2×10⁻⁴
Batch Size:    16 (2×8)
Sequence Len:  600-1200
GPU Memory:    ~11GB (单卡)
Training Time: ~3天 (8×V100)
```

---

## 🛠️ 快速开始

### Step 1: 克隆代码
```bash
cd RoadNetwork/
```

### Step 2: 准备数据
```bash
# 下载nuScenes数据集
# 放置到 data/nuscenes/
```

### Step 3: 运行推理（预训练模型）
```bash
python tools/test.py \
    configs/rntr_ar_roadseq/lss_ar_rntr_val_with_vis.py \
    checkpoints/ar_rntr_epoch_300.pth \
    --show-dir vis_results
```

### Step 4: 查看结果
```bash
# 在 vis_results/ 目录查看可视化结果
```

---

## 📚 参考资料

### 论文
- **标题**: Translating Images to Road Network: A Sequence-to-Sequence Perspective
- **会议**: IEEE (Extended Version)
- **代码**: https://github.com/fudan-zvg/RoadNetworkTRansformer

### 相关工作
- **STSU**: Structured Bird's Eye View Traffic Scene Understanding
- **TPLR**: Topology Preserved Line Recognition
- **LSS**: Lift-Splat-Shoot for BEV Segmentation
- **Pix2Seq**: A Language Modeling Framework for Object Detection

---

## ❓ 常见问题

### Q1: 为什么叫"自回归"？
A: 因为生成每个token时，依赖于之前生成的所有token，就像GPT生成文本一样。

### Q2: 为什么需要Clone节点？
A: 因为道路网络是DAG（有向无环图），有些节点有多个父节点。转换成树结构时需要复制节点。

### Q3: 约束机制是论文提出的吗？
A: 不是，这是代码实现时添加的工程优化，确保生成合法的token。

### Q4: 为什么Offshoot权重×3？
A: 因为Offshoot只占6.4%，属于稀有类别。提高权重强制模型关注。

### Q5: 能用于实时系统吗？
A: AR-RNTR较慢（~0.5s/帧）。建议用NAR-RNTR（~0.02s/帧，47×加速）。

---

## 🎓 进阶学习

### 扩展主题
1. **SAR-RNTR**: 半自回归版本，6×加速
2. **NAR-RNTR**: 非自回归版本，47×加速
3. **TIT训练策略**: 拓扑继承训练
4. **SD-Map提示学习**: 使用先验地图

### 代码阅读顺序
```
1. ar_rntr.py (主模型)
2. ar_rntr_head.py (解码头)
3. core/centerline/structures/ljc_bz_centerline.py (序列处理)
4. LiftSplatShoot.py (BEV编码器)
5. rntr_transformer.py (Transformer实现)
```

---

## 📞 技术支持

### 遇到问题？
1. 📖 **先查看第4部分的"常见问题"章节**
2. 🐛 **检查GitHub Issues**: 可能别人也遇到过
3. 💬 **提交新Issue**: 附上完整错误信息和配置

### 贡献教程
- 发现错误？欢迎提PR！
- 有更好的解释？欢迎补充！
- 想添加新内容？欢迎建议！

---

## ✨ 总结

AR-RNTR是一个**优雅而强大**的算法：
- ✅ 统一表示欧几里得和非欧几里得数据
- ✅ 利用Transformer的序列建模能力
- ✅ 通过约束机制保证生成合法性
- ✅ 在nuScenes数据集上达到SOTA性能

希望本教程能帮助你**从零到精通**AR-RNTR！🚀

---

**祝学习愉快！** 🎉

*最后更新：2025-10-26*
