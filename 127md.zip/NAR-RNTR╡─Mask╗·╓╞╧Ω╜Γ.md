# NAR-RNTR的Mask机制详解 🎭

> **核心问题**：NAR如何通过masking实现全并行生成？

---

## 概览

NAR-RNTR使用**Masked Language Modeling (MLM)** 策略，灵感来自BERT：

| 阶段 | Mask策略 | 目标 |
|------|----------|------|
| **训练** | 随机掩码90%的GT token | 学习从部分信息预测全序列 |
| **推理** | 迭代式置信度掩码 | 逐步精炼低置信度的预测 |

---

## 1. 训练时的Masking（MLM）

### 1.1 核心思想

**传统AR训练**：
```python
输入: [START, x1, x2, x3, x4]
目标: [x1, x2, x3, x4, EOS]

# Teacher Forcing：逐个预测
预测x1 ← 输入[START]
预测x2 ← 输入[START, x1]
预测x3 ← 输入[START, x1, x2]
...
```

**NAR-MLM训练**：
```python
GT序列: [START, x1, x2, x3, x4, EOS]

# 随机掩码90%
输入: [START, MASK, x2, MASK, MASK, EOS]
目标: [START, x1,   x2, x3,   x4,   EOS]

# 并行预测所有MASK位置
模型一次性输出所有位置的预测
```

---

### 1.2 代码实现（训练）

#### Step 1: 在SAR_RNTR中随机掩码

```python
# sar_rntr.py L740-780
def prepare_inputs_NAR_MLM_train(self, batch_inputs_dict, batch_data_samples):
    """NAR-MLM训练：随机掩码高比例的输入token"""
    
    nar_mlm_train = bool(getattr(self.pts_bbox_head, 'nar_mlm_train', False))
    if not nar_mlm_train:
        return batch_inputs_dict  # 不是NAR训练，直接返回
    
    # 获取mask参数
    mask_ratio = float(getattr(self.pts_bbox_head, 'nar_mask_ratio', 0.9))
    no_known = int(getattr(self.pts_bbox_head, 'no_known', 573))
    
    # 遍历batch中的每个样本
    for sample in batch_data_samples:
        gt_seq = sample.gt_labels_3d['centerline_sequence']  # [T]
        T = gt_seq.shape[0]
        
        # Step 1: 生成随机mask（跳过START token）
        mask_prob = torch.rand(T, device=gt_seq.device)
        mask_indices = (mask_prob < mask_ratio) & (torch.arange(T) > 0)
        # mask_indices: [False, True, False, True, True, ...] (90%为True)
        
        # Step 2: 将被mask的位置替换为NO_KNOWN token
        masked_seq = gt_seq.clone()
        masked_seq[mask_indices] = no_known
        # 结果: [START, 573, x2, 573, 573, ...]
        
        # Step 3: 更新输入序列
        sample.gt_labels_3d['centerline_sequence'] = masked_seq
        
        # Step 4: 创建loss mask（只在被mask的位置计算loss）
        loss_mask = mask_indices.float()
        sample.gt_labels_3d['nar_loss_mask'] = loss_mask
    
    return batch_inputs_dict
```

#### Step 2: 损失计算（只计算被mask位置）

```python
# sar_rntr.py L850-900
def loss_by_feat_NAR_MLM(self, pred_seq, gt_seq, nar_loss_mask):
    """NAR-MLM损失：只在被mask的位置计算"""
    
    # pred_seq: [B, T, V] 所有位置的预测logits
    # gt_seq: [B, T] 原始GT序列
    # nar_loss_mask: [B, T] 0/1 mask，1表示该位置被mask了
    
    # 计算交叉熵
    loss_all = F.cross_entropy(
        pred_seq.reshape(-1, V),
        gt_seq.reshape(-1),
        reduction='none'
    )  # [B*T]
    
    # 只保留被mask位置的loss
    loss_masked = loss_all * nar_loss_mask.reshape(-1)
    
    # 归一化
    num_masked = nar_loss_mask.sum()
    loss = loss_masked.sum() / (num_masked + 1e-6)
    
    return loss
```

---

### 1.3 训练示例

**原始GT序列**（26个token）：
```python
GT = [572,  # START
      0, 61, 0, 0, 0, 0,      # 节点1: (0,61) Ancestor
      36, 62, 1, 0, 32, 107,  # 节点2: (36,62) Lineal
      95, 65, 1, 0, 80, 109,  # 节点3: (95,65) Lineal
      108, 65, 1, 0, 115, 111, # 节点4
      571]  # EOS
```

**掩码后的输入**（90% mask）：
```python
# 随机保留10%，掩码90%
Input = [572,   # START（永远不mask）
         573, 573, 573, 0, 573, 0,     # 大部分被mask
         573, 62, 573, 573, 32, 573,   # 随机保留62, 32
         573, 573, 573, 573, 573, 573, # 全mask
         573, 573, 573, 573, 573, 573,
         571]  # EOS（可选是否mask）

# 573 = NO_KNOWN token
```

**模型任务**：
- 输入: 10%的真实token + 90%的MASK
- 输出: 预测所有位置（包括已知的）
- 损失: 只计算90%被mask位置的预测误差

---

## 2. 推理时的Masking（Iterative Refinement）

### 2.1 核心思想

**推理流程**（3次迭代）：

```
初始化: 全MASK序列
  ↓
Iter 1: 预测所有位置 → 保留高置信度 → 重新mask低置信度
  ↓
Iter 2: 预测所有位置 → 保留高置信度 → 重新mask低置信度
  ↓
Iter 3: 预测所有位置 → 接受所有预测
  ↓
最终输出
```

**类比**：
```
就像画画：
Iter 1: 画个大概轮廓（粗糙）
Iter 2: 修正不满意的地方
Iter 3: 最后润色
```

---

### 2.2 代码实现（推理）

```python
# sar_rntr_head.py L580-700
def forward_NAR_inference(self, x, img_metas):
    """NAR迭代推理"""
    
    B = img_metas[0]['batch_size']
    T = self.max_iteration + 1  # 序列长度
    
    # ============ 初始化：全MASK序列 ============
    seq = torch.full((B, T), self.no_known, device=x.device, dtype=torch.long)
    seq[:, 0] = self.start  # 第一个位置是START
    # seq: [572, 573, 573, 573, ..., 573]
    #      START MASK MASK MASK     MASK
    
    # ============ 迭代精炼 ============
    iters = self.nar_iters  # 论文中设置为3
    
    for it in range(iters):
        print(f"\n[NAR] Iteration {it+1}/{iters}")
        
        # Step 1: 嵌入当前序列
        tgt = self.embedding(seq)  # [B, T, D]
        
        # Step 2: Transformer预测（全可见mask）
        tgt_mask = torch.zeros(T, T, device=x.device)  # 全0 = 全可见
        outs_dec, _ = self.transformer(tgt, x, tgt_mask, ...)
        
        # Step 3: 获取预测logits
        logits = self.vocab_embed(outs_dec[-1])  # [B, T, V]
        probs = logits.softmax(-1)               # [B, T, V]
        
        # Step 4: 获取最高概率的token和置信度
        confidence, predicted_tokens = probs.max(dim=-1)
        # confidence: [B, T] 每个位置的最大概率（置信度）
        # predicted_tokens: [B, T] 预测的token ID
        
        print(f"  Average confidence: {confidence.mean().item():.3f}")
        print(f"  Min confidence: {confidence.min().item():.3f}")
        print(f"  Max confidence: {confidence.max().item():.3f}")
        
        # ============ 最后一次迭代：接受所有 ============
        if it == iters - 1:
            seq = predicted_tokens
            seq[:, 0] = self.start  # 确保START不变
            print(f"  Final iteration: accepting all predictions")
            break
        
        # ============ 置信度筛选：保留高置信度预测 ============
        conf_thresh = self.nar_conf_thresh  # 论文中设置为0.55
        
        # 保留高置信度的预测
        keep_mask = (confidence >= conf_thresh)
        # keep_mask: [B, T] True表示置信度够高，保留
        
        num_keep = keep_mask.sum().item()
        num_total = keep_mask.numel()
        print(f"  Keeping {num_keep}/{num_total} high-confidence tokens")
        
        # Step 5: 更新序列（高置信度→保留，低置信度→重新mask）
        seq = torch.where(
            keep_mask,
            predicted_tokens,  # 高置信度：使用预测
            self.no_known      # 低置信度：重新mask
        )
        seq[:, 0] = self.start  # START永远不变
        
        # 下一次迭代将重新预测被mask的位置
    
    return seq
```

---

### 2.3 推理示例

**Iteration 1**：
```python
输入: [572, 573, 573, 573, 573, 573, ...]  # 全MASK
      START MASK MASK MASK MASK MASK

预测: [572, 10,  62,  15,  5,   107, ...]
置信度: [1.0, 0.9, 0.8, 0.3, 0.4, 0.6, ...]
               ✓    ✓    ✗   ✗    ✓
         (conf_thresh = 0.55)

保留: [572, 10,  62,  573, 573, 107, ...]
      START ✓    ✓    MASK MASK ✓
```

**Iteration 2**：
```python
输入: [572, 10,  62,  573, 573, 107, ...]
      START 已知 已知 MASK MASK 已知

# Transformer看到更多上下文信息（10, 62, 107已知）
预测: [572, 10,  62,  20,  32,  107, ...]
置信度: [1.0, 0.9, 0.9, 0.7, 0.6, 0.9, ...]
                        ✓    ✓

保留: [572, 10,  62,  20,  32,  107, ...]
      START ✓    ✓    ✓    ✓    ✓
```

**Iteration 3（最后）**：
```python
输入: [572, 10,  62,  20,  32,  107, ...]

# 最后一次：接受所有预测
预测: [572, 10,  62,  20,  32,  107, ...]
输出: [572, 10,  62,  20,  32,  107, ..., 571]
                                         EOS
```

---

## 3. 关键参数

### 3.1 配置参数

```python
# configs/rntr_sar_roadseq/lss_nar_finetune_from_sar.py

model = dict(
    pts_bbox_head=dict(
        # ===== 训练参数 =====
        nar_mlm_train=True,      # 启用MLM训练
        nar_mask_ratio=0.9,      # 掩码比例：90%
        
        # ===== 推理参数 =====
        nar_infer=True,          # 启用NAR推理
        nar_iters=3,             # 迭代次数：3次
        nar_conf_thresh=0.55,    # 置信度阈值：0.55
        nar_keep_ratio=0.2,      # Top-k保留比例（可选）
    )
)
```

### 3.2 参数含义

| 参数 | 默认值 | 含义 |
|------|--------|------|
| `nar_mask_ratio` | 0.9 | 训练时掩码比例（90%） |
| `nar_iters` | 3 | 推理时迭代次数 |
| `nar_conf_thresh` | 0.55 | 置信度阈值（>0.55保留） |
| `nar_keep_ratio` | 0.2 | Top-k保留比例（可选） |

---

## 4. 为什么这样设计？

### 4.1 训练时90% Mask

**问题**：为什么不是50%或99%？

**答案**：平衡学习难度
```
Mask太少（如30%）：
- 模型看到太多上下文
- 几乎退化为SAR（依赖已知token）
- 难以学会全并行生成

Mask太多（如99%）：
- 模型几乎没有上下文
- 学习困难，收敛慢
- 性能差

90% Mask（BERT标准）：
- 足够困难，逼迫模型学习全局依赖
- 保留10%提供必要线索
- 已被NLP领域验证有效
```

---

### 4.2 推理时迭代优化

**问题**：为什么不一次生成？

**答案**：逐步精炼提高质量
```
One-shot（1次）：
[MASK, MASK, MASK, ...] → [预测1, 预测2, 预测3, ...]
问题：没有上下文，预测质量差

Iterative（3次）：
Iter 1: [MASK, MASK, ...] → [可信预测, MASK, ...]
Iter 2: [已知, MASK, ...] → [已知, 新预测, ...]
Iter 3: [已知, 已知, ...] → [最终输出]
优势：每次迭代都有更多上下文信息
```

**论文**（Section 3.3）：
> "With each iteration, the results will be gradually refined."

---

### 4.3 置信度阈值

**问题**：为什么用0.55？

**答案**：经验值，平衡速度和质量
```
阈值太低（如0.3）：
- 保留太多低质量预测
- 错误传播到下一次迭代
- 最终质量差

阈值太高（如0.9）：
- 只保留极少数预测
- 需要更多迭代次数
- 速度慢

0.55（中等）：
- 保留中等以上质量预测
- 3次迭代足够收敛
- 速度和质量平衡
```

---

## 5. 与SAR的对比

### 5.1 训练对比

| 方面 | SAR | NAR |
|------|-----|-----|
| **输入** | 真实GT序列 | 90% Mask + 10% GT |
| **Attention Mask** | Block-causal | 全可见（MLM） |
| **损失计算** | 所有位置 | 只在mask位置 |
| **依赖** | 组内自回归 | 全并行 |

---

### 5.2 推理对比

| 方面 | SAR | NAR |
|------|-----|-----|
| **初始化** | [START] | [START, MASK, MASK, ...] |
| **生成方式** | 组间并行，组内串行 | 全并行 |
| **步数** | M步（M=关键点数量） | 3次迭代 |
| **速度** | 6倍 | 47倍 |
| **精度** | 最高 | 略低0.6 |

---

## 6. 完整流程图

### 训练流程

```
GT序列: [START, x1, x2, x3, x4, EOS]
    ↓ 随机mask 90%
Masked: [START, MASK, x2, MASK, MASK, EOS]
    ↓ 嵌入 + Transformer
预测:   [START, x1', x2', x3', x4', EOS']
    ↓ 计算损失（只在MASK位置）
Loss = CE(x1', x1) + CE(x3', x3) + CE(x4', x4)
```

---

### 推理流程

```
初始化: [START, MASK, MASK, MASK, ...]

┌─────────────────────────────────┐
│ Iteration 1                     │
│ 输入: [START, MASK, MASK, ...]   │
│   ↓ Transformer (全可见)         │
│ 预测: [START, x1, x2, x3, ...]   │
│   ↓ 置信度筛选 (>0.55)           │
│ 保留: [START, x1, MASK, x3, ...] │
└──────────┬──────────────────────┘
           ↓
┌─────────────────────────────────┐
│ Iteration 2                     │
│ 输入: [START, x1, MASK, x3, ...] │
│   ↓ Transformer (更多上下文)     │
│ 预测: [START, x1, x2', x3, ...]  │
│   ↓ 置信度筛选                   │
│ 保留: [START, x1, x2', x3, ...]  │
└──────────┬──────────────────────┘
           ↓
┌─────────────────────────────────┐
│ Iteration 3 (最后)               │
│ 输入: [START, x1, x2', x3, ...]  │
│   ↓ Transformer                  │
│ 预测: [START, x1, x2, x3, ..., EOS]│
│   ↓ 接受所有                     │
│ 输出: 最终序列                    │
└─────────────────────────────────┘
```

---

## 7. 核心总结

### Mask策略对比

| 阶段 | Mask方式 | 目的 |
|------|----------|------|
| **训练** | 随机90% | 强迫模型学习从部分信息重建全序列 |
| **推理** | 置信度筛选 | 逐步精炼，保证质量 |

### 关键创新

1. **训练创新**：Masked Language Modeling
   - 借鉴BERT，从NLP迁移到道路生成
   - 90% mask ratio，平衡学习难度

2. **推理创新**：Iterative Refinement
   - 不是one-shot，而是迭代优化
   - 置信度筛选，逐步精炼

3. **性能提升**：
   - 速度：47倍加速（vs AR）
   - 精度：只损失0.6 F1（vs SAR）

**这就是NAR-RNTR的核心：用BERT的mask策略 + 迭代优化，实现全并行、高质量的道路网络生成！** 🎯
