# AR-RNTR算法教程 - 第3部分：训练与推理 🎯

## 目录
1. 训练数据准备
2. 损失函数设计
3. 推理流程详解
4. 约束机制

---

## 1. 训练数据准备

### 1.1 输入数据格式

```python
batch = {
    # 6个相机图片
    'img': Tensor([B, 6, 3, 128, 352]),
    
    # 标注数据
    'img_metas': [
        {
            'centerline_coord': [[10,20], [15,30], [20,40]],  # 节点坐标
            'centerline_label': [0, 1, 1],                    # 节点类型
            'centerline_connect': [0, 0, 1],                  # 父节点索引
            'centerline_coeff': [[12,25], [17,35]],           # 曲线系数
            'n_control': 3,  # 贝塞尔控制点数（3表示二次）
        },
        # ... 更多样本
    ]
}
```

### 1.2 序列构造过程

```python
# ar_rntr.py L467-510

def forward_pts_train(self, bev_feats, gt_lines_coords, 
                     gt_lines_labels, gt_lines_connects, 
                     gt_lines_coeffs, img_metas, num_coeff):
    
    for bi in range(batch_size):
        # ===== Step 1: 组装真实节点 =====
        # 坐标 [N, 2]
        box = torch.tensor(gt_lines_coords[bi]).long()
        box = box.reshape(-1, 2)
        
        # 类型 [N, 1]: 0-3 → 200-203
        label = torch.tensor(gt_lines_labels[bi]).long()
        label = label.reshape(-1, 1) + self.category_start
        
        # 连接 [N, 1]: 索引 → 250+索引
        connect = torch.tensor(gt_lines_connects[bi]).long()
        connect = connect.reshape(-1, 1) + self.connect_start
        
        # 系数 [N, coeff_dim]: 值 → 350+值
        coeff = torch.tensor(gt_lines_coeffs[bi]).long()
        coeff_dim = num_coeff * 2  # 二次贝塞尔: 2个系数
        coeff = coeff.reshape(-1, coeff_dim) + self.coeff_start
        
        # 拼接: [N, 6]
        box_label = torch.cat([box, label, connect, coeff], dim=-1)
        
        # ===== Step 2: 生成噪声节点（防止过早停止）=====
        num_noise = num_box - N  # 填充到固定长度
        
        random_box = torch.rand(num_noise, 2) * 199
        random_label = torch.randint(0, 4, (num_noise, 1)) + 200
        random_connect = torch.randint(0, num_box, (num_noise, 1)) + 250
        random_coeff = torch.rand(num_noise, coeff_dim) * 199 + 350
        
        random_box_label = torch.cat([
            random_box.int(), 
            random_label, 
            random_connect, 
            random_coeff.int()
        ], dim=-1)
        
        # ===== Step 3: 构造输入序列 =====
        # 输入 = [START] + [真实] + [噪声]
        input_seq = torch.cat([box_label, random_box_label], dim=0)
        input_seq = torch.cat([
            torch.tensor([self.start]),  # 572
            input_seq.flatten()
        ])
        
        # ===== Step 4: 构造目标序列 =====
        # 真实节点保持不变
        output_seq_real = box_label
        
        # 噪声节点的目标
        output_na_x = torch.ones(num_noise, 1) * self.no_known  # 573
        output_na_y = torch.ones(num_noise, 1) * self.no_known
        output_na_label = torch.ones(num_noise, 1) * self.noise_label  # 570
        output_na_connect = torch.ones(num_noise, 1) * self.no_known
        output_na_coeff = torch.ones(num_noise, coeff_dim) * self.no_known
        
        output_seq_noise = torch.cat([
            output_na_x, output_na_y, output_na_label, 
            output_na_connect, output_na_coeff
        ], dim=-1)
        
        # 目标 = [真实] + [噪声标记] + [EOS]
        output_seq = torch.cat([
            output_seq_real, 
            output_seq_noise
        ], dim=0)
        output_seq = torch.cat([
            output_seq.flatten(),
            torch.tensor([self.end])  # 571
        ])
```

### 1.3 为什么需要噪声节点？

**论文中的技巧**（Synthetic Noise Objects）：

```
问题：模型可能过早生成[EOS]
      [10, 20, 200, EOS]  ← 只生成1个节点就停止

解决：添加噪声节点
      输入: [START, 真实1, 真实2, 噪声1, 噪声2, ...]
      目标: [真实1, 真实2, NOISE, NOISE, ..., EOS]
      
效果：模型学会：
      - 识别真实节点 vs 噪声节点
      - 在正确位置生成[EOS]
```

---

## 2. 损失函数设计

### 2.1 四个损失分量

```python
# ar_rntr_head.py L630-658

def loss_by_feat_single(self, 
                       preds_coords,   # 预测坐标
                       preds_labels,   # 预测类型
                       preds_connects, # 预测连接
                       preds_coeffs,   # 预测系数
                       gt_coords, gt_labels, gt_connects, gt_coeffs):
    
    # 1️⃣ 坐标损失（交叉熵）
    loss_coords = self.loss_coords(preds_coords, gt_coords)
    
    # 2️⃣ 类型损失（加权交叉熵）
    loss_labels = self.loss_labels(preds_labels, gt_labels)
    
    # 3️⃣ 连接损失（交叉熵）
    loss_connects = self.loss_connects(preds_connects, gt_connects)
    
    # 4️⃣ 系数损失（交叉熵）
    loss_coeffs = self.loss_coeffs(preds_coeffs, gt_coeffs)
    
    # 清理NaN（稳定训练）
    loss_coords = torch.nan_to_num(loss_coords)
    loss_labels = torch.nan_to_num(loss_labels)
    loss_connects = torch.nan_to_num(loss_connects)
    loss_coeffs = torch.nan_to_num(loss_coeffs)
    
    return loss_coords, loss_labels, loss_connects, loss_coeffs
```

### 2.2 损失计算示例

```
假设序列: [10, 20, 201, 250, 367, 385]

预测logits:
  位置0: [0.1, ..., 0.8(索引10), ...]  → CrossEntropy(预测, GT=10)
  位置1: [0.1, ..., 0.7(索引20), ...]  → CrossEntropy(预测, GT=20)
  位置2: [0.0, ..., 0.9(索引201), ...] → CrossEntropy(预测, GT=201)
  ...

总损失 = loss_coords + loss_labels + loss_connects + loss_coeffs
```

### 2.3 类别权重配置

```python
# configs中的配置
label_class_weight = [1.0] * 574

# 基于数据分布调整
label_class_weight[201] = 1.0   # Lineal 60.3%（主导类）
label_class_weight[202] = 3.0   # Offshoot 6.4%（稀有×3）
label_class_weight[203] = 1.5   # Clone 14.7%（较少×1.5）

# 原理：
# 稀有类别损失 × 高权重 = 强制模型关注稀有类
```

### 2.4 论文中的目标函数

```
最大化似然：
  max Σ(i=1 to L) w_i * log P(ŷ_i | y_<i, F)

其中：
  - ŷ_i: 第i个预测token
  - y_<i: 前i-1个真实token
  - F: BEV特征
  - w_i: 类别权重
```

---

## 3. 推理流程详解

### 3.1 自回归生成

```python
# ar_rntr_head.py L509-532

def forward(self, mlvl_feats, input_seqs, img_metas):
    # 推理模式
    if not self.training:
        values = []
        clause_length = 4 + coeff_dim  # 每个节点的token数
        
        for _ in range(self.max_iteration):  # 最多1200次
            # Step 1: 嵌入当前序列
            tgt = self.embedding(input_seqs.long())
            query_embed = self.embedding.position_embeddings.weight
            
            # Step 2: Transformer编码
            outs_dec, _ = self.transformer(
                tgt, x, masks, query_embed, pos_embed
            )
            
            # Step 3: 取最后一个位置的输出
            outs_dec = torch.nan_to_num(outs_dec)[-1, :, -1, :]
            
            # Step 4: 预测词汇
            logits = self.vocab_embed(outs_dec)  # [B, 574]
            
            # Step 5: 🔑 应用槽位约束
            t_cur = int(input_seqs.shape[1])
            logits = self._apply_slot_constraints_step(
                logits, t_cur, clause_length
            )
            
            # Step 6: 采样（取概率最高的）
            probs = logits.softmax(-1)
            value, extra_seq = probs.topk(dim=-1, k=1)
            
            # Step 7: 添加到序列
            input_seqs = torch.cat([input_seqs, extra_seq], dim=-1)
            values.append(value)
            
            # Step 8: 检查是否生成[EOS]
            if extra_seq.item() == self.end:
                break
        
        return input_seqs, values
```

### 3.2 生成过程图解

```
初始: [START]

t=0: [START] → Transformer → 预测"10"
     [START, 10]

t=1: [START, 10] → Transformer → 预测"20"
     [START, 10, 20]

t=2: [START, 10, 20] → Transformer → 预测"200"（Ancestor）
     [START, 10, 20, 200]

t=3: [START, 10, 20, 200] → Transformer → 预测"250"
     [START, 10, 20, 200, 250]

...

t=N: [...] → Transformer → 预测"571"（EOS）
     停止生成！
```

---

## 4. 约束机制详解

### 4.1 为什么需要约束？

```
没有约束的问题：
  位置2（类型槽）: 预测"999" ❌ 超出范围[200,203]
  位置3（连接槽）: 预测"260" ❌ 连接到不存在的节点10
  位置4（系数槽）: 预测"-5"  ❌ 负数无效

有约束：
  位置2: 只允许[200, 201, 202, 203]
  位置3: 只允许[250, ..., 250+当前节点数-1]
  位置4: 只允许[350, ..., 549]
```

### 4.2 槽位约束表

| 步数t | 槽位 | 约束规则 | 示例 |
|-------|------|----------|------|
| t=1 | x坐标 | [0, 199] | 任意坐标 |
| t=2 | y坐标 | [0, 199] | 任意坐标 |
| t=3 | 类型 | [200, 203] | 4种类型 |
| t=4 | 连接 | [250, 250+i-1] | i=当前节点数 |
| t=5 | 系数x | [350, 549] | 200个值 |
| t=6 | 系数y | [350, 549] | 200个值 |

### 4.3 约束代码实现

```python
# ar_rntr_head.py L349-394

def _apply_slot_constraints_step(self, step_logits, t, clause_length):
    """对当前步应用槽位约束"""
    B, V = step_logits.shape  # V=574
    device = step_logits.device
    
    # 计算当前是哪个槽位
    slot = (t - 1) % clause_length
    # t=1: slot=0 (x坐标)
    # t=2: slot=1 (y坐标)
    # t=3: slot=2 (类型)
    # t=4: slot=3 (连接)
    # t=5,6: slot=4,5 (系数)
    
    mask = None
    
    # 🔑 类型槽位：只允许[200, 203]
    if slot == 2:
        s = int(self.category_start)  # 200
        e = int(self.category_start + self.label_num_classes)  # 204
        mask = torch.ones(V, dtype=torch.bool, device=device)
        mask[s:e] = False  # False表示允许
    
    # 🔑 连接槽位：只允许[250, 250+i-1]
    elif slot == 3:
        i = (t - 1) // clause_length  # 当前是第几个节点
        upper = max(0, i - 1)  # 最多连接到前一个节点
        s = int(self.connect_start)  # 250
        e = int(self.connect_start + upper + 1)
        mask = torch.ones(V, dtype=torch.bool, device=device)
        if e > s:
            mask[s:e] = False
        else:
            mask[self.connect_start] = False  # 至少允许250
    
    # 🔑 系数槽位：只允许[350, 549]
    elif slot >= 4:
        s = int(self.coeff_start)  # 350
        e = int(self.coeff_start + self.coeff_range)  # 550
        mask = torch.ones(V, dtype=torch.bool, device=device)
        mask[s:e] = False
    
    # 应用掩码（不允许的位置设为-inf）
    if mask is not None:
        mask_b = mask.unsqueeze(0).expand(B, -1)
        step_logits = step_logits.masked_fill(mask_b, float('-inf'))
    
    return step_logits
```

### 4.4 约束效果示例

```python
# 生成第2个节点的连接槽位（t=9, slot=3）
i = (9 - 1) // 6 = 1  # 第1个节点（从0开始）

# 只允许连接到节点0
allowed_range = [250, 251)
allowed_tokens = [250]

# Softmax前的logits:
logits_before = [-inf, -inf, ..., 5.2(250), -inf, -inf, ...]
                                    ↑ 只有这个位置有效

probs = softmax(logits_before)
# 结果：100%选择token 250
```

---

## 5. 训练技巧总结

### 5.1 数据增强

```python
# 论文Section 4.2
# BEV特征增强：
- Random flip（随机翻转）
- Random rotation（-45° to 45°）
- Random scaling（0.9 to 1.1）
```

### 5.2 训练配置

```python
# 论文标准配置
epochs = 300
learning_rate = 2e-4
batch_size = 16  # 2×8
optimizer = 'Adam'

# 预训练
load_from = 'lss_roadseg_*.pth'  # LSS预训练权重
freeze_pretrain = False  # 微调所有层
```

### 5.3 防止过拟合

```python
# Transformer中的Dropout
dropout = 0.1

# 序列噪声填充
synthetic_noise_objects = True
```

---

## 小结

✅ **训练数据**：真实节点 + 噪声节点
✅ **损失函数**：4个分量（坐标、类型、连接、系数）
✅ **推理流程**：自回归生成 + 槽位约束
✅ **关键技巧**：类别权重、噪声对象、约束机制

下一部分讲解**代码运行实战**！
