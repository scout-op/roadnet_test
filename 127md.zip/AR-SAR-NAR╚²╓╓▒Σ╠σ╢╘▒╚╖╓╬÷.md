# AR-RNTR vs SAR-RNTR vs NAR-RNTR：耦合/解耦对比分析 🔄

> **核心问题**：三个变体在token生成依赖关系上有何区别？

---

## 1. 核心概念：耦合 vs 解耦

### 1.1 什么是"耦合"？

**耦合 (Coupled)**：token之间存在严格的依赖关系

```
生成token t 必须依赖 token 1, 2, ..., t-1
P(y_t | y_{<t}, F) - 必须等前面所有token生成完才能生成当前token
```

### 1.2 什么是"解耦"？

**解耦 (Decoupled)**：token之间没有或有弱依赖关系

```
生成token t 可以独立于其他token（或只依赖部分token）
P(y_t | F) - 直接从特征F预测，不依赖其他token
```

---

## 2. 三种变体对比

### 2.1 总览表

| 变体 | 耦合程度 | token依赖关系 | 生成方式 | 速度 | 精度 |
|------|----------|---------------|----------|------|------|
| **AR-RNTR** | 🔴 **完全耦合** | 严格顺序依赖 | 串行生成 | 1× (慢) | 中等 |
| **SAR-RNTR** | 🟡 **半解耦** | 跨序列并行 + 序列内顺序 | 半并行生成 | 6× (快) | **最高** |
| **NAR-RNTR** | 🟢 **完全解耦** | 无依赖关系 | 完全并行 | 47× (最快) | 较高 |

---

## 3. AR-RNTR：完全耦合 🔴

### 3.1 依赖关系

**论文描述**（Section 3.5）：
> "AR-RNTR generates RoadNet Sequence one by one"

**数学表达**：
```
P(y_1, y_2, ..., y_T | F) = ∏_{t=1}^T P(y_t | y_{<t}, F)
```

**可视化**：
```
Step 1: [START] → 预测 y_1
         ↓ 依赖
Step 2: [START, y_1] → 预测 y_2
                ↓ 依赖
Step 3: [START, y_1, y_2] → 预测 y_3
                        ↓ 依赖
...
Step T: [START, y_1, ..., y_{T-1}] → 预测 y_T
```

### 3.2 代码实现

```python
# ar_rntr_head.py 推理流程
for t in range(max_iteration):
    # Step 1: 嵌入当前序列（必须包含所有前面的token）
    tgt = self.embedding(input_seqs.long())  # [B, t, D]
    
    # Step 2: Transformer处理（使用因果掩码确保顺序依赖）
    outs_dec, _ = self.transformer(tgt, x, masks, query_embed, pos_embed)
    
    # Step 3: 预测下一个token（只依赖前面的token）
    logits = self.vocab_embed(outs_dec[-1, :, -1, :])  # 最后一个位置
    next_token = logits.argmax(dim=-1)
    
    # Step 4: 添加到序列（下一轮依赖当前结果）
    input_seqs = torch.cat([input_seqs, next_token], dim=-1)
    
    if next_token == EOS:
        break  # 只有生成EOS才能停止
```

**关键点**：
- ✅ 每个token必须**串行生成**
- ✅ 使用**因果掩码**（causal mask）确保t只能看到1:t-1
- ✅ 无法并行化

---

## 4. SAR-RNTR：半解耦 🟡

### 4.1 依赖关系

**论文描述**（Section 3.6）：
> "Semi-autoregressive RNTR retains auto-regressive functionality within local contexts while simultaneously conducting non-autoregressive generations in parallel."

**数学表达**：
```
P(y_{1:M, 1:L} | F, V_kp) = ∏_{j=1}^L ∏_{i=1}^M P(y_{i,j} | y_{1:M, 1:j-1}, F, V_kp)
```

**可视化（2D序列）**：
```
        位置j=1    位置j=2    位置j=3
序列1:   y_{1,1} → y_{1,2} → y_{1,3}  ← 序列内顺序依赖
         ↓ 并行    ↓ 并行    ↓ 并行
序列2:   y_{2,1} → y_{2,2} → y_{2,3}  ← 序列内顺序依赖
         ↓ 并行    ↓ 并行    ↓ 并行
序列3:   y_{3,1} → y_{3,2} → y_{3,3}  ← 序列内顺序依赖

竖向（跨序列）：并行生成 ✅
横向（序列内）：顺序依赖 ❌
```

### 4.2 为什么是"半解耦"？

**论文解释**（Section 3.6）：
> "(i) The locations of certain road points (start points, fork points or merge points) can be **independent** of previous vertices and instead depend solely on the BEV feature map, i.e., P(y_i | y_{<i}, F) = P(y_i | F).
> 
> (ii) Except for locations of these road points, other tokens are still strongly auto-regressive."

**核心思想**：
1. **关键点（keypoints）**：起点、分叉点、合并点 → **解耦**（直接从BEV预测）
2. **其他token**：连接线上的点 → **耦合**（依赖前面的token）

### 4.3 代码实现

```python
# sar_rntr_head.py 训练流程

# Step 1: Keypoint检测（完全并行）
kp_query = self.kp_query_embed.weight  # [num_query, D]
kp_out, _ = self.kp_transformer(kp_query, bev_feats, ...)
kp_cls = self.kp_cls_head(kp_out)     # [B, Q, 4] - 并行预测所有keypoints
kp_coord = self.kp_reg_head(kp_out)   # [B, Q, 2]

# Step 2: 2D序列生成（半并行）
tgt = self.embedding(input_seqs_2d)  # [B, M, L, D]

# Axial Attention: Intra-seq（跨M并行） + Inter-seq（L内顺序）
# axial_sar_transformer.py L91-120
# === Intra-seq: 对每个位置j，跨M个序列并行处理 ===
tgt_intra = tgt.permute(0, 2, 1, 3).reshape(B*L, M, D)
# 所有M个序列的位置j可以同时看到所有位置<j的信息

# === Inter-seq: 每个序列内部，仍然是因果的 ===
# 位置j只能看到位置1:j-1，保持自回归
```

**关键点**：
- ✅ M个子序列可以**并行生成**同一位置j
- ❌ 每个子序列内部仍然是**顺序依赖**
- ✅ 复杂度从O(T) → O(T/M)，加速M倍

### 4.4 Axial Attention机制

```python
# axial_sar_transformer.py 核心逻辑

class AxialSARDecoderLayer(nn.Module):
    def forward(self, tgt, memory, ...):
        """
        tgt: [B, M, L, D] - 2D序列
        """
        # === Stage 1: Intra-seq attention (跨M并行) ===
        # 对每个位置j，所有M个序列同时处理
        tgt_intra = tgt.permute(0, 2, 1, 3).reshape(B*L, M, D)
        tgt_intra, _ = self.intra_attn(tgt_intra, tgt_intra, tgt_intra)
        
        # === Stage 2: Inter-seq attention (L内因果) ===
        # 对每个序列i，位置j只能看1:j-1
        tgt_inter = tgt.reshape(B*M, L, D)
        causal_mask = self._build_causal_mask(L)  # 上三角掩码
        tgt_inter, _ = self.inter_attn(
            tgt_inter, tgt_inter, tgt_inter, 
            attn_mask=causal_mask  # 确保因果关系
        )
```

**复杂度分析**：
- Intra-seq: O(L × M²) - L次，每次M²复杂度
- Inter-seq: O(M × L²) - M次，每次L²复杂度
- 总计: O(M²L + ML²) = O(M²+L²) ≪ O(M²L²)

---

## 5. NAR-RNTR：完全解耦 🟢

### 5.1 依赖关系

**论文描述**（Section 3.7 - 推测，论文未详细展开）：
> "NAR-RNTR uses Masked Language Modeling (MLM) for training and iterative refinement for inference."

**数学表达**：
```
P(y_1, y_2, ..., y_T | F) = ∏_{t=1}^T P(y_t | F)  ← 所有token独立
```

**可视化**：
```
BEV特征F
    ↓ 并行
┌───┼───┼───┼───┐
y_1 y_2 y_3 ... y_T  ← 所有token同时生成

迭代refinement:
Round 1: 生成初步预测 [y_1, y_2, ..., y_T]
Round 2: mask低置信度token，重新预测
Round 3: 再次refine
...
```

### 5.2 代码实现

```python
# sar_rntr_head.py NAR模式配置

# NAR训练模式
self.nar_mlm_train = bool(nar_mlm_train)  # 启用MLM训练
self.nar_mask_ratio = float(nar_mask_ratio)  # 0.9 (mask 90%的token)

# NAR推理模式
self.nar_infer = bool(nar_infer)
self.nar_iters = max(1, int(nar_iters))  # 迭代次数（默认3次）
self.nar_conf_thresh = float(nar_conf_thresh)  # 置信度阈值

# 训练时使用全可见掩码（不是因果掩码）
if self.nar_mlm_train:
    tgt_mask = torch.zeros_like(tgt_mask)  # 所有token可以互相看到
```

**MLM训练流程**：
```python
# 训练阶段
def nar_mlm_forward(self, input_seqs):
    # Step 1: 随机mask 90%的token
    mask_indices = random.sample(range(len(input_seqs)), 
                                 k=int(0.9 * len(input_seqs)))
    masked_seqs = input_seqs.clone()
    masked_seqs[mask_indices] = MASK_TOKEN
    
    # Step 2: 并行预测所有token（使用全可见attention）
    tgt = self.embedding(masked_seqs)
    outs, _ = self.transformer(tgt, bev_feats, tgt_mask=None)  # 无掩码
    
    # Step 3: 计算所有位置的损失
    loss = cross_entropy(outs, input_seqs)  # 所有token同时训练
```

**推理流程（迭代refinement）**：
```python
# 推理阶段
def nar_inference(self, bev_feats):
    # Round 1: 初始化为所有MASK
    seqs = torch.full((B, T), MASK_TOKEN)
    
    for iter in range(self.nar_iters):  # 3次迭代
        # 并行预测所有token
        logits = self.forward(seqs, bev_feats)
        probs = logits.softmax(dim=-1)
        pred_tokens = logits.argmax(dim=-1)
        confidence = probs.max(dim=-1)
        
        # 只保留高置信度的预测
        keep_mask = confidence > self.nar_conf_thresh
        seqs = torch.where(keep_mask, pred_tokens, MASK_TOKEN)
        # 下一轮重新预测低置信度的token
    
    return seqs
```

**关键点**：
- ✅ 所有token**完全并行生成**
- ✅ 使用**全可见attention**（无因果掩码）
- ✅ 通过**迭代refinement**提高质量
- ✅ 47倍加速（相比AR-RNTR）

---

## 6. 耦合度对比总结

### 6.1 Attention Mask对比

| 变体 | Mask类型 | 可视化 | token t能看到什么 |
|------|----------|--------|-------------------|
| **AR** | 因果掩码 | `[[1,0,0,0],[1,1,0,0],[1,1,1,0],[1,1,1,1]]` | 只能看1:t-1 |
| **SAR** | 块级因果 | `[[1,1,0,0],[1,1,0,0],[1,1,1,1],[1,1,1,1]]` | 同块内互看，前面块全看 |
| **NAR** | 全可见 | `[[1,1,1,1],[1,1,1,1],[1,1,1,1],[1,1,1,1]]` | 所有token互看 |

### 6.2 代码中的Mask构建

```python
# AR-RNTR: 标准因果掩码
def build_causal_mask(T):
    mask = torch.triu(torch.ones(T, T), diagonal=1).bool()
    mask = mask.masked_fill(mask, float('-inf'))
    return mask
# 结果: 上三角为-inf（不可见）

# SAR-RNTR: 块级因果掩码
def _build_block_causal_mask(T, block_len):
    num_blocks = math.ceil(T / block_len)
    mask = torch.full((T, T), float('-inf'))
    for b in range(num_blocks):
        start = b * block_len
        end = min((b + 1) * block_len, T)
        mask[start:end, :end] = 0.0  # 当前块可以看前面所有
    return mask

# NAR-RNTR: 无掩码
if self.nar_mlm_train:
    tgt_mask = torch.zeros((T, T))  # 全0，所有位置可见
```

---

## 7. 性能对比

### 7.1 速度 vs 精度权衡

```
精度 ↑
 │
51.2├─ SAR (6×速度) ●  ← 最佳平衡
 │              ╱
49.3├─ NAR (47×速度)  ○
 │        ╱
45.6├─ AR (1×速度)    ○
 │  ╱
 └──────────────────→ 速度
    慢              快
```

### 7.2 nuScenes实验结果

| 模型 | Reachability F1 | 推理速度 | 耦合度 | 适用场景 |
|------|-----------------|----------|--------|----------|
| **AR-RNTR** | 45.6 | 1× (基线) | 完全耦合 | 高精度要求 |
| **SAR-RNTR** | **51.2** ⭐ | 6× | 半解耦 | **生产推荐** |
| **NAR-RNTR** | 49.3 | 47× | 完全解耦 | 实时系统 |

**关键发现**：
- SAR-RNTR既保留了关键依赖（序列内），又实现了并行化（跨序列）
- 在精度和速度上达到最佳平衡

---

## 8. 为什么SAR最优？

### 8.1 论文解释（Section 3.6）

> "The human language is highly cohesive, which means that any attempt to generate text without auto-regressive assumption can result in a significant decrease in accuracy. 
> 
> However, it's not the case for road network."

**关键洞察**：
1. **自然语言**：高度连贯，需要严格的顺序依赖（AR最优）
2. **道路网络**：
   - 关键点位置相对独立（可以并行预测）
   - 连接线段仍需要顺序信息（保留自回归）

### 8.2 SAR的优势

```
AR的问题：
  过度耦合 → 串行生成 → 慢 ❌

NAR的问题：
  完全解耦 → 丢失拓扑依赖 → 精度下降 ❌

SAR的解决方案：
  选择性解耦：
  - Keypoints并行 ✅
  - 连接保持顺序 ✅
  → 速度快 + 精度高 ⭐
```

---

## 9. 实际代码验证

### 9.1 查看Mask应用

```python
# ar_rntr_head.py L500+
# AR模式：逐token生成，隐式因果
for t in range(max_iteration):
    tgt = self.embedding(input_seqs[:, :t+1])  # 只看前t个
    out = self.transformer(tgt, ...)
    next_token = out[:, -1, :].argmax(-1)
    input_seqs = torch.cat([input_seqs, next_token], -1)

# sar_rntr_head.py L462
# SAR模式：块级因果掩码
tgt_mask = _build_block_causal_mask(T, block_len, device)
# block_len = clause_length (通常6)

# sar_rntr_head.py L481
# NAR模式：无掩码
if self.nar_mlm_train:
    tgt_mask = torch.zeros_like(tgt_mask)  # 全可见
```

---

## 10. 总结

| 维度 | AR-RNTR | SAR-RNTR | NAR-RNTR |
|------|---------|----------|----------|
| **耦合度** | 🔴 完全耦合 | 🟡 半解耦 | 🟢 完全解耦 |
| **依赖关系** | 严格顺序 | 跨序列并行 + 序列内顺序 | 无依赖 |
| **Mask类型** | 因果掩码 | 块级因果 | 无掩码 |
| **并行度** | 0% (串行) | M倍 (跨序列) | 100% (全并行) |
| **速度** | 1× | 6× | 47× |
| **精度** | 45.6 | **51.2** ⭐ | 49.3 |
| **推荐场景** | 离线分析 | **生产部署** | 实时系统 |

### 核心结论

✅ **AR是完全耦合的**：每个token必须依赖所有前面的token  
✅ **SAR是半解耦的**：关键点解耦 + 连接线保持耦合  
✅ **NAR是完全解耦的**：所有token独立预测  

**SAR-RNTR在精度和速度上达到最佳平衡，是生产部署的首选！** 🎯
