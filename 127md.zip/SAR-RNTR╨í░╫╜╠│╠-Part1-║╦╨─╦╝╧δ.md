# SAR-RNTR小白教程 - Part1：核心思想 💡

> **目标**：用最简单的方式理解SAR-RNTR的核心创新

---

## 1. 为什么需要SAR-RNTR？

### 1.1 AR-RNTR的问题 ❌

**问题1：太慢了！**

```
AR-RNTR生成过程（串行）：
Step 1: [START] → 预测token 1
Step 2: [START, 1] → 预测token 2
Step 3: [START, 1, 2] → 预测token 3
...
Step 100: [...] → 预测token 100

⏱️ 需要100步才能生成100个token
```

**类比**：就像排队买票，必须等前一个人买完，下一个人才能买。

---

### 1.2 SAR-RNTR的核心思想 ✅

**论文洞察**（Section 3.6）：
> "道路网络和自然语言不同！关键点（起点、分叉点）的位置可以独立预测，但连接线段仍需要顺序信息。"

**关键发现**：

```
道路网络的特点：
┌─────────────────┐
│ 关键点（起点A） │ ← 可以独立预测！
└────────┬────────┘
         │ 连接线1
         ↓
┌─────────────────┐
│ 分叉点B         │ ← 可以独立预测！
└────┬───────┬────┘
     │       │
     ↓       ↓
  线2       线3
```

**SAR的策略**：
1. 先**并行预测所有关键点**（快！）
2. 再**并行生成每个分支的连接线**（快！）
3. 每个分支内部仍保持顺序（保证质量！）

---

## 2. 核心创新1️⃣：2D序列表示

### 2.1 从1D到2D

**AR-RNTR的1D序列**：
```
[START, 10, 20, 200, 250, ..., 15, 30, 201, 250, ..., EOS]
       └─── 节点1 ───┘       └─── 节点2 ───┘

一个长长的序列，必须从左到右依次生成
```

**SAR-RNTR的2D序列**：
```
        位置1   位置2   位置3   ...  位置L
分支1: [10,20] [15,30] [20,40] ... [25,50]
       ↓ 并行  ↓ 并行  ↓ 并行      ↓ 并行
分支2: [12,18] [17,28] [22,38] ... [27,48]
       ↓ 并行  ↓ 并行  ↓ 并行      ↓ 并行
分支3: [08,25] [13,35] [18,45] ... [23,55]
       ↓ 并行  ↓ 并行  ↓ 并行      ↓ 并行
...
分支M: [....]  [....]  [....]  ... [....]

纵向（M个分支）：可以同时生成 ✅
横向（L个位置）：按顺序生成 ❌
```

### 2.2 代码实现

```python
# sar_rntr_head.py L158-161
self.use_2d_sequence = True           # 启用2D模式
self.max_sequences = 50               # M: 最多50个分支
self.max_seq_len = 100                # L: 每个分支最多100个token

# 输入形状：[B, M, L, D]
# B: batch size
# M: 分支数量
# L: 每个分支的长度
# D: 特征维度（256）
```

**论文中的配置**（Section 4.2）：
```python
M = 34  # 最多34个关键点（分叉点）
L = 18  # 每个分支6个整数/节点 × 3个节点 = 18
```

---

## 3. 核心创新2️⃣：Keypoint检测

### 3.1 什么是Keypoint？

**论文定义**（Section 3.6）：
> "关键点满足条件：`od(v)>1` 或 `id(v)>1` 或 `id(v)=0`"

**通俗解释**：

```
od(v) = 出度 = 从这个点出发的边数
id(v) = 入度 = 指向这个点的边数

关键点类型：
1️⃣ id(v)=0: 起点（没有父节点）
2️⃣ od(v)>1: 分叉点（有多个子节点）
3️⃣ id(v)>1: 合并点（有多个父节点）
```

**图解**：

```
示例道路网络：
    A (id=0) ← 起点，关键点✅
    ↓
    B (od=2) ← 分叉点，关键点✅
   ↙ ↘
  C   D
  ↓   ↓
  E   F (id=2) ← 合并点（如果C和D都指向F），关键点✅
```

### 3.2 代码实现

```python
# sar_sequence_generator.py L53-85
def identify_keypoints(self, nodes, edges):
    """识别关键点"""
    # 计算出入度
    in_degree = defaultdict(int)
    out_degree = defaultdict(int)
    
    for src_id, tgt_id, _ in edges:
        out_degree[src_id] += 1  # 源节点出度+1
        in_degree[tgt_id] += 1   # 目标节点入度+1
    
    # 按照论文标准识别关键点
    keypoints = []
    for node in nodes:
        node_id = node['id']
        od = out_degree[node_id]
        id_ = in_degree[node_id]
        
        # 论文公式
        if od > 1 or id_ > 1 or id_ == 0:
            keypoints.append(node_id)
    
    return keypoints
```

**示例**：

```python
# 输入道路图
nodes = [
    {'id': 0, 'x': 10, 'y': 20},  # A
    {'id': 1, 'x': 15, 'y': 30},  # B
    {'id': 2, 'x': 20, 'y': 40},  # C
    {'id': 3, 'x': 18, 'y': 25},  # D
]
edges = [
    (0, 1, coeff1),  # A → B
    (1, 2, coeff2),  # B → C
    (1, 3, coeff3),  # B → D (分叉)
]

# 计算度数
# id=0: in=0, out=1 → 关键点（起点）✅
# id=1: in=1, out=2 → 关键点（分叉）✅
# id=2: in=1, out=0 → 普通节点
# id=3: in=1, out=0 → 普通节点

keypoints = [0, 1]  # A和B是关键点
```

---

## 4. 核心创新3️⃣：Keypoint Transformer

### 4.1 并行检测所有关键点

**传统AR方法**：
```
生成A → 生成B → 生成C → ...
慢！串行！
```

**SAR的Keypoint Transformer**：
```
BEV特征
    ↓
[Query1, Query2, ..., QueryN] ← 可学习的查询向量
    ↓ 并行Transformer
[预测点1, 预测点2, ..., 预测点N]
    ↓
筛选出真实的关键点（类似目标检测）
```

**类比**：DETR目标检测！

### 4.2 代码实现

```python
# sar_rntr_head.py L205-208
# 1. 定义Keypoint查询向量
self.kp_query_embed = nn.Embedding(
    self.kp_num_query,  # 200个查询
    self.embed_dims     # 256维
)

# 2. Keypoint Transformer（3层）
self.kp_transformer = MODELS.build(dict(
    type='KeypointTransformer',
    decoder=dict(
        num_layers=3,  # 3层Transformer
        ...
    )
))

# 3. 预测头
self.kp_cls_head = Linear(256, 4)     # 分类：4种类型
self.kp_reg_head = MLP(256, 256, 2, 3)  # 回归：(x,y)坐标
```

**前向传播**：

```python
# 推理时
kp_query = self.kp_query_embed.weight  # [200, 256]
kp_out, _ = self.kp_transformer(
    kp_query,   # 查询向量
    bev_feats,  # BEV特征
    ...
)

# 预测分类和坐标
kp_cls = self.kp_cls_head(kp_out)     # [B, 200, 4]
kp_coord = self.kp_reg_head(kp_out)   # [B, 200, 2]

# 选择置信度最高的top-k个
topk_keypoints = select_topk(kp_coord, kp_cls, k=34)
```

**损失函数**（Hungarian Matching）：

```python
# 论文Section 3.6
# 双边匹配：预测的keypoints ↔ GT keypoints
matcher = HungarianMatcher()
indices = matcher(pred_kp, gt_kp)

# 匹配后的损失
loss_cls = CrossEntropyLoss(pred_kp[indices], gt_kp[indices])
loss_coord = L1Loss(pred_coord[indices], gt_coord[indices])
```

---

## 5. 关键点如何变成2D序列？

### 5.1 DAG分解

**输入**：完整的道路DAG + 识别出的关键点

**步骤**（论文Section 3.6）：
> "We recursively extract these keypoints from their original parent and sub-tree until they become roots with id(v)=0."

**图解**：

```
原始DAG：
    A (起点)
    ↓
    B (分叉)
   ↙ ↘
  C   D
  ↓   ↓
  E   F

识别关键点：A, B

分解成2个子树：
子树1（以A为根）:    子树2（以B为根）:
    A                    B
    ↓                   ↙ ↘
    B'(Clone)          C   D
                       ↓   ↓
                       E   F

2D序列：
seq[0] = [A的6个token, B'的6个token(Clone)]
seq[1] = [B的6个token, C的6个token, E的6个token]
seq[2] = [B的6个token, D的6个token, F的6个token]
```

注意：B'是B的克隆，标记为Clone类型

### 5.2 代码实现

```python
# sar_sequence_generator.py L87-100
def extract_subtrees(self, nodes, edges, keypoint_ids):
    """将DAG分解成以关键点为根的子树"""
    subtrees = []
    
    for kp_id in keypoint_ids:
        # 从该关键点开始DFS遍历
        subtree_nodes, subtree_edges = self.dfs_from_keypoint(kp_id)
        
        # 如果遇到其他关键点，创建Clone节点
        for node in subtree_nodes:
            if node['id'] in keypoint_ids and node['id'] != kp_id:
                clone_node = node.copy()
                clone_node['type'] = 'Clone'
                subtree_nodes.append(clone_node)
        
        subtrees.append({
            'root': kp_id,
            'nodes': subtree_nodes,
            'edges': subtree_edges
        })
    
    return subtrees
```

---

## 小结Part1

✅ **核心思想**：关键点并行 + 分支内串行  
✅ **2D序列**：M个分支 × L个位置  
✅ **Keypoint检测**：od>1 or id>1 or id=0  
✅ **Keypoint Transformer**：类似DETR的目标检测  
✅ **DAG分解**：关键点为根，生成M个子树  

**下一Part讲解Axial Attention机制！** 🚀
