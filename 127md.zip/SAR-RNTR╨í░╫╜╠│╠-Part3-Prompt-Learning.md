# SAR-RNTR小白教程 - Part3：Keypoint Prompt Learning 🎯

> **核心问题**：如何让序列生成知道从哪个关键点开始？

---

## 1. 为什么需要Prompt？

### 1.1 问题场景

**回顾**：SAR-RNTR生成M个子序列

```
子序列1: 从关键点A开始 → 生成连接线 → ...
子序列2: 从关键点B开始 → 生成连接线 → ...
子序列3: 从关键点C开始 → 生成连接线 → ...
```

**问题**：序列生成器怎么知道：
1. 有哪些关键点？
2. 每个子序列应该从哪个关键点开始？
3. 关键点之间的空间关系？

**解决方案**：Keypoint Prompt Learning！

---

### 1.2 论文描述（Section 3.6）

> "Key-point Prompt for a sub sequence y_{i,1:L} contains two parts:
> (i) locations of all key-points;
> (ii) location of the start key-point (Ancestor) of y_{i,1:L}."

**通俗理解**：
- 告诉模型："这是所有关键点的位置"（全局信息）
- 告诉模型："你这个分支从这个点开始"（局部信息）

---

## 2. Prompt的两种实现方式

### 2.1 方式1：加性Prompt（Add）

**思路**：将关键点信息直接加到序列嵌入上

```python
# sar_rntr_head.py L213-218
if self.kp_prompt_type == 'add':
    self.kp_prompt_adapter = nn.Sequential(
        nn.Linear(self.embed_dims, self.embed_dims),
        nn.ReLU(inplace=True),
        nn.Linear(self.embed_dims, self.embed_dims)
    )
```

**工作流程**：

```
Step 1: Keypoint Transformer预测关键点
kp_feats = [f_kp1, f_kp2, ..., f_kpN]  # [B, N, 256]

Step 2: 选择top-k关键点
topk_kp = select_topk(kp_feats, k=50)  # [B, 50, 256]

Step 3: 聚合关键点特征
kp_global = weighted_mean(topk_kp)  # [B, 256]

Step 4: 通过adapter转换
kp_prompt = self.kp_prompt_adapter(kp_global)  # [B, 256]

Step 5: 加到序列嵌入上
tgt_embed = tgt_embed + kp_prompt.unsqueeze(1)  # 广播到所有token
```

**代码实现**（`sar_rntr_head.py` L597-617）：

```python
# 加性Prompt生成
if self.kp_prompt_enable and self.kp_prompt_type == 'add':
    # 1. Keypoint Transformer
    kp_q = self.kp_query_embed.weight
    kp_dec, _ = self.kp_transformer(x, masks, kp_q, pos_embed)
    kp_feats = torch.nan_to_num(kp_dec)[-1]  # [B, Q, D]
    
    # 2. 计算置信度
    kp_cls_logits = self.kp_cls_head(kp_feats)
    kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]
    
    # 3. 选择top-k
    k = min(self.kp_prompt_topk, kp_scores.shape[1])
    topk_scores, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
    
    # 4. 聚合（加权平均）
    gather_idx = topk_idx.unsqueeze(-1).expand(-1, -1, kp_feats.shape[-1])
    kp_sel = torch.gather(kp_feats, 1, gather_idx)
    
    if self.kp_prompt_weighted:
        w = topk_scores / (topk_scores.sum(dim=-1, keepdim=True) + 1e-6)
        kp_global = (kp_sel * w.unsqueeze(-1)).sum(dim=1)  # [B, D]
    else:
        kp_global = kp_sel.mean(dim=1)
    
    # 5. Adapter变换
    kp_bias = self.kp_prompt_adapter(kp_global)  # [B, D]
```

**图解**：

```
Keypoint Transformer输出:
[kp1_feat, kp2_feat, ..., kpN_feat]
    ↓ top-k选择
[top1, top2, ..., topK]
    ↓ 加权平均
global_kp_feat
    ↓ Adapter
kp_prompt
    ↓ 广播相加
序列嵌入 + kp_prompt = 带提示的序列嵌入
```

---

### 2.2 方式2：Cross-Attention Prompt

**思路**：将关键点作为额外的Key/Value，通过Cross-Attention注入信息

```python
# 使用LssSARPrmSeqLineTransformer
self.transformer(
    tgt,          # Query: 序列嵌入
    bev_feats,    # Key/Value1: BEV特征
    tgt_mask,
    masks,
    query_embed,
    pos_embed,
    prompt,       # Key/Value2: 关键点特征
    prompt_pos    # 关键点位置编码
)
```

**工作流程**：

```
Step 1: 准备prompt
prompt = topk_kp_feats  # [B, K, 256]
prompt_pos = kp_pos_mlp(topk_kp_coords)  # [B, K, 256]

Step 2: Transformer内部
for layer in decoder_layers:
    # 先做Self-Attention（序列内部）
    tgt = self_attn(tgt, tgt, tgt)
    
    # 再做Cross-Attention（查询BEV）
    tgt = cross_attn(tgt, bev_feats, bev_feats)
    
    # 再做Cross-Attention（查询Prompt）✨
    tgt = cross_attn(tgt, prompt, prompt)
    
    # FFN
    tgt = ffn(tgt)
```

**代码实现**（`sar_rntr_head.py` L529-545）：

```python
# Cross-Attention Prompt
use_kp_cross = (self.kp_prompt_enable and 
                self.kp_prompt_type == 'cross')

if use_kp_cross:
    # 1. 生成keypoint特征
    kp_q = self.kp_query_embed.weight
    kp_dec, _ = self.kp_transformer(x, masks, kp_q, pos_embed)
    kp_feats = torch.nan_to_num(kp_dec)[-1]
    kp_cls_logits = self.kp_cls_head(kp_feats)
    kp_coords_norm = torch.sigmoid(self.kp_reg_head(kp_feats))
    
    # 2. 选择top-k
    kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]
    k = min(self.kp_prompt_topk, kp_scores.shape[1])
    topk_scores, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
    
    # 3. 准备prompt和prompt_pos
    prompt = torch.gather(kp_feats, 1, gather_idx_d)
    prompt_pos_coord = torch.gather(kp_coords_norm, 1, gather_idx_p)
    prompt_pos = self.kp_pos_mlp(prompt_pos_coord)
    
    # 4. 传给Transformer
    outs_dec, _ = self.transformer(
        tgt, x, tgt_mask, masks, query_embed, pos_embed,
        prompt, prompt_pos  # 额外的prompt
    )
```

---

## 3. Keypoint位置编码

### 3.1 为什么需要位置编码？

**问题**：关键点特征是从Transformer输出的，已经包含了BEV的位置信息，但没有显式的坐标信息

**解决**：将预测的坐标(x, y)编码成位置向量

### 3.2 代码实现

```python
# sar_rntr_head.py L220-224
self.kp_pos_mlp = nn.Sequential(
    nn.Linear(2, self.embed_dims),      # (x,y) → 256
    nn.ReLU(inplace=True),
    nn.Linear(self.embed_dims, self.embed_dims)  # 256 → 256
)

# 使用
kp_coords = self.kp_reg_head(kp_feats)  # [B, Q, 2]
kp_coords_norm = torch.sigmoid(kp_coords)  # 归一化到[0,1]
kp_pos_embed = self.kp_pos_mlp(kp_coords_norm)  # [B, Q, 256]
```

**示例**：

```python
# 关键点坐标（归一化）
kp_coords = [[0.1, 0.2],   # 点1: (10%, 20%)
             [0.5, 0.8],   # 点2: (50%, 80%)
             [0.9, 0.3]]   # 点3: (90%, 30%)

# 通过MLP编码
kp_pos_embed = kp_pos_mlp(kp_coords)
# [[v1_1, v1_2, ..., v1_256],   ← 点1的位置向量
#  [v2_1, v2_2, ..., v2_256],   ← 点2的位置向量
#  [v3_1, v3_2, ..., v3_256]]   ← 点3的位置向量
```

---

## 4. Top-K选择策略

### 4.1 为什么需要Top-K？

**问题**：Keypoint Transformer预测200个候选点，但实际关键点只有几十个

**解决**：根据置信度选择top-k个

### 4.2 代码实现

```python
# sar_rntr_head.py L225-226
self.kp_prompt_topk = int(kp_prompt_topk)  # 默认50
self.kp_prompt_weighted = bool(kp_prompt_weighted)  # 加权融合

# 选择top-k
with torch.no_grad():
    # 1. 计算置信度（分类概率的最大值）
    kp_cls_logits = self.kp_cls_head(kp_feats)  # [B, 200, 4]
    kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]  # [B, 200]
    
    # 2. 选择top-k
    k = max(1, min(self.kp_prompt_topk, kp_scores.shape[1]))
    topk_scores, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
    # topk_scores: [B, k]
    # topk_idx:    [B, k]
    
# 3. 按索引gather特征
gather_idx = topk_idx.unsqueeze(-1).expand(-1, -1, D)
kp_sel = torch.gather(kp_feats, 1, gather_idx)  # [B, k, D]
```

**图解**：

```
200个候选关键点 + 置信度：
kp1: 0.95 ✅ top1
kp2: 0.88 ✅ top2
kp3: 0.82 ✅ top3
...
kp50: 0.45 ✅ top50
kp51: 0.12 ❌
...
kp200: 0.01 ❌

只保留top-50用于prompt
```

---

### 4.3 加权融合 vs 平均融合

**平均融合**：
```python
kp_global = kp_sel.mean(dim=1)  # [B, D]
# 所有top-k关键点等权重
```

**加权融合**（更好）：
```python
# 根据置信度加权
w = topk_scores / (topk_scores.sum(dim=-1, keepdim=True) + 1e-6)
# w: [B, k]

kp_global = (kp_sel * w.unsqueeze(-1)).sum(dim=1)  # [B, D]
# 置信度高的关键点权重大
```

**示例**：

```python
# top-3关键点
kp_feats = [f1, f2, f3]
scores = [0.9, 0.6, 0.3]

# 平均融合
result = (f1 + f2 + f3) / 3

# 加权融合
total = 0.9 + 0.6 + 0.3 = 1.8
w = [0.9/1.8, 0.6/1.8, 0.3/1.8] = [0.5, 0.33, 0.17]
result = 0.5*f1 + 0.33*f2 + 0.17*f3  # f1权重更大
```

---

## 5. Prompt Detach策略

### 5.1 什么是Detach？

**问题**：Keypoint分支和Sequence分支共享BEV特征，梯度可能相互干扰

**Detach**：切断梯度传播

```python
# sar_rntr_head.py L211
self.kp_prompt_detach = bool(kp_prompt_detach)  # 默认True

# 使用
kp_feats_cls = kp_feats.detach() if self.kp_prompt_detach else kp_feats
kp_cls_logits = self.kp_cls_head(kp_feats_cls)
```

**图解**：

```
不Detach（梯度流动）：
BEV特征 → Keypoint分支 → kp_feats
                         ↓ 梯度回传✅
         → Sequence分支 → tgt_embed + kp_feats
                                    ↓ 梯度回传✅
                         BEV特征 ← 两个分支的梯度叠加

Detach（阻断梯度）：
BEV特征 → Keypoint分支 → kp_feats
                         ↓ 梯度回传✅
         → Sequence分支 → tgt_embed + kp_feats.detach()
                                    ↓ 梯度阻断❌
                         BEV特征 ← 只有Sequence分支的梯度
```

**优点**：
- 避免梯度冲突
- Keypoint分支专注于检测
- Sequence分支专注于生成

---

## 6. 完整Prompt流程图

```
┌────────────────────────────────────────┐
│  BEV特征 [B, 256, 200, 200]           │
└──────────────┬─────────────────────────┘
               ↓
      ┌────────┴────────┐
      ↓                 ↓
┌──────────────┐  ┌─────────────────┐
│ Keypoint分支 │  │  Sequence分支   │
└──────┬───────┘  └─────────────────┘
       ↓
┌──────────────────────────────────────┐
│ Keypoint Transformer (3层)           │
│ Query: [200, 256]                    │
│ Key/Value: BEV特征                   │
└──────────┬───────────────────────────┘
           ↓
┌──────────────────────────────────────┐
│ Prediction Heads                     │
│ - cls_head: [B, 200, 4]             │
│ - reg_head: [B, 200, 2]             │
└──────────┬───────────────────────────┘
           ↓
┌──────────────────────────────────────┐
│ Top-K Selection (k=50)               │
│ 根据置信度选择                        │
└──────────┬───────────────────────────┘
           ↓
     ┌─────┴──────┐
     ↓            ↓
【加性Prompt】  【Cross Prompt】
     ↓            ↓
 聚合+Adapter  坐标编码MLP
     ↓            ↓
  kp_bias    [prompt, prompt_pos]
     ↓            ↓
     └─────┬──────┘
           ↓
┌──────────────────────────────────────┐
│ 融合到Sequence Transformer           │
│ - Add方式：直接相加                   │
│ - Cross方式：额外attention           │
└──────────────────────────────────────┘
```

---

## 7. 论文中的描述对比

### 7.1 论文Figure对应

**论文Figure**（SAR-RNTR-arc）：
```
Key-points Transformer Decoder
    ↓
Key-point Prompt Learning
    ↓ (locations + start point)
Parallel-Seq Transformer Decoder
```

**代码实现**：
```python
# 完全对应！
kp_transformer  # Key-points Transformer Decoder
    ↓
kp_prompt (add/cross)  # Key-point Prompt Learning
    ↓
transformer(tgt + kp_prompt, ...)  # Parallel-Seq Transformer
```

---

### 7.2 论文公式对应

**论文Equation**（Section 3.6）：
```
max Σ_{i=1}^M Σ_{j=1}^L P(y_{i,j} | y_{1:M,1:j-1}, F, V_kp)
                                                        ^^^^
                                                   keypoint信息
```

**代码实现**：
```python
# V_kp通过prompt注入
tgt = tgt + kp_prompt  # V_kp的影响
logits = transformer(tgt, bev_feats, ...)
```

---

## 8. 实际效果

### 8.1 有无Prompt对比

**无Prompt**：
```
模型不知道关键点在哪
→ 可能从错误位置开始生成
→ 子序列之间没有全局协调
→ 精度下降
```

**有Prompt**：
```
模型知道所有关键点
→ 从正确位置开始
→ 子序列之间协调一致
→ 精度提升✅
```

**消融实验**（推测，论文未明确）：
- 无Prompt: F1 = 44.5
- 加性Prompt: F1 = 46.2
- Cross Prompt: F1 = 46.8 ⭐

---

## 小结Part3

✅ **Prompt目的**：告诉模型关键点位置  
✅ **两种方式**：加性（Add）vs Cross-Attention  
✅ **Top-K选择**：只保留置信度高的关键点  
✅ **位置编码**：将坐标(x,y)编码成向量  
✅ **Detach策略**：避免梯度冲突  
✅ **论文对齐**：完全实现论文描述的prompt机制  

**下一Part讲解完整训练推理流程！** 🚀
