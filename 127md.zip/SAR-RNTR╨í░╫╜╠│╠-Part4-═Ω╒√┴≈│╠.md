# SAR-RNTR小白教程 - Part4：完整训练推理流程 🚀

> **目标**：串联所有模块，理解端到端的工作流程

---

## 1. 整体架构回顾

### 1.1 三大模块

```
输入：多视角图像
    ↓
┌────────────────────────────────┐
│ 模块1: BEV特征编码器           │
│ (LiftSplatShoot)               │
│ 6张图 → BEV特征 [B,256,200,200]│
└────────────┬───────────────────┘
             ↓
      ┌──────┴──────┐
      ↓             ↓
┌─────────────┐ ┌──────────────────┐
│ 模块2:      │ │ 模块3:           │
│ Keypoint    │ │ Parallel-Seq     │
│ Transformer │ │ Transformer      │
│             │ │                  │
│ 检测关键点  │ │ 生成2D序列       │
└──────┬──────┘ └────────┬─────────┘
       │                 ↑
       └─── Prompt ──────┘
```

---

## 2. 训练流程（Training）

### 2.1 数据准备

**输入数据**（1个样本）：

```python
# 从DataLoader获取
data = {
    'img': [img1, img2, ..., img6],  # 6张相机图片
    'cam_intrinsic': [...],          # 相机内参
    'cam_extrinsic': [...],          # 相机外参
    
    # Ground Truth
    'gt_keypoints': [[x1,y1], [x2,y2], ...],  # 关键点坐标
    'gt_kp_labels': [0, 1, 2, ...],           # 关键点类型
    'gt_seq_2d': [B, M, L],                   # 2D序列（整数）
}
```

**经过Pipeline预处理**：

```python
# 1. 图像增强
imgs = data_augmentation(imgs)  # 旋转、缩放、颜色抖动

# 2. 序列生成（SAR格式）
seq_2d = generate_sar_sequence(
    road_graph,        # 原始道路图
    keypoints,         # 识别的关键点
    max_M=50,          # 最多50个分支
    max_L=100          # 每分支最多100个token
)
```

---

### 2.2 前向传播（Forward Pass）

#### Step 1: BEV特征提取

```python
# sar_rntr.py L300-350（forward_pts_train方法）
def forward_pts_train(self, imgs, img_metas, gt_lines_coords, ...):
    """训练时的前向传播"""
    
    # 1. 提取BEV特征
    bev_feats = self.view_transformers(imgs, img_metas)
    # bev_feats: [B, 256, 200, 200]
    
    # 2. 展平BEV
    B, C, H, W = bev_feats.shape
    bev_feats_flat = bev_feats.view(B, C, H*W).permute(0, 2, 1)
    # bev_feats_flat: [B, 40000, 256]
```

**对应论文**（Section 3.6）：
> "Ego-car Feature Encoder follows that in AR-RNTR."

---

#### Step 2: Keypoint检测

```python
    # 3. Keypoint Transformer（并行检测）
    kp_preds = self.pts_bbox_head.forward_keypoint_branch(
        bev_feats_flat,
        img_metas
    )
    # kp_preds = {
    #     'cls': [B, num_query, 4],    # 分类logits
    #     'coord': [B, num_query, 2],  # 坐标预测
    # }
```

**对应论文**（Section 3.6）：
> "Key-point Transformer Decoder is a parallel Transformer decoder which takes a fixed set of learned positional embeddings as input and predict locations of key points."

**代码细节**（`sar_rntr_head.py`）：

```python
def forward_keypoint_branch(self, bev_feats, img_metas):
    """Keypoint分支前向传播"""
    B = bev_feats.shape[0]
    
    # 查询向量
    kp_query = self.kp_query_embed.weight  # [200, 256]
    kp_query = kp_query.unsqueeze(0).repeat(B, 1, 1)
    
    # Transformer解码
    kp_dec, _ = self.kp_transformer(
        bev_feats,      # memory: [B, HW, 256]
        None,           # mask
        kp_query,       # query: [B, 200, 256]
        pos_embed       # position embedding
    )
    
    # 预测头
    kp_feats = kp_dec[-1]  # 最后一层 [B, 200, 256]
    kp_cls = self.kp_cls_head(kp_feats)    # [B, 200, 4]
    kp_coord = self.kp_reg_head(kp_feats)  # [B, 200, 2]
    
    return {'cls': kp_cls, 'coord': kp_coord}
```

---

#### Step 3: 生成Keypoint Prompt

```python
    # 4. 生成Prompt（用于序列生成）
    kp_prompt = self.pts_bbox_head.generate_kp_prompt(
        kp_preds, 
        topk=50
    )
    # kp_prompt: [B, 256] 或 [B, K, 256]
```

**代码细节**：

```python
def generate_kp_prompt(self, kp_preds, topk=50):
    """从keypoint预测生成prompt"""
    kp_cls = kp_preds['cls']    # [B, 200, 4]
    kp_feats = kp_preds['feats'] # [B, 200, 256]
    
    # 计算置信度
    kp_scores = kp_cls.softmax(-1).max(dim=-1)[0]  # [B, 200]
    
    # Top-K选择
    topk_scores, topk_idx = torch.topk(kp_scores, k=topk, dim=-1)
    
    # Gather特征
    gather_idx = topk_idx.unsqueeze(-1).expand(-1, -1, 256)
    kp_sel = torch.gather(kp_feats, 1, gather_idx)  # [B, 50, 256]
    
    # 加权聚合
    w = topk_scores / (topk_scores.sum(dim=-1, keepdim=True) + 1e-6)
    kp_prompt = (kp_sel * w.unsqueeze(-1)).sum(dim=1)  # [B, 256]
    
    return kp_prompt
```

---

#### Step 4: 序列生成（2D Transformer）

```python
    # 5. 准备序列输入（Teacher Forcing）
    input_seq_2d = gt_seq_2d[:, :, :-1]  # 去掉最后一个token
    target_seq_2d = gt_seq_2d[:, :, 1:]  # 去掉第一个token（START）
    
    # 6. 序列Transformer（Axial Attention）
    seq_logits = self.pts_bbox_head(
        bev_feats_flat,
        input_seq_2d,
        kp_prompt=kp_prompt,  # 注入prompt
        img_metas=img_metas
    )
    # seq_logits: [num_layers, B, M*L, vocab_size]
```

**对应论文**（Section 3.6）：
> "Parallel-Seq Transformer Decoder with Axial Attention."

**代码细节**（`sar_rntr_head.py` forward方法）：

```python
def forward(self, mlvl_feats, input_seqs, img_metas, ...):
    """序列生成的前向传播"""
    B, M, L = input_seqs.shape  # [B, 50, 100]
    
    # 1. Token嵌入
    tgt = self.embedding(input_seqs.long())  # [B, M, L, 256]
    
    # 2. 添加Keypoint Prompt
    if kp_prompt is not None:
        tgt = tgt + kp_prompt.unsqueeze(1).unsqueeze(1)
    
    # 3. Axial Transformer
    if self.use_axial_attention:
        # 2D Axial模式
        outs_dec, _ = self.transformer(
            tgt,                # [B, M, L, 256]
            mlvl_feats,         # [B, HW, 256]
            tgt_mask_2d=None,   # 训练时不需要掩码
            memory_mask=masks,
            pos_embed=pos_embed
        )
    else:
        # 1D模式（flatten）
        tgt_flat = tgt.reshape(B, M*L, 256)
        outs_dec, _ = self.transformer(tgt_flat, mlvl_feats, ...)
    
    # 4. 预测vocab
    logits = self.vocab_embed(outs_dec)  # [L, B, M*L, vocab_size]
    
    return logits
```

---

### 2.3 损失计算（Loss Computation）

#### 损失1：Keypoint损失

```python
# sar_rntr.py loss方法
def loss(self, pred_dict, gt_dict):
    """计算总损失"""
    losses = {}
    
    # 1. Keypoint分支损失
    if self.kp_enable:
        kp_losses = self.loss_keypoint(
            pred_dict['kp_cls'],    # [B, 200, 4]
            pred_dict['kp_coord'],  # [B, 200, 2]
            gt_dict['gt_keypoints'],
            gt_dict['gt_kp_labels']
        )
        losses.update(kp_losses)
```

**Keypoint损失细节**（Hungarian Matching）：

```python
def loss_keypoint(self, pred_cls, pred_coord, gt_kp, gt_labels):
    """Keypoint分支的Hungarian损失"""
    B = pred_cls.shape[0]
    
    # 1. Hungarian匹配
    indices = self.kp_assigner.assign(
        pred_cls,    # [B, 200, 4]
        pred_coord,  # [B, 200, 2]
        gt_kp,       # [B, K_gt, 2]
        gt_labels    # [B, K_gt]
    )
    # indices[b] = (pred_idx, gt_idx)
    
    # 2. 按匹配结果计算损失
    loss_cls = 0
    loss_reg = 0
    for b in range(B):
        pred_idx, gt_idx = indices[b]
        
        # 分类损失
        loss_cls += self.kp_loss_cls(
            pred_cls[b, pred_idx],
            gt_labels[b, gt_idx]
        )
        
        # 回归损失（只对正样本）
        pos_mask = (gt_labels[b, gt_idx] > 0)
        if pos_mask.sum() > 0:
            loss_reg += self.kp_loss_reg(
                pred_coord[b, pred_idx[pos_mask]],
                gt_kp[b, gt_idx[pos_mask]]
            )
    
    return {
        'loss_kp_cls': loss_cls * self.kp_weights['cls'],
        'loss_kp_reg': loss_reg * self.kp_weights['reg']
    }
```

**对应论文**（Section 3.6, Equation 262-264）：
> "Hungarian loss is a linear combination of a negative log-likelihood for class prediction and a L-1 loss."

---

#### 损失2：序列生成损失

```python
    # 2. 序列生成损失（4个分量）
    seq_losses = self.loss_sequence(
        pred_dict['seq_logits'],  # [L, B, T, vocab_size]
        gt_dict['target_seq']     # [B, T]
    )
    losses.update(seq_losses)
    
    return losses
```

**序列损失细节**（与AR-RNTR相同）：

```python
def loss_sequence(self, logits, targets):
    """序列生成的4个损失"""
    # logits: [num_layers, B, T, vocab_size]
    # targets: [B, T] - 包含所有6个slot
    
    # 拆分target
    coords_x = targets[:, 0::6]  # slot 0
    coords_y = targets[:, 1::6]  # slot 1
    labels = targets[:, 2::6]    # slot 2
    connects = targets[:, 3::6]  # slot 3
    coeff_x = targets[:, 4::6]   # slot 4
    coeff_y = targets[:, 5::6]   # slot 5
    
    # 拆分logits
    logits_x = logits[:, :, 0::6, :]
    logits_y = logits[:, :, 1::6, :]
    logits_label = logits[:, :, 2::6, :]
    logits_connect = logits[:, :, 3::6, :]
    logits_coeff_x = logits[:, :, 4::6, :]
    logits_coeff_y = logits[:, :, 5::6, :]
    
    # 计算4个损失
    loss_coords = (
        F.cross_entropy(logits_x, coords_x, weight=class_weight) +
        F.cross_entropy(logits_y, coords_y, weight=class_weight)
    )
    
    loss_labels = F.cross_entropy(
        logits_label, labels, 
        weight=label_class_weight
    )
    
    loss_connects = F.cross_entropy(
        logits_connect, connects,
        weight=connect_class_weight
    )
    
    loss_coeffs = (
        F.cross_entropy(logits_coeff_x, coeff_x) +
        F.cross_entropy(logits_coeff_y, coeff_y)
    )
    
    return {
        'loss_coords': loss_coords,
        'loss_labels': loss_labels,
        'loss_connects': loss_connects,
        'loss_coeffs': loss_coeffs
    }
```

---

#### 总损失

```python
# 汇总所有损失
total_loss = (
    loss_kp_cls + 
    loss_kp_reg + 
    loss_coords + 
    loss_labels + 
    loss_connects + 
    loss_coeffs
)

# 反向传播
total_loss.backward()
optimizer.step()
```

---

## 3. 推理流程（Inference）

### 3.1 推理模式选择

SAR-RNTR支持多种推理模式：

```python
# 配置文件
test_cfg = dict(
    use_2d_sequence=True,          # 2D序列模式
    use_axial_attention=True,      # Axial Attention
    block_parallel_infer=False,    # 块并行推理
    nar_infer=False,               # NAR迭代推理
    max_iteration=180              # 最大生成步数
)
```

---

### 3.2 标准SAR推理

#### Step 1: BEV特征提取

```python
def simple_test(self, imgs, img_metas):
    """推理入口"""
    # 1. BEV特征
    bev_feats = self.view_transformers(imgs, img_metas)
    bev_feats_flat = bev_feats.view(B, C, -1).permute(0, 2, 1)
```

---

#### Step 2: Keypoint检测

```python
    # 2. 并行检测所有keypoints
    kp_query = self.kp_query_embed.weight
    kp_dec, _ = self.kp_transformer(bev_feats_flat, None, kp_query, ...)
    kp_feats = kp_dec[-1]
    
    kp_cls = self.kp_cls_head(kp_feats)
    kp_coord = torch.sigmoid(self.kp_reg_head(kp_feats))
    
    # 3. 筛选有效keypoints
    kp_scores = kp_cls.softmax(-1).max(-1)[0]
    valid_mask = kp_scores > 0.3  # 置信度阈值
    valid_kps = kp_coord[valid_mask]  # [K, 2]
```

---

#### Step 3: 为每个Keypoint生成子序列

**传统AR方式**（逐token生成）：

```python
    # 4. 初始化序列
    M = len(valid_kps)  # 关键点数量
    sequences = []
    
    for i in range(M):
        # 为第i个关键点生成子序列
        seq_i = [START_TOKEN]
        
        for t in range(max_seq_len):
            # 嵌入
            tgt = self.embedding(torch.tensor(seq_i))
            
            # Transformer
            out = self.transformer(tgt, bev_feats, ...)
            
            # 预测下一个token
            logits = self.vocab_embed(out[-1, -1, :])
            next_token = logits.argmax(-1).item()
            
            seq_i.append(next_token)
            
            if next_token == EOS_TOKEN:
                break
        
        sequences.append(seq_i)
```

**问题**：M个子序列仍然是串行生成！

---

**SAR的并行加速**（Axial Attention支持）：

```python
    # 改进：M个子序列并行生成同一位置
    M = len(valid_kps)
    L = max_seq_len
    
    # 初始化：所有子序列从START开始
    seqs = torch.full((1, M, L), PAD_TOKEN)
    seqs[:, :, 0] = START_TOKEN
    
    # 逐位置生成（但跨M并行）
    for j in range(1, L):
        # 嵌入当前序列 [1, M, j, 256]
        tgt = self.embedding(seqs[:, :, :j])
        
        # Axial Transformer（M个分支并行处理位置j）
        outs = self.transformer(tgt, bev_feats, ...)
        
        # 预测位置j的token（M个分支同时预测）
        logits_j = self.vocab_embed(outs[-1, :, :, -1, :])  # [1, M, vocab]
        next_tokens = logits_j.argmax(-1)  # [1, M]
        
        seqs[:, :, j] = next_tokens
        
        # 检查是否所有分支都结束
        if (next_tokens == EOS_TOKEN).all():
            break
```

**加速效果**：
- AR模式：生成M个子序列，每个L步 → 总共M×L步
- SAR模式：L步，每步并行处理M个分支 → 总共L步
- **加速M倍！** ✅

---

#### Step 4: 序列解析

```python
    # 5. 解析序列为道路图
    road_graph = self.parse_sequences(sequences)
```

**解析过程**（`seq2bznodelist`）：

```python
def parse_sequences(self, sequences):
    """将整数序列解析为道路图"""
    nodes = []
    edges = []
    
    for seq_i in sequences:
        # 按6个整数一组解析
        for j in range(0, len(seq_i), 6):
            if seq_i[j] == EOS_TOKEN:
                break
            
            x, y, label, connect, coeff_x, coeff_y = seq_i[j:j+6]
            
            # 解码坐标
            x_real = (x - 0) * 0.5 - 55.0  # 离散化逆过程
            y_real = (y - 0) * 0.5 - 55.0
            
            # 解码类型
            node_type = label - 200  # 200-203 → 0-3
            
            # 解码连接
            parent_idx = connect - 250
            
            # 解码贝塞尔系数
            coeff_x_real = (coeff_x - 350 - 10) * 0.5 - 55.0
            coeff_y_real = (coeff_y - 350 - 10) * 0.5 - 55.0
            
            # 创建节点
            node = {
                'pos': [x_real, y_real],
                'type': ['Ancestor', 'Lineal', 'Offshoot', 'Clone'][node_type],
                'parent': parent_idx if parent_idx >= 0 else None
            }
            nodes.append(node)
            
            # 创建边
            if node['parent'] is not None:
                edge = {
                    'src': node['parent'],
                    'dst': len(nodes) - 1,
                    'coeff': [coeff_x_real, coeff_y_real]
                }
                edges.append(edge)
    
    return {'nodes': nodes, 'edges': edges}
```

---

## 4. 关键代码位置总结

| 功能 | 文件 | 关键方法/类 |
|------|------|------------|
| **BEV编码** | `sar_rntr.py` | `LiftSplatShootEgo` |
| **Keypoint检测** | `sar_rntr_head.py` | `forward_keypoint_branch` |
| **Keypoint损失** | `sar_rntr.py` | `loss_keypoint` |
| **Prompt生成** | `sar_rntr_head.py` | `generate_kp_prompt` |
| **Axial Transformer** | `axial_sar_transformer.py` | `AxialSARTransformer` |
| **序列生成** | `sar_rntr_head.py` | `forward` |
| **序列损失** | `sar_rntr_head.py` | `loss_by_feat` |
| **推理入口** | `sar_rntr.py` | `simple_test` |
| **序列解析** | `core/centerline/` | `seq2bznodelist` |

---

## 5. 配置文件示例

```python
# configs/rntr_sar_roadseq/sar_rntr.py

model = dict(
    type='SAR_RNTR',
    
    # BEV编码器
    lss_cfg=dict(
        img_backbone=dict(type='ResNet50'),
        img_neck=dict(type='FPN'),
        downsample=16
    ),
    
    # Grid配置
    grid_conf=dict(
        xbound=[-55.0, 55.0, 0.5],
        ybound=[-55.0, 55.0, 0.5],
        zbound=[-10.0, 10.0, 20.0]
    ),
    
    # 解码器
    pts_bbox_head=dict(
        type='SARRNTRHead',
        
        # 2D序列配置
        use_2d_sequence=True,
        use_axial_attention=True,
        max_sequences=50,
        max_seq_len=100,
        
        # Keypoint配置
        kp_num_query=200,
        kp_num_classes=4,
        kp_prompt_enable=True,
        kp_prompt_type='add',
        kp_prompt_topk=50,
        
        # Transformer配置
        transformer=dict(
            type='AxialSARTransformer',
            num_layers=6,
            d_model=256,
            nhead=8
        ),
        
        # 词表大小
        num_center_classes=576,
        max_iteration=180
    ),
    
    # 损失权重
    kp_weights=dict(cls=1.0, reg=5.0)
)

# 训练配置
train_cfg = dict(
    max_epochs=300,
    batch_size=8,
    optimizer=dict(type='AdamW', lr=2e-4)
)

# 测试配置
test_cfg = dict(
    max_iteration=180,
    use_2d_sequence=True,
    use_axial_attention=True
)
```

---

## 6. 训练脚本示例

```bash
# 单卡训练
python tools/train.py \
    configs/rntr_sar_roadseq/sar_rntr.py \
    --work-dir work_dirs/sar_rntr

# 多卡训练（4卡）
bash tools/dist_train.sh \
    configs/rntr_sar_roadseq/sar_rntr.py \
    4 \
    --work-dir work_dirs/sar_rntr
```

---

## 7. 性能对比

| 模式 | Landmark F1 | Reach F1 | 推理时间 | 显存 |
|------|-------------|----------|----------|------|
| **AR-RNTR** | 42.3 | 45.6 | 1.0s | 8GB |
| **SAR-RNTR** | **46.8** ⭐ | **51.2** ⭐ | 0.17s (6×快) | 10GB |
| **NAR-RNTR** | 45.1 | 49.3 | 0.02s (47×快) | 12GB |

---

## 小结Part4

✅ **训练流程**：BEV编码 → Keypoint检测 → Prompt生成 → 序列生成 → 损失计算  
✅ **推理流程**：BEV编码 → Keypoint检测 → 并行序列生成 → 解析道路图  
✅ **关键加速**：M个子序列并行生成，L步完成（vs AR的M×L步）  
✅ **损失函数**：Keypoint Hungarian损失 + 序列4分量损失  
✅ **完整对齐**：代码完全实现论文描述的流程  

**SAR-RNTR教程完结！** 🎉
