# SD-Map 详解：标准地图先验 🗺️

> **核心问题**：SD-Map是什么？如何使用？哪些模型用了？

---

## 1. SD-Map是什么？

### 1.1 定义

**SD-Map = Standard Definition Map**（标准清晰度地图）

**论文描述**（Section 3.12）：
> "We extract only road topology information from the navigation map, commonly referred to as standard definition maps (SD-Maps)."

### 1.2 与HD-Map（高精地图）的对比

| 维度 | HD-Map（高精地图） | SD-Map（标准地图） |
|------|-------------------|-------------------|
| **精度** | 厘米级 (cm-level) | 米级 (meter-level) |
| **详细程度** | 车道级 (lane-level) | 道路级 (road-level) |
| **信息** | 车道数、精确位置、曲率 | 只有道路连接关系 |
| **来源** | 专业采集（昂贵） | 导航地图（免费） |
| **例子** | nuScenes标注 | OpenStreetMap, Google Maps |

**图解**：

```
HD-Map (目标)：
    Lane1 ━━━━━━━━━━━━━━━━━━━━━
    Lane2 ━━━━━━━━━━━━━━━━━━━━━  ← 3条车道，精确位置
    Lane3 ━━━━━━━━━━━━━━━━━━━━━

SD-Map (先验)：
    Road ━━━━━━━━━━━━━━━━━━━━━   ← 只知道有一条路，不知道几条车道
    (粗糙的连接关系)
```

---

## 2. 为什么需要SD-Map？

### 2.1 论文指出的问题

**问题1：BEV编码器的局限**（Section 3.11）
- 固定分辨率的网格表示，丢失细节
- 遮挡物（障碍物、地形）影响感知
- 无法看到被遮挡的道路

**问题2：TIT仍不够**（Section 3.12）
> "Although TIT partly solves the bottlenecks, the obstacles of roads from barriers or terrain are not fundamentally resolved."

**解决方案**：
> "Some prior information should be provided. The prior information should be easy to obtain and inexpensive to process."

---

### 2.2 SD-Map的优势

✅ **易获取**：全球导航地图（Google Maps, OpenStreetMap）
✅ **免费**：OpenStreetMap开源
✅ **全覆盖**：几乎所有城市都有
✅ **足够用**：虽然粗糙，但提供了基本拓扑结构

**论文**（Introduction）：
> "In daily driving experiences, navigation maps like Google Maps are almost a necessity worldwide, making it easy to gather some information from them."

---

## 3. SD-Map如何获取和处理？

### 3.1 数据收集（论文Section 3.12）

**来源**：OpenStreetMap

**区域**：
- Singapore onenorth
- Singapore Queenstown
- Singapore Hollandvillage
- Boston Seaport

**提取规则**：
```python
# 只保留highway节点和link roads类型
export_tracktopo_data(
    node_type='highway',
    secondary_type='link_roads'
)
```

---

### 3.2 数据对齐

**挑战**：nuScenes没有GPS坐标

**解决**：
> "We align the SD-Map with the nuScenes map manually. We also manually adjust some nodes to correct obvious errors in the alignment."

**注意**：
- 这是因为nuScenes数据集的缺陷
- 实际应用中，GPS对齐是自动的
- 允许一定的位置误差（因为本身就是粗糙的）

---

### 3.3 序列构建：SD-Seq

**问题**：SD-Map可能有环（不是DAG）

**解决**（论文Section 3.12）：
> "SD-Maps may not be Directed Acyclic Graphs since cycles may exist. We duplicate the vertex whenever it is traversed again during a Depth-First Search."

**流程**：

```
原始SD-Map（有环）：
    A → B → C
    ↓       ↑
    D ──────┘  (环: A→D→C→B)

DFS遍历 + 节点复制：
    A → B → C
    ↓
    D → C' (C的复制)

变成DAG后，转换为序列：
SD-Seq = [A_x, A_y, ..., B_x, B_y, ..., C_x, C_y, ..., D_x, D_y, ..., C'_x, C'_y, ...]
```

**简化**：
- 不包含贝塞尔曲线系数（减少长度）
- 边当作直线处理

---

## 4. SD-Map如何使用？Topo-RNTR

### 4.1 Prompt Learning

**论文描述**（Section 3.12）：
> "We use SD-Seq as a sequence prompt before the start of RoadNet Sequence. This change does not alter the AR-RNTR model."

**模型名称**：**Topo-RNTR** (Topology-RNTR)

---

### 4.2 实现方式

**输入序列拼接**：

```python
# 原始AR-RNTR输入
input_seq = [START, token1, token2, ..., tokenN, EOS]

# Topo-RNTR输入（加入SD-Map prompt）
input_seq = [START, 
             sd_token1, sd_token2, ..., sd_tokenM,  # SD-Map序列
             SEP,  # 分隔符
             token1, token2, ..., tokenN,  # 真实预测序列
             EOS]
```

**Transformer处理**：

```
SD-Seq部分 → 提供全局拓扑先验
    ↓
SEP分隔符 → 标记SD-Seq结束
    ↓
RoadNet-Seq → 基于先验生成精确预测
```

**关键点**：
- **不改变模型结构**！只是改变输入序列
- SD-Map提供"上下文"，引导生成
- 类似于NLP中的prompt learning

---

### 4.3 代码实现

**数据加载**（`transforms/loading.py`）：

```python
@TRANSFORMS.register_module()
class LoadSDMapSeqPrompt:
    """Load SD-Map sequence as prompt"""
    
    def __call__(self, results):
        # 1. 加载预计算的SD-Map序列
        sd_seq = load_precomputed_sdmap(scene_token)
        
        # 2. 或者从原始SD-Map构建
        if sd_seq is None:
            sd_graph = load_sdmap_graph(location)
            sd_seq = graph_to_sequence(sd_graph)
        
        # 3. 保存到results
        results['sd_prompt_seq'] = sd_seq  # [M] 整数序列
        return results
```

**模型前向**（`sar_rntr_head.py`）：

```python
def _gather_sd_prompt(self, img_metas, device, embed_dims):
    """收集SD-Map prompt"""
    # 方式1: 序列prompt (优先)
    seq_list = []
    for m in img_metas:
        sd_seq = m.get('sd_prompt_seq', None)
        if sd_seq is not None:
            seq_list.append(sd_seq)
    
    if len(seq_list) == len(img_metas):
        # 拼接到输入序列前面
        sd_prompt = self.embedding(torch.tensor(seq_list))
        return sd_prompt, None
    
    # 方式2: 位置prompt (fallback)
    pos_list = []
    for m in img_metas:
        sd_pos = m.get('sd_prompt_pos', None)
        if sd_pos is not None:
            pos_list.append(sd_pos)
    
    if len(pos_list) == len(img_metas):
        # 作为Cross-Attention的prompt
        sd_pos_tensor = torch.stack(pos_list)
        prompt_pos = self.pos_mlp(sd_pos_tensor)
        return None, prompt_pos
    
    return None, None
```

**Cross-Attention使用**：

```python
# Transformer内部
if sd_prompt is not None:
    # SD-Map作为额外的Key/Value
    out = self.transformer(
        tgt,          # Query: 目标序列
        bev_feats,    # Key/Value1: BEV特征
        sd_prompt,    # Key/Value2: SD-Map先验 ✨
        ...
    )
```

---

## 5. 哪些算法使用了SD-Map？

### 5.1 论文实验结果

**Table 5: Non-overfitting Split**

| 模型 | Landmark F1 | Reachability F1 |
|------|-------------|-----------------|
| AR-RNTR | 36.5 | 40.9 |
| SAR-RNTR | 36.9 | 43.0 |
| NAR-RNTR | 36.2 | 42.3 |
| AR-RNTR + TIT | 39.1 | 49.8 |
| **Topo-RNTR (AR+TIT+SD-Map)** | **54.7** ⭐ | **62.6** ⭐ |

**关键发现**（论文Section 4.3）：
> "The usage of SD-Maps as prior information brings significant improvements... It raises the Landmark F-score from 39.1 to **54.7** and the Reachability F-score from 49.8 to **62.6**."

**提升幅度**：
- Landmark: +15.6 (39.1 → 54.7) 🔥
- Reachability: +12.8 (49.8 → 62.6) 🔥

**最显著的提升！**

---

### 5.2 只应用于AR-RNTR

**论文没有报告**：
- ❌ SAR-RNTR + SD-Map
- ❌ NAR-RNTR + SD-Map

**只有**：
- ✅ AR-RNTR + TIT + SD-Map = **Topo-RNTR**

---

### 5.3 为什么只用于AR-RNTR？

**推测原因**：

1. **AR-RNTR最适合Prompt**
   - 序列到序列模型
   - 可以直接拼接prompt序列
   - 不需要改变模型结构

2. **SAR/NAR实现复杂**
   - SAR是2D序列，prompt如何组织？
   - NAR是并行生成，prompt如何融合？
   - 需要重新设计prompt机制

3. **实验资源限制**
   - 论文重点展示AR-RNTR的改进路径
   - TIT + SD-Map已经让AR超过了SAR/NAR
   - 没必要在所有变体上都尝试

4. **效果已经足够好**
   - Topo-RNTR (54.7 Landmark) 已经远超SAR (36.9)
   - 证明了SD-Map的有效性

---

## 6. 代码中的SD-Map支持

### 6.1 SAR-RNTR中的实现

虽然论文没报告，但代码中**SAR-RNTR支持SD-Map**：

```python
# sar_rntr_head.py L137-138
sd_prompt_enable: bool = True,
sd_prompt_type: str = 'cross',  # 'cross' or 'none'

# L229-230
self.sd_prompt_enable = bool(sd_prompt_enable)
self.sd_prompt_type = sd_prompt_type
```

**使用方式**：
- 不是序列拼接（2D序列不方便）
- 而是**Cross-Attention Prompt**
- SD-Map作为额外的Key/Value

```python
# sar_rntr_head.py L488
sd_prompt, sd_prompt_pos = self._gather_sd_prompt(img_metas, ...)

# L525-526
if sd_prompt is not None and sd_prompt_pos is not None:
    outs_dec, _ = self.transformer(
        tgt, bev_feats, 
        sd_prompt, sd_prompt_pos  # SD-Map prompt
    )
```

---

### 6.2 配置示例

```python
# AR-RNTR配置（序列prompt）
model = dict(
    type='AR_RNTR',
    pts_bbox_head=dict(
        use_sd_prompt=True,
        sd_prompt_type='sequence',  # 拼接到输入序列
    )
)

# SAR-RNTR配置（Cross-Attention prompt）
model = dict(
    type='SAR_RNTR',
    pts_bbox_head=dict(
        sd_prompt_enable=True,
        sd_prompt_type='cross',  # Cross-Attention
    )
)
```

---

## 7. SD-Map的局限性

**论文指出**（Section 5, Limitations）：
> "While SD-Maps offer valuable priors, their **coarse resolution** limits their effectiveness for precise landmark localization, which may restrict performance in high-precision navigation scenarios."

**具体问题**：

1. **粗糙精度**
   - 只有米级精度
   - 无法提供精确的车道位置
   - 节点位置可能有偏移

2. **缺少细节**
   - 不知道车道数量
   - 不知道车道宽度
   - 没有曲率信息

3. **需要对齐**
   - nuScenes数据集需要手动对齐
   - 实际应用需要GPS自动对齐
   - 对齐误差会影响效果

---

## 8. 总结

### 8.1 SD-Map核心要点

✅ **定义**：道路级、米级精度的导航地图  
✅ **来源**：OpenStreetMap（免费、全球覆盖）  
✅ **作用**：提供粗糙的拓扑先验，帮助模型理解道路连接  
✅ **使用**：作为Prompt注入Transformer  

### 8.2 使用情况

| 模型 | 使用SD-Map？ | 实现方式 | 论文报告？ |
|------|-------------|----------|-----------|
| **AR-RNTR** | ✅ 是 | 序列拼接 | ✅ 是（Topo-RNTR） |
| **SAR-RNTR** | ⚠️ 代码支持 | Cross-Attention | ❌ 否 |
| **NAR-RNTR** | ❌ 否 | - | ❌ 否 |

### 8.3 效果对比

```
Non-overfitting Split上的Landmark F1：
    
AR-RNTR:            36.5  ━━━━━━━━
AR-RNTR + TIT:      39.1  ━━━━━━━━━
AR-RNTR + TIT + SD: 54.7  ━━━━━━━━━━━━━━━━ ⭐ (+15.6!)

SAR-RNTR:           36.9  ━━━━━━━━
```

**SD-Map带来了最显著的提升！**

---

## 9. 实际应用建议

### 推荐使用场景

✅ **新城市部署**：SD-Map提供基础拓扑，减少对训练数据的依赖  
✅ **遮挡场景**：树木、建筑遮挡时，SD-Map提供补充信息  
✅ **低精度要求**：导航规划（不需要车道级精度）  

### 不适用场景

❌ **车道级控制**：自动驾驶轨迹规划需要厘米级精度  
❌ **动态道路**：新修道路、施工区域，SD-Map更新不及时  
❌ **无SD-Map区域**：偏远地区可能没有OpenStreetMap数据  

---

**结论**：SD-Map是AR-RNTR的关键增强，通过廉价的导航地图先验，实现了显著的性能提升！🎯
