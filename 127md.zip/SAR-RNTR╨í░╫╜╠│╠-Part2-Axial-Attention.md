# SAR-RNTR小白教程 - Part2：Axial Attention机制 🔥

> **核心问题**：如何在2D序列上做高效的注意力计算？

---

## 1. 为什么需要Axial Attention？

### 1.1 直接做2D Attention的问题

**2D序列形状**：`[B, M, L, D]`
- M = 50个分支
- L = 100个token/分支
- 总token数 = M × L = 5000

**如果直接flatten成1D做Self-Attention**：

```python
# 展平成1D
tgt_flat = tgt.reshape(B, M*L, D)  # [B, 5000, D]

# Self-Attention
attn_out = self.attn(tgt_flat, tgt_flat, tgt_flat)

# 注意力矩阵大小
attention_matrix = [5000, 5000]  # 25,000,000个元素！

# 显存占用（float32）
memory = 5000 × 5000 × 4 bytes = 100 MB（仅1个样本！）
```

**论文指出**（Section 3.6）：
> "Memory complexity O(M² × L²)"

**问题**：
- M=50, L=100 → O(50² × 100²) = O(25,000,000) ❌
- 显存爆炸！训练不动！

---

### 1.2 Axial Attention的解决方案

**核心思想**：不要一次性计算所有token之间的attention，而是**分两步**计算！

**论文描述**（Section 3.6）：
> "A cross combination of self-attention from different directions leads to a final global attention. 
> The memory complexity is reduced to O(M²+L²) ≪ O(M²×L²)."

**数学对比**：
```
直接2D Attention: O(M² × L²) = O(50² × 100²) = 25,000,000
Axial Attention:  O(M² + L²) = O(50² + 100²) = 12,500

加速比：25,000,000 / 12,500 = 2000倍！✅
```

---

## 2. Axial Attention两阶段

### 2.1 Stage 1: Intra-seq Attention（跨M）

**目标**：对每个位置j，让所有M个分支的token相互交流

**可视化**：

```
2D序列（M=3, L=4）：
        位置0   位置1   位置2   位置3
分支0:  [a00]  [a01]  [a02]  [a03]
分支1:  [a10]  [a11]  [a12]  [a13]
分支2:  [a20]  [a21]  [a22]  [a23]

Stage 1 处理（对每个位置j独立）：
位置j=0:  [a00, a10, a20] 相互做attention ←─┐
位置j=1:  [a01, a11, a21] 相互做attention   │ 可以并行！
位置j=2:  [a02, a12, a22] 相互做attention   │
位置j=3:  [a03, a13, a23] 相互做attention ←─┘
```

**代码实现**（`axial_sar_transformer.py` L91-114）：

```python
def forward(self, tgt, memory, ...):
    """
    tgt: [B, M, L, D] - 2D序列
    """
    B, M, L, D = tgt.shape
    
    # === Stage 1: Intra-seq attention ===
    # Step 1: Reshape [B, M, L, D] → [B*L, M, D]
    # 把L个位置拆开，每个位置独立处理
    tgt_intra = tgt.permute(0, 2, 1, 3).reshape(B*L, M, D)
    # 现在形状：[B*L, M, D]
    # 相当于有B*L个样本，每个样本有M个token
    
    # Step 2: 对每个位置的M个token做Self-Attention
    tgt_intra_out, _ = self.intra_attn(
        tgt_intra,  # query:  [B*L, M, D]
        tgt_intra,  # key:    [B*L, M, D]
        tgt_intra   # value:  [B*L, M, D]
    )
    # 输出：[B*L, M, D]
    
    # Step 3: Add & Norm
    tgt_intra = self.intra_norm(
        tgt_intra + self.intra_dropout(tgt_intra_out)
    )
    
    # Step 4: Reshape回2D [B*L, M, D] → [B, M, L, D]
    tgt = tgt_intra.reshape(B, L, M, D).permute(0, 2, 1, 3)
```

**复杂度分析**：
```
- 总共有L个位置
- 每个位置处理M个token，复杂度O(M²)
- 总复杂度：L × O(M²) = O(L × M²)
```

---

### 2.2 Stage 2: Inter-seq Attention（跨L）

**目标**：对每个分支i，让位置j可以看到位置1:j-1（因果关系）

**可视化**：

```
2D序列（M=3, L=4）：
        位置0   位置1   位置2   位置3
分支0:  [a00] → [a01] → [a02] → [a03]  ← 顺序依赖
分支1:  [a10] → [a11] → [a12] → [a13]  ← 顺序依赖
分支2:  [a20] → [a21] → [a22] → [a23]  ← 顺序依赖
        ↓ 并行  ↓ 并行  ↓ 并行  ↓ 并行

Stage 2 处理（对每个分支i独立）：
分支0: [a00] → [a01] → [a02] → [a03] ←─┐
       └──看─┘  └───看──┘               │ 可以并行！
分支1: [a10] → [a11] → [a12] → [a13]   │
分支2: [a20] → [a21] → [a22] → [a23] ←─┘

注意：a02可以看到a00和a01，但看不到a03（因果掩码）
```

**代码实现**（`axial_sar_transformer.py` L116-141）：

```python
# === Stage 2: Inter-seq attention ===
# Step 1: Reshape [B, M, L, D] → [B*M, L, D]
# 把M个分支拆开，每个分支独立处理
tgt_inter = tgt.reshape(B*M, L, D)
# 现在形状：[B*M, L, D]
# 相当于有B*M个样本，每个样本有L个token

# Step 2: 生成因果掩码
causal_mask = self._generate_causal_mask(L, device)
# 因果掩码形状：[L, L]
# mask[i, j] = 0    if j <= i  (可以看到)
#            = -inf if j > i   (不能看到)

# Step 3: 对每个分支的L个token做Causal Self-Attention
tgt_inter_out, _ = self.inter_attn(
    tgt_inter,     # query:  [B*M, L, D]
    tgt_inter,     # key:    [B*M, L, D]
    tgt_inter,     # value:  [B*M, L, D]
    attn_mask=causal_mask  # [L, L] 因果掩码
)
# 输出：[B*M, L, D]

# Step 4: Add & Norm
tgt_inter = self.inter_norm(
    tgt_inter + self.inter_dropout(tgt_inter_out)
)

# Step 5: Reshape回2D [B*M, L, D] → [B, M, L, D]
tgt = tgt_inter.reshape(B, M, L, D)
```

**因果掩码生成**（`axial_sar_transformer.py` L172-182）：

```python
@staticmethod
def _generate_causal_mask(seq_len, device):
    """生成上三角掩码"""
    mask = torch.triu(
        torch.full((seq_len, seq_len), float('-inf'), device=device),
        diagonal=1  # 对角线上方为-inf
    )
    return mask

# 示例（L=4）：
# [[  0, -inf, -inf, -inf],   ← 位置0只能看自己
#  [  0,   0,  -inf, -inf],   ← 位置1能看0,1
#  [  0,   0,    0,  -inf],   ← 位置2能看0,1,2
#  [  0,   0,    0,    0]]    ← 位置3能看0,1,2,3
```

**复杂度分析**：
```
- 总共有M个分支
- 每个分支处理L个token，复杂度O(L²)
- 总复杂度：M × O(L²) = O(M × L²)
```

---

## 3. 为什么Axial Attention有效？

### 3.1 数学证明

**目标**：让每个token能看到全局信息

**直接方法**：一次性计算所有token的attention
```
token[i,j]关注所有token[i',j']
复杂度：O((M×L)²) = O(M²L²)
```

**Axial方法**：两步实现全局attention

**Step 1（Intra-seq）**：
```
token[i,j]关注所有token[i',j]（同列）
每个token获得了"跨分支"的信息
```

**Step 2（Inter-seq）**：
```
token[i,j]关注所有token[i,j']（同行，j'<j）
每个token获得了"本分支历史"的信息
```

**组合效果**：
```
经过两步后，token[i,j]间接获得了全局信息：
- 直接看到同列的所有分支
- 直接看到本行的历史
- 间接通过同列token看到其他分支的历史

等效于全局attention！✅
```

**论文引用**（Section 3.6）：
> "Inspired by [Wang2020Axial], where a cross combination of self-attention from different directions leads to a final global attention."

---

### 3.2 图解理解

```
假设有3个分支，4个位置：

初始状态（没有attention）：
[a00] [a01] [a02] [a03]
[a10] [a11] [a12] [a13]
[a20] [a21] [a22] [a23]

经过Stage 1（Intra-seq）后：
每个token融合了同列信息
[a00'] [a01'] [a02'] [a03']  ← a00'包含了a00,a10,a20的信息
[a10'] [a11'] [a12'] [a13']  ← a10'包含了a00,a10,a20的信息
[a20'] [a21'] [a22'] [a23']  ← a20'包含了a00,a10,a20的信息

经过Stage 2（Inter-seq）后：
每个token融合了本行历史
[a00''] [a01''] [a02''] [a03'']
[a10''] [a11''] [a12''] [a13'']
[a20''] [a21''] [a22''] [a23'']

现在a12''包含了什么信息？
- 直接：a10, a11, a12（本分支历史）
- 间接：a00, a01, a02（分支0的历史，通过a02'传递）
- 间接：a20, a21, a22（分支2的历史，通过a22'传递）

相当于看到了几乎全局！✅
```

---

## 4. 与AR-RNTR的Attention对比

### 4.1 AR-RNTR的Attention

```python
# ar_rntr_head.py
# 1D序列：[B, T, D]，T = M×L

# Self-Attention with causal mask
mask = torch.triu(torch.ones(T, T), diagonal=1)
# [[0, 1, 1, 1, ...],   ← token 0只能看自己
#  [0, 0, 1, 1, ...],   ← token 1能看0,1
#  [0, 0, 0, 1, ...],   ← token 2能看0,1,2
#  ...]

attn_out = self.attn(tgt, tgt, tgt, attn_mask=mask)
# 复杂度：O(T²) = O((M×L)²) = O(M²L²)
```

---

### 4.2 SAR-RNTR的Attention

```python
# sar_rntr_head.py + axial_sar_transformer.py
# 2D序列：[B, M, L, D]

# Stage 1: Intra-seq
tgt_intra = tgt.permute(0, 2, 1, 3).reshape(B*L, M, D)
intra_out = self.intra_attn(tgt_intra, tgt_intra, tgt_intra)
# 复杂度：L × O(M²) = O(LM²)

# Stage 2: Inter-seq
tgt_inter = tgt.reshape(B*M, L, D)
causal_mask = self._generate_causal_mask(L, device)
inter_out = self.inter_attn(tgt_inter, tgt_inter, tgt_inter, 
                            attn_mask=causal_mask)
# 复杂度：M × O(L²) = O(ML²)

# 总复杂度：O(LM² + ML²) = O(M²L + ML²) = O(L(M²+ML))
# 当M≈L时，约等于O(M²+L²)
```

---

### 4.3 复杂度对比表

| 方法 | 复杂度 | M=50, L=100的实际计算量 |
|------|--------|------------------------|
| **AR (1D)** | O(M²L²) | 50² × 100² = 25,000,000 |
| **SAR (Axial)** | O(M²+L²) | 50² + 100² = 12,500 |
| **加速比** | - | **2000倍** ✅ |

---

## 5. Cross-Attention到BEV特征

### 5.1 第三阶段

**Stage 3**：将2D序列与BEV特征做Cross-Attention

```python
# axial_sar_transformer.py L143-160
# === Stage 3: Cross-attention to BEV ===
# Step 1: Flatten 2D序列 [B, M, L, D] → [B, M*L, D]
tgt_cross = tgt.reshape(B, M*L, D)

# Step 2: Cross-Attention
# Query: 2D序列token
# Key/Value: BEV特征
tgt_cross_out, _ = self.cross_attn(
    tgt_cross,        # query:  [B, M*L, D]
    memory_with_pos,  # key:    [B, HW, D] (BEV)
    memory            # value:  [B, HW, D]
)

# Step 3: Add & Norm
tgt_cross = self.cross_norm(
    tgt_cross + self.cross_dropout(tgt_cross_out)
)

# Step 4: Reshape回2D
tgt_out = tgt_cross.reshape(B, M, L, D)
```

**为什么flatten？**
- Cross-Attention不需要保持2D结构
- Query来自序列，Key/Value来自BEV
- 展平后可以让所有token同时查询BEV

---

## 6. 完整流程图

```
输入：2D序列 [B, M, L, D]
  ↓
┌─────────────────────────────────┐
│ Stage 1: Intra-seq Attention    │
│ Reshape [B,M,L,D] → [B*L,M,D]  │
│ 对每个位置j，M个分支相互交流     │
│ 复杂度：O(L×M²)                 │
└────────────┬────────────────────┘
             ↓
  更新后的2D序列 [B, M, L, D]
             ↓
┌─────────────────────────────────┐
│ Stage 2: Inter-seq Attention    │
│ Reshape [B,M,L,D] → [B*M,L,D]  │
│ 对每个分支i，L个位置因果交流     │
│ 复杂度：O(M×L²)                 │
└────────────┬────────────────────┘
             ↓
  更新后的2D序列 [B, M, L, D]
             ↓
┌─────────────────────────────────┐
│ Stage 3: Cross-Attention        │
│ Flatten [B,M,L,D] → [B,M*L,D]  │
│ 所有token查询BEV特征             │
│ 复杂度：O(M×L×HW)               │
└────────────┬────────────────────┘
             ↓
┌─────────────────────────────────┐
│ Stage 4: FFN                    │
│ 前馈网络                         │
└────────────┬────────────────────┘
             ↓
  输出：[B, M, L, D]
```

---

## 7. 代码验证

### 7.1 打印形状变化

```python
# axial_sar_transformer.py 实际运行
B, M, L, D = 2, 50, 100, 256

# 输入
tgt = torch.randn(B, M, L, D)
print(f"Input: {tgt.shape}")  # [2, 50, 100, 256]

# Stage 1
tgt_intra = tgt.permute(0, 2, 1, 3).reshape(B*L, M, D)
print(f"Stage 1 reshape: {tgt_intra.shape}")  # [200, 50, 256]

# Stage 2
tgt_inter = tgt.reshape(B*M, L, D)
print(f"Stage 2 reshape: {tgt_inter.shape}")  # [100, 100, 256]

# Stage 3
tgt_cross = tgt.reshape(B, M*L, D)
print(f"Stage 3 reshape: {tgt_cross.shape}")  # [2, 5000, 256]

# 输出
print(f"Output: {tgt.shape}")  # [2, 50, 100, 256]
```

---

## 小结Part2

✅ **Axial Attention**：两阶段实现全局attention  
✅ **Intra-seq**：跨分支交流（O(LM²)）  
✅ **Inter-seq**：分支内因果（O(ML²)）  
✅ **总复杂度**：O(M²+L²) vs O(M²L²)，2000倍加速！  
✅ **等效性**：两步组合 = 全局attention  

**下一Part讲解Keypoint Prompt Learning！** 🎯
