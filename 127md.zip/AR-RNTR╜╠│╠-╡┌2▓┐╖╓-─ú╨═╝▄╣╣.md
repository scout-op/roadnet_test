# AR-RNTR算法教程 - 第2部分：模型架构 🏗️

## 目录
1. 整体架构
2. BEV编码器
3. Transformer解码器
4. 嵌入层设计

---

## 1. 整体架构

### 1.1 三大模块

```
┌─────────────────────────────────────────┐
│         AR-RNTR 完整流程                 │
├─────────────────────────────────────────┤
│                                          │
│  输入：6个相机图片                        │
│  [1, 6, 3, 128, 352]                    │
│         ↓                                │
│  ┌──────────────────┐                   │
│  │ 模块1: BEV编码器  │                   │
│  │   (LSS)         │                   │
│  └────────┬─────────┘                   │
│           │                             │
│  俯视图特征 [1, 256, 200, 200]           │
│           ↓                             │
│  ┌──────────────────┐                   │
│  │ 模块2: Transformer│                   │
│  │    解码器        │                   │
│  └────────┬─────────┘                   │
│           │                             │
│  序列预测 [B, L, 574]                    │
│           ↓                             │
│  ┌──────────────────┐                   │
│  │ 模块3: 自回归生成  │                   │
│  └────────┬─────────┘                   │
│           │                             │
│  输出：道路网络序列                        │
│  [START, 10, 20, ..., EOS]              │
│                                          │
└─────────────────────────────────────────┘
```

### 1.2 类比理解

```
AR-RNTR ≈ 图像描述生成

图像 → CNN → 特征 → LSTM → "a cat on the sofa"
  ↓      ↓      ↓      ↓           ↓
6相机 → LSS → BEV → Transformer → [10,20,200,...]
```

---

## 2. BEV编码器详解

### 2.1 什么是BEV？

**BEV = Bird's Eye View（鸟瞰图）**

```
侧视图（相机视角）：
     建筑
     │││
  ───┴┴┴───
   道路

俯视图（BEV）：
   ┌─────┐
   │建筑 │
   └─────┘
   ══════  ← 道路
```

### 2.2 LSS工作原理

**Lift-Splat-Shoot分三步**：

```
Step 1: Lift（提升）
  图像像素 + 深度 → 3D点云

Step 2: Splat（投影）
  3D点云 → BEV网格

Step 3: Shoot（聚合）
  多视角特征 → 统一BEV特征图
```

### 2.3 代码实现

```python
# ar_rntr.py L102-104
self.view_transformers = LiftSplatShootEgo(
    grid_conf={
        'xbound': [-48.0, 48.0, 0.5],  # X: -48到48米，分辨率0.5米
        'ybound': [-32.0, 32.0, 0.5],  # Y: -32到32米
        'zbound': [-10.0, 10.0, 20.0], # Z高度范围
        'dbound': [4.0, 48.0, 1.0],    # 深度4-48米
    },
    data_aug_conf={
        'resize_lim': (0.193, 0.225),
        'final_dim': (128, 352),
        'H': 900,
        'W': 1600,
    },
    return_bev=True,
    **lss_cfg
)
```

**BEV尺寸计算**：

```python
# X方向
nx = (48.0 - (-48.0)) / 0.5 = 192

# Y方向
ny = (32.0 - (-32.0)) / 0.5 = 128

# 实际代码中上采样到200×200
BEV特征图: [B, 256, 200, 200]
```

### 2.4 extract_feat函数

```python
# ar_rntr.py L340-361
def extract_feat(self, img, img_metas):
    # Step 1: 提取多视角特征
    img_feats = self.extract_img_feat(img, img_metas)
    # img_feats[0]: [B, 6, 256, H, W]
    
    # Step 2: 选择合适的特征层
    largest_feat_shape = img_feats[0].shape[3]
    down_level = int(np.log2(
        self.downsample // (self.final_dim[0] // largest_feat_shape)
    ))
    
    # Step 3: LSS投影到BEV
    bev_feats = self.view_transformers(
        img_feats[down_level], 
        img_metas
    )
    # 输出: [B, 256, 200, 200]
    
    return bev_feats
```

---

## 3. Transformer解码器

### 3.1 配置参数

```python
# configs/rntr_ar_roadseq/lss_ar_rntr_*.py
transformer=dict(
    type='LssSeqLineTransformer',
    decoder=dict(
        type='PETRTransformerLineDecoder',
        num_layers=6,  # 6层Transformer（论文标准）
        transformerlayers=dict(
            attn_cfgs=[
                # Self-Attention
                dict(
                    type='RNTR2MultiheadAttention',
                    embed_dims=256,
                    num_heads=8,      # 256/32=8头
                    dropout=0.1
                ),
                # Cross-Attention  
                dict(
                    type='RNTR2MultiheadAttention',
                    embed_dims=256,
                    num_heads=8,
                    dropout=0.1
                ),
            ],
            # Feed-Forward Network
            ffn_cfgs=dict(
                type='FFN',
                embed_dims=256,
                feedforward_channels=1024,  # 256×4
                num_fcs=2,
                ffn_drop=0.1,
            ),
        )
    )
)
```

### 3.2 单层结构

```
输入序列嵌入 [B, L, 256]
    ↓
┌─────────────────┐
│ Self-Attention  │ ← 序列内部关注
└────────┬────────┘
    ↓
┌─────────────────┐
│ Layer Norm      │
└────────┬────────┘
    ↓
┌─────────────────┐
│ Cross-Attention │ ← 关注BEV特征
└────────┬────────┘
    ↓
┌─────────────────┐
│ Layer Norm      │
└────────┬────────┘
    ↓
┌─────────────────┐
│      FFN        │ ← 前馈网络
└────────┬────────┘
    ↓
┌─────────────────┐
│ Layer Norm      │
└────────┬────────┘
    ↓
输出 [B, L, 256]
```

### 3.3 前向传播代码

```python
# ar_rntr_head.py L480-507
def forward(self, mlvl_feats, input_seqs, img_metas):
    """
    Args:
        mlvl_feats: BEV特征 [B, 256, 200, 200]
        input_seqs: 输入序列 [B, L]
        img_metas: 元数据
    Returns:
        out: 预测logits [6, B, L, 574]
    """
    # Step 1: BEV特征投影
    x = mlvl_feats
    if self.in_channels != self.embed_dims:
        x = self.bev_proj(x)
    
    # Step 2: BEV位置编码
    pos_embed = self.bev_position_encoding(x)  # [B, 256, 200, 200]
    B, _, H, W = x.shape
    masks = torch.zeros(B, H, W).bool().to(x.device)
    
    # Step 3: 序列嵌入
    tgt = self.embedding(input_seqs.long())  # [B, L, 256]
    query_embed = self.embedding.position_embeddings.weight  # [L, 256]
    
    # Step 4: Transformer处理
    outs_dec, _ = self.transformer(
        tgt,         # 目标序列嵌入
        x,           # BEV特征（展平为[B, HW, 256]）
        masks,       # 注意力掩码
        query_embed, # 查询位置编码
        pos_embed    # BEV位置编码
    )
    # outs_dec: [6, B, L, 256] (6层输出)
    
    # Step 5: 词汇预测
    outs_dec = torch.nan_to_num(outs_dec)
    out = self.vocab_embed(outs_dec)  # [6, B, L, 574]
    
    return out
```

### 3.4 注意力机制

**Self-Attention**：序列内部关注

```
输入：[10, 20, 200, 250, ...]
       ↓   ↓   ↓    ↓
每个token关注所有之前的token
例如：预测250时，关注[10, 20, 200]
```

**Cross-Attention**：序列关注BEV

```
序列token: [10, 20, ...]
              ↓
        查询BEV特征图
              ↓
    BEV [256, 200, 200]
         哪个位置相关？
```

---

## 4. 嵌入层设计

### 4.1 词嵌入 + 位置嵌入

```python
# ar_rntr_head.py L104-131
class DecoderEmbeddings(nn.Module):
    def __init__(self, vocab_size, hidden_dim, 
                 pad_token_id, max_position_embeddings):
        super().__init__()
        
        # 词嵌入表：574个token → 256维向量
        self.word_embeddings = nn.Embedding(
            vocab_size=574,      # 0-573
            embedding_dim=256,
            padding_idx=573      # N/A token
        )
        
        # 位置嵌入表：位置 → 256维向量
        self.position_embeddings = nn.Embedding(
            num_embeddings=1201,  # 最大序列长度
            embedding_dim=256
        )
        
        self.LayerNorm = nn.LayerNorm(256)
    
    def forward(self, x):
        # x: [B, L] token索引
        
        # 词嵌入
        input_embeds = self.word_embeddings(x)  # [B, L, 256]
        
        # 位置嵌入
        seq_length = x.size(1)
        position_ids = torch.arange(
            seq_length, 
            dtype=torch.long, 
            device=x.device
        )
        position_embeds = self.position_embeddings(
            position_ids
        )  # [L, 256]
        
        # 相加+归一化
        embeddings = input_embeds + position_embeds
        embeddings = self.LayerNorm(embeddings)
        
        return embeddings  # [B, L, 256]
```

### 4.2 嵌入过程图解

```
输入序列: [572, 10, 20, 200, ...]
            ↓   ↓   ↓   ↓
词嵌入查表: [e572, e10, e20, e200, ...]  [B,L,256]
            +    +    +    +
位置嵌入:   [p0,  p1,  p2,  p3,  ...]  [L,256]
            ↓    ↓    ↓    ↓
最终嵌入:   [h0,  h1,  h2,  h3,  ...]  [B,L,256]
```

### 4.3 为什么需要位置编码？

**问题**：Transformer没有顺序信息

```
没有位置编码：
[10, 20, 200] 和 [200, 10, 20] 无法区分

有了位置编码：
[10@pos0, 20@pos1, 200@pos2] ≠ [200@pos0, 10@pos1, 20@pos2]
```

### 4.4 词汇预测头

```python
# ar_rntr_head.py L342
self.vocab_embed = MLP(
    input_dim=256,
    hidden_dim=256,
    output_dim=574,  # 574个token的logits
    num_layers=3
)

# 使用时
logits = self.vocab_embed(outs_dec)  # [B, L, 574]
probs = logits.softmax(dim=-1)       # 概率分布
```

---

## 5. 模型尺寸总结

| 组件 | 参数量估算 | 说明 |
|------|-----------|------|
| ResNet-50 | ~25M | 图像特征提取 |
| LSS | ~5M | BEV投影 |
| Transformer (6层) | ~20M | 序列解码 |
| 嵌入层 | 574×256≈0.15M | 词+位置嵌入 |
| **总计** | **~50M** | 适中规模 |

---

## 小结

✅ **BEV编码器**：6相机→俯视图特征
✅ **Transformer解码器**：6层，Self+Cross Attention
✅ **嵌入层**：词嵌入+位置嵌入→256维
✅ **输出**：574个token的概率分布

下一部分讲解**训练和推理过程**！
