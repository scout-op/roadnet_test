#!/usr/bin/env python3
"""
检查并配置matplotlib中文字体
"""

import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

def check_available_fonts():
    """检查系统可用的中文字体"""
    print("🔍 检查系统可用字体...")
    
    # 获取所有字体
    all_fonts = [f.name for f in fm.fontManager.ttflist]
    
    # 常见中文字体
    chinese_fonts = [
        'SimHei',           # 黑体
        'SimSun',           # 宋体
        'Microsoft YaHei',  # 微软雅黑
        'WenQuanYi Micro Hei',  # 文泉驿微米黑
        'WenQuanYi Zen Hei',    # 文泉驿正黑
        'Noto Sans CJK',    # Google Noto
        'Arial Unicode MS', # Arial Unicode
        'STHeiti',          # 华文黑体
        'STSong',           # 华文宋体
    ]
    
    available = []
    for font in chinese_fonts:
        if font in all_fonts:
            available.append(font)
            print(f"  ✅ {font}")
        else:
            print(f"  ❌ {font}")
    
    return available

def test_chinese_display(font_name=None):
    """测试中文显示"""
    print(f"\n🧪 测试中文显示...")
    
    if font_name:
        plt.rcParams['font.sans-serif'] = [font_name]
        print(f"  使用字体: {font_name}")
    
    plt.rcParams['axes.unicode_minus'] = False
    
    # 创建简单测试图
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.text(0.5, 0.5, '中文测试: Lineal节点连接模式', 
            ha='center', va='center', fontsize=16)
    ax.set_title('中文标题测试', fontsize=14, fontweight='bold')
    ax.set_xlabel('X轴标签')
    ax.set_ylabel('Y轴标签')
    ax.axis('off')
    
    test_file = 'chinese_font_test.png'
    plt.savefig(test_file, dpi=100, bbox_inches='tight')
    print(f"  ✅ 测试图已保存: {test_file}")
    print(f"  请查看图片确认中文是否正常显示")
    plt.close()

def recommend_solution():
    """推荐解决方案"""
    print("\n" + "="*60)
    print("💡 解决方案建议")
    print("="*60)
    
    available = check_available_fonts()
    
    if available:
        print(f"\n✅ 找到 {len(available)} 个可用中文字体")
        print(f"   推荐使用: {available[0]}")
        
        # 测试第一个可用字体
        test_chinese_display(available[0])
        
        print(f"\n📝 在脚本中添加以下代码:")
        print(f"   matplotlib.rcParams['font.sans-serif'] = ['{available[0]}']")
        print(f"   matplotlib.rcParams['axes.unicode_minus'] = False")
        
    else:
        print("\n❌ 未找到中文字体！")
        print("\n📥 请安装中文字体:")
        print("\n  方法1: Ubuntu/Debian")
        print("    sudo apt-get install fonts-wqy-microhei fonts-wqy-zenhei")
        print("\n  方法2: CentOS/RedHat")
        print("    sudo yum install wqy-microhei-fonts wqy-zenhei-fonts")
        print("\n  方法3: 使用conda")
        print("    conda install -c conda-forge fonts-wqy-microhei")
        print("\n  方法4: 手动安装")
        print("    1. 下载字体文件 (如 SimHei.ttf)")
        print("    2. 复制到 ~/.fonts/ 目录")
        print("    3. 运行: fc-cache -fv")
        print("    4. 重启Python")
        
        # 测试不使用中文字体（显示方框）
        print("\n⚠️  当前将使用默认字体（中文可能显示为方框）")
        test_chinese_display()

if __name__ == '__main__':
    recommend_solution()
