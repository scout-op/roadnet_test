# ------------------------------------------------------------------------
# SAR Sequence Generator for 2D Semi-Autoregressive Data
# Implements paper-specified keypoint extraction and 2D sequence generation
# ------------------------------------------------------------------------
import numpy as np
from typing import List, Dict, Tuple, Optional
from collections import defaultdict
import torch

class SARSequenceGenerator:
    """Generate 2D SAR sequences from road network graph.
    
    Implements the paper's Semi-Autoregressive RoadNet Sequence generation:
    1. Identify keypoints: od(v)>1 or id(v)>1 or id(v)=0
    2. Extract keypoints to become roots of subtrees
    3. Generate independent sequences for each subtree
    4. Organize as 2D array [[y_{1,1},...,y_{1,L}], ..., [y_{M,1},...,y_{M,L}]]
    """
    
    def __init__(self,
                 n_control: int = 3,
                 max_M: int = 50,  # Max number of subsequences
                 max_L: int = 100,  # Max length per subsequence
                 clause_length: int = None,
                 # Token ranges (aligned with paper)
                 box_range: int = 200,
                 category_start: int = 200,
                 connect_start: int = 250,
                 coeff_start: int = 350,
                 coeff_range: int = 200,
                 # Special tokens
                 no_known: int = 573,
                 start_token: int = 572,
                 end_token: int = 571):
        
        self.n_control = n_control
        self.max_M = max_M
        self.max_L = max_L
        self.clause_length = clause_length or (4 + 2 * (n_control - 2))
        
        # Token ranges
        self.box_range = box_range
        self.category_start = category_start
        self.connect_start = connect_start
        self.coeff_start = coeff_start
        self.coeff_range = coeff_range
        
        # Special tokens
        self.no_known = no_known
        self.start_token = start_token
        self.end_token = end_token
        
    def identify_keypoints(self, nodes: List[Dict], edges: List[Tuple]) -> List[int]:
        """Identify keypoints according to paper criteria.
        
        Paper: "identifying all key-points in the DAG that meet the condition
                od(v)>1 or id(v)>1 or id(v)=0"
        
        Args:
            nodes: List of node dicts with 'id', 'x', 'y', 'label' keys
            edges: List of (source_id, target_id, coeff) tuples
            
        Returns:
            keypoint_ids: List of node IDs that are keypoints
        """
        # Calculate in-degree and out-degree
        in_degree = defaultdict(int)
        out_degree = defaultdict(int)
        
        for src_id, tgt_id, _ in edges:
            out_degree[src_id] += 1
            in_degree[tgt_id] += 1
        
        # Find keypoints
        keypoints = []
        for node in nodes:
            node_id = node['id']
            od = out_degree[node_id]
            id_ = in_degree[node_id]
            
            # Paper criteria
            if od > 1 or id_ > 1 or id_ == 0:
                keypoints.append(node_id)
        
        return keypoints
    
    def extract_subtrees(self, 
                        nodes: List[Dict],
                        edges: List[Tuple],
                        keypoint_ids: List[int]) -> List[Dict]:
        """Extract subtrees rooted at keypoints.
        
        Each keypoint becomes the root of an independent subtree.
        Clone nodes are created for edges between subtrees.
        
        Returns:
            subtrees: List of subtree dicts with 'root', 'nodes', 'edges'
        """
        # Build adjacency lists and calculate degrees
        children = defaultdict(list)
        parents = defaultdict(list)
        edge_coeffs = {}
        in_degree = defaultdict(int)
        out_degree = defaultdict(int)
        
        for src_id, tgt_id, coeff in edges:
            children[src_id].append(tgt_id)
            parents[tgt_id].append(src_id)
            edge_coeffs[(src_id, tgt_id)] = coeff
            out_degree[src_id] += 1
            in_degree[tgt_id] += 1
        
        # Build node lookup
        node_lookup = {node['id']: node for node in nodes}
        
        # Extract subtrees via DFS from each keypoint
        subtrees = []
        visited_global = set()
        # Prepare a running clone id counter unique within this call
        max_node_id = max([n['id'] for n in nodes]) if len(nodes) > 0 else 0
        next_clone_id = max_node_id + 1
        
        for kp_id in keypoint_ids:
            if kp_id in visited_global and in_degree[kp_id] > 0:
                continue  # Already part of another subtree
                
            # DFS to build subtree
            subtree_nodes = []
            subtree_edges = []
            visited_local = set()
            
            def dfs(node_id, parent_id=None):
                nonlocal next_clone_id
                if node_id in visited_local:
                    return
                if node_id in visited_global and node_id != kp_id:
                    # This is a keypoint from another subtree - create Clone
                    clone_node = node_lookup[node_id].copy()
                    clone_node['type'] = 'clone'
                    clone_node['original_id'] = node_id
                    # assign a unique local id for the clone to avoid id collision
                    clone_node['id'] = next_clone_id
                    local_clone_id = next_clone_id
                    next_clone_id += 1
                    subtree_nodes.append(clone_node)
                    if parent_id is not None:
                        coeff = edge_coeffs.get((parent_id, node_id), [0, 0])
                        # link parent to the clone id inside this subtree
                        subtree_edges.append((parent_id, local_clone_id, coeff))
                    return
                    
                visited_local.add(node_id)
                visited_global.add(node_id)
                subtree_nodes.append(node_lookup[node_id])
                
                if parent_id is not None:
                    coeff = edge_coeffs.get((parent_id, node_id), [0, 0])
                    subtree_edges.append((parent_id, node_id, coeff))
                
                # Visit children (but not other keypoints)
                for child_id in children[node_id]:
                    if child_id not in keypoint_ids or child_id == kp_id:
                        dfs(child_id, node_id)
            
            dfs(kp_id)
            
            if len(subtree_nodes) > 0:
                subtrees.append({
                    'root': kp_id,
                    'nodes': subtree_nodes,
                    'edges': subtree_edges
                })
        
        return subtrees
    
    def subtree_to_sequence(self, subtree: Dict) -> List[int]:
        """Convert a subtree to a sequence of tokens.
        
        Uses DFS traversal with the paper's 4 node types:
        - Ancestor (root): label=0
        - Lineal (first child): label=1  
        - Offshoot (non-first child): label=2
        - Clone (reference to other subtree): label=3
        
        Each node generates a clause of tokens:
        [x, y, label, connect_idx, coeff_x, coeff_y, ...]
        
        Returns:
            sequence: Flat list of token IDs
        """
        nodes = subtree['nodes']
        edges = subtree['edges']
        root_id = subtree['root']
        
        # Build adjacency
        children = defaultdict(list)
        edge_coeffs = {}
        for src_id, tgt_id, coeff in edges:
            children[src_id].append((tgt_id, coeff))
            edge_coeffs[(src_id, tgt_id)] = coeff
        
        # Build node lookup
        node_lookup = {n['id']: n for n in nodes}
        
        # DFS to generate sequence
        sequence = []
        node_order = []  # Track order for connect indices
        node_id_to_idx = {}  # Map node_id to sequence index
        
        def dfs(node_id, parent_idx=None, is_first_child=False):
            node = node_lookup[node_id]
            node_idx = len(node_order)
            node_order.append(node_id)
            node_id_to_idx[node_id] = node_idx
            
            # Generate tokens for this node
            tokens = []
            
            # Coordinates (x, y)
            x = min(max(0, int(node['x'])), self.box_range - 1)
            y = min(max(0, int(node['y'])), self.box_range - 1)
            tokens.append(x)
            tokens.append(y)
            
            # Label (node type)
            if node_id == root_id:
                label = 0  # Ancestor
            elif node.get('type') == 'clone':
                label = 3  # Clone
            elif is_first_child:
                label = 1  # Lineal
            else:
                label = 2  # Offshoot
            tokens.append(self.category_start + label)
            
            # Connect index
            if label == 1:  # Lineal connects to previous (implicit)
                connect = 0
            elif label == 2:  # Offshoot connects to parent
                connect = parent_idx if parent_idx is not None else 0
            elif label == 3:  # Clone connects to original
                # Find original in current sequence
                original_id = node.get('original_id', node_id)
                connect = node_id_to_idx.get(original_id, 0)
            else:  # Ancestor
                connect = 0
            # Clamp connect to valid range
            connect = min(max(0, connect), node_idx)
            tokens.append(self.connect_start + connect)
            
            # Coefficients (Bezier control points)
            coeff = node.get('coeff', [])
            if len(coeff) == 0:
                coeff = [0] * (self.clause_length - 4)
            
            # Ensure we have the right number of coefficients
            num_coeffs = self.clause_length - 4
            coeff_list = list(coeff)[:num_coeffs]
            while len(coeff_list) < num_coeffs:
                coeff_list.append(0)
            
            for c in coeff_list:
                c_token = min(max(0, int(c)), self.coeff_range - 1)
                tokens.append(self.coeff_start + c_token)
            
            sequence.extend(tokens)
            
            # Visit children
            child_list = children[node_id]
            for i, (child_id, _) in enumerate(child_list):
                dfs(child_id, node_idx, is_first_child=(i == 0))
        
        dfs(root_id)
        return sequence
    
    def generate_2d_sequences(self,
                              nodes: List[Dict],
                              edges: List[Tuple]) -> Dict:
        """Generate 2D SAR sequences from graph.
        
        Returns:
            dict with:
                - sequences_2d: [M, L] numpy array of token IDs
                - mask_2d: [M, L] boolean mask (True=valid)
                - keypoints: list of keypoint info
                - M: number of subsequences
                - L: max subsequence length
        """
        # Step 1: Identify keypoints
        keypoint_ids = self.identify_keypoints(nodes, edges)
        
        # Step 2: Extract subtrees
        subtrees = self.extract_subtrees(nodes, edges, keypoint_ids)
        
        # Step 3: Convert each subtree to sequence
        subsequences = []
        for subtree in subtrees[:self.max_M]:  # Limit to max_M
            seq = self.subtree_to_sequence(subtree)
            # Add START token at beginning
            seq = [self.start_token] + seq
            # Truncate if too long
            if len(seq) > self.max_L * self.clause_length:
                seq = seq[:self.max_L * self.clause_length]
            subsequences.append(seq)
        
        # Step 4: Organize as 2D array with padding
        M = len(subsequences)
        L = max([len(seq) for seq in subsequences]) if M > 0 else self.clause_length
        
        # Round L up to multiple of clause_length
        L = ((L + self.clause_length - 1) // self.clause_length) * self.clause_length
        L = min(L, self.max_L * self.clause_length)
        
        # Create 2D array
        sequences_2d = np.full((self.max_M, L), self.no_known, dtype=np.int32)
        mask_2d = np.zeros((self.max_M, L), dtype=bool)
        
        for i, seq in enumerate(subsequences):
            seq_len = len(seq)
            sequences_2d[i, :seq_len] = seq
            mask_2d[i, :seq_len] = True
            # Add END token
            if seq_len < L:
                sequences_2d[i, seq_len] = self.end_token
                mask_2d[i, seq_len] = True
        
        # Reshape to [M, L_clauses, clause_length]
        L_clauses = L // self.clause_length
        sequences_3d = sequences_2d.reshape(self.max_M, L_clauses, self.clause_length)
        mask_3d = mask_2d.reshape(self.max_M, L_clauses, self.clause_length)[:, :, 0]  # One mask per clause
        
        # Extract keypoint info
        keypoint_info = []
        for kp_id in keypoint_ids:
            node = next((n for n in nodes if n['id'] == kp_id), None)
            if node:
                keypoint_info.append({
                    'id': kp_id,
                    'x': node['x'],
                    'y': node['y'],
                    'label': node.get('label', 0)
                })
        
        return {
            'sequences_2d': sequences_3d,  # [M, L_clauses, clause_length]
            'mask_2d': mask_3d,  # [M, L_clauses]
            'keypoints': keypoint_info,
            'M': M,
            'L': L_clauses,
            'clause_length': self.clause_length
        }
    
    @staticmethod
    def collate_batch(batch_data: List[Dict]) -> Dict:
        """Collate multiple samples into a batch.
        
        Args:
            batch_data: List of dicts from generate_2d_sequences
            
        Returns:
            Batched tensors
        """
        B = len(batch_data)
        
        # Find max dimensions
        max_M = max([d['M'] for d in batch_data])
        max_L = max([d['L'] for d in batch_data])
        clause_length = batch_data[0]['clause_length']
        
        # Initialize tensors
        sequences = []
        masks = []
        
        for data in batch_data:
            seq = data['sequences_2d']  # [M, L, clause_length]
            mask = data['mask_2d']  # [M, L]
            
            # Pad to max dimensions
            M, L, _ = seq.shape
            if L < max_L:
                pad_L = max_L - L
                seq = np.pad(seq, ((0, 0), (0, pad_L), (0, 0)), 
                            mode='constant', constant_values=573)  # no_known
                mask = np.pad(mask, ((0, 0), (0, pad_L)), 
                             mode='constant', constant_values=False)
            
            sequences.append(seq)
            masks.append(mask)
        
        # Convert to tensors
        sequences_tensor = torch.tensor(np.stack(sequences), dtype=torch.long)
        masks_tensor = torch.tensor(np.stack(masks), dtype=torch.bool)
        
        return {
            'sequences_2d': sequences_tensor,  # [B, M, L, clause_length]
            'mask_2d': masks_tensor,  # [B, M, L]
            'keypoints_batch': [d['keypoints'] for d in batch_data]
        }


def convert_from_existing_format(centerline_coords: List,
                                 centerline_labels: List,
                                 centerline_connects: List,
                                 centerline_coeffs: List,
                                 n_control: int = 3) -> Tuple[List[Dict], List[Tuple]]:
    """Convert from existing AR format to graph format.
    
    Args:
        centerline_coords: List of [N, 2] coordinate arrays
        centerline_labels: List of [N] label arrays
        centerline_connects: List of [N] connect index arrays
        centerline_coeffs: List of [N, coeff_dim] coefficient arrays
        
    Returns:
        nodes: List of node dicts
        edges: List of edge tuples
    """
    nodes = []
    edges = []
    node_id_counter = 0
    
    # Process each sequence (corresponds to a tree in the forest)
    for seq_idx in range(len(centerline_coords)):
        coords = centerline_coords[seq_idx]
        labels = centerline_labels[seq_idx]
        connects = centerline_connects[seq_idx]
        coeffs = centerline_coeffs[seq_idx] if seq_idx < len(centerline_coeffs) else None
        
        # Create nodes
        seq_nodes = []
        for i in range(len(coords)):
            node = {
                'id': node_id_counter,
                'x': float(coords[i, 0]),
                'y': float(coords[i, 1]),
                'label': int(labels[i]),
                'seq_idx': seq_idx,
                'pos_in_seq': i
            }
            nodes.append(node)
            seq_nodes.append(node)
            node_id_counter += 1
        
        # Create edges based on connectivity
        for i in range(len(seq_nodes)):
            if i == 0:
                continue  # Root has no parent
                
            label = labels[i]
            connect_idx = connects[i]
            
            if label == 1:  # Lineal - connects to previous
                parent_idx = i - 1
            elif label in [2, 3]:  # Offshoot or Clone
                parent_idx = connect_idx
            else:
                continue
            
            if 0 <= parent_idx < len(seq_nodes):
                parent_id = seq_nodes[parent_idx]['id']
                child_id = seq_nodes[i]['id']
                coeff = coeffs[i] if coeffs is not None else [0, 0]
                edges.append((parent_id, child_id, coeff))
    
    return nodes, edges
