"""
Road Topology Visualization for SwanLab logging with Bezier curve support.
"""
import numpy as np
import cv2

# Try to import bezier for curve rendering
try:
    import bezier
    BEZIER_AVAILABLE = True
except ImportError:
    BEZIER_AVAILABLE = False


def render_topology_graph(pred_tokens_sample, clause_length, box_range=200, canvas_size=500):
    """
    Render road topology graph with node types, connections, and visual effects.
    
    Args:
        pred_tokens_sample: Predicted token sequence [T], torch.Tensor
        clause_length: Length of each clause (4 + coeff_dim*2)
        box_range: Coordinate range (default 200)
        canvas_size: Output canvas size (default 500x500)
        
    Returns:
        np.ndarray: Topology visualization image (BGR format for cv2)
        
    Visualization includes:
        - Node types (different colors): Ancestor, Lineal, Offshoot, Clone
        - Connection arrows (topology edges)
        - Node indices for debugging
    """
    try:
        H = W = int(canvas_size)
        # White background
        canvas = np.ones((H, W, 3), dtype=np.uint8) * 255
        
        # Color scheme (BGR format for OpenCV)
        colors = {
            'Ancestor': (255, 100, 100),   # Light Blue
            'Lineal': (100, 200, 100),     # Light Green
            'Offshoot': (50, 150, 255),    # Orange
            'Clone': (200, 150, 255),      # Light Pink
            'Unknown': (180, 180, 180),    # Gray
        }
        
        # Parse prediction tokens
        T = int(pred_tokens_sample.shape[0])
        max_nodes = T // clause_length
        nodes = []
        
        for i in range(max_nodes):
            base_idx = i * clause_length
            if base_idx + 3 >= T:
                break
            
            # Extract node information
            x_token = int(pred_tokens_sample[base_idx + 0].item())
            y_token = int(pred_tokens_sample[base_idx + 1].item())
            label_token = int(pred_tokens_sample[base_idx + 2].item())
            connect_token = int(pred_tokens_sample[base_idx + 3].item())
            
            # Extract Bezier coefficients if available
            coeff = None
            if clause_length > 4 and base_idx + clause_length <= T:
                try:
                    # Extract coeff tokens (in Bezier grid coords)
                    coeff_tokens = []
                    for c_idx in range(4, min(clause_length, 6)):  # First 2 coeff (c_x, c_y)
                        if base_idx + c_idx < T:
                            c_val = int(pred_tokens_sample[base_idx + c_idx].item())
                            # Convert from token space to grid space
                            if c_val >= 350:  # coeff_start = 350
                                coeff_tokens.append(c_val - 350)
                            else:
                                coeff_tokens.append(0)
                    if len(coeff_tokens) >= 2:
                        coeff = coeff_tokens
                except Exception:
                    coeff = None
            
            # Scale coordinates to canvas
            x = int(x_token * W / box_range)
            y = int(y_token * H / box_range)
            x = max(10, min(W - 10, x))
            y = max(10, min(H - 10, y))
            
            # Decode label type
            label_map = {
                200: 'Ancestor',
                201: 'Lineal',
                202: 'Offshoot',
                203: 'Clone'
            }
            label_name = label_map.get(label_token, 'Unknown')
            
            # Decode connection
            connect_to = None
            if connect_token >= 250:
                connect_to = connect_token - 250
                if connect_to >= i:  # Invalid: future connection
                    connect_to = None
            
            nodes.append({
                'idx': i,
                'pos': (x, y),
                'label': label_name,
                'connect_to': connect_to,
                'coeff': coeff,
                'color': colors.get(label_name, colors['Unknown'])
            })
        
        # Helper function to draw Bezier curve or straight line
        def draw_edge(canvas, pt1, pt2, coeff, color, thickness):
            """Draw Bezier curve if coeff available and bezier library loaded."""
            if not BEZIER_AVAILABLE or coeff is None or len(coeff) < 2:
                # Fallback to straight arrow
                cv2.arrowedLine(canvas, pt1, pt2, color, thickness, tipLength=0.12)
                return
            
            try:
                # Scale coeff from grid coords to canvas
                c_x = int(coeff[0] * W / box_range)
                c_y = int(coeff[1] * H / box_range)
                c_x = max(5, min(W - 5, c_x))
                c_y = max(5, min(H - 5, c_y))
                
                # Create Bezier curve
                p0 = np.array(pt1, dtype=float)
                p1 = np.array(pt2, dtype=float)
                c = np.array([c_x, c_y], dtype=float)
                
                fin_res = np.stack((p0, c, p1))
                curve = bezier.Curve(fin_res.T, degree=2)
                s_vals = np.linspace(0.0, 1.0, 25)
                data_b = curve.evaluate_multi(s_vals).T
                pts = data_b.astype(np.int32)
                
                # Draw curve
                if pts.shape[0] >= 2:
                    cv2.polylines(canvas, [pts], False, color=color, thickness=thickness)
                    # Add arrow at end
                    if pts.shape[0] > 10:
                        arrow_pts = pts[-3:-1, :]
                        if not np.all(arrow_pts[0] == arrow_pts[1]):
                            cv2.arrowedLine(canvas, tuple(arrow_pts[0]), tuple(arrow_pts[1]),
                                          color, thickness, tipLength=0.3)
            except Exception:
                # Fallback on error
                cv2.arrowedLine(canvas, pt1, pt2, color, thickness, tipLength=0.12)
        
        # Draw connections (arrows) - behind nodes
        for node in nodes:
            if node['connect_to'] is not None and node['connect_to'] < len(nodes):
                parent = nodes[node['connect_to']]
                pt1 = parent['pos']
                pt2 = node['pos']
                coeff = node.get('coeff', None)
                
                # Arrow style based on node type
                if node['label'] == 'Offshoot':
                    # Offshoot: thicker
                    thickness = 3
                    color = (100, 100, 100)
                elif node['label'] == 'Clone':
                    # Clone: thinner, lighter
                    thickness = 1
                    color = (180, 180, 180)
                else:
                    # Lineal: normal
                    thickness = 2
                    color = (140, 140, 140)
                
                # Draw edge with Bezier curve support
                draw_edge(canvas, pt1, pt2, coeff, color, thickness)
        
        # Draw nodes - on top
        for node in nodes:
            x, y = node['pos']
            color = node['color']
            
            # Node size varies by type
            if node['label'] == 'Ancestor':
                radius = 8
            elif node['label'] == 'Offshoot':
                radius = 7
            else:
                radius = 6
            
            # Draw node circle
            cv2.circle(canvas, (x, y), radius, color, -1)
            cv2.circle(canvas, (x, y), radius, (50, 50, 50), 2)  # Dark border
            
            # Draw node index
            text = str(node['idx'])
            text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.35, 1)[0]
            text_pos = (x - text_size[0] // 2, y + text_size[1] // 2)
            # White text with black shadow for readability
            cv2.putText(canvas, text, (text_pos[0] + 1, text_pos[1] + 1),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 0), 2, cv2.LINE_AA)
            cv2.putText(canvas, text, text_pos,
                       cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 255, 255), 1, cv2.LINE_AA)
        
        # Draw legend
        legend_x = 15
        legend_y = 20
        legend_width = 130
        legend_height = 100
        
        # Legend background
        cv2.rectangle(canvas, 
                     (legend_x - 8, legend_y - 8),
                     (legend_x + legend_width, legend_y + legend_height),
                     (250, 250, 250), -1)
        cv2.rectangle(canvas,
                     (legend_x - 8, legend_y - 8),
                     (legend_x + legend_width, legend_y + legend_height),
                     (100, 100, 100), 2)
        
        # Legend title
        cv2.putText(canvas, 'Node Types:', (legend_x, legend_y),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, cv2.LINE_AA)
        
        # Legend items
        y_offset = legend_y + 18
        for label_name, color in [('Ancestor', colors['Ancestor']),
                                   ('Lineal', colors['Lineal']),
                                   ('Offshoot', colors['Offshoot']),
                                   ('Clone', colors['Clone'])]:
            cv2.circle(canvas, (legend_x + 6, y_offset + 3), 5, color, -1)
            cv2.circle(canvas, (legend_x + 6, y_offset + 3), 5, (50, 50, 50), 1)
            cv2.putText(canvas, label_name, (legend_x + 18, y_offset + 8),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.38, (0, 0, 0), 1, cv2.LINE_AA)
            y_offset += 20
        
        # Title with node count
        title = f'Road Topology: {len(nodes)} nodes'
        title_size = cv2.getTextSize(title, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
        title_x = W - title_size[0] - 20
        cv2.putText(canvas, title, (title_x, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (50, 50, 50), 2, cv2.LINE_AA)
        
        # Statistics summary at bottom
        stats_y = H - 25
        if len(nodes) > 0:
            label_counts = {}
            for node in nodes:
                label_counts[node['label']] = label_counts.get(node['label'], 0) + 1
            
            stats_text = ' | '.join([f"{k}:{v}" for k, v in sorted(label_counts.items())])
            cv2.putText(canvas, stats_text, (20, stats_y),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (100, 100, 100), 1, cv2.LINE_AA)
        
        return canvas
        
    except Exception as e:
        # Return error canvas
        error_canvas = np.ones((500, 500, 3), dtype=np.uint8) * 255
        cv2.putText(error_canvas, 'Visualization Error', (150, 250),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2, cv2.LINE_AA)
        cv2.putText(error_canvas, str(e)[:40], (100, 280),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (100, 100, 100), 1, cv2.LINE_AA)
        return error_canvas
