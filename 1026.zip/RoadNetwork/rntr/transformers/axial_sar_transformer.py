# ------------------------------------------------------------------------
# Axial Semi-Autoregressive Transformer (Paper-aligned)
# Implements the two-directional attention mechanism described in the paper:
# - Intra-seq attention: across M subsequences for each position j
# - Inter-seq attention: within each subsequence i across positions 1:j-1
# Memory complexity: O(M^2 + L^2) instead of O(M^2 * L^2)
# ------------------------------------------------------------------------
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple
from mmcv.cnn.bricks.transformer import BaseTransformerLayer, TransformerLayerSequence
from mmdet.models.layers.transformer import DetrTransformerDecoderLayer
from mmdet3d.registry import MODELS
import math


class AxialSARDecoderLayer(nn.Module):
    """Single layer of Axial SAR Decoder.
    
    Implements the paper's two-stage attention:
    1. Intra-seq self-attention: attention across M subsequences at each position j
    2. Inter-seq causal self-attention: attention within each subsequence with causal mask
    3. Cross-attention to BEV features
    
    Args:
        d_model: dimension of features (256)
        nhead: number of attention heads (8)
        dim_feedforward: dimension of feedforward network (1024)
        dropout: dropout rate (0.1)
    """
    
    def __init__(self, 
                 d_model: int = 256,
                 nhead: int = 8, 
                 dim_feedforward: int = 1024,
                 dropout: float = 0.1,
                 activation: str = 'relu'):
        super().__init__()
        
        # Intra-seq self-attention (across M)
        self.intra_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=True)
        self.intra_norm = nn.LayerNorm(d_model)
        self.intra_dropout = nn.Dropout(dropout)
        
        # Inter-seq self-attention (across L with causal mask)
        self.inter_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=True)
        self.inter_norm = nn.LayerNorm(d_model)
        self.inter_dropout = nn.Dropout(dropout)
        
        # Cross-attention to BEV features
        self.cross_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=True)
        self.cross_norm = nn.LayerNorm(d_model)
        self.cross_dropout = nn.Dropout(dropout)
        
        # FFN
        self.ffn = nn.Sequential(
            nn.Linear(d_model, dim_feedforward),
            nn.ReLU() if activation == 'relu' else nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim_feedforward, d_model),
            nn.Dropout(dropout)
        )
        self.ffn_norm = nn.LayerNorm(d_model)
        
    def forward(self, 
                tgt: torch.Tensor,  # [B, M, L, D]
                memory: torch.Tensor,  # [B, HW, D]
                tgt_mask_2d: Optional[torch.Tensor] = None,  # [B, M, L] validity mask
                memory_mask: Optional[torch.Tensor] = None,  # [B, HW]
                pos_embed_2d: Optional[torch.Tensor] = None,  # [B, M, L, D]
                memory_pos: Optional[torch.Tensor] = None) -> torch.Tensor:  # [B, HW, D]
        """
        Args:
            tgt: target sequence embeddings [B, M, L, D]
            memory: BEV features [B, HW, D]
            tgt_mask_2d: validity mask for target [B, M, L], True=valid
            memory_mask: validity mask for memory [B, HW]
            pos_embed_2d: positional embeddings for target [B, M, L, D]
            memory_pos: positional embeddings for memory [B, HW, D]
        
        Returns:
            Updated tgt [B, M, L, D]
        """
        B, M, L, D = tgt.shape
        
        # Add positional embeddings
        if pos_embed_2d is not None:
            tgt = tgt + pos_embed_2d
        
        # === Stage 1: Intra-seq attention (across M for each j) ===
        # Reshape: [B, M, L, D] -> [B*L, M, D]
        tgt_intra = tgt.permute(0, 2, 1, 3).reshape(B*L, M, D)
        
        # Create attention mask if needed
        attn_mask_intra = None
        if tgt_mask_2d is not None:
            # [B, M, L] -> [B*L, M]
            key_padding_mask_intra = ~tgt_mask_2d.permute(0, 2, 1).reshape(B*L, M)
        else:
            key_padding_mask_intra = None
        
        # Apply Intra-seq attention (no causal mask, all M can see each other)
        tgt_intra_out, _ = self.intra_attn(
            tgt_intra, tgt_intra, tgt_intra,
            attn_mask=attn_mask_intra,
            key_padding_mask=key_padding_mask_intra
        )
        
        # Add & Norm
        tgt_intra = self.intra_norm(tgt_intra + self.intra_dropout(tgt_intra_out))
        
        # Reshape back: [B*L, M, D] -> [B, M, L, D]
        tgt = tgt_intra.reshape(B, L, M, D).permute(0, 2, 1, 3)
        
        # === Stage 2: Inter-seq attention (across L with causal mask) ===
        # Reshape: [B, M, L, D] -> [B*M, L, D]
        tgt_inter = tgt.reshape(B*M, L, D)
        
        # Create causal mask for L
        causal_mask = self._generate_causal_mask(L, tgt.device)
        
        # Create attention mask if needed
        if tgt_mask_2d is not None:
            # [B, M, L] -> [B*M, L]
            key_padding_mask_inter = ~tgt_mask_2d.reshape(B*M, L)
        else:
            key_padding_mask_inter = None
        
        # Apply Inter-seq attention with causal mask
        tgt_inter_out, _ = self.inter_attn(
            tgt_inter, tgt_inter, tgt_inter,
            attn_mask=causal_mask,
            key_padding_mask=key_padding_mask_inter
        )
        
        # Add & Norm
        tgt_inter = self.inter_norm(tgt_inter + self.inter_dropout(tgt_inter_out))
        
        # Reshape back: [B*M, L, D] -> [B, M, L, D]
        tgt = tgt_inter.reshape(B, M, L, D)
        
        # === Stage 3: Cross-attention to BEV features ===
        # Reshape: [B, M, L, D] -> [B, M*L, D]
        tgt_cross = tgt.reshape(B, M*L, D)
        
        # Add memory positional embeddings if available
        if memory_pos is not None:
            memory_with_pos = memory + memory_pos
        else:
            memory_with_pos = memory
        
        # Apply cross-attention
        tgt_cross_out, _ = self.cross_attn(
            tgt_cross, memory_with_pos, memory,
            key_padding_mask=memory_mask
        )
        
        # Add & Norm
        tgt_cross = self.cross_norm(tgt_cross + self.cross_dropout(tgt_cross_out))
        
        # === Stage 4: FFN ===
        tgt_ffn = self.ffn(tgt_cross)
        tgt_out = self.ffn_norm(tgt_cross + tgt_ffn)
        
        # Reshape back: [B, M*L, D] -> [B, M, L, D]
        tgt_out = tgt_out.reshape(B, M, L, D)
        
        return tgt_out
    
    @staticmethod
    def _generate_causal_mask(seq_len: int, device: torch.device) -> torch.Tensor:
        """Generate causal mask for sequence length L.
        
        Returns:
            mask [L, L] where mask[i, j] = 0 if j <= i else -inf
        """
        mask = torch.triu(
            torch.full((seq_len, seq_len), float('-inf'), device=device),
            diagonal=1
        )
        return mask


@MODELS.register_module()
class AxialSARTransformer(nn.Module):
    """Axial Semi-Autoregressive Transformer Decoder.
    
    Implements the paper's Parallel-Seq Transformer Decoder with:
    - Two-dimensional sequence processing [B, M, L, D]
    - Axial attention mechanism (Intra-seq + Inter-seq)
    - O(M^2 + L^2) complexity instead of O(M^2 * L^2)
    
    Args:
        num_layers: number of decoder layers (6)
        d_model: dimension of features (256)
        nhead: number of attention heads (8)
        dim_feedforward: dimension of feedforward network (1024)
        dropout: dropout rate (0.1)
        return_intermediate: whether to return intermediate layer outputs
    """
    
    def __init__(self,
                 num_layers: int = 6,
                 d_model: int = 256,
                 nhead: int = 8,
                 dim_feedforward: int = 1024,
                 dropout: float = 0.1,
                 activation: str = 'relu',
                 return_intermediate: bool = True):
        super().__init__()
        
        self.num_layers = num_layers
        self.d_model = d_model
        self.return_intermediate = return_intermediate
        
        # Stack of decoder layers
        self.layers = nn.ModuleList([
            AxialSARDecoderLayer(
                d_model=d_model,
                nhead=nhead,
                dim_feedforward=dim_feedforward,
                dropout=dropout,
                activation=activation
            )
            for _ in range(num_layers)
        ])
        
        # 2D positional encoding (row + column) with sinusoidal initialization
        row_pe = self._create_sinusoidal_encoding(100, d_model)
        col_pe = self._create_sinusoidal_encoding(500, d_model)
        self.row_embed = nn.Parameter(row_pe.view(1, 100, 1, d_model))
        self.col_embed = nn.Parameter(col_pe.view(1, 1, 500, d_model))  # Max L=500
        
    def init_weights(self):
        """Initialize parameters following common transformer init.
        Keeps default PyTorch init for nn.MultiheadAttention/Linear, and
        initializes positional embeddings with the precomputed sinusoidals.
        """
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.LayerNorm):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self,
                tgt: torch.Tensor,  # [B, M, L, D] or token IDs
                memory: torch.Tensor,  # BEV features [B, C, H, W]
                tgt_mask: Optional[torch.Tensor] = None,  # [B, M, L] validity
                memory_mask: Optional[torch.Tensor] = None,  # [B, H, W] boolean mask
                query_embed: Optional[torch.Tensor] = None,  # Optional query embeddings
                pos_embed: Optional[torch.Tensor] = None,  # BEV positional embeddings
                **kwargs) -> Tuple[torch.Tensor, None]:
        """
        Args:
            tgt: target sequence [B, M, L, D] (embeddings) or [B, M, L] (token IDs)
            memory: BEV features [B, C, H, W]
            tgt_mask: validity mask [B, M, L], True=valid
            memory_mask: BEV mask [B, H, W]
            query_embed: optional query embeddings
            pos_embed: BEV positional embeddings
            
        Returns:
            output: decoder outputs [num_layers, B, M, L, D] if return_intermediate
                    else [B, M, L, D]
            None (for compatibility)
        """
        # Flatten BEV features
        B, C, H, W = memory.shape
        memory_flat = memory.flatten(2).permute(0, 2, 1)  # [B, HW, C]
        
        if memory_mask is not None:
            memory_mask_flat = memory_mask.flatten(1)  # [B, HW]
        else:
            memory_mask_flat = None
        
        if pos_embed is not None:
            pos_embed_flat = pos_embed.flatten(2).permute(0, 2, 1)  # [B, HW, C]
        else:
            pos_embed_flat = None
        
        # Handle different input formats
        if tgt.dim() == 3:  # [B, M, L] token IDs
            # This case needs external embedding layer, skip for now
            raise NotImplementedError("Token ID input not yet supported")
        elif tgt.dim() == 4:  # [B, M, L, D] embeddings
            B, M, L, D = tgt.shape
        else:
            raise ValueError(f"Invalid tgt shape: {tgt.shape}")
        
        # Generate 2D positional embeddings
        row_embed = self.row_embed[:, :M, :, :]  # [1, M, 1, D]
        col_embed = self.col_embed[:, :, :L, :]  # [1, 1, L, D]
        pos_embed_2d = row_embed + col_embed  # [1, M, L, D]
        pos_embed_2d = pos_embed_2d.expand(B, -1, -1, -1)  # [B, M, L, D]
        
        # Apply decoder layers
        output = tgt
        intermediate = []
        
        for layer in self.layers:
            output = layer(
                output, 
                memory_flat,
                tgt_mask_2d=tgt_mask,
                memory_mask=memory_mask_flat,
                pos_embed_2d=pos_embed_2d,
                memory_pos=pos_embed_flat
            )
            
            if self.return_intermediate:
                intermediate.append(output)
        
        if self.return_intermediate:
            # Stack: [num_layers, B, M, L, D]
            output = torch.stack(intermediate, dim=0)
        
        return output, None
    
    @staticmethod
    def _create_sinusoidal_encoding(max_len: int, d_model: int) -> torch.Tensor:
        """Create sinusoidal positional encoding.
        
        Args:
            max_len: maximum sequence length
            d_model: dimension of embeddings
            
        Returns:
            pe: [max_len, d_model] positional encoding
        """
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * 
                            (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return pe


@MODELS.register_module()
class AxialSARTransformerV2(AxialSARTransformer):
    """Extended version with Key-point Prompt support.
    
    Adds support for Key-point Prompt Learning as described in the paper:
    - All keypoints' locations
    - Start keypoint (Ancestor) of each subsequence
    """
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Key-point prompt adapter
        self.kp_prompt_proj = nn.Sequential(
            nn.Linear(self.d_model, self.d_model),
            nn.ReLU(),
            nn.Linear(self.d_model, self.d_model)
        )

    def init_weights(self):
        super().init_weights()
        
    def forward(self,
                tgt: torch.Tensor,  # [B, M, L, D]
                memory: torch.Tensor,  # BEV features [B, C, H, W]
                tgt_mask: Optional[torch.Tensor] = None,
                memory_mask: Optional[torch.Tensor] = None,
                query_embed: Optional[torch.Tensor] = None,
                pos_embed: Optional[torch.Tensor] = None,
                kp_prompt: Optional[torch.Tensor] = None,  # [B, D]
                kp_prompt_pos: Optional[torch.Tensor] = None,  # [B, num_kp, 2]
                **kwargs) -> Tuple[torch.Tensor, None]:
        """
        Extended forward with Key-point Prompt.
        
        Additional Args:
            kp_prompt: keypoint global features [B, D]
            kp_prompt_pos: keypoint positions [B, num_kp, 2] normalized to [0,1]
        """
        # Process keypoint prompt if provided
        if kp_prompt is not None:
            # Project keypoint features
            kp_features = self.kp_prompt_proj(kp_prompt)  # [B, D]
            
            # Add to target as bias (paper: "added to Semi-Autoregressive RoadNet Sequence")
            # Broadcast to all positions [B, M, L, D]
            B = tgt.shape[0]
            kp_global = kp_features.view(B, 1, 1, -1)  # [B, 1, 1, D]
            tgt = tgt + kp_global
        
        # Call parent forward
        return super().forward(tgt, memory, tgt_mask, memory_mask, 
                              query_embed, pos_embed, **kwargs)
