#!/usr/bin/env python
"""Analyze prediction distribution on a few samples."""

import argparse
import torch
import numpy as np
from mmengine.config import Config
from mmengine.runner import Runner
from collections import Counter


def analyze_single_batch(model, data_batch):
    """Analyze predictions for a single batch."""
    with torch.no_grad():
        outputs = model.val_step(data_batch)
    
    # Extract predictions
    line_results = outputs.get('predictions', outputs)
    img_metas = data_batch['data_samples']
    
    n_control = img_metas[0].get('n_control', 3)
    clause_length = 4 + (n_control - 2) * 2
    
    all_labels = []
    all_connects = []
    
    for result in line_results:
        seq = result['line_seqs']
        if isinstance(seq, torch.Tensor):
            seq = seq.cpu().numpy()
        
        num_clauses = len(seq) // clause_length
        for c in range(num_clauses):
            idx = c * clause_length
            if idx + 3 < len(seq):
                label = int(seq[idx + 2])
                connect = int(seq[idx + 3])
                if label not in [573, 574, 575]:
                    all_labels.append(label)
                if connect not in [573, 574, 575]:
                    all_connects.append(connect)
    
    return all_labels, all_connects


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('config', help='config file')
    parser.add_argument('checkpoint', help='checkpoint file')
    parser.add_argument('--samples', type=int, default=10, help='number of samples to analyze')
    args = parser.parse_args()
    
    # Load config and model
    cfg = Config.fromfile(args.config)
    runner = Runner.from_cfg(cfg)
    runner.load_checkpoint(args.checkpoint)
    model = runner.model
    model.eval()
    
    # Initialize statistics collection
    try:
        if hasattr(model, 'module'):
            head = model.module.pts_bbox_head
        else:
            head = model.pts_bbox_head
        head._pred_label_stats = []
        head._pred_connect_stats = []
        print("✅ Statistics collection initialized")
    except Exception as e:
        print(f"⚠️  Warning: Could not initialize statistics: {e}")
    
    # Get test dataloader
    test_dataloader = runner.test_dataloader
    
    print(f"\n{'='*80}")
    print(f"Analyzing {args.samples} batches...")
    print(f"{'='*80}\n")
    
    all_labels = []
    all_connects = []
    
    for i, data_batch in enumerate(test_dataloader):
        if i >= args.samples:
            break
        
        labels, connects = analyze_single_batch(model, data_batch)
        all_labels.extend(labels)
        all_connects.extend(connects)
        
        print(f"Batch {i+1}: {len(labels)} predictions")
    
    # Print statistics
    print(f"\n{'='*80}")
    print("📊 Overall Statistics")
    print(f"{'='*80}\n")
    
    label_counter = Counter(all_labels)
    print(f"Label Distribution (Total: {len(all_labels)}):")
    print("-" * 80)
    for token, count in label_counter.most_common(10):
        if 200 <= token < 250:
            cat = token - 200
            name = {0: 'start', 1: 'continue', 2: 'fork', 3: 'merge'}.get(cat, f'unk_{cat}')
            pct = count / len(all_labels) * 100
            print(f"  {name:12s} (token={token}): {count:6d} ({pct:5.2f}%)")
    
    connect_counter = Counter(all_connects)
    print(f"\nConnect Distribution (Total: {len(all_connects)}):")
    print("-" * 80)
    for token, count in connect_counter.most_common(10):
        if 250 <= token < 350:
            idx = token - 250
            pct = count / len(all_connects) * 100
            print(f"  connect={idx:3d} (token={token}): {count:6d} ({pct:5.2f}%)")
    
    # Collapse detection
    print(f"\n{'='*80}")
    print("🔍 Collapse Detection")
    print(f"{'='*80}")
    
    continue_count = label_counter.get(201, 0)
    continue_pct = continue_count / len(all_labels) * 100 if all_labels else 0
    
    connect0_count = connect_counter.get(250, 0)
    connect0_pct = connect0_count / len(all_connects) * 100 if all_connects else 0
    
    if continue_pct > 80:
        print(f"⚠️  WARNING: 'continue' dominates ({continue_pct:.1f}%)")
    if connect0_pct > 80:
        print(f"⚠️  WARNING: connect=0 dominates ({connect0_pct:.1f}%)")
    
    if continue_pct <= 80 and connect0_pct <= 80:
        print("✅ No obvious collapse detected")
    
    print(f"\n{'='*80}\n")


if __name__ == '__main__':
    main()
