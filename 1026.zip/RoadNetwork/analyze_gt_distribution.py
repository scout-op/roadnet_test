#!/usr/bin/env python3
"""
统计AR-RNTR GT数据分布，评估潜在问题的影响范围
分析内容：
1. 节点合并阈值（2.1m）的实际影响
2. Bezier重采样（<10点）的触发率
3. 起止索引顺序问题
4. 其他数据质量指标
"""

import os
import sys
import numpy as np
import pickle
import json
from collections import defaultdict, Counter
from pathlib import Path
import argparse
import random

# 不需要导入任何项目模块，直接实现统计逻辑即可


class GTDistributionAnalyzer:
    """GT数据分布分析器"""
    
    def __init__(self, data_root, version='v1.0-trainval'):
        self.data_root = Path(data_root)
        self.version = version
        self.reset_stats()
    
    def reset_stats(self):
        """重置统计信息"""
        # 节点合并相关
        self.node_merge_stats = {
            'total_samples': 0,
            'total_raw_nodes': 0,
            'total_merged_nodes': 0,
            'merge_distances': [],  # 记录所有被合并的节点对距离
            'samples_with_merge': 0,
            'suspicious_merges': [],  # 记录可疑合并（>1.5m）的详细信息
        }
        
        # Bezier重采样相关
        self.bezier_stats = {
            'total_edges': 0,
            'edges_lt_10_points': 0,
            'edge_point_counts': [],
            'min_points': float('inf'),
            'max_points': 0,
        }
        
        # 起止索引相关
        self.index_stats = {
            'total_centerlines': 0,
            'start_eq_end': 0,  # start == end
            'start_gt_end': 0,  # start > end (逆序)
            'empty_slices': 0,  # 切片为空
            'single_point': 0,  # 只有一个点
            'valid_slices': 0,
        }
        
        # 拓扑相关
        self.topology_stats = {
            'label_distribution': Counter(),
            'total_nodes': 0,
            'start_nodes': 0,
            'continue_nodes': 0,
            'fork_nodes': 0,
            'merge_nodes': 0,
        }
    
    def load_infos(self, split='train', info_prefix='nuscenes_centerline'):
        """加载预处理后的pkl文件"""
        # 尝试多种文件名格式
        possible_names = [
            f'{info_prefix}_infos_pon_{split}.pkl',  # 标准格式
            f'nuscenes_infos_{split}.pkl',  # 旧格式
            f'{info_prefix}_infos_{split}.pkl',  # 通用格式
        ]
        
        pkl_file = None
        for name in possible_names:
            candidate = self.data_root / name
            if candidate.exists():
                pkl_file = candidate
                break
        
        if pkl_file is None:
            print(f"❌ 文件不存在，尝试过的文件名:")
            for name in possible_names:
                print(f"   - {self.data_root / name}")
            return None
        
        print(f"📂 加载数据: {pkl_file}")
        with open(pkl_file, 'rb') as f:
            data = pickle.load(f)
        
        # 解析数据格式
        if isinstance(data, dict):
            if 'infos' in data:
                infos = data['infos']
                print(f"   格式: dict(infos=..., metadata=...)")
            elif 'data_list' in data:
                infos = data['data_list']
                print(f"   格式: dict(data_list=...)")
            else:
                print(f"⚠️ 未知字典格式，keys: {list(data.keys())}")
                return None
        elif isinstance(data, list):
            infos = data
            print(f"   格式: list")
        else:
            print(f"⚠️ 未知数据格式: {type(data)}")
            return None
        
        print(f"✅ 加载 {len(infos)} 个样本")
        return infos
    
    def analyze_node_merge(self, all_nodes_raw, sample_token=None, centerlines_info=None):
        """分析节点合并影响（模拟BzNode.__eq__逻辑）"""
        if len(all_nodes_raw) == 0:
            return 0, [], []
        
        merged_distances = []
        merged_count = 0
        suspicious_merges = []  # 存储可疑合并（>1.5m）
        threshold = 2.1
        suspicious_threshold = 1.5
        
        for i in range(len(all_nodes_raw)):
            for j in range(i + 1, len(all_nodes_raw)):
                pos_i = np.array(all_nodes_raw[i]['pos'])
                pos_j = np.array(all_nodes_raw[j]['pos'])
                dist = np.linalg.norm(pos_i - pos_j)
                
                if dist < threshold:
                    merged_distances.append(dist)
                    merged_count += 1
                    
                    # 记录可疑合并
                    if dist >= suspicious_threshold:
                        merge_info = {
                            'distance': float(dist),
                            'node_i': {
                                'pos': pos_i.tolist(),
                                'centerline_idx': all_nodes_raw[i].get('centerline_idx', -1),
                                'is_start': all_nodes_raw[i].get('is_start', None),
                                'type': all_nodes_raw[i].get('type', None),
                            },
                            'node_j': {
                                'pos': pos_j.tolist(),
                                'centerline_idx': all_nodes_raw[j].get('centerline_idx', -1),
                                'is_start': all_nodes_raw[j].get('is_start', None),
                                'type': all_nodes_raw[j].get('type', None),
                            },
                            'sample_token': sample_token,
                        }
                        
                        # 添加incoming/outgoing信息
                        if centerlines_info:
                            for idx in [i, j]:
                                cl_idx = all_nodes_raw[idx].get('centerline_idx', -1)
                                if 0 <= cl_idx < len(centerlines_info['types']):
                                    node_key = 'node_i' if idx == i else 'node_j'
                                    merge_info[node_key]['incoming_ids'] = centerlines_info.get('incoming_ids', [[]])[cl_idx]
                                    merge_info[node_key]['outgoing_ids'] = centerlines_info.get('outgoing_ids', [[]])[cl_idx]
                                    merge_info[node_key]['centerline_type'] = centerlines_info.get('types', [None])[cl_idx]
                        
                        suspicious_merges.append(merge_info)
        
        return merged_count, merged_distances, suspicious_merges
    
    def analyze_bezier_resampling(self, centerlines, start_idxs, end_idxs):
        """分析Bezier重采样触发情况"""
        edge_stats = []
        
        for i, centerline in enumerate(centerlines):
            if i >= len(start_idxs) or i >= len(end_idxs):
                continue
            
            start_idx = int(start_idxs[i])
            end_idx = int(end_idxs[i])
            
            # 获取实际点数
            if start_idx <= end_idx:
                n_points = end_idx - start_idx + 1
            else:
                n_points = 0  # 逆序
            
            edge_stats.append({
                'n_points': n_points,
                'start_idx': start_idx,
                'end_idx': end_idx,
                'centerline_len': len(centerline),
            })
        
        return edge_stats
    
    def analyze_index_order(self, centerlines, start_idxs, end_idxs):
        """分析起止索引顺序问题"""
        stats = {
            'start_eq_end': 0,
            'start_gt_end': 0,
            'empty_slices': 0,
            'single_point': 0,
            'valid_slices': 0,
        }
        
        for i in range(len(centerlines)):
            if i >= len(start_idxs) or i >= len(end_idxs):
                continue
            
            start_idx = int(start_idxs[i])
            end_idx = int(end_idxs[i])
            
            if start_idx == end_idx:
                stats['start_eq_end'] += 1
                stats['single_point'] += 1
            elif start_idx > end_idx:
                stats['start_gt_end'] += 1
                stats['empty_slices'] += 1
            else:
                n_points = end_idx - start_idx + 1
                if n_points == 1:
                    stats['single_point'] += 1
                else:
                    stats['valid_slices'] += 1
        
        return stats
    
    def analyze_sample(self, info):
        """分析单个样本"""
        if 'center_lines' not in info:
            return
        
        centerlines_data = info['center_lines']
        sample_token = info.get('token', 'unknown')
        
        # 1. 节点合并分析
        if 'centerlines' in centerlines_data:
            centerlines = centerlines_data['centerlines']
            types = centerlines_data.get('type', [])
            incoming_ids = centerlines_data.get('incoming_ids', [])
            outgoing_ids = centerlines_data.get('outgoing_ids', [])
            
            # 构建节点列表（模拟all_nodes_raw），带上下文信息
            all_nodes_raw = []
            for idx, cl in enumerate(centerlines):
                if len(cl) > 0:
                    # 起点
                    all_nodes_raw.append({
                        'pos': cl[0][:2],
                        'centerline_idx': idx,
                        'is_start': True,
                        'type': types[idx] if idx < len(types) else None,
                    })
                    # 终点
                    all_nodes_raw.append({
                        'pos': cl[-1][:2],
                        'centerline_idx': idx,
                        'is_start': False,
                        'type': types[idx] if idx < len(types) else None,
                    })
            
            centerlines_info = {
                'types': types,
                'incoming_ids': incoming_ids,
                'outgoing_ids': outgoing_ids,
            }
            
            merge_count, merge_dists, suspicious = self.analyze_node_merge(
                all_nodes_raw, sample_token, centerlines_info
            )
            
            self.node_merge_stats['total_samples'] += 1
            self.node_merge_stats['total_raw_nodes'] += len(all_nodes_raw)
            self.node_merge_stats['total_merged_nodes'] += merge_count
            self.node_merge_stats['merge_distances'].extend(merge_dists)
            self.node_merge_stats['suspicious_merges'].extend(suspicious)
            if merge_count > 0:
                self.node_merge_stats['samples_with_merge'] += 1
        
        # 2. Bezier重采样分析
        if all(k in centerlines_data for k in ['centerlines', 'start_point_idxs', 'end_point_idxs']):
            centerlines = centerlines_data['centerlines']
            start_idxs = centerlines_data['start_point_idxs']
            end_idxs = centerlines_data['end_point_idxs']
            
            edge_stats = self.analyze_bezier_resampling(centerlines, start_idxs, end_idxs)
            
            for stat in edge_stats:
                n_points = stat['n_points']
                if n_points > 0:
                    self.bezier_stats['total_edges'] += 1
                    self.bezier_stats['edge_point_counts'].append(n_points)
                    
                    if n_points < 10:
                        self.bezier_stats['edges_lt_10_points'] += 1
                    
                    self.bezier_stats['min_points'] = min(self.bezier_stats['min_points'], n_points)
                    self.bezier_stats['max_points'] = max(self.bezier_stats['max_points'], n_points)
        
        # 3. 起止索引顺序分析
        if all(k in centerlines_data for k in ['centerlines', 'start_point_idxs', 'end_point_idxs']):
            idx_stats = self.analyze_index_order(
                centerlines_data['centerlines'],
                centerlines_data['start_point_idxs'],
                centerlines_data['end_point_idxs']
            )
            
            self.index_stats['total_centerlines'] += len(centerlines_data['centerlines'])
            for key in idx_stats:
                self.index_stats[key] += idx_stats[key]
    
    def run_analysis(self, split='train', info_prefix='nuscenes_centerline', export_samples=100):
        """运行完整分析"""
        print("\n" + "="*80)
        print(f"AR-RNTR GT 数据分布分析 - {split.upper()} 集")
        print("="*80)
        
        infos = self.load_infos(split, info_prefix)
        if infos is None:
            return
        
        print(f"\n⏳ 分析中...")
        for idx, info in enumerate(infos):
            self.analyze_sample(info)
            if (idx + 1) % 1000 == 0:
                print(f"  已处理: {idx + 1}/{len(infos)}")
        
        print(f"✅ 分析完成\n")
        self.print_report()
        
        # 导出可疑合并样本
        self.export_suspicious_merges(max_samples=export_samples)
    
    def print_report(self):
        """打印分析报告"""
        print("\n" + "="*80)
        print("📊 分析报告")
        print("="*80)
        
        # 1. 节点合并影响
        print("\n【1】节点合并阈值（2.1m）影响分析")
        print("-" * 80)
        
        total_samples = self.node_merge_stats['total_samples']
        total_raw = self.node_merge_stats['total_raw_nodes']
        total_merged = self.node_merge_stats['total_merged_nodes']
        samples_with_merge = self.node_merge_stats['samples_with_merge']
        
        print(f"总样本数: {total_samples}")
        print(f"总原始节点数: {total_raw}")
        print(f"被合并的节点对数: {total_merged}")
        print(f"有节点合并的样本数: {samples_with_merge} ({100*samples_with_merge/max(1,total_samples):.2f}%)")
        
        if total_merged > 0:
            merge_dists = self.node_merge_stats['merge_distances']
            print(f"\n合并距离统计:")
            print(f"  最小距离: {np.min(merge_dists):.3f}m")
            print(f"  平均距离: {np.mean(merge_dists):.3f}m")
            print(f"  中位数: {np.median(merge_dists):.3f}m")
            print(f"  最大距离: {np.max(merge_dists):.3f}m")
            
            # 距离分布
            bins = [0, 0.5, 1.0, 1.5, 2.0, 2.1]
            hist, _ = np.histogram(merge_dists, bins=bins)
            print(f"\n距离分布:")
            for i in range(len(bins)-1):
                pct = 100 * hist[i] / len(merge_dists)
                print(f"  [{bins[i]:.1f}m - {bins[i+1]:.1f}m): {hist[i]} ({pct:.1f}%)")
            
            merge_rate = total_merged / max(1, total_raw) * 100
            print(f"\n⚠️  节点合并率: {merge_rate:.2f}%")
            if merge_rate > 5:
                print(f"   → 高风险！超过5%的节点对被合并，显著影响拓扑")
            elif merge_rate > 1:
                print(f"   → 中风险：1-5%的节点对被合并，可能影响精度")
            else:
                print(f"   → 低风险：<1%的节点对被合并，影响较小")
        else:
            print("✅ 未发现节点合并（可能数据本身节点间距都>2.1m）")
        
        # 2. Bezier重采样影响
        print("\n\n【2】Bezier重采样（<10点触发直线插值）影响分析")
        print("-" * 80)
        
        total_edges = self.bezier_stats['total_edges']
        lt_10 = self.bezier_stats['edges_lt_10_points']
        
        print(f"总边数: {total_edges}")
        print(f"<10点的边数: {lt_10} ({100*lt_10/max(1,total_edges):.2f}%)")
        
        if total_edges > 0:
            point_counts = self.bezier_stats['edge_point_counts']
            print(f"\n边点数统计:")
            print(f"  最小点数: {self.bezier_stats['min_points']}")
            print(f"  平均点数: {np.mean(point_counts):.1f}")
            print(f"  中位数: {np.median(point_counts):.0f}")
            print(f"  最大点数: {self.bezier_stats['max_points']}")
            
            # 分布
            bins = [0, 5, 10, 20, 50, 100, 500]
            hist, _ = np.histogram(point_counts, bins=bins)
            print(f"\n点数分布:")
            for i in range(len(bins)-1):
                pct = 100 * hist[i] / len(point_counts)
                print(f"  [{bins[i]}-{bins[i+1]}): {hist[i]} ({pct:.1f}%)")
            
            trigger_rate = lt_10 / total_edges * 100
            print(f"\n⚠️  重采样触发率: {trigger_rate:.2f}%")
            if trigger_rate > 25:
                print(f"   → 高风险！>25%的边触发直线插值，曲率学习严重失真")
            elif trigger_rate > 10:
                print(f"   → 中风险：10-25%的边触发，影响系数槽学习")
            elif trigger_rate > 0:
                print(f"   → 低风险：<10%的边触发，影响有限")
            else:
                print(f"   → 无风险：所有边都>=10点")
        
        # 3. 起止索引顺序问题
        print("\n\n【3】起止索引顺序问题分析")
        print("-" * 80)
        
        total_cl = self.index_stats['total_centerlines']
        start_eq_end = self.index_stats['start_eq_end']
        start_gt_end = self.index_stats['start_gt_end']
        empty = self.index_stats['empty_slices']
        single = self.index_stats['single_point']
        valid = self.index_stats['valid_slices']
        
        print(f"总中心线数: {total_cl}")
        print(f"start == end (单点): {start_eq_end} ({100*start_eq_end/max(1,total_cl):.2f}%)")
        print(f"start > end (逆序): {start_gt_end} ({100*start_gt_end/max(1,total_cl):.2f}%)")
        print(f"空切片: {empty} ({100*empty/max(1,total_cl):.2f}%)")
        print(f"有效切片: {valid} ({100*valid/max(1,total_cl):.2f}%)")
        
        if start_gt_end > 0:
            print(f"\n❌ 致命问题：发现 {start_gt_end} 个逆序索引！")
            print(f"   → 会导致空切片，get_bezier_coeff()失败")
            print(f"   → 必须修复：添加 assert 或交换逻辑")
        elif start_eq_end > 0:
            print(f"\n⚠️  发现 {start_eq_end} 个单点边")
            print(f"   → 可能导致Bezier拟合退化")
            print(f"   → 建议：过滤或延伸至至少2点")
        else:
            print(f"\n✅ 所有索引顺序正常")
        
        # 总结
        print("\n\n" + "="*80)
        print("📋 优先级建议")
        print("="*80)
        
        issues = []
        
        if start_gt_end > 0:
            issues.append(("P0 - 致命", f"逆序索引: {start_gt_end}个，必须立即修复"))
        
        merge_rate = self.node_merge_stats['total_merged_nodes'] / max(1, self.node_merge_stats['total_raw_nodes']) * 100
        if merge_rate > 5:
            issues.append(("P0 - 高风险", f"节点合并率 {merge_rate:.1f}%，显著改变拓扑"))
        elif merge_rate > 1:
            issues.append(("P1 - 中风险", f"节点合并率 {merge_rate:.1f}%，建议调整阈值"))
        
        trigger_rate = lt_10 / max(1, total_edges) * 100
        if trigger_rate > 25:
            issues.append(("P0 - 高风险", f"Bezier重采样触发率 {trigger_rate:.1f}%，严重失真"))
        elif trigger_rate > 10:
            issues.append(("P1 - 中风险", f"Bezier重采样触发率 {trigger_rate:.1f}%，建议改进"))
        
        if start_eq_end > 0:
            issues.append(("P1 - 中风险", f"单点边 {start_eq_end}个，影响拟合质量"))
        
        if not issues:
            print("✅ 未发现高优先级问题")
        else:
            for idx, (priority, desc) in enumerate(issues, 1):
                print(f"{idx}. [{priority}] {desc}")
        
        print("\n" + "="*80)


    def export_suspicious_merges(self, max_samples=100):
        """导出可疑合并节点对供人工检查"""
        suspicious = self.node_merge_stats['suspicious_merges']
        
        if len(suspicious) == 0:
            return
        
        output_file = self.data_root / 'suspicious_node_merges.json'
        
        # 随机抽样
        if len(suspicious) > max_samples:
            sampled = random.sample(suspicious, max_samples)
            print(f"\n📝 从 {len(suspicious)} 个可疑合并中随机抽样 {max_samples} 个")
        else:
            sampled = suspicious
            print(f"\n📝 导出全部 {len(suspicious)} 个可疑合并")
        
        # 按距离排序
        sampled_sorted = sorted(sampled, key=lambda x: x['distance'], reverse=True)
        
        export_data = {
            'total_suspicious': len(suspicious),
            'exported_count': len(sampled_sorted),
            'distance_threshold': 1.5,
            'samples': sampled_sorted,
            'annotation_guide': {
                'should_merge': '这两个节点应该合并（例如：同一个交叉点）',
                'should_not_merge': '这两个节点不应该合并（独立的节点）',
                'uncertain': '不确定',
            }
        }
        
        with open(output_file, 'w') as f:
            json.dump(export_data, f, indent=2)
        
        print(f"✅ 已导出到: {output_file}")
        print(f"\n使用方法：")
        print(f"  1. 打开 {output_file}")
        print(f"  2. 查看每对节点的坐标、距离、centerline类型、incoming/outgoing信息")
        print(f"  3. 根据上下文判断是否应该合并")
        print(f"  4. 统计'应该合并'和'不应该合并'的比例")
        print(f"\n快速检查提示：")
        print(f"  - 如果两个节点来自同一条centerline的起终点 → 可能是环路，看incoming/outgoing")
        print(f"  - 如果两个节点来自不同centerline且有共同的incoming/outgoing → 很可能应该合并")
        print(f"  - 如果距离>2.0m → 很可能不应该合并")

def main():
    parser = argparse.ArgumentParser(description='分析AR-RNTR GT数据分布')
    parser.add_argument('--data-root', type=str, 
                       default='./data/nuscenes',
                       help='nuScenes数据根目录')
    parser.add_argument('--split', type=str, default='train',
                       choices=['train', 'val'],
                       help='分析训练集或验证集')
    parser.add_argument('--version', type=str, default='v1.0-trainval',
                       help='nuScenes版本')
    parser.add_argument('--info-prefix', type=str, default='nuscenes_centerline',
                       help='pkl文件前缀（默认: nuscenes_centerline）')
    parser.add_argument('--export-samples', type=int, default=100,
                       help='导出可疑合并的样本数量（默认: 100）')
    
    args = parser.parse_args()
    
    analyzer = GTDistributionAnalyzer(args.data_root, args.version)
    analyzer.run_analysis(args.split, args.info_prefix, args.export_samples)


if __name__ == '__main__':
    main()
