"""
快速检查训练数据中各节点类型的分布
"""
import numpy as np
from collections import Counter

# 从训练日志中提取的样本
# Step 4: Sample 0
# inputs_cls_i: numel=179, unique=[200, 201, 202, 203, 570]

# 假设你有训练数据，统计GT label分布
def analyze_label_distribution():
    """
    分析训练数据中各节点类型的分布
    需要在实际训练时添加统计代码
    """
    
    print("="*80)
    print("需要添加以下代码到 ar_rntr.py 的训练循环中：")
    print("="*80)
    
    code = '''
# 在 simple_test_pts_train 或 loss 函数中添加：
if self._is_main_process() and epoch == 1 and batch_idx == 0:
    # 统计GT label分布
    all_gt_labels = []
    for bi in range(len(gt_lines_labels)):
        labels = gt_lines_labels[bi]  # 原始label [0,1,2,3]
        all_gt_labels.extend(labels)
    
    from collections import Counter
    label_counts = Counter(all_gt_labels)
    total = sum(label_counts.values())
    
    print("\\n" + "="*80)
    print("[LABEL DISTRIBUTION] GT Training Data Statistics")
    print("="*80)
    print(f"Total nodes: {total}")
    for lbl in [0, 1, 2, 3]:
        count = label_counts.get(lbl, 0)
        pct = 100.0 * count / total if total > 0 else 0
        label_name = ["Ancestor", "Lineal", "Offshoot", "Clone"][lbl]
        print(f"  {label_name:10s} (label={lbl}): {count:6d} ({pct:5.1f}%)")
    print("="*80 + "\\n")
'''
    
    print(code)
    print()
    print("="*80)
    print("临时解决方案：检查推理时的预测分布")
    print("="*80)
    
    # 从你的日志
    samples = [
        {"Ancestor": 28, "Lineal": 4, "Offshoot": 0, "Clone": 168},
        {"Ancestor": 27, "Lineal": 5, "Offshoot": 0, "Clone": 169},
        {"Ancestor": 25, "Lineal": 6, "Offshoot": 0, "Clone": 169},
        {"Ancestor": 21, "Lineal": 7, "Offshoot": 0, "Clone": 172},
        {"Ancestor": 22, "Lineal": 7, "Offshoot": 0, "Clone": 171},
    ]
    
    total_nodes = 0
    total_counts = {"Ancestor": 0, "Lineal": 0, "Offshoot": 0, "Clone": 0}
    
    for sample in samples:
        for key in total_counts:
            total_counts[key] += sample[key]
        total_nodes += sum(sample.values())
    
    print(f"Inference prediction statistics (5 samples, 200 nodes each):")
    print(f"Total nodes: {total_nodes}")
    for label_name in ["Ancestor", "Lineal", "Offshoot", "Clone"]:
        count = total_counts[label_name]
        pct = 100.0 * count / total_nodes
        print(f"  {label_name:10s}: {count:4d} ({pct:5.1f}%)")
    
    print()
    print("⚠️ 分析：Clone占83.8%，Offshoot占0%，这是严重不正常的！")
    print()
    print("可能原因：")
    print("1. 训练数据中Clone本身就占多数（需要验证GT分布）")
    print("2. 模型过拟合到Clone类别（loss_labels虽小但分布崩溃）")
    print("3. 推理约束或采样策略导致偏向Clone")

if __name__ == "__main__":
    analyze_label_distribution()
