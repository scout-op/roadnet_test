#!/usr/bin/env python3
"""
自动分析可疑节点合并的JSON文件
基于启发式规则判断哪些合并是合理的，哪些是错误的
"""

import json
import argparse
from pathlib import Path
from collections import Counter


class SuspiciousMergeAnalyzer:
    """可疑合并分析器"""
    
    def __init__(self, json_path):
        self.json_path = Path(json_path)
        self.data = None
        self.results = []
    
    def load_data(self):
        """加载JSON文件"""
        with open(self.json_path, 'r') as f:
            self.data = json.load(f)
        print(f"✅ 加载 {len(self.data['samples'])} 个可疑合并样本")
    
    def has_common_connection(self, node_i, node_j):
        """判断两个节点是否有共同的incoming或outgoing连接"""
        incoming_i = set(node_i.get('incoming_ids', []))
        incoming_j = set(node_j.get('incoming_ids', []))
        outgoing_i = set(node_i.get('outgoing_ids', []))
        outgoing_j = set(node_j.get('outgoing_ids', []))
        
        common_incoming = incoming_i & incoming_j
        common_outgoing = outgoing_i & outgoing_j
        
        # 检查交叉连接：i的outgoing是j的incoming，或反之
        cross_connection = (
            (incoming_i & outgoing_j) or 
            (incoming_j & outgoing_i)
        )
        
        return {
            'common_incoming': list(common_incoming),
            'common_outgoing': list(common_outgoing),
            'cross_connection': bool(cross_connection),
            'has_any_common': bool(common_incoming or common_outgoing or cross_connection)
        }
    
    def analyze_sample(self, sample):
        """分析单个样本，判断是否应该合并"""
        distance = sample['distance']
        node_i = sample['node_i']
        node_j = sample['node_j']
        
        # 基本信息
        same_centerline = (node_i['centerline_idx'] == node_j['centerline_idx'])
        same_type = (node_i.get('centerline_type') == node_j.get('centerline_type'))
        both_start = (node_i.get('is_start') and node_j.get('is_start'))
        both_end = (not node_i.get('is_start') and not node_j.get('is_start'))
        one_start_one_end = (
            (node_i.get('is_start') and not node_j.get('is_start')) or
            (not node_i.get('is_start') and node_j.get('is_start'))
        )
        
        # 连接关系
        connection_info = self.has_common_connection(node_i, node_j)
        
        # 决策规则
        decision = "uncertain"
        confidence = 0.5
        reason = []
        
        # 规则1：同一条centerline的起点和终点
        if same_centerline and one_start_one_end:
            if distance < 1.0:
                decision = "should_merge"
                confidence = 0.6
                reason.append(f"同一centerline的起终点，距离{distance:.2f}m<1.0m，可能是环路或短lane")
            else:
                decision = "should_not_merge"
                confidence = 0.8
                reason.append(f"同一centerline的起终点，但距离{distance:.2f}m>=1.0m，应该是独立的长lane")
        
        # 规则2：不同centerline但有共同incoming/outgoing
        elif not same_centerline and connection_info['has_any_common']:
            if connection_info['common_incoming'] and connection_info['common_outgoing']:
                decision = "should_merge"
                confidence = 0.9
                reason.append(f"不同centerline但有共同incoming和outgoing，很可能是同一交叉点")
                reason.append(f"  共同incoming: {connection_info['common_incoming'][:2]}")
                reason.append(f"  共同outgoing: {connection_info['common_outgoing'][:2]}")
            elif connection_info['common_incoming']:
                decision = "should_merge"
                confidence = 0.75
                reason.append(f"不同centerline但有共同incoming，可能是同一汇入点")
            elif connection_info['common_outgoing']:
                decision = "should_merge"
                confidence = 0.75
                reason.append(f"不同centerline但有共同outgoing，可能是同一分叉点")
            elif connection_info['cross_connection']:
                decision = "should_merge"
                confidence = 0.7
                reason.append(f"存在交叉连接，可能是同一连接点")
        
        # 规则3：距离>2.0m且无共同连接
        elif distance > 2.0 and not connection_info['has_any_common']:
            decision = "should_not_merge"
            confidence = 0.95
            reason.append(f"距离{distance:.2f}m>2.0m且无共同连接，应该是独立节点")
        
        # 规则4：距离1.5-2.0m且无共同连接
        elif 1.5 <= distance <= 2.0 and not connection_info['has_any_common']:
            decision = "should_not_merge"
            confidence = 0.8
            reason.append(f"距离{distance:.2f}m在1.5-2.0m且无共同连接，很可能是独立节点")
        
        # 规则5：不同类型(lane vs lane_connector)且无共同连接
        elif not same_type and not connection_info['has_any_common']:
            decision = "should_not_merge"
            confidence = 0.7
            reason.append(f"不同类型({node_i.get('centerline_type')} vs {node_j.get('centerline_type')})且无共同连接")
        
        # 规则6：兜底规则
        else:
            if distance < 1.8:
                decision = "uncertain"
                confidence = 0.5
                reason.append(f"距离{distance:.2f}m，无明确规则匹配，不确定")
            else:
                decision = "should_not_merge"
                confidence = 0.6
                reason.append(f"距离{distance:.2f}m>=1.8m，倾向于不合并")
        
        return {
            'sample': sample,
            'decision': decision,
            'confidence': confidence,
            'reason': reason,
            'metadata': {
                'same_centerline': same_centerline,
                'same_type': same_type,
                'has_common_connection': connection_info['has_any_common'],
                'distance': distance,
            }
        }
    
    def analyze_all(self):
        """分析所有样本"""
        print("\n⏳ 分析中...")
        for sample in self.data['samples']:
            result = self.analyze_sample(sample)
            self.results.append(result)
        print("✅ 分析完成\n")
    
    def print_report(self):
        """打印分析报告"""
        print("="*80)
        print("📊 自动分析报告")
        print("="*80)
        
        # 统计决策分布
        decision_counts = Counter(r['decision'] for r in self.results)
        total = len(self.results)
        
        print(f"\n样本总数: {total}")
        print(f"  应该合并 (should_merge): {decision_counts['should_merge']} ({100*decision_counts['should_merge']/total:.1f}%)")
        print(f"  不应该合并 (should_not_merge): {decision_counts['should_not_merge']} ({100*decision_counts['should_not_merge']/total:.1f}%)")
        print(f"  不确定 (uncertain): {decision_counts['uncertain']} ({100*decision_counts['uncertain']/total:.1f}%)")
        
        # 置信度统计
        avg_confidence = sum(r['confidence'] for r in self.results) / total
        high_confidence = sum(1 for r in self.results if r['confidence'] >= 0.8)
        
        print(f"\n平均置信度: {avg_confidence:.2f}")
        print(f"高置信度(>=0.8)样本: {high_confidence} ({100*high_confidence/total:.1f}%)")
        
        # 推断总体情况
        total_suspicious = self.data['total_suspicious']
        estimated_wrong_merges = int(total_suspicious * decision_counts['should_not_merge'] / total)
        
        print("\n" + "="*80)
        print("📈 推断总体影响")
        print("="*80)
        print(f"可疑合并总数(距离>1.5m): {total_suspicious}")
        print(f"抽样分析: {total}个样本")
        print(f"推断错误合并数: {estimated_wrong_merges} ({100*decision_counts['should_not_merge']/total:.1f}%)")
        
        # 从原始报告推断全局影响
        print(f"\n如果全局节点数为1,843,694:")
        print(f"  错误合并影响的节点: {estimated_wrong_merges}")
        print(f"  占比: {100*estimated_wrong_merges/1843694:.2f}%")
        
        if decision_counts['should_not_merge'] / total > 0.5:
            print(f"\n⚠️  结论：超过50%的可疑合并是错误的，建议修复合并阈值逻辑")
        elif decision_counts['should_not_merge'] / total > 0.3:
            print(f"\n⚠️  结论：30-50%的可疑合并是错误的，建议考虑修复")
        else:
            print(f"\n✅ 结论：<30%的可疑合并是错误的，影响相对有限")
    
    def print_detailed_samples(self, n=10, decision_filter=None):
        """打印详细样本（用于验证规则）"""
        print("\n" + "="*80)
        print(f"📋 详细样本展示 (前{n}个)")
        print("="*80)
        
        filtered = self.results
        if decision_filter:
            filtered = [r for r in self.results if r['decision'] == decision_filter]
        
        for i, result in enumerate(filtered[:n]):
            sample = result['sample']
            print(f"\n【样本 {i+1}】")
            print(f"距离: {sample['distance']:.3f}m")
            print(f"决策: {result['decision']} (置信度: {result['confidence']:.2f})")
            print(f"原因: {result['reason'][0] if result['reason'] else 'N/A'}")
            
            node_i = sample['node_i']
            node_j = sample['node_j']
            print(f"节点i: centerline_{node_i['centerline_idx']}, {'起点' if node_i['is_start'] else '终点'}, {node_i.get('centerline_type')}")
            print(f"       incoming: {node_i.get('incoming_ids', [])[:2]}")
            print(f"       outgoing: {node_i.get('outgoing_ids', [])[:2]}")
            print(f"节点j: centerline_{node_j['centerline_idx']}, {'起点' if node_j['is_start'] else '终点'}, {node_j.get('centerline_type')}")
            print(f"       incoming: {node_j.get('incoming_ids', [])[:2]}")
            print(f"       outgoing: {node_j.get('outgoing_ids', [])[:2]}")
    
    def export_results(self, output_path=None):
        """导出分析结果"""
        if output_path is None:
            output_path = self.json_path.parent / 'suspicious_merges_analysis_result.json'
        
        export_data = {
            'source_file': str(self.json_path),
            'total_samples': len(self.results),
            'decision_summary': dict(Counter(r['decision'] for r in self.results)),
            'results': self.results
        }
        
        with open(output_path, 'w') as f:
            json.dump(export_data, f, indent=2)
        
        print(f"\n💾 分析结果已保存到: {output_path}")
    
    def run(self, show_samples=10, export=True):
        """运行完整分析流程"""
        self.load_data()
        self.analyze_all()
        self.print_report()
        
        if show_samples > 0:
            print("\n" + "="*80)
            print("【不应该合并】的样本示例:")
            self.print_detailed_samples(n=show_samples, decision_filter='should_not_merge')
            
            print("\n" + "="*80)
            print("【应该合并】的样本示例:")
            self.print_detailed_samples(n=min(5, show_samples), decision_filter='should_merge')
        
        if export:
            self.export_results()


def main():
    parser = argparse.ArgumentParser(description='分析可疑节点合并JSON文件')
    parser.add_argument('--json-path', type=str,
                       default='./data/nuscenes/suspicious_node_merges.json',
                       help='可疑合并JSON文件路径')
    parser.add_argument('--show-samples', type=int, default=10,
                       help='显示详细样本数量')
    parser.add_argument('--no-export', action='store_true',
                       help='不导出分析结果')
    
    args = parser.parse_args()
    
    analyzer = SuspiciousMergeAnalyzer(args.json_path)
    analyzer.run(show_samples=args.show_samples, export=not args.no_export)


if __name__ == '__main__':
    main()
