#!/usr/bin/env python3
"""
Quick test: Load config to see detailed error messages
"""

import sys
import os

# Go to mmdetection3d root
os.chdir('/data/roadnet_data/new_code/mmdetection3d')
sys.path.insert(0, '/data/roadnet_data/new_code/mmdetection3d')

print("Loading config...")
print("="*60)

# Try to load the config
try:
    from mmengine.config import Config
    cfg = Config.fromfile('./projects/RoadNetwork/configs/sar_rntr_2d/sar_rntr_2d_paper_aligned.py')
    print("\n" + "="*60)
    print("✅ Config loaded successfully!")
    print("="*60)
except Exception as e:
    print("\n" + "="*60)
    print("❌ Config loading failed!")
    print("="*60)
    import traceback
    traceback.print_exc()
    sys.exit(1)
