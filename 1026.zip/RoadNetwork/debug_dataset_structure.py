#!/usr/bin/env python3
"""
数据集结构调试脚本
随机抽样几个样本，查看实际的数据结构
"""

import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

import numpy as np
import random
from mmengine.config import Config
from mmengine.registry import init_default_scope
from mmdet3d.registry import DATASETS


def inspect_sample(sample, sample_idx):
    """详细检查单个样本的结构"""
    print(f"\n{'='*80}")
    print(f"📦 样本 #{sample_idx}")
    print(f"{'='*80}")
    
    print(f"\n🔑 顶层键（Top-level keys）:")
    if isinstance(sample, dict):
        for key in sample.keys():
            value = sample[key]
            value_type = type(value).__name__
            
            if isinstance(value, (list, tuple)):
                print(f"  - {key}: {value_type} (长度: {len(value)})")
            elif isinstance(value, np.ndarray):
                print(f"  - {key}: {value_type} (shape: {value.shape}, dtype: {value.dtype})")
            elif isinstance(value, dict):
                print(f"  - {key}: {value_type} (子键: {list(value.keys())[:5]}...)")
            else:
                print(f"  - {key}: {value_type}")
    else:
        print(f"  ⚠️  样本不是字典类型，是: {type(sample)}")
        return
    
    # ==================== 重点检查 data_samples ====================
    if 'data_samples' in sample:
        print(f"\n🔍 深入检查 'data_samples' 对象:")
        data_samples = sample['data_samples']
        print(f"  类型: {type(data_samples)}")
        print(f"  模块: {type(data_samples).__module__}")
        
        # 检查对象的属性
        print(f"\n  📋 对象属性:")
        attrs = [attr for attr in dir(data_samples) if not attr.startswith('_')]
        for attr in attrs[:20]:  # 只显示前20个
            try:
                value = getattr(data_samples, attr)
                if not callable(value):
                    print(f"    - {attr}: {type(value).__name__}")
            except:
                pass
        
        # 尝试常见的属性
        print(f"\n  🔍 尝试访问常见属性:")
        for attr_name in ['gt_instances', 'gt_labels', 'metainfo', 'gt_pts_seg', 'data', 'keys']:
            if hasattr(data_samples, attr_name):
                try:
                    value = getattr(data_samples, attr_name)
                    print(f"    ✅ {attr_name}: {type(value)}")
                    if isinstance(value, dict):
                        print(f"       键: {list(value.keys())}")
                    elif hasattr(value, '__dict__'):
                        print(f"       属性: {list(value.__dict__.keys())[:10]}")
                except Exception as e:
                    print(f"    ⚠️  {attr_name}: 访问失败 - {e}")
            else:
                print(f"    ❌ {attr_name}: 不存在")
        
        # 检查是否有 to_dict 或类似方法
        print(f"\n  🔍 检查序列化方法:")
        for method_name in ['to_dict', 'keys', 'items', 'values']:
            if hasattr(data_samples, method_name):
                print(f"    ✅ 有 {method_name}() 方法")
                if method_name == 'keys':
                    try:
                        keys = data_samples.keys()
                        print(f"       键列表: {list(keys)}")
                    except:
                        pass
            else:
                print(f"    ❌ 无 {method_name}() 方法")
    
    # 检查centerline相关的键
    print(f"\n🔍 查找 'centerline' 相关的键:")
    centerline_keys = [k for k in sample.keys() if 'centerline' in k.lower() or 'center' in k.lower()]
    if centerline_keys:
        for key in centerline_keys:
            value = sample[key]
            print(f"\n  ✅ 发现: {key}")
            print(f"     类型: {type(value)}")
            if isinstance(value, np.ndarray):
                print(f"     Shape: {value.shape}")
                print(f"     Dtype: {value.dtype}")
                if value.size > 0 and value.size <= 20:
                    print(f"     内容: {value}")
                elif value.size > 0:
                    print(f"     前5个: {value.flatten()[:5]}")
            elif isinstance(value, (list, tuple)):
                print(f"     长度: {len(value)}")
                if len(value) > 0 and len(value) <= 5:
                    print(f"     内容: {value}")
            elif isinstance(value, dict):
                print(f"     子键: {list(value.keys())}")
    else:
        print(f"  ❌ 未发现包含 'centerline' 或 'center' 的键")
    
    # 检查是否有label、connect等
    print(f"\n🔍 查找 'label', 'connect', 'coord' 相关的键:")
    related_keys = [k for k in sample.keys() if any(x in k.lower() for x in ['label', 'connect', 'coord', 'coeff'])]
    if related_keys:
        for key in related_keys:
            value = sample[key]
            print(f"  - {key}: {type(value)}, ", end='')
            if isinstance(value, np.ndarray):
                print(f"shape={value.shape}")
            elif isinstance(value, (list, tuple)):
                print(f"len={len(value)}")
            else:
                print(f"value={value}")
    else:
        print(f"  ❌ 未发现相关键")
    
    # 特别检查center_lines字段（原始数据）
    if 'center_lines' in sample:
        print(f"\n🔍 详细检查 'center_lines' 字段:")
        center_lines = sample['center_lines']
        print(f"  类型: {type(center_lines)}")
        if isinstance(center_lines, dict):
            print(f"  子键: {list(center_lines.keys())}")
            for k, v in center_lines.items():
                print(f"    - {k}: {type(v)}, ", end='')
                if isinstance(v, (list, tuple)):
                    print(f"len={len(v)}")
                elif isinstance(v, np.ndarray):
                    print(f"shape={v.shape}")
                else:
                    print(f"value={v}")
        elif hasattr(center_lines, '__dict__'):
            print(f"  属性: {dir(center_lines)}")


def test_data_extraction(sample, sample_idx):
    """测试数据提取逻辑（模拟主脚本的提取方式）"""
    print(f"\n{'='*80}")
    print(f"🧪 测试样本 #{sample_idx} 的数据提取")
    print(f"{'='*80}")
    
    try:
        # ==================== 按主脚本逻辑提取数据 ====================
        if 'data_samples' not in sample:
            print("❌ 样本中没有 'data_samples' 键")
            return False
        
        data_samples = sample['data_samples']
        print(f"✅ 获取 data_samples 对象: {type(data_samples)}")
        
        # 检查必需属性
        if not hasattr(data_samples, 'centerline_label'):
            print("❌ data_samples 没有 'centerline_label' 属性")
            return False
        
        print(f"✅ 找到 centerline_label 属性")
        
        # 提取数据
        labels = np.array(data_samples.centerline_label)
        connects = np.array(data_samples.centerline_connect)
        coords = np.array(data_samples.centerline_coord) if hasattr(data_samples, 'centerline_coord') else None
        
        print(f"\n📊 提取的数据:")
        print(f"  - labels: shape={labels.shape}, dtype={labels.dtype}")
        print(f"    前10个: {labels[:10].tolist()}")
        print(f"  - connects: shape={connects.shape}, dtype={connects.dtype}")
        print(f"    前10个: {connects[:10].tolist()}")
        if coords is not None:
            print(f"  - coords: shape={coords.shape}, dtype={coords.dtype}")
            print(f"    前3个: {coords[:3].tolist()}")
        
        # 验证数据有效性
        if len(labels) == 0 or len(connects) == 0:
            print("❌ 数据为空")
            return False
        
        print(f"\n✅ 数据验证通过！")
        print(f"  总节点数: {len(labels)}")
        
        # 统计节点类型
        unique, counts = np.unique(labels, return_counts=True)
        print(f"\n  节点类型分布:")
        type_names = {0: 'Ancestor', 1: 'Lineal', 2: 'Offshoot', 3: 'Clone'}
        for label_val, count in zip(unique, counts):
            type_name = type_names.get(int(label_val), f'Unknown({label_val})')
            print(f"    {type_name}: {count} ({count/len(labels)*100:.1f}%)")
        
        # 检查Lineal连接模式
        lineal_indices = np.where(labels == 1)[0]
        if len(lineal_indices) > 0:
            print(f"\n  Lineal节点连接分析:")
            lineal_to_prev = 0
            lineal_skip = 0
            lineal_invalid = 0
            
            for i in lineal_indices:
                if i == 0:
                    continue
                conn = connects[i]
                if conn == i - 1:
                    lineal_to_prev += 1
                elif conn < i - 1:
                    lineal_skip += 1
                else:
                    lineal_invalid += 1
            
            total_lineal = len(lineal_indices)
            if total_lineal > 0:
                print(f"    总Lineal节点: {total_lineal}")
                print(f"    连接到i-1: {lineal_to_prev} ({lineal_to_prev/total_lineal*100:.1f}%)")
                print(f"    跨节点连接: {lineal_skip} ({lineal_skip/total_lineal*100:.1f}%)")
                print(f"    无效连接: {lineal_invalid} ({lineal_invalid/total_lineal*100:.1f}%)")
        
        # 提取Bezier系数
        if hasattr(data_samples, 'centerline_coeff'):
            coeffs = np.array(data_samples.centerline_coeff)
            print(f"\n  Bezier系数:")
            print(f"    shape: {coeffs.shape}")
            print(f"    范围: [{coeffs.min():.1f}, {coeffs.max():.1f}]")
        
        # 提取token
        token = 'unknown'
        if hasattr(data_samples, 'metainfo') and 'token' in data_samples.metainfo:
            token = data_samples.metainfo['token']
            print(f"\n  Token: {token}")
        
        print(f"\n{'='*80}")
        print(f"✅ 样本 #{sample_idx} 数据提取成功！")
        print(f"{'='*80}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ 数据提取失败:")
        print(f"   错误: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """主函数"""
    config_file = './projects/RoadNetwork/configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py'
    data_root = './data/nuscenes'
    ann_file = 'nuscenes_centerline_infos_pon_val.pkl'
    
    print("="*80)
    print("🔍 数据集结构调试工具（增强版）")
    print("="*80)
    print(f"配置文件: {config_file}")
    print(f"数据文件: {data_root}/{ann_file}")
    print("="*80)
    
    # 检查文件是否存在
    if not Path(config_file).exists():
        print(f"❌ 配置文件不存在: {config_file}")
        return
    
    # 加载配置
    print(f"\n📂 加载配置...")
    cfg = Config.fromfile(config_file)
    
    # 初始化注册表
    init_default_scope('mmdet3d')
    
    # 构建数据集
    print(f"📂 构建数据集...")
    dataset_cfg = cfg.train_dataloader.dataset
    dataset_cfg.data_root = data_root
    dataset_cfg.ann_file = ann_file
    
    dataset = DATASETS.build(dataset_cfg)
    print(f"✅ 数据集加载成功: {len(dataset)} 个样本")
    
    # 随机抽样5个样本
    total_samples = len(dataset)
    sample_indices = random.sample(range(total_samples), min(5, total_samples))
    
    print(f"\n🎲 随机抽样 {len(sample_indices)} 个样本: {sample_indices}")
    
    # 第一阶段：详细结构检查（只看第1个）
    print(f"\n" + "="*80)
    print(f"📋 第一阶段：详细结构检查")
    print(f"="*80)
    
    first_sample = dataset[sample_indices[0]]
    inspect_sample(first_sample, sample_indices[0])
    
    # 第二阶段：数据提取测试（所有样本）
    print(f"\n" + "="*80)
    print(f"🧪 第二阶段：数据提取测试")
    print(f"="*80)
    
    success_count = 0
    for idx in sample_indices:
        try:
            sample = dataset[idx]
            if test_data_extraction(sample, idx):
                success_count += 1
        except Exception as e:
            print(f"\n❌ 样本 #{idx} 处理失败:")
            print(f"   错误: {type(e).__name__}: {e}")
    
    # 总结
    print(f"\n" + "="*80)
    print(f"📊 测试总结")
    print(f"="*80)
    print(f"  测试样本数: {len(sample_indices)}")
    print(f"  成功: {success_count} ✅")
    print(f"  失败: {len(sample_indices) - success_count} ❌")
    print(f"  成功率: {success_count/len(sample_indices)*100:.1f}%")
    
    if success_count == len(sample_indices):
        print(f"\n🎉 所有样本数据提取成功！")
        print(f"✅ 可以将此逻辑应用到主脚本了。")
    else:
        print(f"\n⚠️  部分样本提取失败，需要进一步调查。")
    
    print(f"\n{'='*80}")
    print("✅ 调试完成！")
    print("="*80)


if __name__ == '__main__':
    main()
