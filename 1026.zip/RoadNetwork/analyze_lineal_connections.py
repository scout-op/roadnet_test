#!/usr/bin/env python3
"""
Lineal节点连接模式统计脚本

用途：验证 force_lineal_prev 约束的合理性
分析GT数据中Lineal节点是否总是连接到直接前驱（i-1）

基于训练命令提取的数据集路径：
- 训练集：./data/nuscenes/nuscenes_centerline_infos_pon_train.pkl
- 验证集：./data/nuscenes/nuscenes_centerline_infos_pon_val.pkl

注意：需要从mmdetection3d根目录运行此脚本
"""

import sys
import os
from pathlib import Path

# Add project root to path for imports
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

import numpy as np
from collections import defaultdict
import matplotlib.pyplot as plt
import json
import mmengine
from mmengine.config import Config
from tqdm import tqdm

# ==================== 解决中文乱码 ====================
import matplotlib
import matplotlib.font_manager as fm

def setup_chinese_font():
    """自动配置中文字体"""
    # 获取所有可用字体
    all_fonts = [f.name for f in fm.fontManager.ttflist]
    
    # 按优先级尝试中文字体
    chinese_fonts = [
        'WenQuanYi Micro Hei',  # 文泉驿微米黑（Linux常见）
        'WenQuanYi Zen Hei',    # 文泉驿正黑
        'SimHei',               # 黑体
        'Microsoft YaHei',      # 微软雅黑
        'SimSun',               # 宋体
        'Noto Sans CJK SC',     # Google Noto
        'Arial Unicode MS',     # Arial Unicode
        'STHeiti',              # 华文黑体
    ]
    
    # 查找第一个可用的中文字体
    selected_font = None
    for font in chinese_fonts:
        if font in all_fonts:
            selected_font = font
            print(f"✅ 使用中文字体: {font}")
            break
    
    if selected_font:
        matplotlib.rcParams['font.sans-serif'] = [selected_font, 'DejaVu Sans']
    else:
        print("⚠️  未找到中文字体，图表中文可能显示为方框")
        print("   运行 'python projects/RoadNetwork/fix_chinese_font.py' 查看解决方案")
        matplotlib.rcParams['font.sans-serif'] = ['DejaVu Sans']
    
    matplotlib.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 配置中文字体
setup_chinese_font()


def load_dataset_with_transforms(config_path, ann_file, data_root):
    """使用配置文件加载数据集并应用transforms"""
    print(f"📂 Loading config: {config_path}")
    cfg = Config.fromfile(config_path)
    
    print(f"📂 Loading dataset: {ann_file}")
    
    # Build dataset using mmengine registry
    from mmengine.registry import init_default_scope
    init_default_scope('mmdet3d')
    
    from mmdet3d.registry import DATASETS
    
    # Extract dataset config
    if hasattr(cfg, 'train_dataloader'):
        dataset_cfg = cfg.train_dataloader.dataset
    else:
        print("❌ Cannot find train_dataloader in config")
        return None
    
    # Update paths
    dataset_cfg.data_root = data_root
    dataset_cfg.ann_file = ann_file
    
    # Build dataset
    dataset = DATASETS.build(dataset_cfg)
    
    print(f"✅ Loaded {len(dataset)} samples")
    return dataset


def analyze_lineal_connections(dataset, dataset_name='dataset', max_samples=None):
    """
    全面分析道路网络数据集的统计特性
    
    节点类型定义：
    - 0: Ancestor (起始节点)
    - 1: Lineal (直线延续)
    - 2: Offshoot (分叉节点)
    - 3: Clone (合并节点)
    
    Args:
        dataset: 数据集对象
        dataset_name: 数据集名称（用于显示）
        max_samples: 最多分析的样本数，None表示全部
    """
    stats = {
        'total_samples': 0,
        'samples_with_lineal': 0,
        
        # ==================== 节点类型统计 ====================
        'total_nodes': 0,
        'ancestor_count': 0,
        'lineal_count': 0,
        'offshoot_count': 0,
        'clone_count': 0,
        
        # ==================== Lineal连接模式统计 ====================
        'lineal_connect_to_prev': 0,      # connect = i-1
        'lineal_connect_skip': 0,          # connect < i-1
        'lineal_connect_invalid': 0,       # connect >= i (不应该出现)
        'lineal_skip_distances': [],       # Lineal跳过距离
        'lineal_skip_examples': [],        # 存储跨节点连接的样本
        
        # ==================== 其他节点类型连接模式 ====================
        'offshoot_connections': [],        # Offshoot的连接距离
        'clone_connections': [],           # Clone的连接距离
        'ancestor_connections': [],        # Ancestor的连接（应该都是0）
        
        # ==================== 拓扑结构统计 ====================
        'nodes_per_sample': [],            # 每个样本的节点数
        'max_connection_distance': [],     # 每个样本最大连接距离
        'avg_connection_distance': [],     # 每个样本平均连接距离
        
        # ==================== 坐标分布统计 ====================
        'coord_x_values': [],              # 所有x坐标
        'coord_y_values': [],              # 所有y坐标
        'coord_out_of_bounds': 0,          # 越界坐标数量
        
        # ==================== Bezier系数统计 ====================
        'coeff_values': [],                # 所有系数值
        'coeff_out_of_range': 0,           # 超出训练范围的系数
        
        # ==================== 序列长度统计 ====================
        'sequence_lengths': [],            # 序列长度分布
        
        # ==================== 异常检测 ====================
        'samples_with_invalid_connections': 0,  # 包含无效连接的样本数
        'samples_with_oob_coords': 0,           # 包含越界坐标的样本数
        'forward_connections': [],              # 前向连接（connect >= i）
        
        # ==================== 连接模式矩阵 ====================
        # 统计从类型A到类型B的连接频率
        'connection_matrix': {
            # (from_type, to_type): count
            # 例如 (1, 1): Lineal -> Lineal
        },
        
        # ==================== 详细样本信息 ====================
        'sample_details': [],
        
        # ==================== 新增：类别共现统计 ====================
        'samples_by_node_count': {},       # {node_count: sample_count}
        'class_distribution_per_sample': []  # 每个样本的类别分布
    }
    
    # 确定处理范围
    total_samples = len(dataset)
    process_samples = min(max_samples, total_samples) if max_samples else total_samples
    
    print(f"📊 分析 {dataset_name}: {process_samples}/{total_samples} 样本")
    if max_samples and max_samples < total_samples:
        print(f"   ⚡ 采样模式：分析前 {max_samples} 个样本（统计置信度 > 99%）")
    
    # 使用tqdm添加进度条
    for sample_idx in tqdm(range(process_samples), 
                           desc=f"🔄 {dataset_name}", 
                           unit="sample",
                           ncols=100):
        try:
            # Get processed data with transforms applied
            sample = dataset[sample_idx]
            
            # ==================== 正确提取数据 ====================
            # mmdetection3d 使用 Det3DDataSample 封装数据
            # 数据在 data_samples 的直接属性中
            
            if 'data_samples' not in sample:
                continue
            
            data_samples = sample['data_samples']
            
            # 直接通过属性访问（不是字典访问！）
            if not hasattr(data_samples, 'centerline_label'):
                continue
            
            labels = np.array(data_samples.centerline_label)
            connects = np.array(data_samples.centerline_connect)
            coords = np.array(data_samples.centerline_coord) if hasattr(data_samples, 'centerline_coord') else None
            
            # 验证数据有效性
            if len(labels) == 0 or len(connects) == 0:
                continue
                
        except Exception as e:
            # Skip samples that fail to load
            continue
        
        stats['total_samples'] += 1
        num_nodes = len(labels)
        stats['total_nodes'] += num_nodes
        
        # 记录序列长度
        stats['nodes_per_sample'].append(num_nodes)
        stats['sequence_lengths'].append(num_nodes)
        
        # 记录节点数分布
        if num_nodes not in stats['samples_by_node_count']:
            stats['samples_by_node_count'][num_nodes] = 0
        stats['samples_by_node_count'][num_nodes] += 1
        
        # 样本级别的统计
        sample_class_dist = {'ancestor': 0, 'lineal': 0, 'offshoot': 0, 'clone': 0}
        sample_has_invalid = False
        sample_has_oob = False
        sample_connection_distances = []
        
        # 统计节点类型分布和坐标
        for idx, lbl in enumerate(labels):
            if lbl == 0:
                stats['ancestor_count'] += 1
                sample_class_dist['ancestor'] += 1
            elif lbl == 1:
                stats['lineal_count'] += 1
                sample_class_dist['lineal'] += 1
            elif lbl == 2:
                stats['offshoot_count'] += 1
                sample_class_dist['offshoot'] += 1
            elif lbl == 3:
                stats['clone_count'] += 1
                sample_class_dist['clone'] += 1
            
            # 坐标统计
            if coords is not None and idx < len(coords):
                x, y = coords[idx]
                stats['coord_x_values'].append(int(x))
                stats['coord_y_values'].append(int(y))
                
                # 检查越界（假设范围0-199，根据实际BEV grid调整）
                if x < 0 or x >= 200 or y < 0 or y >= 200:
                    stats['coord_out_of_bounds'] += 1
                    sample_has_oob = True
        
        # 记录样本类别分布
        stats['class_distribution_per_sample'].append(sample_class_dist)
        
        # 分析Lineal节点的连接
        has_lineal = False
        
        # 获取 token（在 metainfo 中）
        token = 'unknown'
        if hasattr(data_samples, 'metainfo') and 'token' in data_samples.metainfo:
            token = data_samples.metainfo['token']
        
        sample_lineal_info = {
            'sample_idx': sample_idx,
            'token': token,
            'num_nodes': num_nodes,
            'lineal_nodes': []
        }
        
        for i in range(1, num_nodes):  # 跳过第一个节点（通常是Ancestor）
            conn = connects[i]
            lbl = labels[i]
            
            # 计算连接距离
            if conn < i:
                conn_dist = i - conn
                sample_connection_distances.append(conn_dist)
            
            # 连接模式矩阵统计
            from_type = int(labels[conn]) if conn < len(labels) else -1
            to_type = int(lbl)
            if from_type >= 0:
                key = (from_type, to_type)
                if key not in stats['connection_matrix']:
                    stats['connection_matrix'][key] = 0
                stats['connection_matrix'][key] += 1
            
            # ==================== Lineal节点分析 ====================
            if lbl == 1:
                has_lineal = True
                
                lineal_info = {
                    'index': i,
                    'connect': conn,
                    'expected': i - 1,
                    'is_valid': conn < i,
                    'is_prev': conn == i - 1,
                }
                
                if coords is not None and i < len(coords):
                    lineal_info['coord'] = coords[i].tolist()
                
                if conn == i - 1:
                    # 连接到直接前驱
                    stats['lineal_connect_to_prev'] += 1
                    lineal_info['pattern'] = 'prev'
                elif conn < i - 1:
                    # 跨节点连接
                    stats['lineal_connect_skip'] += 1
                    skip_dist = i - 1 - conn
                    stats['lineal_skip_distances'].append(skip_dist)
                    lineal_info['pattern'] = 'skip'
                    lineal_info['skip_distance'] = skip_dist
                    
                    # 记录跨节点连接的案例
                    if len(stats['lineal_skip_examples']) < 10:  # 只保存前10个例子
                        stats['lineal_skip_examples'].append({
                            'sample_idx': sample_idx,
                            'token': token,
                            'node_idx': i,
                            'connect': conn,
                            'skip_distance': skip_dist,
                            'coord': coords[i].tolist() if coords is not None and i < len(coords) else None
                        })
                else:
                    # 无效连接（connect >= i）
                    stats['lineal_connect_invalid'] += 1
                    lineal_info['pattern'] = 'invalid'
                    sample_has_invalid = True
                    stats['forward_connections'].append({
                        'sample_idx': sample_idx,
                        'node_idx': i,
                        'type': 'Lineal',
                        'connect': conn
                    })
                
                sample_lineal_info['lineal_nodes'].append(lineal_info)
            
            # ==================== Offshoot节点分析 ====================
            elif lbl == 2:
                if conn < i:
                    stats['offshoot_connections'].append(i - conn)
                elif conn >= i:
                    sample_has_invalid = True
                    stats['forward_connections'].append({
                        'sample_idx': sample_idx,
                        'node_idx': i,
                        'type': 'Offshoot',
                        'connect': conn
                    })
            
            # ==================== Clone节点分析 ====================
            elif lbl == 3:
                if conn < i:
                    stats['clone_connections'].append(i - conn)
                elif conn >= i:
                    sample_has_invalid = True
                    stats['forward_connections'].append({
                        'sample_idx': sample_idx,
                        'node_idx': i,
                        'type': 'Clone',
                        'connect': conn
                    })
            
            # ==================== Ancestor节点分析 ====================
            elif lbl == 0:
                stats['ancestor_connections'].append(conn)
        
        # ==================== Bezier系数统计 ====================
        if hasattr(data_samples, 'centerline_coeff'):
            coeffs = np.array(data_samples.centerline_coeff)
            if coeffs.size > 0:
                stats['coeff_values'].extend(coeffs.flatten().tolist())
                # 检查超出范围（假设训练范围0-199）
                out_of_range = np.sum((coeffs < 0) | (coeffs >= 200))
                stats['coeff_out_of_range'] += out_of_range
        
        # ==================== 样本级统计汇总 ====================
        if sample_connection_distances:
            stats['max_connection_distance'].append(max(sample_connection_distances))
            stats['avg_connection_distance'].append(np.mean(sample_connection_distances))
        
        if sample_has_invalid:
            stats['samples_with_invalid_connections'] += 1
        
        if sample_has_oob:
            stats['samples_with_oob_coords'] += 1
        
        if has_lineal:
            stats['samples_with_lineal'] += 1
            if len(sample_lineal_info['lineal_nodes']) > 0:
                stats['sample_details'].append(sample_lineal_info)
    
    return stats


def generate_report(train_stats, val_stats, output_dir='./'):
    """生成统计报告"""
    output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True)
    
    print("\n" + "="*80)
    print("📊 Lineal节点连接模式分析报告")
    print("="*80)
    
    def print_dataset_stats(stats, dataset_name):
        print(f"\n### {dataset_name} ###")
        print(f"  总样本数: {stats['total_samples']}")
        print(f"  包含Lineal的样本: {stats['samples_with_lineal']} ({stats['samples_with_lineal']/max(stats['total_samples'],1)*100:.1f}%)")
        print(f"\n  节点类型分布:")
        total_nodes = stats['total_nodes']
        print(f"    总节点数: {total_nodes}")
        print(f"    Ancestor:  {stats['ancestor_count']:6d} ({stats['ancestor_count']/max(total_nodes,1)*100:5.1f}%)")
        print(f"    Lineal:    {stats['lineal_count']:6d} ({stats['lineal_count']/max(total_nodes,1)*100:5.1f}%) ⭐")
        print(f"    Offshoot:  {stats['offshoot_count']:6d} ({stats['offshoot_count']/max(total_nodes,1)*100:5.1f}%)")
        print(f"    Clone:     {stats['clone_count']:6d} ({stats['clone_count']/max(total_nodes,1)*100:5.1f}%)")
        
        print(f"\n  Lineal连接模式:")
        total_lineal = stats['lineal_count']
        if total_lineal > 0:
            prev_ratio = stats['lineal_connect_to_prev'] / total_lineal * 100
            skip_ratio = stats['lineal_connect_skip'] / total_lineal * 100
            invalid_ratio = stats['lineal_connect_invalid'] / total_lineal * 100
            
            print(f"    连接到i-1 (直接前驱):  {stats['lineal_connect_to_prev']:6d} ({prev_ratio:5.1f}%) ✅")
            print(f"    跨节点连接 (< i-1):    {stats['lineal_connect_skip']:6d} ({skip_ratio:5.1f}%) ⚠️")
            print(f"    无效连接 (>= i):       {stats['lineal_connect_invalid']:6d} ({invalid_ratio:5.1f}%) ❌")
            
            if stats['lineal_skip_distances']:
                skip_dist = np.array(stats['lineal_skip_distances'])
                print(f"\n  跨节点连接距离统计:")
                print(f"    最小: {skip_dist.min()}")
                print(f"    最大: {skip_dist.max()}")
                print(f"    平均: {skip_dist.mean():.2f}")
                print(f"    中位数: {np.median(skip_dist):.1f}")
            
            # 结论
            print(f"\n  🎯 结论:")
            if prev_ratio > 95:
                print(f"    ✅ {prev_ratio:.1f}% 的Lineal连接到i-1")
                print(f"    ✅ force_lineal_prev 约束是合理的！")
            elif prev_ratio > 90:
                print(f"    ⚠️ {prev_ratio:.1f}% 的Lineal连接到i-1")
                print(f"    ⚠️ 约束基本合理，但{skip_ratio:.1f}%被强制修正")
            else:
                print(f"    ❌ 仅{prev_ratio:.1f}% 的Lineal连接到i-1")
                print(f"    ❌ force_lineal_prev 约束过于严格，建议关闭！")
        else:
            print(f"    (无Lineal节点)")
        
        # ==================== 新增：其他统计信息 ====================
        print(f"\n  📊 拓扑结构统计:")
        if stats['nodes_per_sample']:
            print(f"    节点数/样本: min={min(stats['nodes_per_sample'])}, max={max(stats['nodes_per_sample'])}, avg={np.mean(stats['nodes_per_sample']):.1f}")
        if stats['max_connection_distance']:
            print(f"    最大连接距离: min={min(stats['max_connection_distance'])}, max={max(stats['max_connection_distance'])}, avg={np.mean(stats['max_connection_distance']):.2f}")
        
        print(f"\n  📍 坐标分布:")
        if stats['coord_x_values']:
            print(f"    X坐标范围: [{min(stats['coord_x_values'])}, {max(stats['coord_x_values'])}]")
            print(f"    Y坐标范围: [{min(stats['coord_y_values'])}, {max(stats['coord_y_values'])}]")
            print(f"    越界坐标数: {stats['coord_out_of_bounds']} ({stats['coord_out_of_bounds']/max(len(stats['coord_x_values']),1)*100:.2f}%)")
        
        print(f"\n  🔢 Bezier系数统计:")
        if stats['coeff_values']:
            coeff_arr = np.array(stats['coeff_values'])
            print(f"    系数范围: [{coeff_arr.min():.1f}, {coeff_arr.max():.1f}]")
            print(f"    超范围系数: {stats['coeff_out_of_range']} ({stats['coeff_out_of_range']/max(len(stats['coeff_values']),1)*100:.2f}%)")
        
        print(f"\n  ⚠️  异常检测:")
        print(f"    包含无效连接的样本: {stats['samples_with_invalid_connections']} ({stats['samples_with_invalid_connections']/max(stats['total_samples'],1)*100:.2f}%)")
        print(f"    包含越界坐标的样本: {stats['samples_with_oob_coords']} ({stats['samples_with_oob_coords']/max(stats['total_samples'],1)*100:.2f}%)")
        if stats['forward_connections']:
            print(f"    前向连接总数: {len(stats['forward_connections'])}")
        
        print(f"\n  🔗 连接模式统计:")
        if stats['offshoot_connections']:
            print(f"    Offshoot连接距离: min={min(stats['offshoot_connections'])}, max={max(stats['offshoot_connections'])}, avg={np.mean(stats['offshoot_connections']):.2f}")
        if stats['clone_connections']:
            print(f"    Clone连接距离: min={min(stats['clone_connections'])}, max={max(stats['clone_connections'])}, avg={np.mean(stats['clone_connections']):.2f}")
    
    print_dataset_stats(train_stats, "训练集")
    print_dataset_stats(val_stats, "验证集")
    
    # 显示跨节点连接的案例
    print("\n" + "="*80)
    print("📝 跨节点连接案例（前10个）")
    print("="*80)
    
    for dataset_name, stats in [("训练集", train_stats), ("验证集", val_stats)]:
        if stats['lineal_skip_examples']:
            print(f"\n### {dataset_name} ###")
            for idx, example in enumerate(stats['lineal_skip_examples'][:10], 1):
                print(f"  案例{idx}:")
                print(f"    Token: {example['token']}")
                print(f"    Node index: {example['node_idx']}")
                print(f"    Connect: {example['connect']} (期望: {example['node_idx']-1})")
                print(f"    跳过距离: {example['skip_distance']}")
                if example['coord']:
                    print(f"    坐标: {example['coord']}")
    
    # 生成可视化
    print("\n" + "="*80)
    print("📈 生成可视化图表...")
    print("="*80)
    
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('Lineal Node Connection Pattern Analysis', fontsize=16, fontweight='bold')
    
    datasets = [('Training Set', train_stats), ('Validation Set', val_stats)]
    
    for idx, (dataset_name, stats) in enumerate(datasets):
        # 1. 节点类型分布饼图
        ax1 = axes[idx, 0]
        labels_pie = ['Ancestor', 'Lineal', 'Offshoot', 'Clone']
        sizes = [
            stats['ancestor_count'],
            stats['lineal_count'],
            stats['offshoot_count'],
            stats['clone_count']
        ]
        colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#f7b731']
        
        # Skip pie chart if all sizes are 0
        if sum(sizes) > 0:
            ax1.pie(sizes, labels=labels_pie, autopct='%1.1f%%', colors=colors, startangle=90)
            ax1.set_title(f'{dataset_name} - Node Type Distribution')
        else:
            ax1.text(0.5, 0.5, 'No Data', ha='center', va='center', transform=ax1.transAxes, fontsize=14)
            ax1.set_title(f'{dataset_name} - Node Type Distribution')
        
        # 2. Lineal connection pattern bar chart
        ax2 = axes[idx, 1]
        if stats['lineal_count'] > 0:
            patterns = ['Connect i-1', 'Skip Connect', 'Invalid']
            counts = [
                stats['lineal_connect_to_prev'],
                stats['lineal_connect_skip'],
                stats['lineal_connect_invalid']
            ]
            colors_bar = ['#2ecc71', '#f39c12', '#e74c3c']
            bars = ax2.bar(patterns, counts, color=colors_bar)
            ax2.set_ylabel('Node Count')
            ax2.set_title(f'{dataset_name} - Lineal Connection Pattern')
            
            # 添加百分比标签
            total = sum(counts)
            for bar, count in zip(bars, counts):
                height = bar.get_height()
                ax2.text(bar.get_x() + bar.get_width()/2., height,
                        f'{count}\n({count/total*100:.1f}%)',
                        ha='center', va='bottom')
        else:
            ax2.text(0.5, 0.5, 'No Lineal Nodes', ha='center', va='center', transform=ax2.transAxes)
            ax2.set_title(f'{dataset_name} - Lineal Connection Pattern')
    
    plt.tight_layout()
    plot_path = output_dir / 'lineal_connection_analysis.png'
    plt.savefig(plot_path, dpi=150, bbox_inches='tight')
    print(f"✅ 图表已保存: {plot_path}")
    
    # 生成JSON报告
    report = {
        'train': {
            'total_samples': train_stats['total_samples'],
            'total_nodes': train_stats['total_nodes'],
            'node_distribution': {
                'ancestor': train_stats['ancestor_count'],
                'lineal': train_stats['lineal_count'],
                'offshoot': train_stats['offshoot_count'],
                'clone': train_stats['clone_count'],
            },
            'lineal_patterns': {
                'connect_to_prev': train_stats['lineal_connect_to_prev'],
                'connect_skip': train_stats['lineal_connect_skip'],
                'connect_invalid': train_stats['lineal_connect_invalid'],
                'prev_ratio': train_stats['lineal_connect_to_prev'] / max(train_stats['lineal_count'], 1) * 100,
            }
        },
        'val': {
            'total_samples': val_stats['total_samples'],
            'total_nodes': val_stats['total_nodes'],
            'node_distribution': {
                'ancestor': val_stats['ancestor_count'],
                'lineal': val_stats['lineal_count'],
                'offshoot': val_stats['offshoot_count'],
                'clone': val_stats['clone_count'],
            },
            'lineal_patterns': {
                'connect_to_prev': val_stats['lineal_connect_to_prev'],
                'connect_skip': val_stats['lineal_connect_skip'],
                'connect_invalid': val_stats['lineal_connect_invalid'],
                'prev_ratio': val_stats['lineal_connect_to_prev'] / max(val_stats['lineal_count'], 1) * 100,
            }
        }
    }
    
    json_path = output_dir / 'lineal_connection_report.json'
    with open(json_path, 'w') as f:
        json.dump(report, f, indent=2)
    print(f"✅ JSON报告已保存: {json_path}")
    
    print("\n" + "="*80)
    print("✅ 分析完成！")
    print("="*80)


def main():
    # 从训练命令提取的数据集路径
    data_root = './data/nuscenes'
    train_pkl = 'nuscenes_centerline_infos_pon_train.pkl'
    val_pkl = 'nuscenes_centerline_infos_pon_val.pkl'
    config_file = './projects/RoadNetwork/configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py'
    
    # 🔥 采样参数（可修改）
    # 根据debug发现：Lineal连接i-1比例仅5-10%，建议先用1000样本验证
    MAX_TRAIN_SAMPLES = 1000  # None=全部(28008)，或设置为1000, 5000等
    MAX_VAL_SAMPLES = 500     # None=全部(6141)，或设置为200, 1000等
    
    # 📊 如需全量分析（耗时7-15小时），设置为 None
    
    print("="*80)
    print("🔍 Lineal节点连接模式分析工具")
    print("="*80)
    print(f"目的: 验证 force_lineal_prev 约束的合理性")
    print(f"假设: Lineal节点应该总是连接到直接前驱 (i-1)")
    print("="*80)
    print(f"\n⚙️  配置文件: {config_file}")
    print(f"📁 数据根目录: {data_root}")
    print(f"📄 训练集: {train_pkl}")
    print(f"📄 验证集: {val_pkl}")
    
    if MAX_TRAIN_SAMPLES:
        print(f"\n⚡ 采样模式启用:")
        print(f"   训练集: 最多 {MAX_TRAIN_SAMPLES} 样本")
        if MAX_VAL_SAMPLES:
            print(f"   验证集: 最多 {MAX_VAL_SAMPLES} 样本")
    
    print("="*80)
    
    # 检查文件是否存在
    if not Path(config_file).exists():
        print(f"❌ 错误: 配置文件不存在: {config_file}")
        print(f"   请从mmdetection3d根目录运行此脚本")
        return
    
    if not Path(data_root).exists():
        print(f"❌ 错误: 数据根目录不存在: {data_root}")
        return
    
    # 加载数据集（会自动应用transforms）
    print("\n🔄 加载训练集...")
    train_dataset = load_dataset_with_transforms(config_file, train_pkl, data_root)
    if train_dataset is None:
        return
    
    print("\n🔄 加载验证集...")
    # For validation, use same config but different ann_file
    val_dataset = load_dataset_with_transforms(config_file, val_pkl, data_root)
    if val_dataset is None:
        return
    
    # 分析
    print()
    train_stats = analyze_lineal_connections(
        train_dataset, '训练集', max_samples=MAX_TRAIN_SAMPLES
    )
    
    print()
    val_stats = analyze_lineal_connections(
        val_dataset, '验证集', max_samples=MAX_VAL_SAMPLES
    )
    
    # 生成报告
    output_dir = './projects/RoadNetwork'
    generate_report(train_stats, val_stats, output_dir=output_dir)
    print(f"\n💾 报告已保存到: {output_dir}/")


if __name__ == '__main__':
    main()
