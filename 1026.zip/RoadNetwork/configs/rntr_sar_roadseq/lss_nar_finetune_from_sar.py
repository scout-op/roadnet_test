# NAR Finetuning Configuration (Step 2 for NAR)
# This config is used to finetune NAR from trained SAR model
# Usage: Must specify load_from pointing to SAR pretrained weights

_base_ = ['./lss_sar_rntr_paper_fp16_torch2.py']

# ⭐ CRITICAL: Must load from trained SAR model
# Set this via command line: --cfg-options load_from='work_dirs/sar_pretrain/latest.pth'
load_from = None  # Must be specified!

# ✅ Enable NAR-MLM training
model = dict(
    pts_bbox_head=dict(
        nar_mlm_train=True,      # ✅ NAR-MLM finetuning
        nar_mask_ratio=0.9,      # ✅ 90% mask (paper setting)
        nar_infer=True,           # ✅ Use NAR iterative inference
        nar_iters=3,              # ✅ 3 iterations (paper setting)
        nar_conf_thresh=0.55,    # Confidence threshold
        nar_keep_ratio=0.2,      # Top-k keep ratio
    )
)

# Training schedule (paper: 100 extra epochs)
max_epochs = 500
train_cfg = dict(max_epochs=max_epochs)

# Learning rate schedule
param_scheduler = [
    dict(
        type='LinearLR',
        start_factor=1.0 / 3,
        by_epoch=False,
        begin=0,
        end=500),
    dict(
        type='CosineAnnealingLR',
        begin=0,
        T_max=max_epochs,
        end=max_epochs,
        by_epoch=True,
        eta_min=1e-7)
]

# ⚠️ IMPORTANT: This config requires SAR pretrained weights!
# Example usage:
#   ./tools/dist_train.sh configs/rntr_sar_roadseq/lss_nar_finetune_from_sar.py 8 \
#     --cfg-options load_from='work_dirs/sar_pretrain/latest.pth'
