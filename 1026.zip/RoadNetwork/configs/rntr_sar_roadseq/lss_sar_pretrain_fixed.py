# SAR Pretraining Configuration - FIXED for Collapse Issue
# This config fixes the training collapse observed at epoch 40

_base_ = ['./lss_sar_rntr_paper_fp16_torch2.py']

# ==================== KEY FIXES ====================

# Fix 1: Increase class weights to prevent collapse
num_center_classes = 574  # Aligned with paper Table (0-573)
label_class_weight = [1.0] * num_center_classes
connect_class_weight = [1.0] * num_center_classes

# Don't reduce 'continue' and 'connect=0' too much
label_class_weight[201] = 0.5  # continue: was 0.2, now 0.5
connect_class_weight[250] = 0.5  # connect=0: was 0.2, now 0.5

# Fix 2: Greatly increase topology loss weights
model = dict(
    pts_bbox_head=dict(
        # Disable NAR for pure SAR training
        nar_mlm_train=False,
        nar_infer=False,
        
        # Increase loss weights to fight collapse
        loss_coords=dict(
            type='mmdet.CrossEntropyLoss', 
            loss_weight=2.0  # Increased from 1.0
        ),
        loss_labels=dict(
            type='mmdet.CrossEntropyLoss', 
            class_weight=label_class_weight,
            loss_weight=4.0  # Increased from 2.0
        ),
        loss_connects=dict(
            type='mmdet.CrossEntropyLoss', 
            class_weight=connect_class_weight,
            loss_weight=6.0  # Increased from 3.0
        ),
        loss_coeffs=dict(
            type='mmdet.CrossEntropyLoss', 
            loss_weight=3.0  # Increased from 1.5
        ),
    )
)

# Fix 3: Reduce learning rate for more stable training
# Keep AmpOptimWrapper (FP16) from base config, only change lr
optim_wrapper = dict(
    type='AmpOptimWrapper',
    loss_scale='dynamic',
    optimizer=dict(
        type='AdamW',
        lr=1e-4,  # Reduced from 2e-4
        weight_decay=0.01
    ),
    clip_grad=dict(max_norm=35, norm_type=2)
)

# Training schedule
max_epochs = 300
train_cfg = dict(
    max_epochs=max_epochs,
    val_interval=10  # Validate more frequently to catch issues early
)

# Learning rate schedule with longer warmup
param_scheduler = [
    dict(
        type='LinearLR',
        start_factor=0.1,  # Start from 10% of lr
        by_epoch=False,
        begin=0,
        end=1000  # Longer warmup: 1000 iterations
    ),
    dict(
        type='CosineAnnealingLR',
        begin=0,
        T_max=max_epochs,
        end=max_epochs,
        by_epoch=True,
        eta_min=1e-7
    )
]

# Fix 4: More aggressive data augmentation to prevent overfitting to (0,0)
train_dataloader = dict(
    batch_size=2,  # Keep same as original
    num_workers=8
)

# ==================== END OF FIXES ====================

# Expected behavior after fixes:
# - Epoch 10: loss_labels should be 1.0-2.0 (not 0.001!)
# - Epoch 10: loss_connects should be 1.5-3.0 (not 0.001!)
# - Epoch 40: Landmark F1 should be > 0.15
# - Epoch 40: Reachability F1 should be > 0.05
