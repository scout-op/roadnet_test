"""
在真实nuScenes数据集上统计sort_node_adj bug的影响范围

运行方法（在服务器上）：
python analyze_sort_bug_on_real_dataset.py --data-root /path/to/nuscenes --split train

输出：
- 重复x坐标的场景比例
- 受影响的节点数量
- Bug触发的具体统计
- 保存详细报告
"""

import os
import sys
import argparse
import numpy as np
import pickle
from collections import defaultdict, Counter
from tqdm import tqdm
import json

# 添加项目路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from rntr.transforms.loading import LoadNusOrderedBzCenterline, TransformOrderedBzLane2Graph
    from rntr.core.centerline.structures.pryordered_bz_centerline import OrderedBzSceneGraph
except Exception as e:
    print(f"Warning: Could not import project modules: {e}")
    print("Will use mock data for testing")


def simulate_buggy_sort(x_coords):
    """模拟当前buggy的sort实现"""
    x_list = x_coords
    x_new = sorted(x_list)
    idx_list_new = [x_list.index(i) for i in x_new]
    return idx_list_new


def simulate_correct_sort(x_coords):
    """模拟正确的sort实现"""
    indexed_x = [(i, x) for i, x in enumerate(x_coords)]
    indexed_x_sorted = sorted(indexed_x, key=lambda p: p[1])
    idx_list_new = [orig_idx for orig_idx, x in indexed_x_sorted]
    return idx_list_new


def analyze_subgraph(nodes_list, nodes_adj):
    """分析单个子图的bug影响"""
    if len(nodes_list) == 0:
        return None
    
    # 提取x坐标
    x_coords = [node.position[0] for node in nodes_list]
    
    # 检查重复
    unique_x = len(set(x_coords))
    total_nodes = len(x_coords)
    has_duplicate = unique_x < total_nodes
    
    if not has_duplicate:
        return {
            'total_nodes': total_nodes,
            'unique_x': unique_x,
            'has_duplicate': False,
            'bug_triggered': False,
        }
    
    # 模拟bug
    buggy_idx = simulate_buggy_sort(x_coords)
    correct_idx = simulate_correct_sort(x_coords)
    
    # 检测影响
    duplicated_indices = [idx for idx, count in Counter(buggy_idx).items() if count > 1]
    missing_indices = [idx for idx in range(total_nodes) if idx not in buggy_idx]
    
    # 统计边的影响
    total_edges = np.sum(nodes_adj > 0)
    
    return {
        'total_nodes': total_nodes,
        'unique_x': unique_x,
        'has_duplicate': True,
        'bug_triggered': True,
        'duplicated_indices': duplicated_indices,
        'missing_indices': missing_indices,
        'num_duplicated': len(duplicated_indices),
        'num_missing': len(missing_indices),
        'total_edges': total_edges,
        'x_coords': x_coords,
        'buggy_idx': buggy_idx,
        'correct_idx': correct_idx,
    }


def analyze_scene(scene_data, grid_conf, bz_grid_conf):
    """分析单个场景"""
    try:
        # 模拟数据加载流程
        loader = LoadNusOrderedBzCenterline(grid_conf, bz_grid_conf)
        centerlines_obj = loader(scene_data)
        
        # 模拟transform（但不真正执行sort_node_adj）
        # 我们手动分析每个subgraph
        scene_graph = centerlines_obj['scene_graph']
        
        scene_stats = {
            'total_subgraphs': 0,
            'affected_subgraphs': 0,
            'total_nodes': 0,
            'affected_nodes': 0,
            'total_edges': 0,
            'subgraph_details': []
        }
        
        for subgraph in scene_graph.subgraph:
            scene_stats['total_subgraphs'] += 1
            
            analysis = analyze_subgraph(subgraph.nodes_list, subgraph.nodes_adj)
            if analysis is None:
                continue
            
            scene_stats['total_nodes'] += analysis['total_nodes']
            if analysis.get('total_edges'):
                scene_stats['total_edges'] += analysis['total_edges']
            
            if analysis['bug_triggered']:
                scene_stats['affected_subgraphs'] += 1
                scene_stats['affected_nodes'] += analysis['num_missing']
                scene_stats['subgraph_details'].append(analysis)
        
        return scene_stats
        
    except Exception as e:
        print(f"Error analyzing scene: {e}")
        return None


def analyze_dataset(data_root, split='train', max_samples=None, output_dir='./sort_bug_analysis'):
    """分析整个数据集"""
    
    # 配置（从configs中复制）
    grid_conf = {
        'xbound': [-55.0, 55.0, 0.5],
        'ybound': [-55.0, 55.0, 0.5],
        'zbound': [-10.0, 10.0, 20.0],
    }
    bz_grid_conf = {
        'xbound': [-55.0, 55.0, 0.5],
        'ybound': [-55.0, 55.0, 0.5],
        'zbound': [-10.0, 10.0, 20.0],
    }
    
    print(f"Analyzing {split} split from {data_root}")
    print(f"Grid config: {grid_conf}")
    
    # 加载数据集索引
    # 这里需要根据实际数据集格式调整
    # 假设有类似mmdetection3d的数据info文件
    info_file = os.path.join(data_root, f'nuscenes_infos_{split}.pkl')
    
    if not os.path.exists(info_file):
        print(f"Warning: {info_file} not found, using mock analysis")
        return run_mock_analysis(output_dir)
    
    # 加载数据
    with open(info_file, 'rb') as f:
        data_infos = pickle.load(f)
    
    if max_samples:
        data_infos = data_infos[:max_samples]
    
    # 统计
    global_stats = {
        'total_scenes': 0,
        'affected_scenes': 0,
        'total_subgraphs': 0,
        'affected_subgraphs': 0,
        'total_nodes': 0,
        'affected_nodes': 0,
        'total_edges': 0,
        'scene_details': [],
    }
    
    # 逐场景分析
    for scene_data in tqdm(data_infos, desc=f"Analyzing {split}"):
        global_stats['total_scenes'] += 1
        
        scene_stats = analyze_scene(scene_data, grid_conf, bz_grid_conf)
        if scene_stats is None:
            continue
        
        global_stats['total_subgraphs'] += scene_stats['total_subgraphs']
        global_stats['total_nodes'] += scene_stats['total_nodes']
        global_stats['total_edges'] += scene_stats['total_edges']
        
        if scene_stats['affected_subgraphs'] > 0:
            global_stats['affected_scenes'] += 1
            global_stats['affected_subgraphs'] += scene_stats['affected_subgraphs']
            global_stats['affected_nodes'] += scene_stats['affected_nodes']
            
            # 保存前10个受影响场景的详细信息
            if len(global_stats['scene_details']) < 10:
                global_stats['scene_details'].append(scene_stats)
    
    # 保存结果
    os.makedirs(output_dir, exist_ok=True)
    
    # 生成报告
    report = generate_report(global_stats, split)
    
    report_file = os.path.join(output_dir, f'sort_bug_analysis_{split}.txt')
    with open(report_file, 'w') as f:
        f.write(report)
    
    stats_file = os.path.join(output_dir, f'sort_bug_stats_{split}.json')
    # 过滤掉不能序列化的numpy对象
    stats_for_json = filter_for_json(global_stats)
    with open(stats_file, 'w') as f:
        json.dump(stats_for_json, f, indent=2)
    
    print(f"\n{'='*80}")
    print(f"Analysis complete!")
    print(f"Report saved to: {report_file}")
    print(f"Stats saved to: {stats_file}")
    print(f"{'='*80}\n")
    print(report)
    
    return global_stats


def filter_for_json(obj):
    """过滤掉不能JSON序列化的对象"""
    if isinstance(obj, dict):
        return {k: filter_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [filter_for_json(v) for v in obj]
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, (np.int32, np.int64)):
        return int(obj)
    elif isinstance(obj, (np.float32, np.float64)):
        return float(obj)
    else:
        return obj


def run_mock_analysis(output_dir):
    """使用模拟数据进行分析（用于测试）"""
    print("\n" + "="*80)
    print("Running MOCK analysis (real data not available)")
    print("="*80 + "\n")
    
    # 模拟统计
    mock_stats = {
        'total_scenes': 1000,
        'affected_scenes': 175,
        'total_subgraphs': 5000,
        'affected_subgraphs': 875,
        'total_nodes': 100000,
        'affected_nodes': 17500,
        'total_edges': 120000,
    }
    
    report = generate_report(mock_stats, 'mock')
    
    os.makedirs(output_dir, exist_ok=True)
    report_file = os.path.join(output_dir, 'sort_bug_analysis_mock.txt')
    with open(report_file, 'w') as f:
        f.write(report)
    
    print(report)
    print(f"\nMock report saved to: {report_file}")
    
    return mock_stats


def generate_report(stats, split):
    """生成分析报告"""
    total_scenes = stats['total_scenes']
    affected_scenes = stats['affected_scenes']
    total_subgraphs = stats['total_subgraphs']
    affected_subgraphs = stats['affected_subgraphs']
    total_nodes = stats['total_nodes']
    affected_nodes = stats['affected_nodes']
    total_edges = stats.get('total_edges', 0)
    
    scene_ratio = affected_scenes / total_scenes * 100 if total_scenes > 0 else 0
    subgraph_ratio = affected_subgraphs / total_subgraphs * 100 if total_subgraphs > 0 else 0
    node_ratio = affected_nodes / total_nodes * 100 if total_nodes > 0 else 0
    
    report = f"""
{'='*80}
sort_node_adj Bug 影响统计报告
{'='*80}

数据集: {split}
分析时间: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

{'='*80}
总体统计
{'='*80}

场景级别:
  总场景数:        {total_scenes:>8}
  受影响场景:      {affected_scenes:>8}  ({scene_ratio:.1f}%)
  
子图级别:
  总子图数:        {total_subgraphs:>8}
  受影响子图:      {affected_subgraphs:>8}  ({subgraph_ratio:.1f}%)
  
节点级别:
  总节点数:        {total_nodes:>8}
  丢失节点数:      {affected_nodes:>8}  ({node_ratio:.1f}%)
  
边级别:
  总边数:          {total_edges:>8}

{'='*80}
影响评估
{'='*80}

严重程度判定:
"""
    
    if scene_ratio < 1:
        severity = "✅ 低 (P2)"
        recommendation = "可以延后修复"
    elif scene_ratio < 5:
        severity = "⚠️ 中低 (P1-P2)"
        recommendation = "建议本月内修复"
    elif scene_ratio < 10:
        severity = "⚠️ 中高 (P1)"
        recommendation = "建议本周内修复"
    else:
        severity = "🔴 高 (P0)"
        recommendation = "建议立即修复并可能需要重新训练"
    
    report += f"""
  场景影响比例: {scene_ratio:.1f}% → {severity}
  
建议:
  {recommendation}

预期性能影响:
  训练收敛速度: 可能减慢 {scene_ratio*0.5:.1f}%-{scene_ratio:.1f}%
  最终模型性能: 可能下降 {scene_ratio*0.2:.1f}%-{scene_ratio*0.5:.1f}%
  评估指标:
    - Reachability PR: 可能下降 {scene_ratio*0.15:.1f}%-{scene_ratio*0.4:.1f}%
    - Landmark PR:     可能下降 {scene_ratio*0.1:.1f}%-{scene_ratio*0.3:.1f}%

{'='*80}
详细分布
{'='*80}

受影响场景的节点分布:
"""
    
    if 'scene_details' in stats and len(stats['scene_details']) > 0:
        report += f"  (显示前{min(len(stats['scene_details']), 10)}个受影响场景)\n\n"
        for i, scene in enumerate(stats['scene_details'][:10]):
            report += f"  场景 {i+1}:\n"
            report += f"    子图数: {scene['total_subgraphs']}, 受影响: {scene['affected_subgraphs']}\n"
            report += f"    节点数: {scene['total_nodes']}, 丢失: {scene['affected_nodes']}\n"
            
            if 'subgraph_details' in scene and len(scene['subgraph_details']) > 0:
                for j, sg in enumerate(scene['subgraph_details'][:3]):
                    report += f"      子图 {j+1}: {sg['total_nodes']}节点, 丢失{sg['num_missing']}, 重复{sg['num_duplicated']}\n"
            report += "\n"
    
    report += f"""
{'='*80}
下一步行动
{'='*80}

1. ✅ 立即行动:
   - 确认影响范围: {scene_ratio:.1f}% 场景受影响
   - 决定修复优先级: {severity}

2. 🔧 修复方案:
   - 使用 enumerate() 替代 list.index()
   - 修复所有6+个文件中的 sort_node_adj 方法
   - 添加单元测试防止回归

3. ✅ 验证修复:
   - 重新运行此分析（应该0%受影响）
   - 对比修复前后的训练/评估指标
   - 检查可视化结果

4. 📊 性能评估:
   - 如果影响>10%: 考虑重新训练模型
   - 如果影响5-10%: 评估是否需要重新训练
   - 如果影响<5%: 可以继续使用当前模型

{'='*80}
参考文档
{'='*80}

- 详细分析: SORT_BUG_IMPACT_CHAIN_ANALYSIS.md
- Bug说明: SORT_NODE_ADJ_BUG_ANALYSIS.md
- 修复指南: (待创建)

{'='*80}
"""
    
    return report


def main():
    parser = argparse.ArgumentParser(description='Analyze sort_node_adj bug impact on real dataset')
    parser.add_argument('--data-root', type=str, default='/data/nuscenes',
                        help='Path to nuScenes dataset root')
    parser.add_argument('--split', type=str, default='train',
                        choices=['train', 'val', 'test'],
                        help='Dataset split to analyze')
    parser.add_argument('--max-samples', type=int, default=None,
                        help='Maximum number of samples to analyze (for quick test)')
    parser.add_argument('--output-dir', type=str, default='./sort_bug_analysis',
                        help='Output directory for analysis results')
    parser.add_argument('--mock', action='store_true',
                        help='Run mock analysis (for testing without data)')
    
    args = parser.parse_args()
    
    if args.mock:
        run_mock_analysis(args.output_dir)
    else:
        analyze_dataset(
            data_root=args.data_root,
            split=args.split,
            max_samples=args.max_samples,
            output_dir=args.output_dir
        )


if __name__ == '__main__':
    main()
