"""
检测sort_node_adj bug的实际影响范围

运行方法：
python check_sort_bug_impact.py
"""

import numpy as np
from collections import Counter


def simulate_buggy_sort(x_coords):
    """模拟当前buggy的sort_node_adj实现"""
    x_list = x_coords
    x_new = sorted(x_list)
    
    # Buggy implementation
    idx_list_new = [x_list.index(i) for i in x_new]
    
    return idx_list_new


def simulate_correct_sort(x_coords):
    """模拟正确的sort_node_adj实现"""
    # Method 1: Using enumerate
    indexed_x = [(i, x) for i, x in enumerate(x_coords)]
    indexed_x_sorted = sorted(indexed_x, key=lambda p: p[1])
    idx_list_new = [orig_idx for orig_idx, x in indexed_x_sorted]
    
    return idx_list_new


def check_for_bugs(x_coords):
    """检查给定的x坐标列表是否会触发bug"""
    buggy_result = simulate_buggy_sort(x_coords)
    correct_result = simulate_correct_sort(x_coords)
    
    # Check if results differ
    if buggy_result != correct_result:
        return True, buggy_result, correct_result
    return False, None, None


def analyze_test_cases():
    """分析各种测试用例"""
    print("="*80)
    print("测试用例分析")
    print("="*80)
    
    test_cases = [
        # (name, x_coords)
        ("无重复", [10.0, 20.0, 30.0, 40.0]),
        ("两个重复", [10.0, 20.0, 10.0, 30.0]),
        ("三个重复", [10.0, 10.0, 10.0, 20.0]),
        ("多组重复", [10.0, 20.0, 10.0, 20.0]),
        ("真实场景1: 垂直道路", [50.0, 50.0, 50.0, 50.0, 50.0]),
        ("真实场景2: 平行道路", [30.0, 35.0, 30.0, 35.0, 40.0]),
        ("真实场景3: 交叉口", [49.9, 50.0, 50.1, 50.0, 50.2]),
    ]
    
    for name, x_coords in test_cases:
        has_bug, buggy, correct = check_for_bugs(x_coords)
        
        print(f"\n测试: {name}")
        print(f"  x坐标: {x_coords}")
        print(f"  有重复x: {len(x_coords) != len(set(x_coords))}")
        
        if has_bug:
            print(f"  ❌ BUG触发!")
            print(f"    错误映射: {buggy}")
            print(f"    正确映射: {correct}")
            
            # 分析丢失和重复的索引
            buggy_counter = Counter(buggy)
            correct_counter = Counter(correct)
            
            duplicated = [idx for idx, count in buggy_counter.items() if count > 1]
            missing = [idx for idx in range(len(x_coords)) if idx not in buggy]
            
            if duplicated:
                print(f"    重复索引: {duplicated} (出现次数: {[buggy_counter[i] for i in duplicated]})")
            if missing:
                print(f"    丢失索引: {missing}")
        else:
            print(f"  ✅ 无Bug")


def estimate_real_world_impact():
    """估算真实数据集中的影响"""
    print("\n" + "="*80)
    print("真实场景影响估算")
    print("="*80)
    
    # 模拟不同场景下x坐标重复的概率
    scenarios = {
        "简单道路（无重复）": 0.01,
        "有平行道路": 0.15,
        "有交叉口": 0.25,
        "复杂城市场景": 0.40,
        "有环形/垂直道路": 0.60,
    }
    
    print("\n估算不同场景类型中x坐标重复的概率：")
    for scenario, prob in scenarios.items():
        print(f"  {scenario}: {prob*100:.1f}%")
    
    print("\n如果数据集构成：")
    composition = {
        "简单道路": (0.30, 0.01),
        "平行道路": (0.25, 0.15),
        "交叉口": (0.30, 0.25),
        "复杂场景": (0.15, 0.40),
    }
    
    total_affected = 0
    for scene_type, (ratio, bug_prob) in composition.items():
        affected = ratio * bug_prob
        total_affected += affected
        print(f"  {scene_type}: {ratio*100:.0f}% 场景 × {bug_prob*100:.1f}% bug概率 = {affected*100:.1f}% 受影响")
    
    print(f"\n估算总体影响: {total_affected*100:.1f}% 场景可能受影响")
    
    # 估算节点层面的影响
    print("\n节点层面影响（假设每个受影响场景平均20个节点）：")
    print(f"  如果有40,000个训练样本")
    print(f"  受影响场景: {40000 * total_affected:.0f}")
    print(f"  受影响节点: {40000 * total_affected * 20:.0f}")


def provide_recommendations():
    """提供修复建议"""
    print("\n" + "="*80)
    print("建议和优先级")
    print("="*80)
    
    print("\n🔍 立即验证（P0）：")
    print("  1. 在实际数据集上运行检测脚本")
    print("  2. 统计有多少场景实际有重复x坐标")
    print("  3. 检查训练日志是否有异常（如拓扑错误、NaN等）")
    
    print("\n📊 影响评估（P0）：")
    print("  - 如果 <1% 场景受影响 → P2修复（低优先级）")
    print("  - 如果 1-5% 场景受影响 → P1修复（中优先级）")
    print("  - 如果 5-10% 场景受影响 → P0修复（高优先级）")
    print("  - 如果 >10% 场景受影响 → 🔴 严重问题，立即修复+重新训练")
    
    print("\n🔧 修复方案（P1）：")
    print("  使用enumerate()或numpy.argsort()替代list.index()")
    print("  修复所有6+个文件中的sort_node_adj方法")
    
    print("\n✅ 验证修复（P1）：")
    print("  1. 添加单元测试")
    print("  2. 在修复后的代码上重新生成序列")
    print("  3. 对比修复前后的指标变化")


if __name__ == "__main__":
    print("\n" + "="*80)
    print("sort_node_adj Bug 影响分析工具")
    print("="*80)
    
    # 运行测试用例分析
    analyze_test_cases()
    
    # 估算真实影响
    estimate_real_world_impact()
    
    # 提供建议
    provide_recommendations()
    
    print("\n" + "="*80)
    print("分析完成")
    print("="*80)
    print("\n下一步：")
    print("1. 在实际数据集上验证x坐标重复比例")
    print("2. 根据实际影响决定修复优先级")
    print("3. 应用修复并测试")
    print("\n详细分析见: SORT_NODE_ADJ_BUG_ANALYSIS.md")
