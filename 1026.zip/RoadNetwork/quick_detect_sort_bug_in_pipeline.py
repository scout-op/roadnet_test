"""
快速检测：直接在数据pipeline中插入统计代码
不需要修改代码，只需运行几个batch就能看到影响

运行方法：
python quick_detect_sort_bug_in_pipeline.py

原理：
猴子补丁(monkey patch)临时替换sort_node_adj方法，
在运行时统计bug触发情况
"""

import os
import sys
import numpy as np
from collections import Counter

# 添加项目路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# 全局统计
GLOBAL_STATS = {
    'total_subgraphs': 0,
    'affected_subgraphs': 0,
    'total_nodes': 0,
    'affected_nodes': 0,
    'examples': [],
}


def patched_sort_node_adj(original_method):
    """创建带统计的sort_node_adj包装器"""
    
    def wrapper(self, subgraph):
        """包装后的sort_node_adj"""
        GLOBAL_STATS['total_subgraphs'] += 1
        
        # 获取原始数据
        nodes_list = subgraph.nodes_list
        if len(nodes_list) == 0:
            return original_method(self, subgraph)
        
        # 提取x坐标
        x_list = [node.position[0] for node in nodes_list]
        
        # 检测重复
        unique_x = len(set(x_list))
        total = len(x_list)
        
        GLOBAL_STATS['total_nodes'] += total
        
        if unique_x < total:
            # 有重复，会触发bug
            GLOBAL_STATS['affected_subgraphs'] += 1
            
            # 模拟bug结果
            x_new = sorted(x_list)
            idx_buggy = [x_list.index(i) for i in x_new]
            
            # 统计丢失节点
            missing = [i for i in range(total) if i not in idx_buggy]
            GLOBAL_STATS['affected_nodes'] += len(missing)
            
            # 记录示例（前10个）
            if len(GLOBAL_STATS['examples']) < 10:
                GLOBAL_STATS['examples'].append({
                    'total_nodes': total,
                    'unique_x': unique_x,
                    'missing_count': len(missing),
                    'missing_indices': missing,
                    'x_coords': x_list[:10],  # 只保存前10个坐标
                })
        
        # 调用原始方法
        return original_method(self, subgraph)
    
    return wrapper


def apply_monkey_patch():
    """应用猴子补丁"""
    try:
        from rntr.core.centerline.structures import pryordered_bz_centerline
        from rntr.core.centerline.structures import pryordered_bz_plcenterline
        from rntr.core.centerline.structures import av2_ordered_bz_centerline
        
        # 找到所有需要patch的类
        classes_to_patch = [
            (pryordered_bz_centerline, 'OrderedBzSceneGraph'),
            (pryordered_bz_plcenterline, 'OrderedBzPlSceneGraph'),
            (av2_ordered_bz_centerline, 'Av2OrderedBzSceneGraph'),
        ]
        
        patched_count = 0
        for module, class_name in classes_to_patch:
            try:
                cls = getattr(module, class_name)
                if hasattr(cls, 'sort_node_adj'):
                    original = cls.sort_node_adj
                    cls.sort_node_adj = patched_sort_node_adj(original)
                    patched_count += 1
                    print(f"✅ Patched {class_name}.sort_node_adj")
            except Exception as e:
                print(f"⚠️ Failed to patch {class_name}: {e}")
        
        print(f"\n总共patch了 {patched_count} 个类\n")
        return patched_count > 0
        
    except Exception as e:
        print(f"❌ Failed to apply monkey patch: {e}")
        return False


def run_quick_test():
    """运行快速测试：加载几个batch的数据"""
    print("="*80)
    print("快速检测 sort_node_adj bug")
    print("="*80)
    
    # 应用补丁
    if not apply_monkey_patch():
        print("无法应用补丁，退出")
        return
    
    # 尝试加载配置和数据
    try:
        from mmcv import Config
        from mmdet.datasets import build_dataset
        
        # 加载配置
        config_path = 'projects/RoadNetwork/configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py'
        if not os.path.exists(config_path):
            config_path = 'configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py'
        
        if not os.path.exists(config_path):
            print(f"配置文件不存在: {config_path}")
            print("请从项目根目录运行此脚本")
            return
        
        print(f"加载配置: {config_path}")
        cfg = Config.fromfile(config_path)
        
        # 构建数据集（只加载几个样本）
        print("构建数据集...")
        dataset = build_dataset(cfg.data.train)
        
        # 加载前N个样本
        num_samples = min(100, len(dataset))
        print(f"\n加载 {num_samples} 个样本进行统计...\n")
        
        for i in range(num_samples):
            if i % 10 == 0:
                print(f"处理 {i}/{num_samples}...")
            
            try:
                data = dataset[i]
            except Exception as e:
                print(f"样本 {i} 加载失败: {e}")
                continue
        
        # 打印统计结果
        print_statistics()
        
    except Exception as e:
        print(f"运行测试失败: {e}")
        import traceback
        traceback.print_exc()


def print_statistics():
    """打印统计结果"""
    stats = GLOBAL_STATS
    
    total_subgraphs = stats['total_subgraphs']
    affected_subgraphs = stats['affected_subgraphs']
    total_nodes = stats['total_nodes']
    affected_nodes = stats['affected_nodes']
    
    if total_subgraphs == 0:
        print("\n⚠️ 没有处理任何子图，可能是数据加载失败")
        return
    
    subgraph_ratio = affected_subgraphs / total_subgraphs * 100
    node_ratio = affected_nodes / total_nodes * 100 if total_nodes > 0 else 0
    
    print("\n" + "="*80)
    print("统计结果")
    print("="*80)
    print(f"\n子图统计:")
    print(f"  总子图数:       {total_subgraphs:>6}")
    print(f"  受影响子图:     {affected_subgraphs:>6}  ({subgraph_ratio:.1f}%)")
    print(f"\n节点统计:")
    print(f"  总节点数:       {total_nodes:>6}")
    print(f"  丢失节点数:     {affected_nodes:>6}  ({node_ratio:.1f}%)")
    
    print(f"\n严重程度: ", end="")
    if subgraph_ratio < 5:
        print("✅ 低")
    elif subgraph_ratio < 10:
        print("⚠️ 中")
    else:
        print("🔴 高")
    
    if len(stats['examples']) > 0:
        print(f"\n受影响示例 (前{len(stats['examples'])}个):")
        for i, ex in enumerate(stats['examples'][:5]):
            print(f"\n  示例 {i+1}:")
            print(f"    节点数: {ex['total_nodes']}")
            print(f"    唯一x: {ex['unique_x']}")
            print(f"    丢失节点: {ex['missing_count']} 个 (索引: {ex['missing_indices']})")
            if ex['x_coords']:
                print(f"    x坐标样本: {[f'{x:.1f}' for x in ex['x_coords'][:5]]}")
    
    print("\n" + "="*80)
    
    # 外推到全数据集
    if affected_subgraphs > 0:
        print("\n外推到全数据集 (假设40000训练样本，每样本5子图):")
        total_estimated = 40000 * 5
        affected_estimated = int(total_estimated * subgraph_ratio / 100)
        node_affected_estimated = int(40000 * 20 * node_ratio / 100)
        
        print(f"  预估受影响子图: ~{affected_estimated:,}")
        print(f"  预估丢失节点:   ~{node_affected_estimated:,}")
        print(f"\n建议: ", end="")
        
        if subgraph_ratio >= 10:
            print("🔴 立即修复 + 可能需要重新训练")
        elif subgraph_ratio >= 5:
            print("⚠️ 本周内修复")
        else:
            print("✅ 可延后修复")
    
    print("\n" + "="*80)


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--num-samples', type=int, default=100,
                        help='Number of samples to test')
    args = parser.parse_args()
    
    run_quick_test()


if __name__ == '__main__':
    main()
