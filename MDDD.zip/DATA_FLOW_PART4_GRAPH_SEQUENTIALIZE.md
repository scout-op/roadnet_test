# AR-RNTR 数据流分析 - Part 4: 图结构构建与序列化（核心）

## Stage 3 & 4: 图结构构建和序列生成

这是数据流中最核心的部分，将centerlines转换为论文中定义的RoadNet Sequence。

### 3.1 TransformOrderedBzLane2Graph Transform

**文件**: `rntr/transforms/loading.py:685-733`

```python
@TRANSFORMS.register_module()
class TransformOrderedBzLane2Graph(object):
    """
    核心Transform：将NusOrederedBzCenterLine对象转换为序列
    
    论文对应：Section 3.2 - Coupled RoadNet Sequence
    """
    def __init__(self, n_control=3, orderedDFS=True):
        self.order = orderedDFS      # 是否使用有序DFS
        self.n_control = n_control   # Bezier控制点数量（论文中为3）

    def __call__(self, results):
        centerlines = results['center_lines']  # NusOrederedBzCenterLine对象
        
        # Step 1: 导出节点和邻接矩阵
        nodes, nodes_adj = centerlines.export_node_adj()
        
        # Step 2: 分割子图
        centerlines.sub_graph_split()
        
        # Step 3: 构建场景图对象
        scene_graph = OrderedBzSceneGraph(
            centerlines.subgraphs_nodes,
            centerlines.subgraphs_adj,
            centerlines.subgraphs_points_in_between_nodes,
            self.n_control
        )
        
        # Step 4: 序列化（最关键的步骤）
        scene_sentance, scene_sentance_list = scene_graph.sequelize_new(
            orderedDFS=self.order
        )
        
        # Step 5: 转换为整数序列
        centerline_sequence = sentance2bzseq(
            scene_sentance_list,
            centerlines.pc_range,
            centerlines.dx,
            centerlines.bz_pc_range,
            centerlines.bz_dx,
            centerlines.bz_nx,
            centerlines.nx
        )
        
        # Step 6: 拆分为不同的数组
        clause_length = 4 + 2*(self.n_control-2)  # 4 + 2*1 = 6
        
        if len(centerline_sequence) % clause_length != 0:
            centerline_sequence = centerline_sequence[:
                (len(centerline_sequence)//clause_length*clause_length)]
        
        # 每6个元素一组：[x, y, label, connect, coeff_x, coeff_y]
        centerline_coord = np.stack([
            centerline_sequence[::clause_length],      # x坐标
            centerline_sequence[1::clause_length]      # y坐标
        ], axis=1)
        
        centerline_label = centerline_sequence[2::clause_length]    # 类别
        centerline_connect = centerline_sequence[3::clause_length]  # 连接索引
        centerline_coeff = np.stack([
            centerline_sequence[k::clause_length] 
            for k in range(4, clause_length)
        ], axis=1)  # Bezier系数 (coeff_x, coeff_y)
        
        # Step 7: 保存到results
        results['centerline_sequence'] = centerline_sequence
        results['centerline_coord'] = centerline_coord
        results['centerline_label'] = centerline_label
        results['centerline_connect'] = centerline_connect
        results['centerline_coeff'] = centerline_coeff
        results['n_control'] = self.n_control
        
        return results
```

### 3.2 详解各步骤

#### 3.2.1 export_node_adj() - 导出节点和邻接矩阵

**目的**: 将centerlines列表转换为图的节点和边表示

**实现逻辑**:
```python
def export_node_adj(self):
    """
    从centerlines构建图结构
    
    返回:
        all_nodes: List[Node对象], 每个Node代表一条centerline的端点
        adj: np.array (N, N), 邻接矩阵
    """
    # 为每条centerline创建起点和终点Node
    all_nodes = []
    for i, centerline in enumerate(self.centerlines):
        start_pt = centerline[self.start_point_idxs[i]]
        end_pt = centerline[self.end_point_idxs[i]]
        
        start_node = Node(position=start_pt)
        end_node = Node(position=end_pt)
        
        start_node.node_index = 2*i
        end_node.node_index = 2*i + 1
        
        all_nodes.append(start_node)
        all_nodes.append(end_node)
    
    # 构建邻接矩阵
    N = len(all_nodes)
    adj = np.zeros((N, N), dtype=np.int64)
    
    for i, centerline_id in enumerate(self.centerline_ids):
        start_idx = 2*i
        end_idx = 2*i + 1
        
        # 连接同一条centerline的起点和终点
        adj[start_idx, end_idx] = 1
        adj[end_idx, start_idx] = -1
        
        # 连接不同centerlines（根据incoming/outgoing关系）
        for outgoing_id in self.outgoing_ids[i]:
            if outgoing_id in self.centerline_ids:
                j = self.centerline_ids.index(outgoing_id)
                # 连接当前centerline的终点到下一条centerline的起点
                adj[end_idx, 2*j] = 1
                adj[2*j, end_idx] = -1
    
    self.all_nodes = all_nodes
    self.adj = adj
    return all_nodes, adj
```

#### 3.2.2 sub_graph_split() - 子图分割

**目的**: 将整个road network分割为多个连通子图

**代码位置**: `pryordered_bz_centerline.py:565-623`

```python
def sub_graph_split(self):
    """
    使用DFS将graph分割为连通子图
    
    论文对应：将DAG分解为Directed Forest
    """
    def dfs(index, visited, subgraph_nodes, adj):
        if visited[index]:
            return
        visited[index] = True
        subgraph_nodes.append(index)
        
        # 遍历所有邻居（入边和出边）
        for idx, i in enumerate(adj[index]):
            if adj[index][idx] == 1 or adj[index][idx] == -1:
                dfs(idx, visited, subgraph_nodes, adj)
    
    # 对每个未访问的节点进行DFS
    visited = [False for i in self.all_nodes]
    subgraphs_nodes = []
    
    for idx, node in enumerate(self.all_nodes):
        subgraph_nodes = []
        if not visited[idx]:
            dfs(idx, visited, subgraph_nodes, self.adj)
        
        # 过滤掉单节点子图
        if len(subgraph_nodes) > 1:
            subgraphs_nodes.append(subgraph_nodes)
    
    # 为每个子图构建独立的节点列表和邻接矩阵
    self.subgraphs_nodes = []
    self.subgraphs_adj = []
    self.subgraphs_points_in_between_nodes = []
    
    for sub_nodes in subgraphs_nodes:
        # 提取子图节点
        sub_node_list = [self.all_nodes[idx] for idx in sub_nodes]
        
        # 提取子图邻接矩阵
        n = len(sub_nodes)
        subgraph_adj = np.zeros((n, n), dtype=np.int64)
        for i in range(n):
            for j in range(n):
                subgraph_adj[i][j] = self.adj[sub_nodes[i]][sub_nodes[j]]
        
        # 提取子图的边上点信息
        between_points = {}
        for i in range(n):
            for j in range(n):
                if subgraph_adj[i][j] == 1:
                    between_points[(i, j)] = self.points_in_between_nodes[
                        (sub_nodes[i], sub_nodes[j])
                    ]
        
        self.subgraphs_nodes.append(sub_node_list)
        self.subgraphs_adj.append(subgraph_adj)
        self.subgraphs_points_in_between_nodes.append(between_points)
```

#### 3.2.3 OrderedBzSceneGraph - 场景图对象

**文件**: 定义在`centerline_utils.py`中

```python
class OrderedBzSceneGraph(object):
    """
    管理所有子图的场景图对象
    负责对子图进行序列化
    """
    def __init__(self, subgraphs_nodes, subgraphs_adj, 
                 subgraphs_points_in_between_nodes, n_control=3):
        self.subgraphs_nodes = subgraphs_nodes
        self.subgraphs_adj = subgraphs_adj
        self.subgraphs_points = subgraphs_points_in_between_nodes
        self.n_control = n_control
        
        # 为每个子图创建LaneGraph对象
        self.subgraph = []
        for i in range(len(subgraphs_nodes)):
            # 计算Bezier系数
            points_with_coeff = self._fit_bezier(
                subgraphs_nodes[i],
                subgraphs_adj[i],
                subgraphs_points_in_between_nodes[i],
                n_control
            )
            
            lane_graph = OrderedBzLaneGraph(
                subgraphs_nodes[i],
                subgraphs_adj[i],
                points_with_coeff
            )
            self.subgraph.append(lane_graph)
        
        self.num = len(self.subgraph)
    
    def _fit_bezier(self, nodes, adj, points_between, n_control):
        """
        拟合Bezier曲线，计算控制点
        
        论文对应：Section 3.1 - 使用n阶Bezier曲线表示centerline
        """
        points_with_coeff = {}
        
        for (i, j), pts in points_between.items():
            if len(pts) < 2:
                continue
            
            # 起点和终点
            p0 = nodes[i].position[:2]
            p_end = nodes[j].position[:2]
            
            # 拟合Bezier曲线，获取中间控制点
            # n_control=3 表示3阶Bezier（4个控制点：起点、2个中间、终点）
            # 论文中只存储1个中间控制点（n_control-2=1）
            control_points = fit_bezier_curve(pts, n_control)
            
            # 只保存中间控制点（不包括起点和终点）
            # 对于n_control=3，保存1个中间控制点的(x,y)
            coeff = control_points[1:-1].flatten()  # shape: (2*(n_control-2),)
            
            points_with_coeff[(i, j)] = coeff
        
        return points_with_coeff
```

#### 3.2.4 sequelize_new() - 有序DFS序列化

**文件**: `centerline_utils.py:363-485`

**核心思想**: 按照拓扑顺序遍历子图，生成包含节点类型的序列

```python
def sequelize_new(self, orderedDFS=True):
    """
    序列化所有子图
    
    论文对应：Section 3.2 - 从Directed Forest生成RoadNet Sequence
    
    返回:
        result: 扁平化的节点列表（带子图ID）
        result_list: 每个子图的节点列表
    """
    # 1. 按x坐标排序子图（从左到右）
    self.subgraphs_sorted = sorted(
        self.subgraph,
        key=lambda x: x.first_start_node.position[0]
    )
    
    # 2. 对每个子图进行序列化
    result = []
    result_list = []
    
    for idx, subgraph in enumerate(self.subgraphs_sorted):
        subgraph_sequence = self.subgraph_sequelize(subgraph)
        result.extend([(idx, node) for node in subgraph_sequence])
        result_list.append(subgraph_sequence)
    
    return result, result_list

def subgraph_sequelize(self, subgraph):
    """
    序列化单个子图
    
    步骤：
    1. 按照拓扑顺序（有序DFS）排列节点
    2. 确定每个节点的类型（start, continue, fork, merge）
    """
    nodes = subgraph.nodes_list
    adj = subgraph.nodes_adj
    nodes_points = subgraph.nodes_points
    
    # Step 1: 有序DFS遍历
    start_nodes_sorted = subgraph.start_nodes_idx_sorted  # 起始节点按x坐标排序
    
    visited = [False] * len(nodes)
    ordered_nodes = []
    
    for start_idx in start_nodes_sorted:
        if not visited[start_idx]:
            dfs_result = self._dfs_traverse(start_idx, visited, adj)
            ordered_nodes.extend(dfs_result)
    
    # Step 2: 为每个节点分配序列索引
    for idx, node in enumerate(ordered_nodes):
        node.sque_index = idx
    
    # Step 3: 确定节点类型
    final_sequence = self.get_node_type(ordered_nodes, adj)
    
    return final_sequence

def get_node_type(self, nodes, adj):
    """
    确定每个节点的类型
    
    论文对应：Section 3.2 - 类别定义
    - Ancestor (start): 0 → 类型为0
    - Lineal (continue): 1 → 类型为1
    - Offshoot (fork): 2 → 类型为2
    - Clone (merge): 3 → 类型为3
    """
    # 1. 标记start节点（没有入边）
    for i in range(len(nodes)):
        if np.min(adj[i]) > -1:  # 没有-1（入边）
            nodes[i].sque_type = 'start'
    
    # 2. 标记continue节点（前驱是i-1）
    for i in range(1, len(nodes)):
        if adj[i][i-1] == -1:
            nodes[i].sque_type = 'continue'
    
    # 3. 标记fork节点（前驱不是i-1）
    split_nodes = []  # 用于处理一个节点需要分裂为多个的情况
    
    for i in range(1, len(nodes)):
        father_indices = np.argwhere(adj[i] == -1).flatten()
        
        for father_idx in father_indices:
            if father_idx < i - 1:  # 不是直接前驱
                if nodes[i].sque_type is None:
                    nodes[i].sque_type = "fork"
                    nodes[i].fork_from_index = father_idx
                else:
                    # 节点已经有类型，需要分裂
                    cp_fork = copy.deepcopy(nodes[i])
                    cp_fork.sque_type = 'fork'
                    cp_fork.fork_from_index = father_idx
                    split_nodes.append(cp_fork)
    
    # 4. 标记merge节点（后继索引小于当前索引）
    for i in range(1, len(nodes)):
        child_indices = np.argwhere(adj[i] == 1).flatten()
        
        for child_idx in child_indices:
            if child_idx < i:  # 后继在前面（merge到之前的节点）
                cp_merge = copy.deepcopy(nodes[i])
                cp_merge.sque_type = 'merge'
                cp_merge.merge_with_index = child_idx
                split_nodes.append(cp_merge)
    
    # 5. 插入分裂的节点
    nodes_new = copy.deepcopy(nodes)
    for i, split_node in enumerate(split_nodes):
        position = split_node.sque_index + i + 1
        nodes_new.insert(position, split_node)
    
    return nodes_new
```

#### 3.2.5 sentance2bzseq() - 转换为整数序列

**文件**: `centerline_utils.py:710-760`

**目的**: 将Node对象列表转换为扁平化的整数序列

```python
def sentance2bzseq(sentance, pc_range, dx, bz_pc_range, bz_dx, bz_nx, nx=None):
    """
    将节点序列转换为整数token序列
    
    论文对应：Section 3.2 - 6-integer tuple序列化
    
    参数:
        sentance: List[List[Node]] - 每个子图的节点列表
        pc_range: BEV范围 [-30, -15, -10, 30, 15, 10]
        dx: BEV分辨率 [0.3, 0.3, 20.0]
        bz_pc_range: Bezier范围（同pc_range）
        bz_dx: Bezier分辨率 [0.15, 0.15, 20.0]
        bz_nx: Bezier网格数量 [400, 200, 1]
        nx: BEV网格数量 [200, 100, 1]
    
    返回:
        seq: List[int] - 扁平化的整数序列
    """
    type_idx_map = {
        'start': 0,      # Ancestor
        'continue': 1,   # Lineal
        'fork': 2,       # Offshoot
        'merge': 3       # Clone
    }
    
    seq = []
    
    for sub_graph_idx, sub_sent in enumerate(sentance):
        for node in sub_sent:
            # 1. 转换坐标到网格索引
            node.position = (node.position - pc_range[:3]) / dx
            
            # 2. 更新序列索引（全局索引）
            if sub_graph_idx == 0:
                node.sque_index += 1
            else:
                node.sque_index = (node.sque_index + 
                                   sentance[sub_graph_idx-1][-1].sque_index + 1)
            
            # 3. 添加顶点坐标 (vx, vy)
            if nx is not None:
                # 限制在网格范围内
                x_coord = int(np.clip(node.position[0], 0, nx[0] - 1))
                y_coord = int(np.clip(node.position[1], 0, nx[1] - 1))
                seq += [x_coord, y_coord]
            else:
                seq += node.position[:2].astype(int).tolist()
            
            # 4. 添加类别 (vc)
            seq.append(type_idx_map[node.sque_type])
            
            # 5. 添加连接索引 (vd)
            if node.sque_type == "fork":
                # Fork节点：记录从哪个节点fork出来
                if sub_graph_idx == 0:
                    node.fork_from_index += 1
                else:
                    node.fork_from_index = (node.fork_from_index + 
                                           sentance[sub_graph_idx-1][-1].sque_index + 1)
                seq.append(node.fork_from_index)
                
            elif node.sque_type == "merge":
                # Merge节点：记录merge到哪个节点
                if sub_graph_idx == 0:
                    node.merge_with_index += 1
                else:
                    node.merge_with_index = (node.merge_with_index + 
                                            sentance[sub_graph_idx-1][-1].sque_index + 1)
                seq.append(node.merge_with_index)
                
            else:
                # Start或Continue节点：连接索引为0
                seq.append(0)
            
            # 6. 添加Bezier系数 (epx, epy)
            if len(node.coeff) > 0:
                # 转换到Bezier网格坐标
                node.coeff = (node.coeff - bz_pc_range[:2]) / bz_dx[:2]
                node.coeff[0] = np.clip(node.coeff[0], 0, bz_nx[0]-1)
                node.coeff[1] = np.clip(node.coeff[1], 0, bz_nx[1]-1)
                node.coeff = node.coeff.astype(int)
                
                seq.append(node.coeff[0])  # epx
                seq.append(node.coeff[1])  # epy
            else:
                # 没有Bezier系数（如merge节点）
                seq.append(0)
                seq.append(0)
    
    return seq
```

### 3.3 序列化示例

假设有一个简单的road network：

```
A → B → C
    ↓
    D
```

**步骤1：export_node_adj()**
- Nodes: [A, B, C, D]
- Adjacency: A→B, B→C, B→D

**步骤2：sub_graph_split()**
- 只有一个连通子图：[A, B, C, D]

**步骤3：sequelize_new()**
- 有序DFS遍历：A → B → C → D
- 类型标注：
  - A: start (没有入边)
  - B: continue (A的直接后继)
  - C: continue (B的直接后继)
  - D: fork (B的非直接后继，fork_from_index=B的索引)

**步骤4：sentance2bzseq()**
```python
序列 = [
    # A (start)
    x_A, y_A, 0, 0, coeff_x_AB, coeff_y_AB,
    
    # B (continue)
    x_B, y_B, 1, 0, coeff_x_BC, coeff_y_BC,
    
    # C (continue)
    x_C, y_C, 1, 0, coeff_x_BC, coeff_y_BC,
    
    # D (fork from B)
    x_D, y_D, 2, B_idx, coeff_x_BD, coeff_y_BD,
]
```

每6个整数表示一个顶点-边对。

---

**下一部分**：模型输入格式化和训练过程
