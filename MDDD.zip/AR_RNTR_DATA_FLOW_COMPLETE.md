# AR-RNTR 数据流完整分析

本文档详细解析了AR-RNTR算法从nuScenes原始数据到模型训练输入的完整数据流程。

---

## 📋 文档结构

本分析分为5个部分，每个部分聚焦于数据流的不同阶段：

### [Part 1: 总览与架构](./DATA_FLOW_PART1_OVERVIEW.md)
- 数据流概述
- 核心组件映射（论文概念→代码实现）
- 数据Pipeline配置
- 数据结构层次
- 关键文件索引
- 与论文的对应关系

### [Part 2: 数据集加载详解](./DATA_FLOW_PART2_DATASET_LOADING.md)
- `CenterlineNuScenesDataset`类定义
- 数据加载流程（`load_data_list`, `parse_data_info`）
- Centerline原始数据格式
- 坐标系说明（Global/Ego/LiDAR/Camera）
- BEV网格定义
- Dataset与Pipeline的交互

### [Part 3: Centerline处理与数据增强](./DATA_FLOW_PART3_CENTERLINE_PROCESSING.md)
- `LoadNusOrderedBzCenterline` Transform
- `NusOrederedBzCenterLine`类详解
  - 初始化过程
  - BEV过滤（`filter_bev`）
- 数据增强
  - `CenterlineFlip` - 随机翻转
  - `CenterlineRotateScale` - 旋转和缩放

### [Part 4: 图结构构建与序列化（核心）](./DATA_FLOW_PART4_GRAPH_SEQUENTIALIZE.md)
- `TransformOrderedBzLane2Graph` Transform
- `export_node_adj()` - 导出节点和邻接矩阵
- `sub_graph_split()` - 子图分割
- `OrderedBzSceneGraph` - 场景图对象
- `sequelize_new()` - 有序DFS序列化
- `sentance2bzseq()` - 转换为整数序列
- 序列化示例

### [Part 5: 模型输入格式化与训练](./DATA_FLOW_PART5_MODEL_INPUT.md)
- `Pack3DCenterlineInputs` - 最终格式化
- DataLoader批处理
- `AR_RNTR`模型处理
  - `forward_train()` - 训练前向传播
  - `_build_input_sequence()` - 构建输入序列
  - Synthetic Noise Objects
- Token化映射
- 完整数据流总结

---

## 🎯 核心要点

### 1. 数据流概览

```
nuScenes原始数据 (.pkl)
    ↓
Stage 1: Dataset加载 (CenterlineNuScenesDataset)
    ↓
Stage 2: Centerline处理 (LoadNusOrderedBzCenterline)
    ↓
Stage 3: 图结构构建 (export_node_adj, sub_graph_split)
    ↓
Stage 4: 序列生成 (sequelize_new, sentance2bzseq)
    ↓
Stage 5: Token化与格式化 (Pack3DCenterlineInputs)
    ↓
模型训练输入
```

### 2. 关键转换

| 阶段 | 输入 | 输出 | 关键操作 |
|------|------|------|---------|
| Stage 1 | .pkl文件 | `center_lines`字典 | 解析nuScenes标注 |
| Stage 2 | 字典 | `NusOrederedBzCenterLine`对象 | BEV过滤、网格化 |
| Stage 3 | Centerline对象 | 节点列表+邻接矩阵 | DAG构建、子图分割 |
| Stage 4 | 图结构 | 整数序列 | 有序DFS、坐标离散化 |
| Stage 5 | 序列 | Tensor batch | Padding、Token编码 |

### 3. 论文对应

| 论文章节 | 核心算法 | 代码实现 |
|---------|---------|---------|
| 3.1 Road Network Modeling | DAG表示 | `export_node_adj()`, `sub_graph_split()` |
| 3.2 Coupled RoadNet Sequence | 序列化 | `sequelize_new()`, `sentance2bzseq()` |
| 3.3 Token Embedding | Token范围 | `ar_rntr.py:110-138` |
| 3.4 Transformer | 解码器 | `ARRNTRHead` |
| 4.1 Synthetic Noise | 噪声对象 | `_add_synthetic_noise()` |

### 4. 关键数据结构

#### 原始Centerline格式
```python
{
    'type': ['VEHICLE', ...],
    'centerline_ids': [1234, ...],
    'centerlines': [np.array([[x,y,z], ...]), ...],
    'incoming_ids': [[...], ...],
    'outgoing_ids': [[...], ...],
    'start_point_idxs': [0, ...],
    'end_point_idxs': [15, ...]
}
```

#### 序列格式（每6个整数一组）
```
[vx, vy, vc, vd, epx, epy, ...]
```
- `vx, vy`: 顶点坐标 ∈ [0, 199]
- `vc`: 类别 ∈ {0:start, 1:continue, 2:fork, 3:merge}
- `vd`: 连接索引 ∈ [0, N-1] (fork/merge时有效)
- `epx, epy`: Bezier系数 ∈ [0, 199]

#### Token映射
```python
vx, vy:     [0, 199]      # 坐标
vc:         [200, 203]    # 类别 + 200
vd:         [204, 403]    # 连接 + 204
epx, epy:   [404, 603]    # Bezier + 404
<padding>:  604
<start>:    605
<end>:      606
噪声tokens: 607-609
```

---

## 🔍 深入理解

### 为什么使用有序DFS?

论文Section 3.2提到使用拓扑排序将DAG转换为序列。代码中的**有序DFS**实现了这一点：
1. 按x坐标排序起始节点（从左到右）
2. 对每个起始节点进行DFS遍历
3. 确保节点类型正确标注（start/continue/fork/merge）

### 为什么需要Bezier曲线?

论文Section 3.1使用Bezier曲线表示centerline的几何形状：
- 输入：centerline上的多个采样点
- 输出：1个中间控制点（3阶Bezier，n_control=3）
- 优势：紧凑表示、平滑曲线

### 为什么需要子图分割?

nuScenes场景中的road network可能包含多个不连通的子图（例如：主路和远处的辅路）。子图分割确保：
1. 每个子图独立序列化
2. 序列索引在子图内部连续
3. 减少序列长度，提高训练效率

---

## 📊 数据统计

### 典型nuScenes场景
- **图像数量**: 6张（6个相机视角）
- **Centerline数量**: 10-50条
- **每条Centerline点数**: 10-30个
- **序列长度**: 60-300个节点（视场景复杂度）
- **Token序列长度**: 360-1800个token（每节点6个token）

### BEV网格配置
```python
grid_conf = {
    'xbound': [-30.0, 30.0, 0.3],  # 200网格
    'ybound': [-15.0, 15.0, 0.3],  # 100网格
}

bz_grid_conf = {
    'xbound': [-30.0, 30.0, 0.15],  # 400网格（更精细）
    'ybound': [-15.0, 15.0, 0.15],  # 200网格
}
```

---

## 🛠️ 关键代码文件

| 文件 | 功能 | 重要程度 |
|------|------|---------|
| `centerline_nuscenes_dataset.py` | 数据集加载 | ⭐⭐⭐⭐⭐ |
| `transforms/loading.py` | Transform定义 | ⭐⭐⭐⭐⭐ |
| `pryordered_bz_centerline.py` | Centerline数据结构 | ⭐⭐⭐⭐⭐ |
| `centerline_utils.py` | 图序列化工具 | ⭐⭐⭐⭐⭐ |
| `ar_rntr.py` | 模型主文件 | ⭐⭐⭐⭐ |
| `ar_rntr_head.py` | Transformer头 | ⭐⭐⭐⭐ |

---

## ✅ 验证要点

在理解数据流后，可以验证以下要点：

1. **序列长度一致性**: `centerline_sequence`长度 = `centerline_coord.shape[0] * 6`
2. **Token范围正确**: 所有token ∈ [0, 609]
3. **连接索引有效**: `centerline_connect[i]` ≤ i（fork/merge时）
4. **Bezier系数有效**: `centerline_coeff` ∈ [0, 199]
5. **节点类型分布**: start < continue < fork/merge

---

## 📖 使用建议

1. **按顺序阅读**: 建议按Part 1→5的顺序阅读，逐步深入
2. **对照代码**: 文档中标注了所有关键代码的位置，建议对照阅读
3. **可视化理解**: 可以自己绘制数据流图和序列化示例
4. **调试验证**: 在关键位置添加print语句，观察数据变化

---

## 🔗 相关文档

- [AR-RNTR论文代码对齐验证](./AR_RNTR_PAPER_CODE_ALIGNMENT_VERIFICATION.md)
- [nuScenes数据集文档](https://www.nuscenes.org/nuscenes)
- [MMDetection3D文档](https://mmdetection3d.readthedocs.io/)

---

**作者**: Cascade AI Assistant  
**日期**: 2025-01-23  
**版本**: 1.0  
**论文**: arXiv-2402.08207v3 - Auto-Regressive RoadNetTransformer

---

## 📝 更新日志

- **2025-01-23**: 初始版本，完整5部分数据流分析
