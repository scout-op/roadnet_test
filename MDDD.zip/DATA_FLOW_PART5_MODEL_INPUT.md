# AR-RNTR 数据流分析 - Part 5: 模型输入格式化与训练

## Stage 5: Token化与模型输入

### 5.1 Pack3DCenterlineInputs - 最终格式化

**文件**: `rntr/transforms/formating.py`

这个transform将所有数据打包成模型需要的格式：

```python
@TRANSFORMS.register_module()
class Pack3DCenterlineInputs(object):
    """
    将pipeline处理后的results字典打包成模型输入格式
    """
    def __init__(self, keys, meta_keys):
        self.keys = keys          # 需要保留的数据key
        self.meta_keys = meta_keys  # 需要保留的元信息key
    
    def __call__(self, results):
        """
        打包数据
        
        输入results包含：
        - img: List[np.ndarray] - 6张图像
        - centerline_coord: np.ndarray (N, 2)
        - centerline_label: np.ndarray (N,)
        - centerline_connect: np.ndarray (N,)
        - centerline_coeff: np.ndarray (N, 2)
        - lidar2img: List[np.ndarray]
        - ...其他元信息
        """
        packed_results = {}
        
        # 1. 打包图像数据
        if 'img' in results:
            imgs = results['img']
            if isinstance(imgs, list):
                # (N_views, H, W, C) → (N_views, C, H, W)
                imgs = [img.transpose(2, 0, 1) for img in imgs]
                imgs = np.stack(imgs, axis=0)
            packed_results['imgs'] = torch.from_numpy(imgs)
        
        # 2. 打包centerline数据
        packed_results['centerline_coord'] = torch.from_numpy(
            results['centerline_coord']
        ).long()
        packed_results['centerline_label'] = torch.from_numpy(
            results['centerline_label']
        ).long()
        packed_results['centerline_connect'] = torch.from_numpy(
            results['centerline_connect']
        ).long()
        packed_results['centerline_coeff'] = torch.from_numpy(
            results['centerline_coeff']
        ).long()
        
        # 3. 打包变换矩阵
        packed_results['lidar2img'] = [
            torch.from_numpy(mat).float() for mat in results['lidar2img']
        ]
        
        # 4. 打包元信息
        meta_info = {}
        for key in self.meta_keys:
            if key in results:
                meta_info[key] = results[key]
        packed_results['meta_info'] = meta_info
        
        return packed_results
```

### 5.2 DataLoader批处理

DataLoader会将多个样本组合成batch：

```python
# 单个样本
sample = {
    'imgs': Tensor(6, 3, H, W),
    'centerline_coord': Tensor(N, 2),
    'centerline_label': Tensor(N,),
    'centerline_connect': Tensor(N,),
    'centerline_coeff': Tensor(N, 2),
    'lidar2img': List[Tensor(4, 4)] * 6,
}

# Batch (B个样本)
batch = {
    'imgs': Tensor(B, 6, 3, H, W),
    'centerline_coord': List[Tensor(N_i, 2)] * B,  # 每个样本N不同
    'centerline_label': List[Tensor(N_i,)] * B,
    'centerline_connect': List[Tensor(N_i,)] * B,
    'centerline_coeff': List[Tensor(N_i, 2)] * B,
    'lidar2img': List[List[Tensor(4, 4)] * 6] * B,
}
```

注意：centerline相关的数据是列表，因为每个样本的节点数量N不同。

### 5.3 AR_RNTR模型处理

#### 5.3.1 forward_train() - 训练前向传播

**文件**: `rntr/ar_rntr.py:494-543`

```python
def forward_train(self, img, img_metas, **kwargs):
    """
    训练阶段的前向传播
    
    参数:
        img: (B, N_views, C, H, W) - 多视角图像
        img_metas: List[dict] - 元信息
        kwargs: 包含centerline相关数据
    """
    # Step 1: 提取BEV特征
    bev_feat = self.extract_feat(img, img_metas)  # (B, C_bev, H_bev, W_bev)
    
    # Step 2: 获取GT centerline数据
    centerline_coord = kwargs['centerline_coord']      # List[Tensor(N_i, 2)]
    centerline_label = kwargs['centerline_label']      # List[Tensor(N_i,)]
    centerline_connect = kwargs['centerline_connect']  # List[Tensor(N_i,)]
    centerline_coeff = kwargs['centerline_coeff']      # List[Tensor(N_i, 2)]
    
    # Step 3: 构建输入和输出序列
    input_sequences = []
    output_sequences = []
    
    for i in range(len(centerline_coord)):
        # 3.1 获取单个样本的数据
        coord = centerline_coord[i]      # (N, 2)
        label = centerline_label[i]      # (N,)
        connect = centerline_connect[i]  # (N,)
        coeff = centerline_coeff[i]      # (N, 2)
        
        # 3.2 构建输入序列（teacher forcing）
        # 论文对应：Section 3.3 - 输入序列包含<start> token
        input_seq = self._build_input_sequence(
            coord, label, connect, coeff
        )  # (N+1, D) - 包含<start>
        
        # 3.3 构建输出序列（目标）
        output_seq = self._build_output_sequence(
            coord, label, connect, coeff
        )  # (N+1, D) - 包含<end>
        
        input_sequences.append(input_seq)
        output_sequences.append(output_seq)
    
    # Step 4: Padding到相同长度
    max_len = max([seq.shape[0] for seq in input_sequences])
    
    input_batch = []
    output_batch = []
    padding_mask = []
    
    for input_seq, output_seq in zip(input_sequences, output_sequences):
        cur_len = input_seq.shape[0]
        pad_len = max_len - cur_len
        
        # Padding
        input_padded = torch.cat([
            input_seq,
            torch.full((pad_len, input_seq.shape[1]), 
                      self.no_known, dtype=torch.long)
        ], dim=0)
        
        output_padded = torch.cat([
            output_seq,
            torch.full((pad_len, output_seq.shape[1]), 
                      self.no_known, dtype=torch.long)
        ], dim=0)
        
        # Mask (True表示有效位置)
        mask = torch.cat([
            torch.ones(cur_len, dtype=torch.bool),
            torch.zeros(pad_len, dtype=torch.bool)
        ], dim=0)
        
        input_batch.append(input_padded)
        output_batch.append(output_padded)
        padding_mask.append(mask)
    
    input_batch = torch.stack(input_batch, dim=0)    # (B, max_len, D)
    output_batch = torch.stack(output_batch, dim=0)  # (B, max_len, D)
    padding_mask = torch.stack(padding_mask, dim=0)  # (B, max_len)
    
    # Step 5: Transformer解码
    predictions = self.pts_bbox_head(
        bev_feat,           # BEV特征（作为memory）
        input_batch,        # 输入序列
        padding_mask        # Mask
    )  # (B, max_len, vocab_size)
    
    # Step 6: 计算损失
    losses = self.pts_bbox_head.loss(
        predictions,
        output_batch,
        padding_mask
    )
    
    return losses
```

#### 5.3.2 _build_input_sequence() - 构建输入序列

**代码位置**: `ar_rntr.py` 中的逻辑（简化版）

```python
def _build_input_sequence(self, coord, label, connect, coeff):
    """
    构建输入序列
    
    论文对应：Section 3.3 - Auto-regressive输入
    
    格式: [<start>, (vx1, vy1, vc1, vd1, epx1, epy1), ..., (vxN, vyN, vcN, vdN, epxN, epyN)]
    """
    N = coord.shape[0]
    
    # 1. <start> token
    start_token = torch.full((1, 6), self.start, dtype=torch.long)
    
    # 2. GT序列（每个节点6个token）
    sequence = torch.cat([
        coord,           # (N, 2) - vx, vy
        label.unsqueeze(1),   # (N, 1) - vc
        connect.unsqueeze(1), # (N, 1) - vd
        coeff            # (N, 2) - epx, epy
    ], dim=1)  # (N, 6)
    
    # 3. 拼接：<start> + GT序列
    input_seq = torch.cat([start_token, sequence], dim=0)  # (N+1, 6)
    
    return input_seq
```

#### 5.3.3 Synthetic Noise Objects - 数据增强

**论文对应**: Section 4.1 - 在训练时添加噪声对象

**代码位置**: `ar_rntr.py:494-543`

```python
def _add_synthetic_noise(self, input_seq, output_seq, noise_prob=0.1):
    """
    添加synthetic noise objects
    
    论文中的策略：
    1. 以一定概率在序列中插入噪声节点
    2. 噪声节点的token值设为特殊值
    """
    N = input_seq.shape[0]
    
    for i in range(1, N):  # 跳过<start>
        if random.random() < noise_prob:
            # 替换为噪声token
            input_seq[i, 2] = self.noise_label     # label设为噪声
            input_seq[i, 3] = self.noise_connect   # connect设为噪声
            
            # 输出序列对应位置仍为GT（用于计算损失）
            # 模型需要学会忽略噪声输入
    
    return input_seq, output_seq
```

### 5.4 Token化映射

**代码位置**: `ar_rntr.py:110-138`

```python
# Token范围定义（与论文Table 1对应）
self.num_center_classes = 200  # 坐标范围 [0, 199]
self.box_range = 200           # vx, vy ∈ [0, 199]
self.coeff_range = 200         # epx, epy ∈ [0, 199]

# Token偏移量
self.category_start = 200      # vc ∈ [200, 203]
self.connect_start = 204       # vd ∈ [204, 403]
self.coeff_start = 404         # epx, epy ∈ [404, 603]

# 特殊token
self.no_known = 604            # Padding token
self.start = 605               # <start> token
self.end = 606                 # <end> token
self.noise_connect = 607       # 噪声连接token
self.noise_label = 608         # 噪声标签token
self.noise_coeff = 609         # 噪声系数token

# 词汇表大小
vocab_size = 610
```

### 5.5 Token编码和解码

#### 5.5.1 编码 (Encoding)

```python
def encode_sequence(coord, label, connect, coeff):
    """
    将坐标和类别编码为token
    
    输入:
        coord: (N, 2) ∈ [0, 199] - 网格坐标
        label: (N,) ∈ [0, 3] - 类别
        connect: (N,) ∈ [0, N-1] - 连接索引
        coeff: (N, 2) ∈ [0, 199] - Bezier系数
    
    输出:
        tokens: (N, 6) - token序列
    """
    tokens = torch.cat([
        coord,                              # [0, 199]
        label + category_start,             # [200, 203]
        connect + connect_start,            # [204, 403]
        coeff + coeff_start                 # [404, 603]
    ], dim=1)
    
    return tokens
```

#### 5.5.2 解码 (Decoding)

```python
def decode_sequence(tokens):
    """
    将token序列解码回坐标和类别
    
    输入:
        tokens: (N, 6) - token序列
    
    输出:
        coord: (N, 2) - 坐标
        label: (N,) - 类别
        connect: (N,) - 连接索引
        coeff: (N, 2) - Bezier系数
    """
    coord = tokens[:, :2]  # [0, 199]
    label = tokens[:, 2] - category_start  # [0, 3]
    connect = tokens[:, 3] - connect_start  # [0, N-1]
    coeff = tokens[:, 4:6] - coeff_start  # [0, 199]
    
    return coord, label, connect, coeff
```

### 5.6 完整数据流总结

```
nuScenes原始数据 (.pkl)
    ↓ [CenterlineNuScenesDataset.parse_data_info]
{token, img_filename, lidar2img, center_lines: {...}}
    ↓ [OrgLoadMultiViewImageFromFiles]
+ img: List[np.ndarray]
    ↓ [LoadNusOrderedBzCenterline]
+ center_lines: NusOrederedBzCenterLine对象
    ↓ [ResizeCropFlipImage, NormalizeMultiviewImage]
图像预处理
    ↓ [CenterlineFlip, CenterlineRotateScale]
数据增强
    ↓ [TransformOrderedBzLane2Graph]
+ centerline_coord: (N, 2)
+ centerline_label: (N,)
+ centerline_connect: (N,)
+ centerline_coeff: (N, 2)
+ centerline_sequence: (N*6,)
    ↓ [Pack3DCenterlineInputs]
{
    imgs: Tensor(6, 3, H, W),
    centerline_coord: Tensor(N, 2),
    centerline_label: Tensor(N,),
    centerline_connect: Tensor(N,),
    centerline_coeff: Tensor(N, 2),
    lidar2img: List[Tensor]
}
    ↓ [DataLoader batching]
batch = {
    imgs: Tensor(B, 6, 3, H, W),
    centerline_*: List[Tensor] * B
}
    ↓ [AR_RNTR.forward_train]
- extract_feat() → bev_feat
- _build_input_sequence() → input_seq (with <start>)
- _build_output_sequence() → output_seq (with <end>)
- Padding → (B, max_len, 6)
    ↓ [ARRNTRHead]
- Token Embedding
- Transformer Decoder
- Vocabulary Prediction
    ↓
predictions: (B, max_len, vocab_size)
    ↓ [Loss Calculation]
- CrossEntropyLoss for each slot
- Mask padding positions
    ↓
losses: {loss_coords, loss_labels, loss_connects, loss_coeffs}
```

## 总结

### 关键点

1. **从DAG到序列**: 通过有序DFS遍历将road network DAG转换为线性序列
2. **节点类型**: start(0), continue(1), fork(2), merge(3) 对应论文的Ancestor, Lineal, Offshoot, Clone
3. **Bezier表示**: 使用3阶Bezier曲线，存储1个中间控制点的坐标
4. **Token化**: 将坐标、类别、连接、系数映射到不同的token范围
5. **Auto-regressive**: 使用teacher forcing训练，输入包含<start>，输出包含<end>
6. **Synthetic Noise**: 训练时添加噪声节点提高鲁棒性

### 论文与代码对应

| 论文章节 | 代码实现 |
|---------|---------|
| 3.1 Road Network Modeling | `export_node_adj()`, `sub_graph_split()` |
| 3.2 Coupled RoadNet Sequence | `sequelize_new()`, `sentance2bzseq()` |
| 3.3 Token Embedding | `ar_rntr.py:110-138` |
| 3.4 Transformer Architecture | `ARRNTRHead` |
| 4.1 Synthetic Noise Objects | `_add_synthetic_noise()` |
| 4.2 Topology-Inherited Training | `TIT` module in `ar_rntr.py` |

数据流的核心在于将复杂的road network转换为适合Transformer处理的序列格式，同时保留拓扑信息（通过connect索引）和几何信息（通过Bezier系数）。
