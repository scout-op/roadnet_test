# AR-RNTR 数据流分析 - Part 1: 总览与架构

## 1. 数据流概述

AR-RNTR算法的数据处理流程将nuScenes原始数据转换为可训练的RoadNet序列，整个流程分为以下阶段：

```
nuScenes原始数据
    ↓
Stage 1: 数据集加载 (Dataset Loading)
    ↓
Stage 2: 数据预处理 (Data Preprocessing)
    ↓
Stage 3: 图结构构建 (Graph Construction)
    ↓
Stage 4: 序列生成 (Sequence Generation)
    ↓
Stage 5: Token化与格式化 (Tokenization & Formatting)
    ↓
训练输入 (Training Input)
```

## 2. 核心组件映射

### 2.1 论文概念 → 代码实现

| 论文概念 | 代码实现 | 文件位置 |
|---------|---------|---------|
| Road Network (DAG) | `OrderedBzSceneGraph` | `rntr/core/centerline/structures/` |
| Centerline with Bezier | `NusOrederedBzCenterLine` | `pryordered_bz_centerline.py` |
| Vertex (vx, vy, vc) | `centerline_coord`, `centerline_label` | 存储在results字典 |
| Edge (vd, coefficients) | `centerline_connect`, `centerline_coeff` | 存储在results字典 |
| RoadNet Sequence | `centerline_sequence` | 一维整数数组 |
| Token Embedding | Token constants in `AR_RNTR` | `ar_rntr.py:110-138` |

### 2.2 数据Pipeline配置

在配置文件 `configs/rntr_ar_roadseq/lss_ar_rntr_debug_fp32.py` 中定义：

```python
train_pipeline = [
    # Step 1: 加载多视角图像
    dict(type='OrgLoadMultiViewImageFromFiles', 
         to_float32=False),
    
    # Step 2: 加载Bezier centerline
    dict(type='LoadNusOrderedBzCenterline', 
         grid_conf=grid_conf, 
         bz_grid_conf=bz_grid_conf),
    
    # Step 3: 图像变换（resize, normalize等）
    dict(type='ResizeCropFlipImage', ...),
    dict(type='NormalizeMultiviewImage', ...),
    
    # Step 4: 数据增强
    dict(type='CenterlineFlip', prob=0.5),
    dict(type='CenterlineRotateScale', ...),
    
    # Step 5: 转换为图结构并生成序列
    dict(type='TransformOrderedBzLane2Graph', 
         n_control=3, 
         orderedDFS=True),
    
    # Step 6: 格式化为模型输入
    dict(type='Pack3DCenterlineInputs', ...),
]
```

## 3. 数据结构层次

### 3.1 nuScenes原始数据格式

```python
# 存储在 .pkl 文件中的标注
{
    'token': str,  # 场景唯一标识
    'lidar_path': str,
    'cams': {
        'CAM_FRONT': {...},
        'CAM_FRONT_LEFT': {...},
        # ... 6个相机
    },
    'center_lines': {
        'type': List[str],  # 车道类型
        'centerline_ids': List[int],  # 车道ID
        'centerlines': List[np.ndarray],  # 实际坐标 (N, 3)
        'incoming_ids': List[List[int]],  # 入边连接
        'outgoing_ids': List[List[int]],  # 出边连接
        'start_point_idxs': List[int],
        'end_point_idxs': List[int],
    }
}
```

### 3.2 中间处理结果 (results字典)

```python
results = {
    # 原始数据
    'token': str,
    'img_filename': List[str],  # 6张图像路径
    'lidar2img': List[np.ndarray],  # (6, 4, 4)
    'center_lines': NusOrederedBzCenterLine对象,
    
    # 经过TransformOrderedBzLane2Graph后新增：
    'centerline_sequence': np.ndarray,  # (M,) 一维序列
    'centerline_coord': np.ndarray,     # (N, 2) 顶点坐标
    'centerline_label': np.ndarray,     # (N,) 顶点类别
    'centerline_connect': np.ndarray,   # (N,) 连接索引
    'centerline_coeff': np.ndarray,     # (N, 2*(n_control-2)) Bezier系数
    'n_control': int,                   # Bezier控制点数量
}
```

### 3.3 最终训练输入格式

```python
# 传入AR_RNTR模型的batch
batch = {
    'imgs': torch.Tensor,  # (B, N_views, C, H, W)
    'lidar2img': List[torch.Tensor],
    'centerline_coord': torch.Tensor,  # (B, N, 2)
    'centerline_label': torch.Tensor,  # (B, N)
    'centerline_connect': torch.Tensor,  # (B, N)
    'centerline_coeff': torch.Tensor,  # (B, N, 2*(n_control-2))
}
```

## 4. 关键文件索引

| 功能 | 文件路径 |
|------|---------|
| 数据集类 | `rntr/centerline_nuscenes_dataset.py` |
| Transform操作 | `rntr/transforms/loading.py` |
| Centerline数据结构 | `rntr/core/centerline/structures/pryordered_bz_centerline.py` |
| 图序列化工具 | `rntr/transforms/centerline_utils.py` |
| 模型输入处理 | `rntr/ar_rntr.py:494-543` |

## 5. 与论文对应关系

### 5.1 Section 3.1 - Road Network Modeling

- **论文**：Road network as DAG G=(V,E)
- **代码**：`OrderedBzSceneGraph` 类管理节点和邻接矩阵
- **实现位置**：`centerline_utils.py:OrderedBzSceneGraph`

### 5.2 Section 3.2 - Coupled RoadNet Sequence

- **论文**：6-integer tuple (vx, vy, vc, vd, epx, epy)
- **代码**：`centerline_sequence` 扁平化存储，每6个元素一组
- **转换函数**：`sentance2bzseq()` 在 `centerline_utils.py:710`

### 5.3 Section 3.3 - Token Embedding

- **论文**：Table 1 定义token范围
- **代码**：`ar_rntr.py:110-138` 定义token常量
- **验证**：已在上一份文档中确认对齐

---

**下一部分**：详细解析各个阶段的代码实现
