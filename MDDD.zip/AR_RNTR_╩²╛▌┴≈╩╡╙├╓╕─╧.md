# AR-RNTR 数据流实用指南

> 本文档以数据流为主线，结合论文图表，简洁说明代码实现

---

## 数据流全景图

**论文参考**: Figure 2 (AR-RTSeq - 序列构建流程)

```
nuScenes原始数据 + HD Map
  ↓ 
【Stage 0】离线数据预处理 (create_data_pon_centerline.py)
  ↓ 输出: .pkl标注文件
【Stage 1】数据加载与解析
  ↓ 输出: center_lines字典
【Stage 2】BEV网格化与过滤
  ↓ 输出: NusOrederedBzCenterLine对象
【Stage 3】DAG构建
  ↓ 输出: 节点+邻接矩阵
【Stage 4】DAG→Directed Forest→序列
  ↓ 输出: RoadNet Sequence (整数数组)
【Stage 5】Token化与Padding
  ↓ 输出: 模型输入Tensor
模型训练/推理
```

---

## Stage 0: 离线数据预处理（生成.pkl文件）

**脚本**: `tools/create_data_pon_centerline.py`  
**核心模块**: `rntr/data/nuscenes_converter_pon_centerline.py`

这个阶段在**训练前**执行一次，将nuScenes原始数据和HD Map转换为训练可用的.pkl文件。

### 0.1 预处理目标

**输入**:
- nuScenes原始数据（图像、LiDAR、poses等）
- HD Map数据（每个location的lane和lane_connector）

**输出**:
- `nuscenes_centerline_infos_pon_train.pkl`
- `nuscenes_centerline_infos_pon_val.pkl`

### 0.2 关键参数

```bash
python tools/create_data_pon_centerline.py nuscenes \
    --root-path ./data/nuscenes \
    --version v1.0-trainval \
    --map_resolution 0.5 \
    --map_size -70 70 -70 70 \
    --out-dir ./data/nuscenes
```

参数说明：
- `map_resolution`: centerline采样分辨率（0.5米）
- `map_size`: BEV范围 [-70m, 70m] x [-70m, 70m]（预处理时范围更大）

### 0.3 预处理流程

**Step 1: 加载HD Map数据**

函数：`load_map_data()`

```python
# 为每个location加载地图
LOCATIONS = ['boston-seaport', 'singapore-onenorth', 
             'singapore-queenstown', 'singapore-hollandvillage']

for location in LOCATIONS:
    nusc_map = NuScenesMap(dataroot, location)
    # 离散化centerlines（采样）
    all_centers[location] = nusc_map.discretize_centerlines(resolution=0.5)
```

输出：每个centerline被离散化为0.5米间隔的点序列

**Step 2: 遍历所有样本**

函数：`_fill_trainval_infos()`，核心代码行286-348

对每个nuScenes sample：

1. **获取ego pose信息**
   ```python
   l2e_r = lidar2ego_rotation  # 四元数
   l2e_t = lidar2ego_translation
   e2g_r = ego2global_rotation
   e2g_t = ego2global_translation
   ```

2. **坐标转换：Global → Ego**
   
   转换公式（代码行287-291）：
   ```python
   # 构建 ego2global 变换矩阵
   e2g_mat = [[e2g_r_mat,  e2g_t],
              [0,          1    ]]  # 4x4齐次矩阵
   
   # 逆变换：global → ego
   center_in_ego = (e2g_mat^(-1) @ center_global^T)^T
   ```
   
   这将全局坐标系的centerline转换到当前车辆的ego坐标系

3. **BEV范围过滤**（代码行292-295）
   
   ```python
   # 检查每个点是否在BEV范围内
   in_center_x = (center[:, 0] <= 70) & (center[:, 0] >= -70)
   in_center_y = (center[:, 1] <= 70) & (center[:, 1] >= -70)
   in_center = in_center_x & in_center_y
   
   # 如果至少有一个点在范围内，保留这条centerline
   if np.max(in_center):
       # 只保留在范围内的点
       filtered_centerline = center[in_center, :]
   ```

4. **提取连接关系**（代码行300-301）
   
   ```python
   incoming_ids = map_api.get_incoming_lane_ids(centerline_id)
   outgoing_ids = map_api.get_outgoing_lane_ids(centerline_id)
   ```
   
   这些ID用于构建DAG的邻接关系

5. **确定起点和终点索引**（代码行306-348）
   
   **关键逻辑**：
   
   - **终点**：如果有outgoing lanes，终点是第一个outgoing lane的起点；否则是当前lane的end_pose
   - **起点**：如果有incoming lanes，起点是第一个incoming lane的终点；否则是当前lane的start_pose
   
   然后找到最近的采样点索引：
   ```python
   start_distance = ||centerline_points - start_pose||_2
   end_distance = ||centerline_points - end_pose||_2
   start_point_idx = argmin(start_distance)
   end_point_idx = argmin(end_distance)
   ```

6. **保存信息**（代码行271）
   
   ```python
   info['center_lines'] = {
       'type': [],              # 'lane' or 'lane_connector'
       'centerlines': [],       # List[np.array] - 采样点坐标
       'centerline_ids': [],    # lane token
       'incoming_ids': [],      # List[List[str]] - 入边IDs
       'outgoing_ids': [],      # List[List[str]] - 出边IDs
       'start_point_idxs': [], # int - 起点索引
       'end_point_idxs': [],   # int - 终点索引
   }
   ```

**Step 3: 相机数据**（代码行350-364）

为每个相机（6个）提取：
- 相机路径
- 内参矩阵
- sensor2lidar变换矩阵

**Step 4: 保存为.pkl**（代码行125-132）

```python
data = {
    'infos': train_nusc_infos,  # List[dict]
    'metadata': {'version': 'v1.0-trainval'}
}
mmengine.dump(data, 'nuscenes_centerline_infos_pon_train.pkl')
```

### 0.4 关键设计决策

1. **为什么预处理时用[-70, 70]范围，训练时用[-30, 15]?**
   - 预处理：保留更多数据，避免边界问题
   - 训练：只关注车辆前方可靠区域

2. **start/end索引的作用**
   - 确定centerline在采样点序列中的真实起止位置
   - 用于后续构建DAG时连接边

3. **为什么需要incoming/outgoing_ids?**
   - 构建DAG的邻接关系
   - 确定merge点和fork点

### 0.5 数据统计

处理后的.pkl文件包含：
- **训练集**：~28k个samples
- **验证集**：~6k个samples
- 每个sample包含：
  - 6张相机图像路径
  - LiDAR路径
  - 10-50条centerlines（视场景而定）
  - 每条centerline：10-100个采样点

---

## Stage 1: 数据加载与解析

### 1.1 nuScenes原始数据格式

**论文说明**: Section 3.1 - DAG定义

**关键数学定义**（论文Section 3.1）:

Road Network表示为有向无环图(DAG):
```
G = (V, E)
```
其中：
- **顶点集合** V：所有road landmarks（路口、停止线、分叉点、合并点）
- **边集合** E：连接landmarks的所有centerlines

**顶点定义**:
```
v = (v_x, v_y, v_c) ∈ V
```
- `v_x, v_y ∈ ℝ`: 顶点位置坐标（米）
- `v_c`: 顶点类别
  - 0: Ancestor (start节点)
  - 1: Lineal (continue节点)
  - 2: Offshoot (fork节点)
  - 3: Clone (merge节点)

**边定义**:
```
e = (e_s, e_t, e_px, e_py) ∈ E
```
- `e_s ∈ V`: 边的起点顶点
- `e_t ∈ V`: 边的终点顶点
- `e_px, e_py ∈ ℝ`: Bezier曲线中间控制点坐标

**数据类型分类**:
- **Euclidean数据**（欧几里得）: v_x, v_y, e_px, e_py
- **Non-Euclidean数据**（非欧）: v_c, e_s, e_t

**数据结构**:
```python
# .pkl文件中存储
info = {
    'token': str,  # 场景ID
    'cams': {相机数据...},
    'center_lines': {
        'centerlines': List[np.array],  # 每条lane的坐标点 (N_pts, 3)
        'centerline_ids': List[int],    # lane ID
        'incoming_ids': List[List[int]], # 入边
        'outgoing_ids': List[List[int]], # 出边
        'start_point_idxs': List[int],   # 起点索引
        'end_point_idxs': List[int]      # 终点索引
    }
}
```

### 1.2 数据集类

**类**: `CenterlineNuScenesDataset`  
**文件**: `rntr/centerline_nuscenes_dataset.py:16`

**输入**: 
- `ann_file`: .pkl标注文件路径
- `grid_conf`: BEV网格配置
- `bz_grid_conf`: Bezier系数网格配置

**输出**: 
- `data_list`: List[dict]，每个dict包含一个场景的所有信息

**关键方法**:
```python
# 1. load_data_list() - 加载标注
输入: self.ann_file (.pkl)
输出: List[dict] - 所有场景信息

# 2. parse_data_info() - 解析单个场景
输入: info (dict) - 原始场景标注
输出: input_dict (dict) - 标准化格式
    包含: token, img_filename, lidar2img, center_lines等
```

### 1.3 BEV网格配置

**论文对应**: Section 3.2 - 坐标离散化

```python
grid_conf = {
    'xbound': [-30.0, 30.0, 0.3],  # [min, max, resolution]
    'ybound': [-15.0, 15.0, 0.3],
    'zbound': [-10.0, 10.0, 20.0],
}
# 网格数量: NX=200, NY=100

bz_grid_conf = {
    'xbound': [-30.0, 30.0, 0.15],  # 更高精度用于Bezier系数
    'ybound': [-15.0, 15.0, 0.15],
}
# 网格数量: NX=400, NY=200
```

---

## Stage 2: BEV网格化与过滤

**论文参考**: Section 3.1 - Bezier曲线表示

### 2.1 Centerline对象化

**Transform**: `LoadNusOrderedBzCenterline`  
**文件**: `rntr/transforms/loading.py:1467`

**输入**: `results['center_lines']` (dict)  
**输出**: `results['center_lines']` (NusOrederedBzCenterLine对象)

**实现**:
```python
class LoadNusOrderedBzCenterline:
    def __call__(self, results):
        results['center_lines'] = NusOrederedBzCenterLine(
            results['center_lines'],
            self.grid_conf,
            self.bz_grid_conf
        )
```

### 2.2 NusOrederedBzCenterLine类

**文件**: `rntr/core/centerline/structures/pryordered_bz_centerline.py:418`

**输入**:
- `centerlines`: 原始centerline字典
- `grid_conf`: BEV网格配置
- `bz_grid_conf`: Bezier网格配置

**输出**: 对象包含
- `self.centerlines`: List[np.array] - 过滤后的centerlines
- `self.pc_range`: BEV范围 [-30, -15, -10, 30, 15, 10]
- `self.dx`: 网格分辨率 [0.3, 0.3, 20.0]
- `self.bz_pc_range`, `self.bz_dx`, `self.bz_nx`: Bezier参数

**关键操作**:
```python
def __init__(self):
    # 1. 深拷贝原始数据
    # 2. 计算BEV网格参数
    dx, bx, nx = self.gen_dx_bx(grid_conf['xbound'], ...)
    # 3. 过滤BEV范围外的centerlines
    self.filter_bev()
```

**filter_bev()方法** - 重要！
```python
# 文件: pryordered_bz_centerline.py:490
def filter_bev(self):
    """
    处理三种情况:
    1. 完全在BEV外 → 丢弃
    2. 完全在BEV内 → 保留
    3. 部分在BEV内 → 裁剪并调整start/end索引
    """
    for centerline in self.centerlines:
        # 检查每个点: -30<=x<30, -15<=y<=15
        in_bev_x = (centerline[:, 0] < 30) & (centerline[:, 0] >= -30)
        in_bev_y = (centerline[:, 1] <= 15) & (centerline[:, 1] >= -15)
        in_bev_xy = in_bev_x & in_bev_y
        # ...裁剪逻辑
```

### 2.3 数据增强（可选）

**Transform 1**: `CenterlineFlip`  
**文件**: `rntr/transforms/loading.py:411`  
**操作**: 水平/垂直翻转（各50%概率）

**Transform 2**: `CenterlineRotateScale`  
**文件**: `rntr/transforms/loading.py:465`  
**操作**: 
- 旋转: ±22.5°
- 缩放: 0.95-1.05倍
- 增强后重新执行`filter_bev()`

---

## Stage 3: DAG构建

**论文参考**: 
- Figure 2 上半部分 - DAG结构
- Section 3.1 - 数学建模

### 3.1 Transform入口

**Transform**: `TransformOrderedBzLane2Graph`  
**文件**: `rntr/transforms/loading.py:685`

**输入**: `results['center_lines']` (NusOrederedBzCenterLine对象)  
**输出**: 
- `results['centerline_coord']`: (N, 2)
- `results['centerline_label']`: (N,)
- `results['centerline_connect']`: (N,)
- `results['centerline_coeff']`: (N, 2)
- `results['centerline_sequence']`: (N*6,)

### 3.2 Step 1: 导出节点和邻接矩阵

**方法**: `NusOrederedBzCenterLine.export_node_adj()`  
**文件**: `pryordered_bz_centerline.py` (定义在基类中)

**输入**: `self.centerlines`, `self.incoming_ids`, `self.outgoing_ids`  
**输出**: 
- `all_nodes`: List[Node] - 每条centerline的起点和终点
- `adj`: np.array (N, N) - 邻接矩阵，1表示有向边，-1表示反向

**核心逻辑**:
```python
# 每条centerline生成2个节点
for i, centerline in enumerate(self.centerlines):
    start_node = Node(position=centerline[start_idx])
    end_node = Node(position=centerline[end_idx])
    all_nodes.extend([start_node, end_node])

# 构建邻接矩阵
adj[start_idx, end_idx] = 1  # 同一条centerline内部连接
# 根据incoming/outgoing_ids连接不同centerlines
```

### 3.3 Step 2: 子图分割

**方法**: `NusOrederedBzCenterLine.sub_graph_split()`  
**文件**: `pryordered_bz_centerline.py:565`

**输入**: `self.all_nodes`, `self.adj`  
**输出**: 
- `self.subgraphs_nodes`: List[List[Node]] - 每个子图的节点
- `self.subgraphs_adj`: List[np.array] - 每个子图的邻接矩阵

**算法**: DFS遍历找连通分量

**为什么分割?** nuScenes场景可能包含多个不连通的road network（如主路和远处辅路）

---

## Stage 4: DAG→序列化（核心）

**论文参考**: 
- **Figure 2 完整流程图** [最重要]
- Section 3.2 - Coupled RoadNet Sequence

### 4.0 数学原理（论文Section 3.2）

**DAG → Directed Forest转换**:

问题：DAG中顶点和边的关系模糊 |V| ⇎ |E|，存在冗余

解决：转换为Directed Forest（有向森林）
```
G_f = (V_f, E_f)
```
其中 G_f 是多个不连通有向树的集合

**关键：建立双射(Bijection)**

在树结构中，边和非根顶点之间存在一一对应:
```
f: V_f\{root} → E_f
```
定义为：
```
f(v) = (Parent(v), v)  对于所有 v ∈ V_f, id(v) > 0
```
其中 `id(v)` 是顶点v的入度（incoming degree）

**反函数**:
```
f^(-1)(e) = v_t  对于 e = (v_s, v_t) ∈ E_f
```

**转换操作**（针对merge点）:

对于所有 `v ∈ V, id(v) > 1` (有多个父节点):
1. 复制该节点（除第一个父节点外）
2. 删除对应的边
3. 标记复制节点为"Clone"
4. 在恢复时反转Clone节点的边方向

**顶点-边配对**:

配对规则:
```
(v, f(v))  对于 id(v) = 1 的顶点（有唯一父节点）
(v, None)  对于 id(v) = 0 的顶点（根节点）
```

**序列复杂度分析**:

时间复杂度: `O(|V_f|) = O(|E|)`

这保证了序列表示的高效性和无损性。

### 4.1 构建场景图对象

**类**: `OrderedBzSceneGraph`  
**文件**: `rntr/transforms/centerline_utils.py` (SceneGraph系列)

**输入**:
- `subgraphs_nodes`: List[List[Node]]
- `subgraphs_adj`: List[np.array]
- `subgraphs_points_in_between_nodes`: 边上的点
- `n_control`: Bezier控制点数量=3

**关键操作**: 为每条边拟合Bezier曲线，计算中间控制点

### 4.2 有序DFS序列化

**论文对应**: Figure 2 底部 - 拓扑排序

**方法**: `OrderedBzSceneGraph.sequelize_new()`  
**文件**: `centerline_utils.py:363`

**输入**: 子图列表  
**输出**: `result_list` - List[List[Node]]，每个Node包含:
- `position`: (x, y, z)
- `sque_type`: 'start'/'continue'/'fork'/'merge'
- `fork_from_index` 或 `merge_with_index`: 连接信息
- `coeff`: Bezier系数

**核心算法**:
```python
def sequelize_new(self):
    # 1. 按x坐标排序子图（从左到右）
    subgraphs_sorted = sorted(subgraph, key=lambda x: x.first_start_node.position[0])
    
    # 2. 对每个子图进行序列化
    for subgraph in subgraphs_sorted:
        sequence = self.subgraph_sequelize(subgraph)
        result_list.append(sequence)
```

**subgraph_sequelize()详解**:
```python
def subgraph_sequelize(subgraph):
    # Step 1: 有序DFS - 起始节点按x坐标排序后DFS
    for start_node in start_nodes_sorted:
        dfs_traverse(start_node)  # 深度优先遍历
    
    # Step 2: 节点类型标注 (get_node_type)
    # - start: 没有入边
    # - continue: 前驱是i-1（顺序相邻）
    # - fork: 前驱不是i-1（从其他节点fork出来）
    # - merge: 后继索引<当前索引（merge到前面的节点）
```

**论文对应的4种类别**:
- **Ancestor** (start): 论文Figure 2中的根节点
- **Lineal** (continue): 直接后继
- **Offshoot** (fork): 分叉点
- **Clone** (merge): 合并点

### 4.3 转换为整数序列

**论文对应**: Section 3.2 - 6-integer tuple

**函数**: `sentance2bzseq()`  
**文件**: `centerline_utils.py:710`

**输入**:
- `sentance`: List[List[Node]] - 节点序列
- `pc_range`, `dx`: BEV参数
- `bz_pc_range`, `bz_dx`, `bz_nx`: Bezier参数
- `nx`: BEV网格数量

**输出**: `seq` - List[int]，扁平化整数序列

**离散化公式**（论文Section 3.2）:

每个顶点-边对用6个整数表示：

1. **顶点坐标离散化**:
   ```
   v_x_discrete = int(v_x)
   v_y_discrete = int(v_y)
   ```
   直接截断取整

2. **顶点类别**:
   ```
   v_c ∈ {0, 1, 2, 3}
   ```
   - 0: Ancestor (根节点)
   - 1: Lineal (第一个子节点)
   - 2: Offshoot (非第一个子节点)
   - 3: Clone (复制节点)

3. **连接索引**:
   ```
   v_d = Index(Parent(v))
   ```
   - Ancestor: v_d = None
   - Lineal: v_d忽略（父节点就是v_(i-1)）
   - Offshoot: v_d = 父节点的拓扑序索引
   - Clone: v_d = 原始节点的索引

4. **Bezier系数离散化**:
   ```
   e_px_discrete = int(e_px + 10)
   e_py_discrete = int(e_py + 10)
   ```
   **注意**：加10是为了避免负值！
   
   这是因为Bezier控制点可能：
   - 超出BEV范围
   - 产生负值坐标
   
   通过 `+10` 操作将值域平移到正数范围

**核心代码**（完整展示，论文Section 3.2有详细说明）:
```python
def sentance2bzseq(sentance, pc_range, dx, bz_pc_range, bz_dx, bz_nx, nx=None):
    """
    将Node序列转换为整数token序列
    每个节点用6个整数表示: [vx, vy, vc, vd, epx, epy]
    
    论文对应: Section 3.2 - Sequence construction
    """
    type_idx_map = {
        'start': 0,      # Ancestor
        'continue': 1,   # Lineal
        'fork': 2,       # Offshoot
        'merge': 3       # Clone
    }
    
    seq = []
    for sub_graph_idx, sub_sent in enumerate(sentance):
        for node in sub_sent:
            # 1. 坐标转换到网格索引
            node.position = (node.position - pc_range[:3]) / dx
            
            # 2. 更新全局序列索引
            if sub_graph_idx == 0:
                node.sque_index += 1
            else:
                node.sque_index = (node.sque_index + 
                                   sentance[sub_graph_idx-1][-1].sque_index + 1)
            
            # 3. 添加顶点坐标 (vx, vy)
            if nx is not None:
                x_coord = int(np.clip(node.position[0], 0, nx[0] - 1))  # [0, 199]
                y_coord = int(np.clip(node.position[1], 0, nx[1] - 1))  # [0, 199]
                seq += [x_coord, y_coord]
            else:
                seq += node.position[:2].astype(int).tolist()
            
            # 4. 添加类别 (vc)
            seq.append(type_idx_map[node.sque_type])  # [0, 3]
            
            # 5. 添加连接索引 (vd)
            if node.sque_type == "fork":
                # Fork节点: 记录从哪个节点fork出来
                if sub_graph_idx == 0:
                    node.fork_from_index += 1
                else:
                    node.fork_from_index = (node.fork_from_index + 
                                           sentance[sub_graph_idx-1][-1].sque_index + 1)
                seq.append(node.fork_from_index)
            elif node.sque_type == "merge":
                # Merge节点: 记录merge到哪个节点
                if sub_graph_idx == 0:
                    node.merge_with_index += 1
                else:
                    node.merge_with_index = (node.merge_with_index + 
                                            sentance[sub_graph_idx-1][-1].sque_index + 1)
                seq.append(node.merge_with_index)
            else:
                # Start或Continue节点: 连接索引为0
                seq.append(0)
            
            # 6. 添加Bezier系数 (epx, epy)
            if len(node.coeff) > 0:
                # 转换到Bezier网格坐标
                node.coeff = (node.coeff - bz_pc_range[:2]) / bz_dx[:2]
                node.coeff[0] = np.clip(node.coeff[0], 0, bz_nx[0]-1)  # [0, 399]
                node.coeff[1] = np.clip(node.coeff[1], 0, bz_nx[1]-1)  # [0, 199]
                node.coeff = node.coeff.astype(int)
                
                seq.append(node.coeff[0])  # epx
                seq.append(node.coeff[1])  # epy
            else:
                # 没有Bezier系数（如merge节点）
                seq.append(0)
                seq.append(0)
    
    return seq
```

**输出示例**:
```python
# 假设3个节点的序列
seq = [
    # 节点1 (start)
    50, 60,   # vx=50, vy=60 (BEV坐标)
    0,        # vc=0 (start类型)
    0,        # vd=0 (无连接)
    120, 130, # epx=120, epy=130 (Bezier系数)
    
    # 节点2 (continue)
    55, 65,   # vx=55, vy=65
    1,        # vc=1 (continue类型)
    0,        # vd=0
    125, 135,
    
    # 节点3 (fork from 节点1)
    48, 70,   # vx=48, vy=70
    2,        # vc=2 (fork类型)
    1,        # vd=1 (从节点1 fork)
    118, 140,
]
```

### 4.4 拆分为不同数组

**Transform继续**: `TransformOrderedBzLane2Graph.__call__()`

**输入**: `centerline_sequence` - 扁平化整数序列  
**输出**: 拆分为4个数组

```python
clause_length = 6  # 每个节点6个整数
centerline_coord = np.stack([
    centerline_sequence[::6],   # vx: 每6个取第1个
    centerline_sequence[1::6]   # vy: 每6个取第2个
], axis=1)  # shape: (N, 2)

centerline_label = centerline_sequence[2::6]    # vc, shape: (N,)
centerline_connect = centerline_sequence[3::6]  # vd, shape: (N,)
centerline_coeff = np.stack([
    centerline_sequence[4::6],  # epx
    centerline_sequence[5::6]   # epy
], axis=1)  # shape: (N, 2)
```

---

## Stage 5: Token化与模型输入

**论文参考**: 
- **Table 1 - Embedding range** [Token范围定义]
- Section 3.3 - Sequence Embedding

### 5.1 Token范围定义

**文件**: `rntr/ar_rntr.py:110-138`

**论文对应**: Table 1

```python
# 坐标范围
self.box_range = 200           # vx, vy ∈ [0, 199]
self.coeff_range = 200         # epx, epy ∈ [0, 199]

# Token偏移量
self.category_start = 200      # vc ∈ [200, 203]
self.connect_start = 250       # vd ∈ [250, 449]
self.coeff_start = 350         # epx, epy ∈ [350, 549]

# 特殊token
self.noise_coeff = 570         # 噪声token (共用)
self.noise_label = 570         # 噪声标签
self.noise_connect = 570       # 噪声连接
self.end = 571                 # <END>
self.start = 572               # <START>
self.no_known = 573            # <PAD>

# 词汇表大小 = 574
```

**编码示例**:
```python
# 原始值 → Token
vx, vy = 50, 60          → [50, 60]              # 坐标直接使用
vc = 2 (fork)            → 200 + 2 = 202         # 类别加200
vd = 1 (connect to 1)    → 250 + 1 = 251         # 连接索引加250
epx, epy = 120, 130      → [350+120, 350+130] = [470, 480]  # Bezier加350
```

### 5.1.1 训练Token序列可视化

**论文对应**: Section 3.3 - Auto-regressive 输入输出

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        训练时的Token序列结构                                 │
└─────────────────────────────────────────────────────────────────────────────┘

输入序列 (input_seq):
┌─────┬──────────────────────────────────────────────────────────────┬─────────┐
│START│  Node 1  │  Node 2  │  Node 3  │  ...  │  Node N  │ Padding │
│ 572 │ 6 tokens │ 6 tokens │ 6 tokens │  ...  │ 6 tokens │   573   │
└─────┴──────────────────────────────────────────────────────────────┴─────────┘
   ↓         ↓         ↓         ↓                ↓
   1      vx,vy    vx,vy    vx,vy              vx,vy
  token    vc       vc       vc                 vc
           vd       vd       vd                 vd
          epx      epx      epx                epx
          epy      epy      epy                epy

目标序列 (output_seq):
┌──────────────────────────────────────────────────────────────┬─────┬─────────┐
│  Node 1  │  Node 2  │  Node 3  │  ...  │  Node N  │  END  │ Padding │
│ 6 tokens │ 6 tokens │ 6 tokens │  ...  │ 6 tokens │  571  │   573   │
└──────────────────────────────────────────────────────────────┴─────┴─────────┘

单个节点的6个Token详解:
┌────────────────────────────────────────────────────────────────────────────┐
│ Token位置  │  含义  │  值域  │  编码后范围  │  说明                       │
├────────────────────────────────────────────────────────────────────────────┤
│ Token 0    │  vx    │ 0-199  │   0-199      │ BEV网格X坐标                │
│ Token 1    │  vy    │ 0-199  │   0-199      │ BEV网格Y坐标                │
│ Token 2    │  vc    │ 0-3    │   200-203    │ 类别 (start/continue/fork/  │
│            │        │        │              │       merge)                │
│ Token 3    │  vd    │ 0-199  │   250-449    │ 连接索引 (fork/merge时有效) │
│ Token 4    │  epx   │ 0-199  │   350-549    │ Bezier控制点X               │
│ Token 5    │  epy   │ 0-199  │   350-549    │ Bezier控制点Y               │
└────────────────────────────────────────────────────────────────────────────┘

类别 (vc) 编码详细:
  原始值 0 (start)    → Token 200
  原始值 1 (continue) → Token 201
  原始值 2 (fork)     → Token 202
  原始值 3 (merge)    → Token 203
  噪声值              → Token 570

连接索引 (vd) 编码:
  如果是fork:  vd = 250 + parent_node_index
  如果是merge: vd = 250 + target_node_index
  如果是start/continue: vd = 250 + 0 = 250

Bezier系数 (epx, epy) 编码:
  epx_token = 350 + epx_grid_value  (epx_grid_value ∈ [0, 199])
  epy_token = 350 + epy_grid_value  (epy_grid_value ∈ [0, 199])

特殊Token:
  <NOISE>:  570  # 噪声token
  <END>:    571  # 结束token
  <START>:  572  # 开始token
  <PAD>:    573  # 填充token

实际训练示例 (来自DEBUG):
input_seqs[0][:10]: [572, 0, 76, 200, 250, 350, 350, 32, 77, 201]
                     │    └────┬────┘ │   │   └──┬──┘ └────┬────┘
                     │      Node1      │   │   Node1    Node2
                   START   坐标(0,76)  │   │  Bezier   坐标(32,77)
                                    start vd=0   (epx=0,
                                     类别  (250)   epy=0)
```

### 5.2 数据格式化

**Transform**: `Pack3DCenterlineInputs`  
**文件**: `rntr/transforms/formating.py`

**输入**: 
- `img`: List[np.ndarray] - 6张图像
- `centerline_coord`: np.ndarray (N, 2)
- `centerline_label`: np.ndarray (N,)
- `centerline_connect`: np.ndarray (N,)
- `centerline_coeff`: np.ndarray (N, 2)

**输出**: PyTorch Tensor格式
```python
packed_results = {
    'imgs': Tensor(6, 3, H, W),
    'centerline_coord': Tensor(N, 2),
    'centerline_label': Tensor(N,),
    'centerline_connect': Tensor(N,),
    'centerline_coeff': Tensor(N, 2),
}
```

### 5.3 模型前向传播

**论文参考**: 
- **Figure 3 - AR-RNTR架构图** [模型结构]
- Section 3.4 - Transformer Architecture

**目标函数**（论文Section 3.4）:

Auto-regressive训练的目标是**最大似然估计(MLE)**:
```
max Σ(i=1 to L) w_i log P(ŷ_i | y_<i, F)
```
其中：
- `L`: 序列长度
- `y_i`: GT序列的第i个token
- `y_<i`: 所有i之前的tokens（Teacher Forcing）
- `F`: BEV特征（从图像提取）
- `w_i`: 类别权重（class weight）
- `ŷ_i`: 模型预测的第i个token

**等价于最小化交叉熵损失**:
```
min -Σ(i=1 to L) w_i log P(ŷ_i | y_<i, F)
```

**代码实现中的损失分解**:

总损失分为4个部分（对应6个token的不同slot）:
```
Loss = loss_coords + loss_labels + loss_connects + loss_coeffs
```
- `loss_coords`: 坐标预测损失（vx, vy）
- `loss_labels`: 类别预测损失（vc）
- `loss_connects`: 连接预测损失（vd）
- `loss_coeffs`: Bezier系数损失（epx, epy）

每个都是交叉熵损失：
```
loss_* = CrossEntropyLoss(pred_*, gt_*)
```

**类别权重**（论文Section 4）:

由于Lineal类型和默认连接索引频率过高，对它们使用**较低权重**:
- 坐标、Bezier系数：权重1.0
- 类别中的Lineal：权重 < 1.0
- 默认连接索引：权重 < 1.0

**方法**: `AR_RNTR.forward_train()`  
**文件**: `rntr/ar_rntr.py:494-543`

**关键步骤**:
```python
def forward_train(img, **kwargs):
    # 1. 提取BEV特征
    bev_feat = self.extract_feat(img)  # LSS模块
    
    # 2. 构建输入序列（Teacher Forcing）
    input_seq = [<start>, GT_node1, GT_node2, ..., GT_nodeN]
    
    # 3. 构建目标序列
    output_seq = [GT_node1, GT_node2, ..., GT_nodeN, <end>]
    
    # 4. Padding到相同长度
    # 使用self.no_known (573) padding
    
    # 5. Transformer解码
    predictions = self.pts_bbox_head(bev_feat, input_seq)
    
    # 6. 计算损失
    losses = self.pts_bbox_head.loss(predictions, output_seq)
```

### 5.4 Synthetic Noise Objects

**论文参考**: Section 4.1 - 训练策略

**实现**: 训练时以一定概率将输入序列中的token替换为噪声token

```python
# 文件: ar_rntr.py (在构建输入序列时)
if random.random() < noise_prob:
    input_seq[i, 2] = self.noise_label     # 570
    input_seq[i, 3] = self.noise_connect   # 570
```

**目的**: 提高模型鲁棒性，学会忽略噪声输入

### 5.5 Topology-Inherited Training (TIT)

**论文参考**: Section 4.2 - 拓扑继承训练策略

**原始训练目标**:
```
min_(θ_f, θ_g) E_((x,y)~D) [L_CE(g(f_I(x)), y)]
```
其中：
- `f_I`: 图像BEV编码器（待训练）
- `g`: RoadNet序列解码器
- `L_CE`: 交叉熵损失
- `x`: 图像输入
- `y`: GT RoadNet序列

**TIT分解为两阶段**:

**Stage 1: LiDAR Map训练解码器**
```
min_(θ_g) E_((x_L,y)~D_L) [L_CE(g(f_L(x_L)), y)]
```
- 使用LiDAR点云生成的BEV特征（更准确）
- 只训练解码器g
- 固定高质量的BEV特征

**Stage 2: 图像BEV蒸馏**
```
min_(θ_f) E_((x,x_L)~D) ||f_I(x) - f_L(x_L)||_1
```
- 固定解码器g
- 训练图像编码器f_I
- 使用L1 loss进行特征蒸馏
- 让图像BEV特征接近LiDAR BEV特征

**蒸馏损失**（代码中实现）:
```
L_dist = ||F_img - F_lidar||_1
```
其中：
- `F_img`: 图像编码器输出的BEV特征
- `F_lidar`: LiDAR编码器输出的BEV特征（frozen）

**优势**:
- L1 loss提供更稳定的梯度
- 避免端到端训练中拓扑预测错误导致的梯度震荡
- 解耦BEV特征学习和序列预测

---

## 实际运行示例（来自训练DEBUG）

### 真实Batch数据

**Batch配置**:
```
Batch size: 64
节点数量范围: 4-65个节点/样本
平均节点数: ~30个
```

**Sample 0详细分析**:
```python
# 输入数据
coords: (38, 2)      # 38个节点，每个2D坐标
labels: (38,)        # 38个类别
connects: (38,)      # 38个连接索引
coeffs: (38, 2)      # 38个Bezier系数

# 第一个节点
First coord: [0, 76]    # BEV网格坐标
First label: 0          # start类型
```

**坐标分布观察**（从DEBUG数据）:
```
Sample 0:  [0, 76]     # 靠近BEV左侧
Sample 1:  [2, 72]     # 略微向前
Sample 16: [37, 0]     # 靠近BEV前方中心
Sample 19: [104, 127]  # 超出常规范围（可能是极端情况）
Sample 20: [75, 0]     # BEV前方
```
→ 说明大部分节点在BEV中心区域，符合车辆前方道路的分布

### Token Constants实际值

**来自训练日志**:
```python
start = 572        # <start> token
end = 571          # <end> token
no_known = 573     # padding token
noise_label = 570  # 噪声标签

# 注意：实际代码中的值是固定的！
# ar_rntr.py 中定义: start=572, end=571, no_known=573, noise=570
```

### 序列构建实例

**Padding后的序列**:
```python
max_box: 65           # 最长样本有65个节点
clause_length: 6      # 每个节点6个token
input_seqs: (64, 1081)   # 64个样本，每个1081个token
output_seqs: (64, 1081)  # 同上

# 计算验证
1081 = 65 * 6 + 1 (start token) + padding
```

**Sample 0的序列内容**:
```python
input_seqs[0][:10]: [572, 0, 76, 200, 250, 350, 350, 32, 77, 201]
# 解析:
# 572        - <start> token
# 0, 76      - 节点1坐标 (vx=0, vy=76)
# 200        - 节点1类别 (vc=200, 即start类型)
# 250        - 节点1连接 (vd=250)
# 350, 350   - 节点1 Bezier系数 (epx=350, epy=350)
# 32, 77     - 节点2坐标
# 201        - 节点2类别 (vc=201, 即continue类型)

output_seqs[0][:10]: [0, 76, 200, 250, 350, 350, 32, 77, 201, 250]
# 解析: 去掉<start>，整体左移一位
```

**END token位置**:
```python
Sample 0: END token at position [228]  # 228 = 38*6
Sample 1: END token at position [102]  # 102 = 17*6
# END位置 = 节点数 * 6
```

### 监督信号切片（Sample 0）

**论文对应**: Section 3.4 - Loss计算

```python
valid_len: 1074        # 有效长度（去除END之后）
num_clauses: 179       # 179个clause = 1074/6

# 提取的监督信号
inputs_pos_i: 358个token    # 坐标位置 (179*2)
  unique values: [0, 5, 19, 20, 27, 31, 32, 35, ...]
  
inputs_cls_i: 179个token    # 类别
  unique values: [200, 201, 202, 203, 570]
  # 200=start, 201=continue, 202=fork, 203=merge, 570=noise

inputs_conn_i: 179个token   # 连接索引
  unique values: [250, 254, 257, 258, 260, ...]
  
inputs_coeffs_i: 358个token # Bezier系数 (179*2)

# Mask统计
mask_pos:   76个有效位置    # 只监督坐标位置
mask_cls:   179个有效位置   # 监督所有类别
mask_conn:  38个有效位置    # 只监督fork/merge的连接
mask_coeff: 76个有效位置    # 只监督坐标的Bezier系数
```

**重要发现**:
- 并非所有位置都计算损失（使用mask过滤）
- `mask_conn=38` 说明38个节点中只有部分是fork/merge类型
- 类别中出现`570`（noise_label），说明使用了Synthetic Noise Objects策略

### 批次级别统计

**全batch的监督信号数量**:
```python
coords:   3772个预测值    # 64个样本的所有坐标
labels:   11456个预测值   # 64个样本的所有类别
connects: 1886个预测值    # 只有fork/merge节点
coeffs:   3772个预测值    # 对应坐标的Bezier系数

# 验证一致性
coords数 = coeffs数 = 3772
connects数 远小于 labels数 (1886 << 11456)
# → 说明大部分节点是start/continue类型
```

### Loss值分析

**实际loss**:
```python
loss_coords:   4.12    # 坐标预测loss
loss_labels:   0.12    # 类别预测loss (很小，容易学习)
loss_connects: 0.39    # 连接预测loss
loss_coeffs:   3.84    # Bezier系数loss (最大)

total_loss: 8.54 = 4.12 + 0.12 + 0.39 + 3.84
```

**观察**:
1. `loss_labels`最小 → 类别（4类）最容易学习
2. `loss_coords`和`loss_coeffs`较大 → 坐标回归是难点
3. 所有loss都是有限值，没有NaN → 训练稳定

---

## 数据流统计

### 典型场景数据量

| 项目 | 数值 | 说明 |
|------|------|------|
| Centerlines数量 | 10-50条 | 视场景复杂度 |
| 每条Centerline点数 | 10-30个 | 采样点数量 |
| 节点数量N | 60-300 | 经过序列化后 |
| 序列长度 | 360-1800 | N×6 |
| BEV网格 | 200×100 | 0.3m分辨率 |
| Bezier网格 | 400×200 | 0.15m分辨率 |

### 坐标变换示例

**原始坐标** (ego坐标系, 单位:米):
```
centerline_point = (5.2, -3.7, 0.0)  # x向前, y向左
```

**BEV网格坐标** (离散化):
```
grid_x = int((5.2 - (-30.0)) / 0.3) = int(35.2 / 0.3) = 117
grid_y = int((-3.7 - (-15.0)) / 0.3) = int(11.3 / 0.3) = 37
```

**Token**:
```
vx_token = 117  # ∈ [0, 199]
vy_token = 37   # ∈ [0, 199]
```

---

## 关键概念对照表

| 论文术语 | 代码实现 | 文件位置 |
|---------|---------|---------|
| DAG | `adj` (邻接矩阵) | `export_node_adj()` |
| Directed Forest | `subgraphs_*` | `sub_graph_split()` |
| Ancestor | `'start'` (type=0) | `get_node_type()` |
| Lineal | `'continue'` (type=1) | `get_node_type()` |
| Offshoot | `'fork'` (type=2) | `get_node_type()` |
| Clone | `'merge'` (type=3) | `get_node_type()` |
| Topological sorting | 有序DFS | `sequelize_new()` |
| Bezier middle control point | `node.coeff` | `_fit_bezier()` |
| Coupled RoadNet Sequence | `centerline_sequence` | `sentance2bzseq()` |

---

## 调试检查点

在理解代码时，可以在以下位置添加断点/打印：

1. **Stage 1**: `CenterlineNuScenesDataset.parse_data_info()`  
   查看: `center_lines`字典内容

2. **Stage 2**: `NusOrederedBzCenterLine.__init__()` 末尾  
   查看: 过滤后剩余多少条centerlines

3. **Stage 3**: `export_node_adj()` 返回前  
   查看: `adj`矩阵形状和连接关系

4. **Stage 4**: `sentance2bzseq()` 循环内  
   查看: 每个节点的类型和连接索引

5. **Stage 5**: `AR_RNTR.forward_train()` 构建序列后  
   查看: `input_seq`和`output_seq`的形状

---

## 学习建议

1. **先看论文Figure 2**: 理解DAG→序列的完整流程
2. **对照Table 1**: 记住token范围
3. **跟踪单个样本**: 用调试器跟踪一个完整的数据流
4. **可视化序列**: 将序列还原成图，验证理解

---

**文档版本**: 2.0 (实用版)  
**最后更新**: 2025-01-23
