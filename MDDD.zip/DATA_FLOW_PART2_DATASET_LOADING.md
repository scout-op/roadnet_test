# AR-RNTR 数据流分析 - Part 2: 数据集加载详解

## Stage 1: Dataset初始化与数据加载

### 1.1 数据集类定义

**文件**: `rntr/centerline_nuscenes_dataset.py:16-286`

```python
@DATASETS.register_module()
class CenterlineNuScenesDataset(BaseDataset):
    """
    继承自MMEngine的BaseDataset
    功能：加载nuScenes数据并提供统一接口
    """
    
    def __init__(self,
                 ann_file,           # 标注文件路径 (.pkl)
                 pipeline=None,      # 数据处理pipeline
                 data_root=None,     # 数据根目录
                 grid_conf=None,     # BEV网格配置
                 bz_grid_conf=None,  # Bezier系数网格配置
                 **kwargs):
        # 初始化父类
        super().__init__(...)
        
        # 存储配置
        self.grid_conf = grid_conf
        self.bz_grid_conf = bz_grid_conf
        self.interval = grid_conf['xbound'][-1]  # 网格分辨率
```

**关键配置参数**：

```python
# 来自配置文件
grid_conf = {
    'xbound': [-30.0, 30.0, 0.3],  # [min, max, resolution]
    'ybound': [-15.0, 15.0, 0.3],
    'zbound': [-10.0, 10.0, 20.0],
}

bz_grid_conf = {
    'xbound': [-30.0, 30.0, 0.15],  # 更高分辨率用于Bezier系数
    'ybound': [-15.0, 15.0, 0.15],
    'zbound': [-10.0, 10.0, 20.0],
}
```

### 1.2 数据加载流程

#### 1.2.1 load_data_list() - 读取标注文件

**代码位置**: `centerline_nuscenes_dataset.py:111-164`

```python
def load_data_list(self) -> List[dict]:
    """
    从.pkl文件中加载所有场景的标注信息
    """
    # 加载.pkl文件
    annotations = load(self.ann_file)
    
    # 检查格式
    assert 'infos' in annotations
    assert 'metadata' in annotations
    
    metainfo = annotations['metadata']
    raw_data_list = annotations['infos']  # List[dict]
    
    # 解析每个场景
    data_list = []
    for raw_data_info in raw_data_list:
        data_info = self.parse_data_info(raw_data_info)
        data_list.append(data_info)
    
    return data_list
```

#### 1.2.2 parse_data_info() - 解析单个场景

**代码位置**: `centerline_nuscenes_dataset.py:214-286`

```python
def parse_data_info(self, info: dict) -> dict:
    """
    将原始标注转换为统一格式
    
    输入: nuScenes原始标注字典
    输出: 标准化的data_info字典
    """
    # 1. 基础信息
    input_dict = dict(
        sample_idx=info['token'],
        pts_filename=info['lidar_path'],
        sweeps=info['sweeps'],
        timestamp=info['timestamp'] / 1e6,
        token=info['token'],
    )
    
    # 2. LiDAR到ego坐标变换
    lidar2ego_r = Quaternion(info['lidar2ego_rotation']).rotation_matrix
    lidar2ego_t = info['lidar2ego_translation']
    lidar2ego_rt = np.eye(4)
    lidar2ego_rt[:3, :3] = lidar2ego_r
    lidar2ego_rt[:3, 3] = lidar2ego_t
    input_dict['lidar2ego'] = lidar2ego_rt
    
    # 3. 相机信息（6个相机）
    if self.modality['use_camera']:
        image_paths = []
        lidar2img_rts = []
        intrinsics = []
        extrinsics = []
        
        for cam_type, cam_info in info['cams'].items():
            image_paths.append(cam_info['data_path'])
            
            # 计算lidar2img变换
            lidar2cam_r = np.linalg.inv(cam_info['sensor2lidar_rotation'])
            lidar2cam_t = cam_info['sensor2lidar_translation'] @ lidar2cam_r.T
            lidar2cam_rt = np.eye(4)
            lidar2cam_rt[:3, :3] = lidar2cam_r.T
            lidar2cam_rt[3, :3] = -lidar2cam_t
            
            intrinsic = cam_info['cam_intrinsic']
            viewpad = np.eye(4)
            viewpad[:intrinsic.shape[0], :intrinsic.shape[1]] = intrinsic
            
            lidar2img_rt = viewpad @ lidar2cam_rt.T
            
            intrinsics.append(viewpad)
            extrinsics.append(lidar2cam_rt)
            lidar2img_rts.append(lidar2img_rt)
        
        input_dict.update(dict(
            img_filename=image_paths,
            lidar2img=lidar2img_rts,
            intrinsics=intrinsics,
            extrinsics=extrinsics
        ))
    
    # 4. Centerline标注（关键！）
    if 'center_lines' in info.keys():
        input_dict['center_lines'] = info['center_lines']
    
    return input_dict
```

### 1.3 Centerline原始数据格式

**来源**: nuScenes数据集预处理后的.pkl文件

```python
center_lines = {
    # 车道类型列表
    'type': ['VEHICLE', 'VEHICLE', ...],  # 每条centerline的类型
    
    # 车道ID
    'centerline_ids': [1234, 5678, ...],  # 唯一标识符
    
    # 实际的centerline坐标（ego坐标系）
    'centerlines': [
        np.array([[x1, y1, z1],    # shape: (n_points, 3)
                  [x2, y2, z2],
                  ...]),
        np.array([...]),            # 第二条centerline
        ...
    ],
    
    # 拓扑连接关系
    'incoming_ids': [
        [5678],        # 第一条centerline的前驱（可以有多个）
        [],            # 第二条centerline无前驱（根节点）
        [1234, 5678],  # 第三条centerline有两个前驱（merge点）
        ...
    ],
    
    'outgoing_ids': [
        [9012, 3456],  # 第一条centerline的后继（可以有多个）
        [1234],        # 第二条centerline的后继
        [],            # 第三条centerline无后继（叶节点）
        ...
    ],
    
    # 起点和终点索引（在centerline内部的点索引）
    'start_point_idxs': [0, 0, 0, ...],      # 通常是0
    'end_point_idxs': [15, 20, 18, ...],     # centerline的最后一个点
}
```

### 1.4 坐标系说明

nuScenes使用以下坐标系：

```
1. Global坐标系：世界坐标系
2. Ego坐标系：车辆中心，前方为x+，左侧为y+，上方为z+
3. LiDAR坐标系：LiDAR传感器坐标系
4. Camera坐标系：相机坐标系

变换链：
Global → Ego → LiDAR → Camera → Image
```

**代码中的centerlines在ego坐标系下**：
- X轴：车辆前方（0°方向）
- Y轴：车辆左侧（90°方向）
- Z轴：车辆上方

**BEV网格定义**：
```python
# grid_conf定义的范围
xbound = [-30.0, 30.0, 0.3]  # 前方30m，后方30m，分辨率0.3m
ybound = [-15.0, 15.0, 0.3]  # 左侧15m，右侧15m，分辨率0.3m

# 网格大小
NX = (30.0 - (-30.0)) / 0.3 = 200
NY = (15.0 - (-15.0)) / 0.3 = 100
```

### 1.5 数据统计示例

典型的nuScenes场景：
- **图像**：6张 (6个相机视角)
- **Centerlines数量**：10-50条不等
- **每条Centerline点数**：10-30个点
- **拓扑复杂度**：包含fork、merge、单链等多种模式

### 1.6 Dataset与Pipeline的交互

```python
class CenterlineNuScenesDataset(BaseDataset):
    def __getitem__(self, idx):
        """
        获取单个样本
        """
        # 1. 从data_list获取原始数据
        data_info = self.data_list[idx]
        
        # 2. 通过pipeline进行转换
        results = self.pipeline(data_info)
        
        return results
```

**Pipeline执行顺序**：
```
data_info (dict)
    ↓
OrgLoadMultiViewImageFromFiles  # 加载图像
    ↓
LoadNusOrderedBzCenterline      # 处理centerline → 下一部分详解
    ↓
ResizeCropFlipImage             # 图像变换
    ↓
... (更多transforms)
    ↓
results (dict)
```

---

**下一部分**：详细解析LoadNusOrderedBzCenterline和centerline数据结构转换
