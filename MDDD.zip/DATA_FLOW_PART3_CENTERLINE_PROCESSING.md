# AR-RNTR 数据流分析 - Part 3: Centerline处理与数据增强

## Stage 2: Centerline数据结构转换

### 2.1 LoadNusOrderedBzCenterline Transform

**文件**: `rntr/transforms/loading.py:1467-1485`

```python
@TRANSFORMS.register_module()
class LoadNusOrderedBzCenterline(object):
    """
    将原始centerline字典转换为NusOrederedBzCenterLine对象
    这是关键的数据结构转换步骤
    """
    def __init__(self, grid_conf, bz_grid_conf):
        self.grid_conf = grid_conf
        self.bz_grid_conf = bz_grid_conf

    def __call__(self, results):
        # 核心转换：dict → NusOrederedBzCenterLine对象
        results['center_lines'] = NusOrederedBzCenterLine(
            results['center_lines'],    # 原始centerline字典
            self.grid_conf,             # BEV网格配置
            self.bz_grid_conf          # Bezier系数网格配置
        )
        return results
```

### 2.2 NusOrederedBzCenterLine类详解

**文件**: `rntr/core/centerline/structures/pryordered_bz_centerline.py:418-614`

#### 2.2.1 初始化过程

```python
class NusOrederedBzCenterLine(object):
    def __init__(self, centerlines, grid_conf, bz_grid_conf):
        """
        初始化并过滤centerlines
        
        参数:
            centerlines: 原始centerline字典（来自nuScenes）
            grid_conf: BEV网格配置 (用于顶点坐标)
            bz_grid_conf: Bezier网格配置 (用于控制点)
        """
        # 1. 深拷贝原始数据
        self.types = copy.deepcopy(centerlines['type'])
        self.centerline_ids = copy.deepcopy(centerlines['centerline_ids'])
        self.incoming_ids = copy.deepcopy(centerlines['incoming_ids'])
        self.outgoing_ids = copy.deepcopy(centerlines['outgoing_ids'])
        self.start_point_idxs = copy.deepcopy(centerlines['start_point_idxs'])
        self.end_point_idxs = copy.deepcopy(centerlines['end_point_idxs'])
        self.centerlines = copy.deepcopy(centerlines['centerlines'])
        
        # 2. 计算BEV网格参数
        dx, bx, nx = self.gen_dx_bx(
            grid_conf['xbound'],
            grid_conf['ybound'],
            grid_conf['zbound']
        )
        self.dx = dx          # [0.3, 0.3, 20.0] - 每个网格的尺寸
        self.bx = bx          # [-29.85, -14.85, 0.0] - 网格起点
        self.nx = nx          # [200, 100, 1] - 网格数量
        
        # pc_range: [-30, -15, -10, 30, 15, 10]
        self.pc_range = np.concatenate((
            self.bx - self.dx / 2.,
            self.bx - self.dx / 2. + self.nx * self.dx
        ))
        
        # 3. 计算Bezier系数网格参数（更高分辨率）
        bz_dx, bz_bx, bz_nx = self.gen_dx_bx(
            bz_grid_conf['xbound'],
            bz_grid_conf['ybound'],
            bz_grid_conf['zbound']
        )
        self.bz_dx = bz_dx    # [0.15, 0.15, 20.0]
        self.bz_bx = bz_bx
        self.bz_nx = bz_nx    # [400, 200, 1]
        self.bz_pc_range = np.concatenate((
            bz_bx - bz_dx / 2.,
            bz_bx - bz_dx / 2. + bz_nx * bz_dx
        ))
        
        # 4. 过滤BEV范围外的centerlines
        self.filter_bev()
    
    @staticmethod
    def gen_dx_bx(xbound, ybound, zbound):
        """
        计算网格参数
        
        返回:
            dx: 网格分辨率 [dx, dy, dz]
            bx: 网格中心起点 [bx, by, bz]
            nx: 网格数量 [nx, ny, nz]
        """
        dx = np.array([row[2] for row in [xbound, ybound, zbound]])
        bx = np.array([row[0] + row[2] / 2.0 for row in [xbound, ybound, zbound]])
        nx = np.floor(np.array([(row[1] - row[0]) / row[2] for row in [xbound, ybound, zbound]]))
        return dx, bx, nx
```

#### 2.2.2 BEV过滤 (filter_bev)

**代码位置**: `pryordered_bz_centerline.py:490-544`

```python
def filter_bev(self):
    """
    过滤掉超出BEV范围的centerlines
    
    处理三种情况：
    1. 完全在BEV外 → 丢弃
    2. 完全在BEV内 → 保留
    3. 部分在BEV内 → 裁剪并调整start/end索引
    """
    aug_types = []
    aug_centerlines = []
    aug_centerline_ids = []
    aug_start_point_idxs = []
    aug_end_point_idxs = []
    aug_incoming_ids = []
    aug_outgoing_ids = []
    
    for i in range(len(self.centerlines)):
        centerline = self.centerlines[i]
        idxs = np.arange(len(centerline))
        
        # 检查每个点是否在BEV内
        in_bev_x = np.logical_and(
            centerline[:, 0] < self.pc_range[3],   # x < 30.0
            centerline[:, 0] >= self.pc_range[0]   # x >= -30.0
        )
        in_bev_y = np.logical_and(
            centerline[:, 1] <= self.pc_range[4],  # y <= 15.0
            centerline[:, 1] >= self.pc_range[1]   # y >= -15.0
        )
        in_bev_xy = np.logical_and(in_bev_x, in_bev_y)
        
        # 情况1: 完全不在BEV内 → 跳过
        if not np.max(in_bev_xy):
            continue
        
        # 情况2: 完全在BEV内 → 直接保留
        if np.min(in_bev_xy):
            aug_types.append(self.types[i])
            aug_centerlines.append(centerline)
            aug_centerline_ids.append(self.centerline_ids[i])
            aug_start_point_idxs.append(self.start_point_idxs[i])
            aug_end_point_idxs.append(self.end_point_idxs[i])
            aug_incoming_ids.append(self.incoming_ids[i])
            aug_outgoing_ids.append(self.outgoing_ids[i])
            continue
        
        # 情况3: 部分在BEV内 → 裁剪
        start_point_idx = self.start_point_idxs[i]
        end_point_idx = self.end_point_idxs[i]
        aug_start_point = centerline[start_point_idx]
        aug_end_point = centerline[end_point_idx]
        
        # 只保留在BEV内的点
        aug_centerline = centerline[in_bev_xy, :]
        aug_idxs = idxs[in_bev_xy]
        
        # 重新计算start/end索引
        if start_point_idx not in aug_idxs:
            aug_start_point = aug_centerline[0]
        if end_point_idx not in aug_idxs:
            aug_end_point = aug_centerline[-1]
        
        # 找到最接近原始start/end的点
        start_distance = np.linalg.norm(aug_centerline - aug_start_point, ord=2, axis=1)
        start_point_idx = np.argmin(start_distance)
        
        end_distance = np.linalg.norm(aug_centerline - aug_end_point, ord=2, axis=1)
        end_point_idx = np.argmin(end_distance)
        
        # 保存裁剪后的结果
        aug_types.append(self.types[i])
        aug_centerlines.append(aug_centerline)
        aug_centerline_ids.append(self.centerline_ids[i])
        aug_start_point_idxs.append(start_point_idx)
        aug_end_point_idxs.append(end_point_idx)
        aug_incoming_ids.append(self.incoming_ids[i])
        aug_outgoing_ids.append(self.outgoing_ids[i])
    
    # 更新所有属性
    self.types = aug_types
    self.centerlines = aug_centerlines
    self.centerline_ids = aug_centerline_ids
    self.incoming_ids = aug_incoming_ids
    self.outgoing_ids = aug_outgoing_ids
    self.start_point_idxs = aug_start_point_idxs
    self.end_point_idxs = aug_end_point_idxs
```

### 2.3 数据增强 (Data Augmentation)

数据增强在centerline处理后进行，包括翻转和旋转缩放。

#### 2.3.1 CenterlineFlip - 随机翻转

**文件**: `rntr/transforms/loading.py:411-434`

```python
@TRANSFORMS.register_module()
class CenterlineFlip(object):
    def __init__(self, prob=0.5):
        self.prob = prob

    def __call__(self, results):
        prob = random.uniform(0, 1)
        centerlines = results['center_lines']  # NusOrederedBzCenterLine对象
        lidar2ego = results['lidar2ego']
        
        if prob > self.prob:
            results['flip'] = None
        else:
            # 构造翻转变换矩阵
            rot_mat = np.eye(4, dtype=lidar2ego.dtype)
            h_or_v = random.uniform(0, 1)
            
            if h_or_v > 0.5:
                flip_type = 'horizontal'  # 水平翻转（沿y轴）
                rot_mat[0, 0] = -1.       # x → -x
            else:
                flip_type = 'vertical'    # 垂直翻转（沿x轴）
                rot_mat[1, 1] = -1.       # y → -y
            
            # 更新变换矩阵
            lidar2ego = rot_mat @ lidar2ego
            
            # 翻转centerlines
            centerlines.flip(flip_type)
        
        results['center_lines'] = centerlines
        results['lidar2ego'] = lidar2ego
        return results
```

**NusOrederedBzCenterLine.flip()实现**:

```python
def flip(self, type):
    """翻转所有centerlines"""
    if type not in ['horizontal', 'vertical']:
        return
    
    aug_centerlines = []
    for i in range(len(self.centerlines)):
        centerline = self.centerlines[i]
        if type == 'horizontal':
            centerline[:, 0] = -centerline[:, 0]  # x坐标取反
        else:
            centerline[:, 1] = -centerline[:, 1]  # y坐标取反
        aug_centerlines.append(centerline)
    
    self.centerlines = aug_centerlines
```

#### 2.3.2 CenterlineRotateScale - 旋转和缩放

**文件**: `rntr/transforms/loading.py:465-514`

```python
@TRANSFORMS.register_module()
class CenterlineRotateScale(object):
    def __init__(self, 
                 prob=0.5,
                 max_rotate_degree=22.5,
                 scaling_ratio_range=(0.95, 1.05)):
        self.prob = prob
        self.max_rotate_degree = max_rotate_degree
        self.scaling_ratio_range = scaling_ratio_range

    def __call__(self, results):
        prob = random.uniform(0, 1)
        centerlines = results['center_lines']
        lidar2ego = results['lidar2ego']
        
        if prob > self.prob:
            results['aug_matrix'] = None
        else:
            # 1. 随机旋转角度
            rotation_degree = random.uniform(
                -self.max_rotate_degree,
                self.max_rotate_degree
            )
            rotation_matrix = self._get_rotation_matrix(rotation_degree)
            
            # 2. 随机缩放比例
            scaling_ratio = random.uniform(
                self.scaling_ratio_range[0],
                self.scaling_ratio_range[1]
            )
            scaling_matrix = self._get_scaling_matrix(scaling_ratio)
            
            # 3. 应用变换
            centerlines.scale(scaling_ratio)
            centerlines.rotate(rotation_matrix)
            centerlines.filter_bev()  # 重新过滤
            
            # 4. 更新变换矩阵
            aug_matrix = np.eye(4, dtype=lidar2ego.dtype)
            aug_matrix[:3, :3] = rotation_matrix @ scaling_matrix
            lidar2ego = aug_matrix @ lidar2ego
            
            results['center_lines'] = centerlines
            results['lidar2ego'] = lidar2ego
        
        return results
    
    @staticmethod
    def _get_rotation_matrix(rotate_degrees):
        """构造绕z轴的旋转矩阵"""
        radian = math.radians(rotate_degrees)
        rotation_matrix = np.array(
            [[np.cos(radian), -np.sin(radian), 0.],
             [np.sin(radian), np.cos(radian), 0.],
             [0., 0., 1.]],
            dtype=np.float32)
        return rotation_matrix
    
    @staticmethod
    def _get_scaling_matrix(scale_ratio):
        """构造缩放矩阵"""
        scaling_matrix = np.array(
            [[scale_ratio, 0., 0.],
             [0., scale_ratio, 0.],
             [0., 0., 1.]],
            dtype=np.float32)
        return scaling_matrix
```

**NusOrederedBzCenterLine的scale()和rotate()实现**:

```python
def scale(self, scale_ratio):
    """缩放所有centerlines"""
    scaling_matrix = self._get_scaling_matrix(scale_ratio)
    aug_centerlines = []
    for i in range(len(self.centerlines)):
        centerline = self.centerlines[i]
        # 矩阵乘法：(N, 3) @ (3, 3)^T
        aug_centerline = centerline @ scaling_matrix.T
        aug_centerlines.append(aug_centerline)
    self.centerlines = aug_centerlines

def rotate(self, rotation_matrix):
    """旋转所有centerlines"""
    aug_centerlines = []
    for i in range(len(self.centerlines)):
        centerline = self.centerlines[i]
        # 矩阵乘法：(N, 3) @ (3, 3)^T
        aug_centerline = centerline @ rotation_matrix.T
        aug_centerlines.append(aug_centerline)
    self.centerlines = aug_centerlines
```

### 2.4 数据增强的影响

**论文中的说明**:
- 论文Section 4.1提到使用了数据增强，但未详细说明
- 代码中实现了标准的BEV数据增强：翻转、旋转、缩放

**增强范围**:
- 翻转：水平/垂直各50%概率
- 旋转：±22.5°
- 缩放：0.95-1.05倍

**坐标系一致性**:
- Centerlines和lidar2ego变换同步更新
- 保证图像和centerline的对齐

---

**下一部分**：图结构构建和序列化（最核心的部分）
