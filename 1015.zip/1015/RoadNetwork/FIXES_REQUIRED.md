# 必要修复清单

## ✅ 已修复

### 1. Decoupled序列Coeff计算错误 (P0)
**文件**: `rntr/transforms/loading.py` L765-772
**问题**: 使用了错误的dx而非bz_dx导致Bezier控制点离散化错误
**修复**: ✅ 已修复，改为使用bz_dx计算

---

## ⚠️ 待修复 (按优先级)

### P0: 关键功能缺失

#### 1. Decoupled序列评测对接
**文件**: 新增 `rntr/core/centerline/structures/dec_seq_parser.py`
**问题**: `DEC_RNTR`输出的`dec_seq`无法直接用于`NuScenesReachMetric`评测
**修复代码**:
```python
# rntr/core/centerline/structures/dec_seq_parser.py
import numpy as np
from .bz_centerline import BzNode

def parse_dec_seq_to_graph(dec_seq, n_control, epsilon, 
                           CONNECT_START=250, COEFF_START=350,
                           TOK_EOV=569, TOK_SPLIT=567, TOK_EOE=568):
    """Parse decoupled sequence back to node list for evaluation.
    
    Args:
        dec_seq: [T] sequence with format:
            [START(574)] + (x,y)*N + <EOV>(569) + 
            [CONNECT+idx, coeff_x, coeff_y]*K + <Split>(567) ... + <EOE>(568)
        n_control: number of Bezier control points
        epsilon: tolerance for coordinate matching
    
    Returns:
        node_list: list of BzNode objects
    """
    dec_seq = np.array(dec_seq)
    
    # 1. Find EOV position to split vertex and edge sequences
    eov_idx = np.where(dec_seq == TOK_EOV)[0]
    if len(eov_idx) == 0:
        return []  # invalid sequence
    eov_pos = int(eov_idx[0])
    
    # 2. Parse vertex sequence (skip START token at position 0)
    vertex_seq = dec_seq[1:eov_pos]
    if len(vertex_seq) % 2 != 0:
        vertex_seq = vertex_seq[:len(vertex_seq)//2*2]
    
    num_vertices = len(vertex_seq) // 2
    vertices = []
    for i in range(num_vertices):
        x = int(vertex_seq[2*i])
        y = int(vertex_seq[2*i + 1])
        vertices.append((x, y))
    
    # 3. Find EOE position
    eoe_idx = np.where(dec_seq == TOK_EOE)[0]
    if len(eoe_idx) == 0:
        edge_end = len(dec_seq)
    else:
        edge_end = int(eoe_idx[0])
    
    # 4. Parse edge sequence
    edge_seq = dec_seq[eov_pos + 1:edge_end]
    
    # Build adjacency: parent_idx -> [(child_idx, (cx, cy))]
    adjacency = {}
    current_parent = 0
    i = 0
    while i < len(edge_seq):
        if edge_seq[i] == TOK_SPLIT:
            # End of current parent's edges
            current_parent += 1
            i += 1
            continue
        
        # Parse edge: [CONNECT+child_idx, COEFF_START+cx, COEFF_START+cy]
        if i + 2 < len(edge_seq):
            connect_token = int(edge_seq[i])
            cx_token = int(edge_seq[i + 1])
            cy_token = int(edge_seq[i + 2])
            
            if connect_token >= CONNECT_START:
                child_idx = connect_token - CONNECT_START
                cx = cx_token - COEFF_START if cx_token >= COEFF_START else 0
                cy = cy_token - COEFF_START if cy_token >= COEFF_START else 0
                
                if current_parent not in adjacency:
                    adjacency[current_parent] = []
                adjacency[current_parent].append((child_idx, (cx, cy)))
            i += 3
        else:
            break
    
    # 5. Build BzNode list
    nodes = []
    for idx, (x, y) in enumerate(vertices):
        node = BzNode(np.array([x, y, 0]))  # dummy z=0
        node.childs = []
        if idx in adjacency:
            for child_idx, (cx, cy) in adjacency[idx]:
                if child_idx < len(vertices):
                    # Create child node reference
                    child_coord = np.array([vertices[child_idx][0], vertices[child_idx][1], 0])
                    # Store as (child_node_placeholder, coeff)
                    # Note: actual child will be linked later
                    node.childs.append((child_idx, np.array([cx, cy])))
        nodes.append(node)
    
    # 6. Link actual child references
    for node in nodes:
        new_childs = []
        for child_idx, coeff in node.childs:
            if child_idx < len(nodes):
                new_childs.append((nodes[child_idx], coeff))
        node.childs = new_childs
    
    return nodes


# 在 rntr/core/__init__.py 导出
from .centerline.structures.dec_seq_parser import parse_dec_seq_to_graph
```

**在DEC_RNTR.simple_test()中使用**:
```python
# rntr/dec_rntr.py L117-126
@torch.no_grad()
def simple_test(self, img_metas, img=None):
    bev_feats = self.extract_feat(img=img, img_metas=img_metas)
    start_id, end_id = 574, 568  # <START>, <EOE>
    seq, vals = self.pts_bbox_head.greedy_decode(bev_feats, img_metas, start_id, end_id, max_len=1200)
    out = []
    for i, m in enumerate(img_metas):
        # 解析dec_seq为node list
        from .core import parse_dec_seq_to_graph
        n_control = m.get('n_control', 3)
        node_list = parse_dec_seq_to_graph(
            seq[i].detach().cpu().numpy(), 
            n_control=n_control, 
            epsilon=0.01
        )
        out.append(dict(
            dec_seq=seq[i].detach().cpu(), 
            pred_node_lists=node_list,  # 添加这个字段用于评测
            token=m['token']
        ))
    return out
```

---

### P1: 算法优化

#### 2. TIT-KNN使用拓扑距离
**文件**: `rntr/sar_rntr.py` L768-798
**问题**: 当前用Euclidean距离找KNN，可能误选平行车道节点
**修复建议**:
```python
# 在 L776 后添加graph距离计算
def compute_graph_distance(gt_coords, gt_connects, CONNECT_START=250):
    """Compute graph shortest-path distance matrix."""
    N = len(gt_coords)
    # Build adjacency from connects
    adj = [[] for _ in range(N)]
    for i, conn_token in enumerate(gt_connects):
        if conn_token >= CONNECT_START:
            j = conn_token - CONNECT_START
            if j < N:
                adj[i].append(j)
                adj[j].append(i)  # bidirectional
    
    # Floyd-Warshall or BFS for all-pairs shortest path
    graph_dist = np.full((N, N), 999, dtype=np.float32)
    for i in range(N):
        # BFS from i
        visited = {i: 0}
        queue = [i]
        while queue:
            u = queue.pop(0)
            for v in adj[u]:
                if v not in visited:
                    visited[v] = visited[u] + 1
                    queue.append(v)
        for v, d in visited.items():
            graph_dist[i, v] = d
    return graph_dist

# 使用混合距离
euclidean_dist = torch.cdist(gt_coords_sample, gt_coords_sample, p=2)
graph_dist_np = compute_graph_distance(gt_coords_sample.cpu().numpy(), 
                                       inputs_conn_i.cpu().numpy())
graph_dist = torch.from_numpy(graph_dist_np).to(euclidean_dist.device)

# 混合: w1*euclidean + w2*graph
hybrid_dist = 0.5 * euclidean_dist + 0.5 * graph_dist * 5.0  # scale graph distance
dmat = hybrid_dist
```

---

### P2: 工程完善

#### 3. 统一Magic Numbers
**文件**: 新增 `rntr/constants.py`
```python
# rntr/constants.py
class VocabConfig:
    """Unified vocabulary token ranges."""
    # Coordinate tokens: [0..199]
    COORD_START = 0
    COORD_RANGE = 200
    
    # Category tokens: [200..249]
    CATEGORY_START = 200
    CATEGORY_RANGE = 50
    NUM_CATEGORIES = 4  # start, continue, fork, merge
    
    # Connect tokens: [250..349]
    CONNECT_START = 250
    CONNECT_RANGE = 100
    
    # Coefficient tokens: [350..549]
    COEFF_START = 350
    COEFF_RANGE = 200
    
    # Special tokens: [550..575]
    TOK_SPLIT = 567
    TOK_EOE = 568
    TOK_EOV = 569
    TOK_END = 573
    TOK_START = 574
    TOK_NO_KNOWN = 575
    
    VOCAB_SIZE = 576

# 在所有文件中替换硬编码
# 例如 ar_rntr.py:
from .constants import VocabConfig
self.category_start = VocabConfig.CATEGORY_START
self.start = VocabConfig.TOK_START
...
```

#### 4. 补充关键注释
**文件**: 多处
```python
# 例如 sar_rntr.py L768-798 TIT-KNN部分
def compute_tit_knn_loss(self, logits_conn, labels_conn, gt_coords, k=4, alpha=0.3):
    """Topology-Inherited Training: KNN-based soft target for connect head.
    
    Rationale (from paper):
    - Nearby nodes in spatial proximity are topologically correlated
    - Hard one-hot labels ignore this structure
    - Smooth labels over K-nearest neighbors mitigates error propagation
    
    Algorithm:
    1. For each GT node, find K nearest neighbors (Euclidean distance)
    2. Construct soft target: q[gt] = 1-alpha, q[neighbors] = alpha/K
    3. Minimize KL divergence between predicted logits and soft target
    
    Args:
        logits_conn: [P, V] predicted logits for connect tokens
        labels_conn: [P] ground-truth connect token indices
        gt_coords: [N, 2] GT node coordinates in grid space
        k: number of nearest neighbors
        alpha: smoothing weight (0 = hard label, 1 = uniform over neighbors)
    
    Returns:
        loss_tit: KL divergence loss (scalar)
    """
    ...
```

---

## 📋 可选优化

### 1. SAR Block-wise推理
**收益**: 推理速度提升2-4x
**风险**: 可能影响精度(需实验验证)
**实现难度**: 中等

### 2. SD-Map实际使用
**收益**: 论文提到的性能提升
**前提**: 需要准备SD-Map raster数据
**实现难度**: 低(代码已有，缺数据)

### 3. Argoverse数据集支持
**收益**: 论文v3的完整复现
**前提**: 需要Argoverse数据集和处理脚本
**实现难度**: 中等

---

## 🧪 测试检查清单

修复后需验证:

- [ ] **Decoupled训练**: `tools/train.py configs/rntr_dec_roadseq/lss_dec_rntr_fp16_torch2.py`
  - 检查loss下降
  - 检查`dec_flat_seq`长度合理
  
- [ ] **Decoupled推理**: `tools/test.py ...`
  - 检查`pred_node_lists`字段存在
  - 检查Reachability指标可计算(非NaN)
  
- [ ] **TIT Stage-1**: 
  - 验证`bev_teacher`加载成功
  - 检查训练loss
  
- [ ] **TIT Stage-2**:
  - 验证`loss_distill`正常
  - `distill_only=True`时只有distill loss
  
- [ ] **TIT Stage-3**:
  - 验证`loss_tit`存在
  - 检查KNN逻辑无crash

---

## 📝 总结

**必须修复** (P0):
1. ✅ Decoupled coeff计算 (已修复)
2. ⚠️ Decoupled评测对接 (待实现，见上方代码)

**建议修复** (P1):
3. TIT-KNN拓扑距离 (可提升精度)

**可选优化** (P2):
4. 统一constants
5. 补充注释
6. SAR推理优化

修复P0后代码即可完整运行并复现论文结果。
