# KP Prompt 实现审查报告

## 📋 论文要求总结（来自 3-method.tex L243-L271）

### 1. **KP Prompt 的定义与组成**（L244-L248）
> "Key-point Prompt for a sub sequence $y_{i,1:L}$ contains two parts:  
> (i) locations of all key-points;  
> (ii) location of the start key-point (\texttt{Ancestor}) of $y_{i,1:L}$."

**论文要求**：
- 包含**所有关键点的位置**
- 包含**每个子序列的起始关键点（Ancestor）位置**
- 将这些位置组织为离散 token 序列
- 分配专用的 word embedding 和 position embedding
- **将 KP Prompt 添加到 Semi-Autoregressive 序列中**以聚合关键点信息

### 2. **训练目标**（L250-L266）
> "The objective contains two part: key-points detection and auto-regressive MLE loss.  
> Key-points are optimized by Hungarian loss."

**论文要求**：
- **关键点检测**：使用 Hungarian 匹配 + 分类损失 + L1 回归损失
- **序列生成**：Auto-regressive MLE loss（交叉熵）

### 3. **应用范围**（L232, L279, L300-L302）
- **SAR-RNTR**：公式明确包含 $\mathcal{V}_{kp}$
- **NAR-RNTR**：公式明确包含 $\mathcal{V}_{kp}$
- **AR-RNTR**：论文总结部分提到"三种 Transformer 解码策略"，暗示通用性

---

## ✅ 当前实现的正确之处

### 1. **关键点检测分支**（SAR 头已实现）
- ✅ `SARRNTRHead` 有独立的 `kp_transformer`（Keypoint Transformer Decoder）
- ✅ 使用 `kp_query_embed` 作为 learned positional embeddings
- ✅ 输出 `kp_cls_logits`（分类）和 `kp_coords_norm`（归一化坐标）
- ✅ 在 `sar_rntr.py` 中实现了 Hungarian 匹配和损失计算（L831-L870）

### 2. **KP Prompt 注入机制**（所有头均已实现）
- ✅ **Add 模式**：通过 `kp_prompt_adapter` 将 top-K KP 特征聚合为全局 bias，加到 token embedding
- ✅ **Cross 模式**：将 top-K KP 作为独立 prompt 序列，通过 cross-attention 注入
- ✅ 支持 `kp_prompt_weighted`（加权聚合）和 `kp_prompt_detach`（梯度控制）

### 3. **Transformer 签名适配**（所有头均已实现）
- ✅ 统一的 `_call_transformer_with_sign` 函数
- ✅ 支持 `LssSARPrmSeqLineTransformer`（SAR 专用，支持 prompt）
- ✅ 支持 `LssPlPrySeqLineTransformer`/`LssMLMPlPrySeqLineTransformer`（NAR 专用）
- ✅ 回退到标准 Transformer（不支持 prompt 时自动忽略）

### 4. **覆盖范围**
- ✅ **AR-RNTR**：`ar_rntr_head.py` 训练与推理均支持
- ✅ **SAR-RNTR**：`sar_rntr_head.py` 训练、SAR 推理、NAR 推理、块级并行推理均支持
- ✅ **DEC-RNTR**：`dec_rntr_head.py` 训练与推理均支持

---

## ⚠️ 当前实现与论文的差异

### 🔴 **关键问题 1：缺少 KP 损失计算（AR/DEC 头）**

**论文要求**（L250-L264）：
- 关键点检测需要**独立的训练目标**（Hungarian loss）
- 包括分类损失（是否为关键点）和回归损失（坐标 L1）

**当前状态**：
- ✅ **SAR 头**：在 `sar_rntr.py` 中实现了完整的 KP 损失计算（L831-L870）
- ❌ **AR 头**：虽然添加了 `kp_transformer`、`kp_cls_head`、`kp_reg_head`，但**没有计算 KP 损失**
- ❌ **DEC 头**：同样缺少 KP 损失计算

**影响**：
- AR/DEC 头的 `kp_transformer` 分支**无法被训练**（梯度不会回传）
- KP Prompt 在 AR/DEC 中只能依赖随机初始化或预训练权重，无法针对当前任务优化

**修复建议**：
1. 在 `ARRNTRHead` 和 `DECRNTRHead` 中添加 `forward_keypoints()` 方法（参考 SAR 头 L839-L858）
2. 在对应的 `rntr.py` 或训练脚本中调用 `forward_keypoints()` 并计算 Hungarian loss
3. 将 `loss_kp_cls` 和 `loss_kp_reg` 加入总损失

---

### 🟡 **问题 2：Ancestor（起始关键点）未精确绑定**

**论文要求**（L245）：
> "location of the start key-point (\texttt{Ancestor}) of $y_{i,1:L}$"

**当前实现**：
- 使用**全局 top-K 关键点**作为 prompt（基于置信度排序）
- **未区分每个子序列的 Ancestor**

**论文语义**：
- 每个子序列 $y_{i,1:L}$ 应该知道**它自己的起始关键点**
- 这需要在推理时根据子序列的起点位置，检索最近的关键点作为 Ancestor

**影响**：
- 当前实现更通用（所有子序列共享 top-K KP），但不完全符合论文"per-subsequence Ancestor"的描述
- 对于 SAR 的多子序列并行生成，理论上每个子序列应该有独立的 Ancestor 信息

**修复建议**（可选）：
1. 在 `img_metas` 中传递每个子序列的起点位置（如 `sar_group_start_pos`）
2. 在推理时，为每个子序列计算最近的 KP 作为 Ancestor
3. 将 Ancestor 与全局 KP 拼接作为 prompt

**是否必须修复**：
- 如果你追求**严格对齐论文**，需要修复
- 如果你认为**全局 top-K 更实用**（避免复杂的子序列-KP 绑定逻辑），可以保持现状

---

### 🟡 **问题 3：Position Embedding 的使用方式**

**论文描述**（L247）：
> "assigning dedicated word embeddings and position embedding for the prompt"

**当前实现**：
- `kp_pos_mlp`：将 KP 的归一化坐标 `(x, y)` 映射为 position embedding
- 在 `cross` 模式下，`kp_prompt_pos` 作为 prompt 的位置编码传入 Transformer

**论文语义**：
- 论文提到"将 KP 位置组织为离散 token 序列"
- 可能暗示将坐标**离散化为 token ID**，然后通过 embedding 层获取 word embedding

**影响**：
- 当前实现是**连续的坐标编码**（通过 MLP 映射）
- 论文可能期望**离散的 token 编码**（类似于序列中的 `v_x`, `v_y`）

**修复建议**（可选）：
1. 将 KP 坐标量化为离散 bin（如 200x200 网格）
2. 为每个 bin 分配一个 token ID
3. 通过 embedding 层获取 word embedding
4. 与 position embedding 相加

**是否必须修复**：
- 当前的连续编码方式**更灵活**，不会因离散化损失精度
- 如果你追求严格对齐论文的"离散 token"描述，可以修复

---

### 🟢 **问题 4：Add vs Cross 模式的选择**

**论文描述**（L248）：
> "The Key-point Prompt is then **added** to Semi-Autoregressive \seqdata{}"

**当前实现**：
- 支持 `add` 和 `cross` 两种模式
- `add`：直接加到 token embedding（符合论文描述）
- `cross`：作为独立 prompt 走 cross-attention（更强大但论文未明确提及）

**论文语义**：
- 论文明确说"added"，暗示**加法操作**
- 但论文也提到"facilitates the aggregation of key-point information"，可能暗示更复杂的交互

**影响**：
- `add` 模式**严格符合论文字面描述**
- `cross` 模式**更符合现代 Transformer 的 prompt 设计**（如 DETR 的 object queries）

**建议**：
- 默认使用 `add` 模式（与论文一致）
- 保留 `cross` 模式作为消融实验选项

---

## 📊 实现完整度评分

| 模块 | 论文要求 | 当前实现 | 评分 | 备注 |
|------|---------|---------|------|------|
| **KP 检测分支** | ✅ | ✅ (SAR) / ❌ (AR/DEC) | 🟡 **70%** | AR/DEC 缺少损失计算 |
| **KP Prompt 注入** | ✅ | ✅ | ✅ **100%** | Add + Cross 均已实现 |
| **Transformer 适配** | ✅ | ✅ | ✅ **100%** | 签名分发完善 |
| **Ancestor 绑定** | ✅ | ❌ | 🟡 **60%** | 使用全局 top-K，未 per-subsequence |
| **Position Embedding** | ✅ | 🟡 | 🟡 **80%** | 连续编码 vs 离散 token |
| **覆盖范围** | AR/SAR/NAR | ✅ | ✅ **100%** | 所有头均已接入 |

**总体评分**：🟡 **85%**

---

## 🔧 修复优先级

### 🔴 **高优先级（必须修复）**
1. **为 AR/DEC 头添加 KP 损失计算**
   - 否则 KP 分支无法训练，prompt 效果无法保证

### 🟡 **中优先级（建议修复）**
2. **实现 per-subsequence Ancestor 绑定**（如果追求严格对齐论文）
   - 需要修改 `img_metas` 传递子序列起点信息
   - 在推理时动态检索最近 KP

### 🟢 **低优先级（可选）**
3. **将坐标编码改为离散 token**（如果追求论文字面描述）
   - 量化坐标为 bin，通过 embedding 层获取 word embedding

---

## 📝 推荐的修复步骤

### Step 1: 为 AR/DEC 头添加 KP 损失（高优先级）

**在 `ar_rntr_head.py` 中添加**：
```python
def forward_keypoints(self, mlvl_feats, img_metas):
    """Forward keypoint parallel branch (same as SAR head)."""
    if not self.kp_prompt_enable:
        return None, None
    x = mlvl_feats
    if self.in_channels != self.embed_dims:
        x = self.bev_proj(x)
    pos_embed = self.bev_position_encoding(x)
    B, _, H, W = x.shape
    masks = torch.zeros(B, H, W).bool().to(x.device)
    query_embed = self.kp_query_embed.weight
    outs_dec, _ = self.kp_transformer(x, masks, query_embed, pos_embed)
    feats = torch.nan_to_num(outs_dec)[-1]
    kp_cls_logits = self.kp_cls_head(feats)
    kp_coords_norm = torch.sigmoid(self.kp_reg_head(feats))
    return kp_cls_logits, kp_coords_norm
```

**在训练脚本（如 `rntr.py`）中调用**：
```python
# 在 loss 计算部分
if hasattr(self.pts_bbox_head, 'forward_keypoints'):
    kp_cls_logits, kp_coords_norm = self.pts_bbox_head.forward_keypoints(bev_feats, img_metas)
    if kp_cls_logits is not None:
        # 计算 Hungarian loss（参考 sar_rntr.py L831-L870）
        loss_kp_cls, loss_kp_reg = self._compute_kp_loss(kp_cls_logits, kp_coords_norm, img_metas)
        losses['loss_kp_cls'] = loss_kp_cls
        losses['loss_kp_reg'] = loss_kp_reg
```

### Step 2: 实现 Ancestor 绑定（中优先级，可选）

**修改 `img_metas` 传递子序列起点**：
```python
# 在数据处理阶段，为每个子序列记录起点坐标
img_metas[i]['sar_group_start_coords'] = [[x1, y1], [x2, y2], ...]  # M 个子序列
```

**在推理时检索最近 KP**：
```python
# 在 forward() 中
if 'sar_group_start_coords' in img_metas[0]:
    start_coords = torch.tensor(img_metas[0]['sar_group_start_coords']).to(x.device)  # [M, 2]
    kp_coords = kp_coords_norm * torch.tensor([W, H]).to(x.device)  # [Q, 2]
    # 计算距离矩阵 [M, Q]
    dist = torch.cdist(start_coords, kp_coords)
    # 为每个子序列找最近的 KP
    ancestor_idx = dist.argmin(dim=-1)  # [M]
    # 将 Ancestor 与 top-K KP 拼接
    kp_prompt = torch.cat([kp_feats[ancestor_idx], kp_sel], dim=1)
```

---

## 🎯 结论

**当前实现的优点**：
- ✅ 架构完整，覆盖所有头（AR/SAR/NAR/DEC）
- ✅ 支持两种 prompt 模式（add/cross）
- ✅ Transformer 签名适配灵活
- ✅ SAR 头的 KP 检测与损失计算完善

**需要修复的关键问题**：
- 🔴 **AR/DEC 头缺少 KP 损失计算**（导致 KP 分支无法训练）
- 🟡 **Ancestor 未 per-subsequence 绑定**（与论文描述有偏差）
- 🟡 **Position Embedding 使用连续编码而非离散 token**（与论文字面描述有偏差）

**推荐行动**：
1. **立即修复**：为 AR/DEC 头添加 `forward_keypoints()` 和损失计算
2. **可选修复**：实现 Ancestor 绑定（如果追求严格对齐）
3. **保持现状**：Position Embedding 的连续编码方式更实用

**总体评价**：当前实现在**架构层面已与论文对齐**，但在**训练细节**（KP 损失）和**语义细节**（Ancestor 绑定）上还有改进空间。修复 KP 损失计算后，实现完整度可达 **95%**。
