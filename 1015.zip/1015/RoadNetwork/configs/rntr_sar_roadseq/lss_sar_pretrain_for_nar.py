# SAR Pretraining Configuration (Step 1 for NAR)
# This config is used to train SAR model which will be loaded for NAR finetuning

_base_ = ['./lss_sar_rntr_paper_fp16_torch2.py']

# ✅ Key difference: Disable NAR-MLM training
model = dict(
    pts_bbox_head=dict(
        nar_mlm_train=False,   # ✅ Pure SAR training
        nar_infer=False,        # ✅ Use AR inference during validation
    )
)

# Training schedule
max_epochs = 300
train_cfg = dict(max_epochs=max_epochs)

# Learning rate schedule
param_scheduler = [
    dict(
        type='LinearLR',
        start_factor=1.0 / 3,
        by_epoch=False,
        begin=0,
        end=500),
    dict(
        type='CosineAnnealingLR',
        begin=0,
        T_max=max_epochs,
        end=max_epochs,
        by_epoch=True,
        eta_min=1e-7)
]

# This will be used as: load_from='work_dirs/sar_pretrain/latest.pth' for NAR
