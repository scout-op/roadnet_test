# SAR Block-wise Parallel Decoding Implementation

## 概述

本实现为 SAR (Semi-Autoregressive) RNTR 添加了块级并行推理功能，这是论文中提到的重要优化。与逐 token 生成相比，块级并行解码可以显著提升推理速度，同时保持推理质量。

## 核心思想

- **论文出处**: `arXiv-2402.08207v3/file/3-method.tex` 行 231-236
- **关键概念**: "对于固定的 j，所有 y_{1:M, j} 并行生成；对于固定的 i，y_{i,j} 自回归生成"
- **实现策略**: 使用块级因果掩码，允许块内并行同时保持块间因果关系

## 代码实现

### 1. 新增参数

在 `SARRNTRHead.__init__()` 中新增：

```python
# SAR block-wise inference
sar_block_decode: bool = False,        # 启用块级并行推理
sar_block_max_steps: int = None,       # 最大块级步数（可选）
```

### 2. 核心方法

新增 `_sar_block_decode()` 方法，实现：

- **块级扩展**: 每次扩展一个完整的块（`block_len = clause_length * sar_group_clauses`）
- **掩码复用**: 使用训练时相同的 `_build_block_causal_mask()` 或 `_build_group_mask_from_ids()`
- **并行生成**: 一次 Transformer 前向生成整个块的所有 token
- **早停检测**: 当所有序列都生成 `<END>` token 时提前结束

### 3. 关键逻辑

```python
# 扩展序列到下一个块长度
T_next = min(T_cur + block_len, max_len, max_pos)
padding = torch.full((B, new_block_len), int(self.no_known), device=device)
seq_extended = torch.cat([seq, padding], dim=-1)

# 构建块级因果掩码
tgt_mask = _build_block_causal_mask(T, block_len, device)

# 一次前向生成整个块
outs_dec, _ = self.transformer(tgt, x, tgt_mask, masks, query_embed, pos_embed)
block_feats = outs_dec[-1, :, T_cur:T_next, :]  # 提取新块的特征
block_tokens = self.vocab_embed(block_feats).softmax(-1).argmax(-1)  # 生成tokens
```

## 使用方法

### 配置启用

在 SAR 模型配置中设置：

```python
# 在配置文件中
pts_bbox_head = dict(
    type='SARRNTRHead',
    # ... 其他参数 ...
    sar_block_decode=True,              # 启用块级并行推理
    sar_block_max_steps=50,             # 可选：限制最大步数
    sar_group_clauses=1,                # 每个块包含的子句数
)
```

### 运行时切换

```python
# 动态启用/禁用
model.pts_bbox_head.sar_block_decode = True   # 启用
model.pts_bbox_head.sar_block_decode = False  # 禁用，回退到逐token模式
```

## 性能预期

### 速度提升
- **理论加速比**: 2-4× (取决于 `block_len` 和硬件)
- **实际表现**: 单个块内的 token 可并行计算，减少 Transformer 前向次数

### 精度影响
- **预期**: 与逐 token 模式接近，可能有细微差异
- **建议**: 先在验证集上 A/B 测试，对比 mLP/mLR/mLF 和 mRP/mRR/mRF 指标

## 验证与调试

### 1. 功能验证

```bash
# 测试块级推理
python tools/test.py configs/your_sar_config.py checkpoint.pth --eval-options sar_block_decode=True

# 对比原始推理
python tools/test.py configs/your_sar_config.py checkpoint.pth --eval-options sar_block_decode=False
```

### 2. 参数调优

- **`sar_group_clauses`**: 每个块的子句数，越大并行度越高但显存占用增加
- **`sar_block_max_steps`**: 限制最大块数，防止超长序列
- **掩码策略**: 优先使用 `meta_groups`，回退到 `block_causal`

### 3. 常见问题

- **显存不足**: 减小 `sar_group_clauses` 或 `batch_size`
- **精度下降**: 检查掩码构建是否正确，尝试不同的 `sar_intra_group_mlm` 设置
- **速度无提升**: 确认 Transformer 支持 `tgt_mask`（推荐 `LssSARPrmSeqLineTransformer`）

## 兼容性

- **向后兼容**: 默认 `sar_block_decode=False`，保持原有行为
- **模型兼容**: 无需重新训练，仅推理时生效
- **配置灵活**: 可运行时动态切换模式

## 扩展方向

1. **自适应块长**: 根据置信度动态调整块大小
2. **混合策略**: 前几步用块级，后续用逐token（精度优先）
3. **多尺度并行**: 不同子序列使用不同块长度

---

这个实现完整体现了论文中 SAR "块内并行、块间因果" 的核心思想，为 RNTR 的实用化提供了重要的速度优化。
