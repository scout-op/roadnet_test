# ------------------------------------------------------------------------
# Decoupled Sequence Head for RoadNetTransformer
# Token-level language modeling over a flattened sequence:
# [START] + (x,y)*N + <EOV> + [CONNECT, coeff_x, coeff_y, ... , <Split>]*M + <EOE>
# ------------------------------------------------------------------------
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmdet3d.registry import MODELS

# Reuse utilities from ARRNTRHead
from .ar_rntr_head import PryDecoderEmbeddings, MLP


@MODELS.register_module()
class DECRNTRHead(nn.Module):
    """Minimal token-level head for decoupled sequence.

    Responsibilities:
    - Embed input token ids
    - Run transformer decoder over BEV features
    - Project to vocabulary logits (num_center_classes)
    - Compute CE loss vs. next-token labels
    """

    def __init__(self,
                 in_channels=256,
                 embed_dims=256,
                 num_center_classes=576,
                 max_len=1200,
                 transformer=None,
                 bev_positional_encoding=dict(
                     type='PositionEmbeddingSineBEV', num_feats=128, normalize=True),
                 kp_num_query=34,
                 kp_num_classes=4,
                 kp_prompt_enable=False,
                 kp_prompt_type='add',
                 kp_prompt_detach=True,
                 kp_prompt_topk=34,
                 kp_prompt_weighted=True,
                 ) -> None:
        super().__init__()
        self.in_channels = in_channels
        self.embed_dims = embed_dims
        self.vocab_size = num_center_classes
        self.max_len = int(max_len)

        # build transformer and pos enc
        self.transformer = MODELS.build(transformer)
        self.bev_position_encoding = MODELS.build(bev_positional_encoding)

        # projection for BEV channels if needed
        if self.in_channels != self.embed_dims:
            self.bev_proj = nn.Conv2d(self.in_channels, self.embed_dims, kernel_size=1)
        else:
            self.bev_proj = nn.Identity()

        # token embedding and classifier
        self.embedding = PryDecoderEmbeddings(self.vocab_size, self.embed_dims, self.max_len)
        self.vocab_embed = MLP(self.embed_dims, self.embed_dims, self.vocab_size, 3)

        # optional KP prompt
        self.kp_num_query = kp_num_query
        self.kp_num_classes = kp_num_classes
        self.kp_prompt_enable = bool(kp_prompt_enable)
        self.kp_prompt_type = kp_prompt_type
        self.kp_prompt_detach = bool(kp_prompt_detach)
        self.kp_prompt_topk = int(kp_prompt_topk)
        self.kp_prompt_weighted = bool(kp_prompt_weighted)
        if self.kp_prompt_enable:
            kp_transformer = dict(
                type='LssSARPrmSeqLineTransformer',
                decoder=dict(
                    type='PETRTransformerLineDecoder',
                    return_intermediate=True,
                    num_layers=3,
                    transformerlayers=dict(
                        type='PlPryLineTransformerDecoderLayer',
                        attn_cfgs=[
                            dict(type='RNTR2MultiheadAttention', embed_dims=self.embed_dims, num_heads=8, dropout=0.1),
                            dict(type='RNTR2MultiheadAttention', embed_dims=self.embed_dims, num_heads=8, dropout=0.1),
                        ],
                        ffn_cfgs=dict(type='FFN', embed_dims=self.embed_dims, feedforward_channels=self.embed_dims*4, num_fcs=2, ffn_drop=0.1, act_cfg=dict(type='ReLU', inplace=True)),
                        with_cp=False,
                        operation_order=('self_attn','norm','cross_attn','norm','ffn','norm')
                    ),
                ))
            self.kp_transformer = MODELS.build(kp_transformer)
            self.kp_query_embed = nn.Embedding(self.kp_num_query, self.embed_dims)
            self.kp_cls_head = nn.Linear(self.embed_dims, self.kp_num_classes)
            self.kp_reg_head = MLP(self.embed_dims, self.embed_dims, 2, 3)
            if self.kp_prompt_type == 'add':
                self.kp_prompt_adapter = nn.Sequential(
                    nn.Linear(self.embed_dims, self.embed_dims), nn.ReLU(inplace=True), nn.Linear(self.embed_dims, self.embed_dims)
                )
            self.kp_pos_mlp = nn.Sequential(
                nn.Linear(2, self.embed_dims), nn.ReLU(inplace=True), nn.Linear(self.embed_dims, self.embed_dims)
            )

        # loss
        self.loss_ce = MODELS.build(dict(type='mmdet.CrossEntropyLoss'))

    def init_weights(self):
        if hasattr(self.transformer, 'init_weights'):
            self.transformer.init_weights()

    def forward(self, bev_feats: torch.Tensor, input_tokens: torch.Tensor, img_metas):
        """Forward
        Args:
            bev_feats: [B, C, H, W]
            input_tokens: [B, T] token ids
        Returns:
            logits_all_layers: [L, B, T, V]
        """
        x = self.bev_proj(bev_feats)
        pos_embed = self.bev_position_encoding(x)
        B, _, H, W = x.shape
        masks = torch.zeros(B, H, W, dtype=torch.bool, device=x.device)

        tgt = self.embedding(input_tokens.long())
        kp_bias = None
        kp_prompt = None
        kp_prompt_pos = None
        if self.kp_prompt_enable:
            try:
                kp_q = self.kp_query_embed.weight
                kp_dec, _ = self.kp_transformer(x, masks, kp_q, pos_embed)
                kp_feats = torch.nan_to_num(kp_dec)[-1]
                kp_feats_cls = kp_feats.detach() if self.kp_prompt_detach else kp_feats
                kp_cls_logits = self.kp_cls_head(kp_feats_cls)
                with torch.no_grad():
                    kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]
                    k = max(1, min(self.kp_prompt_topk, kp_scores.shape[1]))
                    topk_scores, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
                gather_idx = topk_idx.unsqueeze(-1).expand(-1, -1, kp_feats.shape[-1])
                kp_sel = torch.gather(kp_feats if not self.kp_prompt_detach else kp_feats.detach(), 1, gather_idx)
                if self.kp_prompt_weighted:
                    w = topk_scores / (topk_scores.sum(dim=-1, keepdim=True) + 1e-6)
                    kp_global = (kp_sel * w.unsqueeze(-1)).sum(dim=1)
                else:
                    kp_global = kp_sel.mean(dim=1)
                if self.kp_prompt_type == 'add':
                    kp_bias = self.kp_prompt_adapter(kp_global)
                else:
                    kp_prompt = kp_sel
                    kp_coords_norm = torch.sigmoid(self.kp_reg_head(kp_feats))
                    gather_idx_p = topk_idx.unsqueeze(-1).expand(-1, -1, kp_coords_norm.shape[-1])
                    kp_prompt_pos = torch.gather(kp_coords_norm, 1, gather_idx_p)
                    kp_prompt_pos = self.kp_pos_mlp(kp_prompt_pos)
            except Exception:
                kp_bias, kp_prompt, kp_prompt_pos = None, None, None
        if kp_bias is not None:
            tgt = tgt + kp_bias.unsqueeze(1)

        query_embed = self.embedding.position_embeddings.weight

        transformer_name = self.transformer.__class__.__name__
        def _call_transformer_with_sign(fname, tgt_, x_, tgt_mask_, masks_, q_embed_, pos_embed_, prm=None, prm_pos=None):
            if fname == 'LssSARPrmSeqLineTransformer':
                if prm is not None and prm_pos is not None:
                    return self.transformer(tgt_, x_, tgt_mask_, masks_, q_embed_, pos_embed_, prm, prm_pos)
                return self.transformer(tgt_, x_, tgt_mask_, masks_, q_embed_, pos_embed_)
            elif fname in ('LssPlPrySeqLineTransformer', 'LssMLMPlPrySeqLineTransformer'):
                tgt_cross = tgt_.unsqueeze(1)
                return self.transformer(tgt_cross, x_, prm, masks_, q_embed_, pos_embed_, prm_pos)
            elif fname == 'LssPlBzTransformer':
                return self.transformer(tgt_, x_, tgt_mask_, masks_, q_embed_, pos_embed_)
            else:
                return self.transformer(tgt_, x_, masks_, q_embed_, pos_embed_)

        tgt_mask_none = None
        try:
            if kp_prompt is not None and kp_prompt_pos is not None and transformer_name in ('LssPlPrySeqLineTransformer','LssMLMPlPrySeqLineTransformer','LssSARPrmSeqLineTransformer'):
                outs_dec, _ = _call_transformer_with_sign(transformer_name, tgt, x, tgt_mask_none, masks, query_embed, pos_embed, kp_prompt, kp_prompt_pos)
            else:
                outs_dec, _ = _call_transformer_with_sign(transformer_name, tgt, x, tgt_mask_none, masks, query_embed, pos_embed, None, None)
        except TypeError:
            outs_dec, _ = _call_transformer_with_sign(transformer_name, tgt, x, tgt_mask_none, masks, query_embed, pos_embed, None, None)
        outs_dec = torch.nan_to_num(outs_dec)
        logits = self.vocab_embed(outs_dec)  # [L, B, T, V]
        return logits

    def loss_by_token(self, logits: torch.Tensor, target: torch.Tensor):
        """Compute token CE loss on the last decoder layer.
        Args:
            logits: [L, B, T, V]
            target: [B, T]
        Returns: dict with 'loss_token'
        """
        last = logits[-1]  # [B, T, V]
        # flatten for CE
        B, T, V = last.shape
        last = last.reshape(B * T, V)
        tgt = target.reshape(B * T)
        loss = self.loss_ce(last, tgt)
        return dict(loss_token=loss)

    @torch.no_grad()
    def greedy_decode(self, bev_feats: torch.Tensor, img_metas, start_id: int, end_id: int, max_len: int = None):
        x = self.bev_proj(bev_feats)
        pos_embed = self.bev_position_encoding(x)
        B, _, H, W = x.shape
        masks = torch.zeros(B, H, W, dtype=torch.bool, device=x.device)
        Tm = self.max_len if max_len is None else max_len
        seq = torch.full((B, 1), int(start_id), device=x.device, dtype=torch.long)
        values = []
        # precompute kp prompt
        kp_bias = None
        kp_prompt = None
        kp_prompt_pos = None
        if self.kp_prompt_enable:
            try:
                kp_q = self.kp_query_embed.weight
                kp_dec, _ = self.kp_transformer(x, masks, kp_q, pos_embed)
                kp_feats = torch.nan_to_num(kp_dec)[-1]
                kp_feats_cls = kp_feats.detach() if self.kp_prompt_detach else kp_feats
                kp_cls_logits = self.kp_cls_head(kp_feats_cls)
                with torch.no_grad():
                    kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]
                    k = max(1, min(self.kp_prompt_topk, kp_scores.shape[1]))
                    topk_scores, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
                gather_idx = topk_idx.unsqueeze(-1).expand(-1, -1, kp_feats.shape[-1])
                kp_sel = torch.gather(kp_feats if not self.kp_prompt_detach else kp_feats.detach(), 1, gather_idx)
                if self.kp_prompt_weighted:
                    w = topk_scores / (topk_scores.sum(dim=-1, keepdim=True) + 1e-6)
                    kp_global = (kp_sel * w.unsqueeze(-1)).sum(dim=1)
                else:
                    kp_global = kp_sel.mean(dim=1)
                if self.kp_prompt_type == 'add':
                    kp_bias = self.kp_prompt_adapter(kp_global)
                else:
                    kp_prompt = kp_sel
                    kp_coords_norm = torch.sigmoid(self.kp_reg_head(kp_feats))
                    gather_idx_p = topk_idx.unsqueeze(-1).expand(-1, -1, kp_coords_norm.shape[-1])
                    kp_prompt_pos = torch.gather(kp_coords_norm, 1, gather_idx_p)
                    kp_prompt_pos = self.kp_pos_mlp(kp_prompt_pos)
            except Exception:
                kp_bias, kp_prompt, kp_prompt_pos = None, None, None

        transformer_name = self.transformer.__class__.__name__
        def _call_transformer_with_sign(fname, tgt_, x_, tgt_mask_, masks_, q_embed_, pos_embed_, prm=None, prm_pos=None):
            if fname == 'LssSARPrmSeqLineTransformer':
                if prm is not None and prm_pos is not None:
                    return self.transformer(tgt_, x_, tgt_mask_, masks_, q_embed_, pos_embed_, prm, prm_pos)
                return self.transformer(tgt_, x_, tgt_mask_, masks_, q_embed_, pos_embed_)
            elif fname in ('LssPlPrySeqLineTransformer', 'LssMLMPlPrySeqLineTransformer'):
                tgt_cross = tgt_.unsqueeze(1)
                return self.transformer(tgt_cross, x_, prm, masks_, q_embed_, pos_embed_, prm_pos)
            elif fname == 'LssPlBzTransformer':
                return self.transformer(tgt_, x_, tgt_mask_, masks_, q_embed_, pos_embed_)
            else:
                return self.transformer(tgt_, x_, masks_, q_embed_, pos_embed_)

        for _ in range(Tm - 1):
            tgt = self.embedding(seq.long())
            if kp_bias is not None:
                tgt = tgt + kp_bias.unsqueeze(1)
            query_embed = self.embedding.position_embeddings.weight
            tgt_mask_none = None
            try:
                if kp_prompt is not None and kp_prompt_pos is not None and transformer_name in ('LssPlPrySeqLineTransformer','LssMLMPlPrySeqLineTransformer','LssSARPrmSeqLineTransformer'):
                    outs_dec, _ = _call_transformer_with_sign(transformer_name, tgt, x, tgt_mask_none, masks, query_embed, pos_embed, kp_prompt, kp_prompt_pos)
                else:
                    outs_dec, _ = _call_transformer_with_sign(transformer_name, tgt, x, tgt_mask_none, masks, query_embed, pos_embed, None, None)
            except TypeError:
                outs_dec, _ = _call_transformer_with_sign(transformer_name, tgt, x, tgt_mask_none, masks, query_embed, pos_embed, None, None)
            step = torch.nan_to_num(outs_dec)[-1, :, -1, :]
            logit = self.vocab_embed(step)
            prob = logit.softmax(-1)
            val, tok = prob.topk(k=1, dim=-1)
            seq = torch.cat([seq, tok], dim=-1)
            values.append(val)
            # early stop if all end
            if (tok.view(-1) == end_id).all():
                break
        if values:
            values = torch.cat(values, dim=-1)
        else:
            values = torch.zeros((B, 0), device=x.device)
        return seq, values

    # ---------------- Keypoint branch API ----------------
    def forward_keypoints(self, bev_feats: torch.Tensor, img_metas):
        """Forward keypoint parallel branch for Hungarian loss computation.
        
        Returns:
            kp_cls_logits: [B, Q, C] classification logits
            kp_coords_norm: [B, Q, 2] normalized coordinates in [0, 1]
        """
        if not getattr(self, 'kp_prompt_enable', False):
            return None, None
        
        x = self.bev_proj(bev_feats)
        pos_embed = self.bev_position_encoding(x)
        B, _, H, W = x.shape
        masks = torch.zeros(B, H, W, dtype=torch.bool, device=x.device)
        query_embed = self.kp_query_embed.weight  # [Q, D]
        
        # Use KeypointTransformer interface
        outs_dec, _ = self.kp_transformer(x, masks, query_embed, pos_embed)
        feats = torch.nan_to_num(outs_dec)[-1]  # [B, Q, D]
        kp_cls_logits = self.kp_cls_head(feats)
        kp_coords_norm = torch.sigmoid(self.kp_reg_head(feats))
        return kp_cls_logits, kp_coords_norm
