import os
import cv2
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmengine.structures import InstanceData
import numpy as np
import time
import torch.distributed as dist

# Optional: SwanLab real-time experiment tracking
try:
    import swanlab  # pip install swanlab
    _SWANLAB_AVAILABLE = True
except Exception:
    swanlab = None
    _SWANLAB_AVAILABLE = False

from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector
from mmdet3d.registry import MODELS
from mmdet3d.structures.ops import bbox3d2result
from .grid_mask import GridMask
from .LiftSplatShoot import LiftSplatShootEgo
from .core import seq2nodelist, seq2bznodelist, seq2plbznodelist, av2seq2bznodelist
# Import registry for assigners (prefer TASK_UTILS for MMDet/MMDet3D 3.x)
KP_ASSIGNERS = None
try:
    from mmdet.registry import TASK_UTILS as _MMDET_TASK_UTILS
    KP_ASSIGNERS = _MMDET_TASK_UTILS
except Exception:
    try:
        from mmdet3d.registry import TASK_UTILS as _MMDET3D_TASK_UTILS
        KP_ASSIGNERS = _MMDET3D_TASK_UTILS
    except Exception:
        try:
            from mmdet.registry import MODELS as _MMDET_MODELS
            KP_ASSIGNERS = _MMDET_MODELS
        except Exception:
            try:
                from mmdet.core.bbox.builder import BBOX_ASSIGNERS as _LEGACY_ASSIGNERS
                KP_ASSIGNERS = _LEGACY_ASSIGNERS
            except Exception:
                KP_ASSIGNERS = None


@MODELS.register_module()
class AR_RNTR(MVXTwoStageDetector):
    """Petr3D. nan for all token except label"""
    def __init__(self,
                 use_grid_mask=False,
                 pts_voxel_layer=None,
                 pts_middle_encoder=None,
                 pts_fusion_layer=None,
                 img_backbone=None,
                 pts_backbone=None,
                 img_neck=None,
                 pts_neck=None,
                 lss_cfg=None,
                 grid_conf=None,
                 data_aug_conf=None,
                 pts_bbox_head=None,
                 img_roi_head=None,
                 img_rpn_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 vis_cfg=None,
                 freeze_pretrain=True,
                 bev_scale=1.0,
                 epsilon=2,
                 max_box_num=100,
                 init_cfg=None,
                 data_preprocessor=None,
                 # SwanLab optional params
                 swanlab_enable=False,
                 swanlab_project='RoadNet',
                 swanlab_run_name=None,
                 swanlab_log_interval=50,
                 swanlab_image_interval=200,
                 tit_cfg=None,
                 # TIT options
                 use_bev_teacher_input=False,
                 # Keypoint branch controls
                 kp_enable=False,
                 kp_weights=None,
                 ):
        super(AR_RNTR, self).__init__(pts_voxel_layer, pts_middle_encoder,
                                                        pts_fusion_layer, img_backbone, pts_backbone,
                                                        img_neck, pts_neck, pts_bbox_head, img_roi_head,
                                                        img_rpn_head, train_cfg, test_cfg, init_cfg,
                                                        data_preprocessor)
        self.grid_mask = GridMask(True, True, rotate=1, offset=False, ratio=0.5, mode=1, prob=0.7)
        self.use_grid_mask = use_grid_mask
        # data_aug_conf = {
        #     'final_dim': (128, 352),
        #     'H': 900, 'W': 1600,
        # }
        # self.up = Up(512, 256, scale_factor=2)
        # view_transformers = []
        # view_transformers.append(
        #     LiftSplatShoot(grid_conf, data_aug_conf, downsample=16, d_in=256, d_out=256, return_bev=True))
        # self.view_transformers = nn.ModuleList(view_transformers)
        # self.view_transformers = LiftSplatShoot(grid_conf, data_aug_conf, downsample=16, d_in=256, d_out=256, return_bev=True)
        self.view_transformers = LiftSplatShootEgo(grid_conf, data_aug_conf, return_bev=True, **lss_cfg)
        self.downsample = lss_cfg['downsample']
        self.final_dim = data_aug_conf['final_dim']

        self.num_center_classes = 576
        self.box_range = 200
        self.coeff_range = 200
        self.num_classes=4
        self.category_start = 200
        self.connect_start = 250
        self.coeff_start = 350
        self.no_known = 575  # n/a and padding share the same label to be eliminated from loss calculation
        self.start = 574
        self.end = 573
        self.noise_connect = 572
        self.noise_label = 571
        self.noise_coeff = 570
        self.vis_cfg = vis_cfg
        self.bev_scale = bev_scale
        self.epsilon = epsilon
        self.max_box_num = max_box_num
        # Topology-Inherited Training (TIT) config (disabled by default)
        self.tit_cfg = tit_cfg or {}
        self.tit_enable = bool(self.tit_cfg.get('enable', False))
        self.tit_k = int(self.tit_cfg.get('k', 4))              # top-K nearest neighbors
        self.tit_alpha = float(self.tit_cfg.get('alpha', 0.3))  # neighbor smoothing weight
        self.tit_weight = float(self.tit_cfg.get('weight', 1.0))
        # Distillation (stage-2) controls
        self.tit_distill = bool(self.tit_cfg.get('distill', False))
        self.tit_distill_only = bool(self.tit_cfg.get('distill_only', False))
        self.tit_distill_weight = float(self.tit_cfg.get('distill_weight', 1.0))
        # Stage-1: use LiDAR BEV (teacher) as direct BEV input
        self.use_bev_teacher_input = bool(use_bev_teacher_input)

        # SwanLab runtime config (only active when enabled and package available)
        self.swanlab_enable = bool(swanlab_enable) or (os.getenv('SWANLAB_ENABLE', '0').lower() in ('1', 'true', 'yes'))
        self.swanlab_project = swanlab_project
        self.swanlab_run_name = swanlab_run_name
        self.swanlab_log_interval = max(1, int(swanlab_log_interval))
        self.swanlab_image_interval = max(1, int(swanlab_image_interval))
        self._swanlab_ready = False
        self._global_step = 0
        self._swanlab_img_step = 0

        if freeze_pretrain:
            self.freeze_pretrain()
        
        # KP loss enable/weights
        self.kp_enable = bool(kp_enable)
        self.kp_weights = kp_weights or {'cls': 1.0, 'reg': 1.0}
        # ---------- Keypoint branch losses/assigner ----------
        if self.kp_enable:
            try:
                self.kp_loss_cls = MODELS.build(dict(type='mmdet.CrossEntropyLoss'))
            except Exception:
                self.kp_loss_cls = MODELS.build(dict(type='CrossEntropyLoss'))
            try:
                self.kp_loss_reg = MODELS.build(dict(type='mmdet.L1Loss'))
            except Exception:
                self.kp_loss_reg = MODELS.build(dict(type='L1Loss'))
            if KP_ASSIGNERS is not None:
                self.kp_assigner = KP_ASSIGNERS.build(dict(
                    type='HungarianAssigner_KP',
                    cls_cost=dict(type='ClassificationCost', weight=1.0),
                    reg_cost=dict(type='BBoxL1Cost', weight=5.0),
                ))
            else:
                self.kp_assigner = None
    
    def freeze_pretrain(self):
        for m in self.img_backbone.parameters():
            m.requires_grad=False
        for m in self.img_neck.parameters():
            m.requires_grad=False
        for m in self.view_transformers.parameters():
            m.requires_grad=False

    # ---------------------- SwanLab utils ----------------------
    def _is_main_process(self):
        try:
            if not dist.is_available() or not dist.is_initialized():
                return True
            return dist.get_rank() == 0
        except Exception:
            return True

    def _init_swanlab(self, cfg: dict = None):
        if self._swanlab_ready:
            return
        if not self.swanlab_enable or not _SWANLAB_AVAILABLE:
            return
        if not self._is_main_process():
            return
        run_name = self.swanlab_run_name or f'AR_RNTR_{int(time.time())}'
        try:
            swanlab.init(project=self.swanlab_project,
                         experiment_name=run_name,
                         config=cfg or {})
            self._swanlab_ready = True
        except Exception:
            # Fail-safe: do not crash training if init fails
            self._swanlab_ready = False

    @staticmethod
    def _to_float(value):
        try:
            if isinstance(value, (list, tuple)):
                vals = []
                for v in value:
                    if torch.is_tensor(v):
                        vals.append(v.detach().float().mean().item())
                    else:
                        try:
                            vals.append(float(v))
                        except Exception:
                            pass
                return sum(vals) / len(vals) if len(vals) > 0 else None
            if torch.is_tensor(value):
                return value.detach().float().mean().item()
            return float(value)
        except Exception:
            return None

    def _render_bev_overlay(self, gt_coords_sample, pred_tokens_sample, clause_length, canvas_size=200):
        try:
            # Prepare canvas
            H = W = int(canvas_size)
            canvas = np.zeros((H, W, 3), dtype=np.uint8)
            # GT coords
            gt = np.array(gt_coords_sample, dtype=np.int32)
            if gt.ndim == 1:
                gt = gt.reshape(-1, 2)
            # Draw GT points (green)
            for (x, y) in gt:
                if 0 <= x < W and 0 <= y < H:
                    cv2.circle(canvas, (int(x), int(y)), 1, (0, 255, 0), -1)
            # Pred coords from tokens
            pred_xy = []
            T = int(pred_tokens_sample.shape[0])
            max_nodes = T // clause_length
            for i in range(max_nodes):
                idx_x = i * clause_length + 0
                idx_y = i * clause_length + 1
                if idx_y >= T:
                    break
                x = int(pred_tokens_sample[idx_x].item())
                y = int(pred_tokens_sample[idx_y].item())
                x = max(0, min(W - 1, x))
                y = max(0, min(H - 1, y))
                pred_xy.append((x, y))
            # Draw Pred points (red)
            for (x, y) in pred_xy:
                cv2.circle(canvas, (x, y), 1, (0, 0, 255), -1)
            # Put legend
            cv2.rectangle(canvas, (0, 0), (110, 28), (32, 32, 32), -1)
            cv2.putText(canvas, 'GT: green', (4, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)
            cv2.putText(canvas, 'Pred: red', (4, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 255), 1, cv2.LINE_AA)
            return canvas
        except Exception:
            return None

    def _swanlab_log_image(self, name: str, img: np.ndarray, step: int):
        if not (self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process() and self._swanlab_ready):
            return
        try:
            # Convert BGR->RGB
            rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            # Try different SwanLab image logging APIs for compatibility
            if hasattr(swanlab, 'Image'):
                try:
                    im = swanlab.Image(rgb)
                    swanlab.log({name: im}, step=step)
                    return
                except Exception:
                    pass
            if hasattr(swanlab, 'log_image'):
                try:
                    swanlab.log_image(name, rgb, step=step)
                    return
                except Exception:
                    pass
            # Fallback: save temp file and log its path as text
            tmp_dir = '/tmp/swanlab_vis'
            os.makedirs(tmp_dir, exist_ok=True)
            tmp_path = os.path.join(tmp_dir, f'{name.replace("/", "_")}_{step}.png')
            cv2.imwrite(tmp_path, img)
            try:
                swanlab.log({f'{name}_path': tmp_path}, step=step)
            except Exception:
                pass
        except Exception:
            pass

    def extract_img_feat(self, img, img_metas):
        """Extract features of images."""
        # print(img[0].size())
        if isinstance(img, list):
            img = torch.stack(img, dim=0)

        B = img.size(0)
        if img is not None:
            input_shape = img.shape[-2:]
            # update real input shape of each single img
            for img_meta in img_metas:
                img_meta.update(input_shape=input_shape)
            if img.dim() == 5:
                if img.size(0) == 1 and img.size(1) != 1:
                    img.squeeze_()
                else:
                    B, N, C, H, W = img.size()
                    img = img.view(B * N, C, H, W)
            if self.use_grid_mask:
                img = self.grid_mask(img)
            img_feats = self.img_backbone(img)
            if isinstance(img_feats, dict):
                img_feats = list(img_feats.values())
        else:
            return None
        if self.with_img_neck:
            img_feats = self.img_neck(img_feats)
        img_feats_reshaped = []
        for img_feat in img_feats:
            BN, C, H, W = img_feat.size()
            img_feats_reshaped.append(img_feat.view(B, int(BN / B), C, H, W))
        return img_feats_reshaped

    def extract_feat(self, img, img_metas):
        """Extract BEV features; optionally bypass with teacher BEV."""
        # Stage-1 bypass: use teacher BEV directly as input BEV
        if self.use_bev_teacher_input:
            if len(img_metas) == 0 or 'bev_teacher' not in img_metas[0]:
                raise ValueError("use_bev_teacher_input=True but 'bev_teacher' not found in img_metas")
            bev_list = []
            for m in img_metas:
                bev_np = m.get('bev_teacher', None)
                if bev_np is None:
                    bev_np = img_metas[0]['bev_teacher']
                # expect [C,H,W]
                bev_t = torch.from_numpy(bev_np).to(self.img_backbone.conv1.weight.device).float()
                bev_list.append(bev_t)
            bev_feats = torch.stack(bev_list, dim=0)  # [B,C,H,W]
            return bev_feats
        # Normal LSS path
        img_feats = self.extract_img_feat(img, img_metas)
        largest_feat_shape = img_feats[0].shape[3]
        down_level = int(np.log2(self.downsample // (self.final_dim[0] // largest_feat_shape)))
        bev_feats = self.view_transformers(img_feats[down_level], img_metas)
        return bev_feats

    def forward_pts_train(self,
                          bev_feats,
                          gt_lines_coords,
                          gt_lines_labels,
                          gt_lines_connects,
                          gt_lines_coeffs,
                          img_metas,
                          num_coeff, ):
        """Forward function for point cloud branch.
        Args:
            pts_feats (list[torch.Tensor]): Features of point cloud branch
            gt_bboxes_3d (list[:obj:`BaseInstance3DBoxes`]): Ground truth
                boxes for each sample.
            gt_labels_3d (list[torch.Tensor]): Ground truth labels for
                boxes of each sampole
            img_metas (list[dict]): Meta information of samples.
            gt_bboxes_ignore (list[torch.Tensor], optional): Ground truth
                boxes to be ignored. Defaults to None.
        Returns:
            dict: Losses of each branch.
        """
        device = bev_feats[0].device
        box_labels = []
        input_seqs = []
        output_seqs = []
        max_box = max([len(target) for target in gt_lines_coords])
        num_box = max(max_box + 2, self.max_box_num)  # 100
        coeff_dim = num_coeff * 2
        for bi in range(len(gt_lines_coords)):
            box = torch.tensor(gt_lines_coords[bi], device=device).long()
            box = box.reshape(-1,2)
            label = torch.tensor(gt_lines_labels[bi], device=device).long() + self.category_start  # [8,1]
            label = label.reshape(-1,1)
            connect = torch.tensor(gt_lines_connects[bi], device=device).long() + self.connect_start  # [8,1]
            connect = connect.reshape(-1,1)
            coeff = torch.tensor(gt_lines_coeffs[bi], device=device).long() + self.coeff_start  # [8,1]
            coeff = coeff.reshape(-1, coeff_dim)
            box_label = torch.cat([box, label, connect, coeff], dim=-1)  # [8, 5]

            random_box = torch.rand(num_box - box_label.shape[0], 2).to(device)
            random_box = (random_box * (self.box_range - 1)).int()
            random_label = torch.randint(0, self.num_classes, (num_box - box_label.shape[0], 1)).to(label)
            random_label = random_label + self.category_start
            random_connect = torch.randint(0, num_box, (num_box - box_label.shape[0], 1)).to(label)
            random_connect = random_connect + self.connect_start
            random_coeff = torch.rand(num_box - box_label.shape[0], coeff_dim).to(device)
            random_coeff = (random_coeff * (self.coeff_range - 1)).int()
            random_coeff = random_coeff + self.coeff_start
            random_box_label = torch.cat([random_box, random_label.int(), random_connect.int(), random_coeff.int()], dim=-1)  # [92, 5]

            # decoder input sequence: [START] + [positive clauses + sampled negatives]
            input_seq = torch.cat([box_label, random_box_label], dim=0)
            input_seq = torch.cat([torch.ones(1).to(box_label) * self.start, input_seq.flatten()])  # [1 + num_box*clause_length]
            input_seqs.append(input_seq.unsqueeze(0))

            # Build negative clauses aligned to [x, y, label, connect, coeffs...]
            # - coords (x,y): fill with no_known to mask out from coord supervision
            # - label: use noise_label to provide hard negative for label classifier
            # - connect/coeff: fill with no_known
            output_na_x = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known
            output_na_y = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known
            output_noise_label = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.noise_label
            output_noise_connect = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known
            output_noise_coeff = torch.ones(num_box - box_label.shape[0], coeff_dim).to(input_seq) * self.no_known
            # Note: do NOT place END token inside a clause; keep END only as a standalone token if needed
            output_seq = torch.cat(
                [output_na_x, output_na_y, output_noise_label, output_noise_connect, output_noise_coeff], dim=-1
            )

            # Supervision sequence: [positive clauses] + [END] + [negative clauses]
            output_seq = torch.cat([box_label.flatten(), torch.ones(1).to(box_label) * self.end, output_seq.flatten()])
            output_seqs.append(output_seq.unsqueeze(0))
        input_seqs = torch.cat(input_seqs, dim=0)  # [B, 1 + num_box*clause_length]
        output_seqs = torch.cat(output_seqs, dim=0)  # [B, 1 + (pos + neg)*clause_length]
        outputs_logits = self.pts_bbox_head(bev_feats, input_seqs, img_metas)[-1, :, :-1, :]  # [B, T-1, V]

        clause_length = 4 + coeff_dim
        all_outputs_pos, all_inputs_pos = [], []
        all_outputs_cls, all_inputs_cls = [], []
        all_outputs_connects, all_inputs_connects = [], []
        all_outputs_coeffs, all_inputs_coeffs = [], []
        # TIT accumulators
        tit_loss_total = outputs_logits.new_tensor(0.0)
        tit_count = 0

        for bi in range(outputs_logits.shape[0]):
            labels_i = output_seqs[bi, :-1]  # [T-1]
            preds_i = outputs_logits[bi]     # [T-1, V]
            # remove the single END token position from supervision
            end_mask = (labels_i == self.end)
            if end_mask.any():
                keep = ~end_mask
                labels_i = labels_i[keep]
                preds_i = preds_i[keep]
            # ensure length is multiple of clause_length
            valid_len = (labels_i.numel() // clause_length) * clause_length
            labels_i = labels_i[:valid_len]
            preds_i = preds_i[:valid_len]

            # slice by clause
            pos_x_logits = preds_i[0::clause_length, :]
            pos_y_logits = preds_i[1::clause_length, :]
            outputs_pos_i = torch.cat([pos_x_logits, pos_y_logits], dim=0)
            inputs_pos_i = torch.cat([labels_i[0::clause_length], labels_i[1::clause_length]], dim=0)

            outputs_cls_i = preds_i[2::clause_length, :]
            inputs_cls_i = labels_i[2::clause_length]

            outputs_conn_i = preds_i[3::clause_length, :]
            inputs_conn_i = labels_i[3::clause_length]

            coeff_logits_list, coeff_labels_list = [], []
            for k in range(4, clause_length):
                coeff_logits_list.append(preds_i[k::clause_length, :])
                coeff_labels_list.append(labels_i[k::clause_length])
            outputs_coeffs_i = torch.cat(coeff_logits_list, dim=0) if coeff_logits_list else preds_i.new_zeros((0, preds_i.shape[-1]))
            inputs_coeffs_i = torch.cat(coeff_labels_list, dim=0) if coeff_labels_list else labels_i.new_zeros((0,), dtype=labels_i.dtype)

            # filter out no_known targets
            mask_pos = (inputs_pos_i != self.no_known)
            mask_cls = (inputs_cls_i != self.no_known)
            mask_conn = (inputs_conn_i != self.no_known)
            mask_coeff = (inputs_coeffs_i != self.no_known)

            # TIT: distance-aware soft supervision on connect logits
            if self.tit_enable and mask_conn.sum().item() > 1:
                try:
                    # Valid connect logits/labels for positives only
                    logits_conn_valid = outputs_conn_i[mask_conn]  # [P, V]
                    labels_conn_valid = inputs_conn_i[mask_conn]   # [P]
                    # Build KNN neighbors from GT coords
                    gt_coords_sample = torch.tensor(gt_lines_coords[bi], device=preds_i.device).long().view(-1, 2).float()
                    P = logits_conn_valid.shape[0]
                    V = logits_conn_valid.shape[-1]
                    if gt_coords_sample.shape[0] >= 2 and P >= 2:
                        # Pairwise distances
                        dmat = torch.cdist(gt_coords_sample, gt_coords_sample, p=2)  # [N,N]
                        # Avoid self
                        diag_idx = torch.arange(dmat.shape[0], device=dmat.device)
                        dmat[diag_idx, diag_idx] = 1e6
                        K = int(min(max(self.tit_k, 1), max(1, dmat.shape[0] - 1)))
                        log_probs = F.log_softmax(logits_conn_valid, dim=-1)
                        for r in range(P):
                            gt_token = int(labels_conn_valid[r].item())
                            # Ensure target is a valid connect token
                            if gt_token < self.connect_start or gt_token >= self.connect_start + gt_coords_sample.shape[0]:
                                continue
                            gt_j = gt_token - self.connect_start
                            # KNN neighbors around GT target node gt_j
                            neigh_idx = torch.topk(dmat[gt_j], k=K, largest=False).indices.tolist()
                            # Exclude GT to avoid double counting in smoothing
                            neigh_idx = [n for n in neigh_idx if n != gt_j]
                            q = logits_conn_valid.new_zeros((V,))
                            alpha = float(self.tit_alpha)
                            q[self.connect_start + gt_j] = 1.0 - alpha
                            if len(neigh_idx) > 0 and alpha > 0:
                                share = alpha / float(len(neigh_idx))
                                for n in neigh_idx:
                                    q[self.connect_start + int(n)] += share
                            # KL divergence between predicted log-probs and soft target q
                            tit_loss_total = tit_loss_total + F.kl_div(log_probs[r], q, reduction='batchmean')
                            tit_count += 1
                except Exception:
                    # TIT is best-effort; never break training
                    pass

            all_outputs_pos.append(outputs_pos_i[mask_pos])
            all_inputs_pos.append(inputs_pos_i[mask_pos])

            all_outputs_cls.append(outputs_cls_i[mask_cls])
            all_inputs_cls.append(inputs_cls_i[mask_cls])

            all_outputs_connects.append(outputs_conn_i[mask_conn])
            all_inputs_connects.append(inputs_conn_i[mask_conn])

            all_outputs_coeffs.append(outputs_coeffs_i[mask_coeff])
            all_inputs_coeffs.append(inputs_coeffs_i[mask_coeff])

        # concat across batch
        outputs_pos = torch.cat(all_outputs_pos, dim=0) if len(all_outputs_pos) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_pos = torch.cat(all_inputs_pos, dim=0) if len(all_inputs_pos) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        outputs_cls = torch.cat(all_outputs_cls, dim=0) if len(all_outputs_cls) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_cls = torch.cat(all_inputs_cls, dim=0) if len(all_inputs_cls) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        outputs_connects = torch.cat(all_outputs_connects, dim=0) if len(all_outputs_connects) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_connects = torch.cat(all_inputs_connects, dim=0) if len(all_inputs_connects) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        outputs_coeffs = torch.cat(all_outputs_coeffs, dim=0) if len(all_outputs_coeffs) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_coeffs = torch.cat(all_inputs_coeffs, dim=0) if len(all_inputs_coeffs) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        gt_coords = [inputs_pos.long()]
        gt_labels = [inputs_cls.long()]
        gt_connects = [inputs_connects.long()]
        gt_coeffs = [inputs_coeffs.long()]
        
        preds_dicts = dict(
            preds_coords=[outputs_pos],
            preds_labels=[outputs_cls],
            preds_connects=[outputs_connects],
            preds_coeffs=[outputs_coeffs]
        )

        loss_inputs = [gt_coords, gt_labels, gt_connects, gt_coeffs, preds_dicts]
        losses = self.pts_bbox_head.loss_by_feat(*loss_inputs)
        # Append TIT loss if enabled
        if self.tit_enable and tit_count > 0:
            losses['loss_tit'] = tit_loss_total / float(tit_count) * self.tit_weight

        # SwanLab logging (rank-0 only, optional)
        try:
            if self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process():
                if not self._swanlab_ready:
                    self._init_swanlab(cfg=dict(model='AR_RNTR', n_control=num_coeff + 2))
                self._global_step += 1
                if (self._global_step % self.swanlab_log_interval) == 0:
                    metrics = {}
                    for k, v in losses.items():
                        val = self._to_float(v)
                        if val is not None:
                            metrics[k] = val
                    # Optionally log sequence stats
                    metrics['seq_max_box'] = float(max_box)
                    metrics['seq_num_box'] = float(num_box)
                    if len(metrics) > 0:
                        swanlab.log(metrics, step=self._global_step)
                # Periodically log BEV overlay (first sample)
                if (self._global_step % self.swanlab_image_interval) == 0:
                    try:
                        pred_tokens0 = outputs_logits[0].detach().argmax(dim=-1)
                        bev_img = self._render_bev_overlay(gt_lines_coords[0], pred_tokens0, clause_length=clause_length, canvas_size=self.box_range)
                        if bev_img is not None:
                            self._swanlab_log_image('vis/bev_overlay', bev_img, step=self._global_step)
                    except Exception:
                        pass
        except Exception:
            pass  # never break training due to logging

        return losses
    
    def loss(self,
             inputs=None,
             data_samples=None,**kwargs):

        img = inputs['img']
        img_metas = [ds.metainfo for ds in data_samples]

        bev_feats = self.extract_feat(img=img, img_metas=img_metas)
        if self.bev_scale != 1.0:
            b, c, h, w = bev_feats.shape
            bev_feats = F.interpolate(bev_feats, (int(h * self.bev_scale), int(w * self.bev_scale)))
        losses = dict()
        # Optional BEV distillation (TIT stage-2)
        if hasattr(self, 'tit_distill') and self.tit_distill:
            if 'bev_teacher' not in img_metas[0]:
                raise ValueError("tit_distill=True but 'bev_teacher' not found in img_metas")
            teacher_list = []
            for m in img_metas:
                bev_np = m.get('bev_teacher', None)
                if bev_np is None:
                    bev_np = img_metas[0]['bev_teacher']
                teacher_list.append(torch.from_numpy(bev_np).to(bev_feats.device).float())
            bev_teacher = torch.stack(teacher_list, dim=0)
            if bev_teacher.shape[-2:] != bev_feats.shape[-2:]:
                bev_teacher = F.interpolate(bev_teacher, size=bev_feats.shape[-2:], mode='bilinear', align_corners=False)
            losses['loss_distill'] = F.l1_loss(bev_feats, bev_teacher) * float(getattr(self, 'tit_distill_weight', 1.0))
            if getattr(self, 'tit_distill_only', False):
                return losses
        gt_lines_coords = [img_meta['centerline_coord'] for img_meta in img_metas]
        gt_lines_labels = [img_meta['centerline_label'] for img_meta in img_metas]
        gt_lines_connects = [img_meta['centerline_connect'] for img_meta in img_metas]
        gt_lines_coeffs = [img_meta['centerline_coeff'] for img_meta in img_metas]
        n_control = img_metas[0]['n_control']
        num_coeff = n_control - 2
        losses_pts = self.forward_pts_train(bev_feats, gt_lines_coords, gt_lines_labels, 
                                            gt_lines_connects, gt_lines_coeffs,
                                            img_metas, num_coeff)
        losses.update(losses_pts)
        
        # -------- Keypoint parallel branch losses (Hungarian assign) --------
        if self.kp_enable and hasattr(self.pts_bbox_head, 'forward_keypoints'):
            try:
                kp_cls_logits, kp_coords_norm = self.pts_bbox_head.forward_keypoints(bev_feats, img_metas)
                if kp_cls_logits is not None and kp_coords_norm is not None:
                    loss_kp_cls_total = kp_cls_logits.new_tensor(0.0)
                    loss_kp_reg_total = kp_cls_logits.new_tensor(0.0)
                    total_pos = 0
                    # BEV canvas size (assume 200x200 as in SAR)
                    NY, NX = 200, 200
                    for bi in range(kp_cls_logits.shape[0]):
                        cls_pred_i = kp_cls_logits[bi]  # [Q, C]
                        coord_pred_i = kp_coords_norm[bi]  # [Q, 2] in [0,1]
                        # GT
                        gt_xy_i = torch.tensor(gt_lines_coords[bi], device=cls_pred_i.device).long().view(-1, 2).float()
                        gt_lbl_i = torch.tensor(gt_lines_labels[bi], device=cls_pred_i.device).long().view(-1)
                        # Build a meta with bev canvas size to normalize GT inside assigner
                        meta_i = dict(img_shape=(NY, NX))
                        # Switch GT to (y, x) order to align with img_shape=(H,W) normalization in assigner
                        gt_yx_i = torch.stack([gt_xy_i[:, 1], gt_xy_i[:, 0]], dim=-1)
                        if self.kp_assigner is not None:
                            assign_result = self.kp_assigner.assign(coord_pred_i, cls_pred_i, gt_yx_i, gt_lbl_i, meta_i)
                            # Access assigned indices
                            gt_inds_attr = getattr(assign_result, 'gt_inds', None)
                            if gt_inds_attr is None:
                                gt_inds_attr = getattr(assign_result, 'assigned_gt_inds', None)
                            if gt_inds_attr is None:
                                continue
                            pos_mask = (gt_inds_attr > 0)
                            if pos_mask.any():
                                pos_idx = gt_inds_attr[pos_mask] - 1
                                # Classification loss on matched
                                loss_kp_cls_total = loss_kp_cls_total + self.kp_loss_cls(cls_pred_i[pos_mask], gt_lbl_i[pos_idx])
                                # Regression L1 on normalized coords (y_norm, x_norm)
                                gt_y_norm = gt_xy_i[:, 1] / float(max(NY - 1, 1))
                                gt_x_norm = gt_xy_i[:, 0] / float(max(NX - 1, 1))
                                gt_xy_norm = torch.stack([gt_y_norm, gt_x_norm], dim=-1).clamp(0, 1)
                                loss_kp_reg_total = loss_kp_reg_total + self.kp_loss_reg(coord_pred_i[pos_mask], gt_xy_norm[pos_idx])
                                total_pos += int(pos_mask.sum().item())
                    if total_pos > 0:
                        losses['loss_kp_cls'] = (loss_kp_cls_total / float(total_pos)) * float(self.kp_weights.get('cls', 1.0))
                        losses['loss_kp_reg'] = (loss_kp_reg_total / float(total_pos)) * float(self.kp_weights.get('reg', 1.0))
            except Exception as e:
                print(f"[AR_RNTR] Keypoint loss calculation failed: {e}")
                pass
        
        return losses
    
    def predict(self, batch_inputs_dict, batch_data_samples, **kwargs):
        """Forward of testing.

        Args:
            batch_inputs_dict (dict): The model input dict which include
                'points' keys.

                - points (list[torch.Tensor]): Point cloud of each sample.
            batch_data_samples (List[:obj:`Det3DDataSample`]): The Data
                Samples. It usually includes information such as
                `gt_instance_3d`.

        Returns:
            list[:obj:`Det3DDataSample`]: Detection results of the
            input sample. Each Det3DDataSample usually contain
            'pred_instances_3d'. And the ``pred_instances_3d`` usually
            contains following keys.

            - scores_3d (Tensor): Classification scores, has a shape
                (num_instances, )
            - labels_3d (Tensor): Labels of bboxes, has a shape
                (num_instances, ).
            - bbox_3d (:obj:`BaseInstance3DBoxes`): Prediction of bboxes,
                contains a tensor with shape (num_instances, 7).
        """
        batch_input_metas = [item.metainfo for item in batch_data_samples]
        batch_input_imgs = batch_inputs_dict['img']
        # Run inference on the full batch instead of slicing to the first sample
        return self.simple_test(batch_input_metas, batch_input_imgs)

    def simple_test_pts(self, pts_feats, img_metas):
        """Test function of point cloud branch."""
        n_control = img_metas[0]['n_control']
        num_coeff = n_control - 2
        clause_length = 4 + num_coeff * 2
        # gt_node_list = self.seq2nodelist(gt_lines_seqs[0])
        # self.vis_from_nodelist(gt_node_list, img_metas[0], self.vis_cfg['path'], 'gt')
        device = pts_feats[0].device
        B = len(img_metas)
        input_seqs = (torch.ones(B, 1, device=device) * self.start).long()
        outs = self.pts_bbox_head(pts_feats, input_seqs, img_metas)
        output_seqs, values = outs
        line_results = []
        for bi in range(output_seqs.shape[0]):
            pred_line_seq = output_seqs[bi]
            pred_line_seq = pred_line_seq[1:]
            if self.end in pred_line_seq:
                stop_idx = (pred_line_seq == self.end).nonzero(as_tuple=True)[0][0]
            else:
                stop_idx = len(pred_line_seq)
            stop_idx = stop_idx // clause_length * clause_length
            pred_line_seq = pred_line_seq[:stop_idx]
            pred_line_seq[2::clause_length] = pred_line_seq[2::clause_length] - self.category_start
            pred_line_seq[3::clause_length] = pred_line_seq[3::clause_length] - self.connect_start
            for k in range(4, clause_length):
                pred_line_seq[k::clause_length] = pred_line_seq[k::clause_length] - self.coeff_start
            # Safety sanitation to reduce invalid long-cross links and OOB coeffs
            try:
                # Clamp coordinate tokens to BEV grid range
                xbound = self.view_transformers.grid_conf['xbound']
                ybound = self.view_transformers.grid_conf['ybound']
                NX = int((xbound[1] - xbound[0]) / xbound[2])
                NY = int((ybound[1] - ybound[0]) / ybound[2])
                pred_line_seq[0::clause_length] = pred_line_seq[0::clause_length].clamp(0, NX - 1)
                pred_line_seq[1::clause_length] = pred_line_seq[1::clause_length].clamp(0, NY - 1)

                # Clamp class token to valid range [0..num_classes-1]
                pred_line_seq[2::clause_length] = pred_line_seq[2::clause_length].clamp(0, self.num_classes - 1)

                # Clamp Bezier control coeff tokens to training range [0..coeff_range-1]
                # Note: coeffs are interleaved as (cx, cy, cx, cy, ...)
                if self.coeff_range is not None and self.coeff_range > 0:
                    for k in range(4, clause_length):
                        pred_line_seq[k::clause_length] = pred_line_seq[k::clause_length].clamp(0, self.coeff_range - 1)

                # Enforce connect indices to reference only prior nodes
                # Sequence is grouped by clauses; connect index must be < current node idx
                num_nodes = pred_line_seq.numel() // clause_length
                if num_nodes > 0:
                    # Work on a clone to avoid dtype/device issues when assigning Python ints
                    seq_clone = pred_line_seq.clone()
                    for i in range(num_nodes):
                        lbl = int(seq_clone[2 + i * clause_length].item())  # 0:start,1:continue,2:fork,3:merge
                        conn_pos = 3 + i * clause_length
                        if i == 0:
                            # First node should be start; set connect to 0
                            seq_clone[conn_pos] = 0
                            continue
                        conn_idx = int(seq_clone[conn_pos].item())
                        # valid connect must point to a previous node [0..i-1]
                        conn_idx = max(0, min(conn_idx, i - 1))
                        # For continue, strongly prefer linking to immediate previous node
                        if lbl == 1:
                            conn_idx = i - 1
                        seq_clone[conn_pos] = conn_idx
                    pred_line_seq = seq_clone
            except Exception:
                # Never break inference due to sanitation
                pass
            pred_node_list = av2seq2bznodelist(pred_line_seq.detach().cpu().numpy(), n_control, self.epsilon)

            line_results.append(dict(
                line_seqs = pred_line_seq.detach().cpu(),
                pred_node_lists = pred_node_list
            ))
        return line_results

    def simple_test(self, img_metas, img=None):
        """Test function without augmentaiton."""
        bev_feats = self.extract_feat(img=img, img_metas=img_metas)
        bbox_list = [dict() for i in range(len(img_metas))]
        line_results = self.simple_test_pts(
            bev_feats, img_metas)
        for result_dict, line_result, img_meta in zip(bbox_list, line_results, img_metas):
            result_dict['line_results'] = line_result
            result_dict['token'] = img_meta['token']
        # Optionally log validation BEV overlay (first sample)
        try:
            if self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process():
                if not self._swanlab_ready:
                    self._init_swanlab(cfg=dict(model='AR_RNTR', phase='val'))
                self._swanlab_img_step += 1
                if (self._swanlab_img_step % self.swanlab_image_interval) == 0:
                    try:
                        n_control = img_metas[0].get('n_control', 3)
                        clause_length = 4 + (int(n_control) - 2) * 2
                        pred_tokens0 = line_results[0]['line_seqs']
                        gt_coords0 = img_metas[0].get('centerline_coord', None)
                        bev_img = self._render_bev_overlay(gt_coords0 if gt_coords0 is not None else [],
                                                           pred_tokens0,
                                                           clause_length=clause_length,
                                                           canvas_size=self.box_range)
                        if bev_img is not None:
                            self._swanlab_log_image('vis/val_bev_overlay', bev_img, step=self._swanlab_img_step)
                    except Exception:
                        pass
        except Exception:
            pass
        return bbox_list