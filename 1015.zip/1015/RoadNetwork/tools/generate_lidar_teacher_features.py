"""
Generate LiDAR-BEV Teacher Features for TIT Stage-1/0

This script extracts BEV features from a trained LiDAR-based model
and saves them as .npy files for each sample token.

Usage:
    python tools/generate_lidar_teacher_features.py \
        --config <lidar_model_config.py> \
        --checkpoint <lidar_model.pth> \
        --output-dir ./data/nuscenes/bev_lidar_teacher/ \
        --data-root ./data/nuscenes \
        --ann-file nuscenes_infos_train.pkl

Note:
- Use detection-style NuScenes infos (e.g., nuscenes_infos_train.pkl / nuscenes_infos_val.pkl)
- CenterPoint config/weights recommended. The script hooks BEV at pts_neck/neck.
"""

import argparse
import os
import numpy as np
import torch
from mmengine import Config
from mmengine.registry import init_default_scope
from mmengine.runner import load_checkpoint
from mmdet3d.registry import MODELS
from tqdm import tqdm


def parse_args():
    parser = argparse.ArgumentParser(description='Generate LiDAR Teacher BEV Features')
    parser.add_argument('--config', required=True, help='Path to LiDAR model config')
    parser.add_argument('--checkpoint', required=True, help='Path to LiDAR model checkpoint')
    parser.add_argument('--output-dir', required=True, help='Output directory for .npy files')
    parser.add_argument('--data-root', default='./data/nuscenes', help='Data root')
    parser.add_argument('--ann-file', default='nuscenes_infos_train.pkl')
    parser.add_argument('--batch-size', type=int, default=1, help='Batch size for extraction')
    parser.add_argument('--device', default=None, help="Torch device, e.g. 'cuda:0' or 'cpu'. Default: auto")
    return parser.parse_args()


def main():
    args = parse_args()
    
    # Load config and model (ensure registry scope for mmdet3d)
    cfg = Config.fromfile(args.config)
    try:
        init_default_scope('mmdet3d')
    except Exception:
        pass
    # optional: some versions expose register_all_modules; ignore if missing
    try:
        from mmdet3d.utils import register_all_modules as _reg_all
        try:
            _reg_all(init_default_scope=True)
        except TypeError:
            _reg_all()
    except Exception:
        pass
    # Resolve device robustly
    if args.device is not None:
        device_str = args.device
    else:
        if torch.cuda.is_available():
            # use first visible GPU explicitly
            device_str = 'cuda:0'
        else:
            device_str = 'cpu'
    # Build and load weights (prefer API if available)
    model = None
    try:
        from mmdet3d.apis import init_model as _init_model
        model = _init_model(cfg, args.checkpoint, device=device_str)
    except Exception:
        # Fallback: manual build + load
        model = MODELS.build(cfg.model)
        load_checkpoint(model, args.checkpoint, map_location='cpu')
        model.to(device_str)
    model.eval()

    # Register a forward hook to capture BEV features from LiDAR neck
    bev_cache = {'feat': None}

    def _bev_hook(_module, _inp, out):
        # many 3D necks (e.g., SECONDFPN) return a list/tuple of multi-scale [B,C,H,W]
        bev = out[0] if isinstance(out, (list, tuple)) else out
        bev_cache['feat'] = bev

    # Try common attribute names in MMDet3D
    hook_handle = None
    for attr in ['pts_neck', 'neck']:
        if hasattr(model, attr) and getattr(model, attr) is not None:
            hook_handle = getattr(model, attr).register_forward_hook(_bev_hook)
            break
    if hook_handle is None:
        raise RuntimeError('Cannot find a neck module (pts_neck/neck) to hook BEV features.')
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Setup dataloader
    from mmdet3d.registry import DATASETS
    from torch.utils.data import DataLoader

    # Override config for inference (use detection infos pkl)
    # Build a complete dataset config by merging base config with overrides
    from mmengine import Config as MMConfig
    
    # Start from test_pipeline (simpler than dataloader.dataset)
    dataset_cfg = MMConfig(dict(
        type='NuScenesDataset',
        data_root=args.data_root,
        ann_file=args.ann_file,
        pipeline=cfg.test_pipeline if hasattr(cfg, 'test_pipeline') else [],
        metainfo=dict(classes=['car','truck','construction_vehicle','bus','trailer','barrier','motorcycle','bicycle','pedestrian','traffic_cone']),
        test_mode=True,
        box_type_3d='LiDAR',
        backend_args=None
    ))
    
    # Merge with existing val/test_dataloader.dataset if available (to inherit any extra fields)
    if hasattr(cfg, 'val_dataloader') and cfg.val_dataloader is not None:
        base_ds = cfg.val_dataloader.dataset
    elif hasattr(cfg, 'test_dataloader') and cfg.test_dataloader is not None:
        base_ds = cfg.test_dataloader.dataset
    else:
        base_ds = None
    
    if base_ds is not None:
        # Merge: keep our critical overrides, but inherit other fields
        for k, v in base_ds.items():
            if k not in ['data_root', 'ann_file', 'test_mode']:  # Don't override our args
                if k not in dataset_cfg:
                    dataset_cfg[k] = v

    # Build dataset (registry)
    dataset = DATASETS.build(dataset_cfg)
    dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        num_workers=4,
        shuffle=False,
        collate_fn=getattr(dataset, 'collate_fn', None)
    )
    
    print(f"[INFO] Model loaded from {args.checkpoint}")
    print(f"[INFO] Output directory: {args.output_dir}")
    print(f"[INFO] Device: {device_str}")
    print(f"[INFO] Dataset: {len(dataset)} samples")
    print(f"[INFO] Extracting BEV features...")
    
    # Helper to extract tokens from batch (MMEngine Det3DDataSample)
    def _extract_tokens(b):
        toks = []
        data_samples = None
        if isinstance(b, dict):
            data_samples = b.get('data_samples', None)
        if data_samples is not None:
            for ds in data_samples:
                meta = getattr(ds, 'metainfo', None)
                if meta is None and hasattr(ds, 'metas'):
                    meta = getattr(ds, 'metas')
                token = None
                if isinstance(meta, dict):
                    token = meta.get('token', meta.get('sample_idx', None))
                toks.append(token)
        else:
            # Fallback legacy
            if isinstance(b, dict):
                token = b.get('token', b.get('sample_idx', None))
                toks = token if isinstance(token, (list, tuple)) else [token]
        return toks

    # Extract features by triggering a normal test_step forward (hook captures BEV)
    with torch.no_grad():
        for batch_idx, batch in enumerate(tqdm(dataloader, desc='Extracting BEV features')):
            try:
                _ = model.test_step(batch)
                bev_feats = bev_cache['feat']
                if bev_feats is None:
                    print(f"[ERROR] No BEV features captured for batch {batch_idx}.")
                    continue
                if isinstance(bev_feats, (list, tuple)):
                    bev_feats = bev_feats[0]
                if bev_feats.dim() != 4:
                    print(f"[ERROR] Unexpected BEV feat shape: {tuple(bev_feats.shape)}")
                    continue
            except Exception as e:
                print(f"[ERROR] Failed to forward batch {batch_idx}: {e}")
                continue

            tokens = _extract_tokens(batch)
            if tokens is None or any(t is None for t in tokens):
                print(f"[WARNING] No token found in batch {batch_idx}, skipping")
                continue

            B = bev_feats.shape[0]
            for i, token in enumerate(tokens):
                if i >= B:
                    break
                feat = bev_feats[i].detach().cpu().numpy()  # [C, H, W]
                save_path = os.path.join(args.output_dir, f"{token}.npy")
                np.save(save_path, feat)
    
    if 'hook_handle' in locals() and hook_handle is not None:
        try:
            hook_handle.remove()
        except Exception:
            pass

    print(f"\n[SUCCESS] Saved {len(os.listdir(args.output_dir))} teacher features to {args.output_dir}")
    
    print("\n[RECOMMENDATION] For most users:")
    print("  → Skip TIT and use SAR/NAR configs directly")
    print("  → TIT provides marginal improvement but requires significant setup")


if __name__ == '__main__':
    main()
