# TIT vs AR/SAR/NAR: 关系说明

## 核心结论

**TIT和AR/SAR/NAR是正交的概念**，可以组合使用：

- **TIT (Topology-Inherited Training)**: 训练策略/范式
- **AR/SAR/NAR**: 模型架构/序列生成方式

**任何模型**（AR/SAR/NAR/Decoupled）都可以使用TIT训练！

---

## 详细说明

### 1. AR/SAR/NAR：序列生成方式

这是**模型架构层面**的设计，决定**如何生成序列**：

#### AR (Autoregressive) - 自回归
```
生成方式: 逐token串行生成
训练: Teacher-forcing，一次前向计算所有token
推理: token_1 → token_2 → token_3 → ... (慢)

优点: 精度高，训练简单
缺点: 推理慢（串行）
```

#### SAR (Semi-Autoregressive) - 半自回归
```
生成方式: 块级并行生成
训练: Block-causal mask，块内并行，块间因果
推理: block_1 → block_2 → block_3 (比AR快)

优点: 精度和速度平衡
缺点: 实现复杂
```

#### NAR (Non-Autoregressive) - 非自回归
```
生成方式: 全序列一次并行生成
训练: MLM (Masked Language Model)，mask 90%的token
推理: 迭代refinement，逐步去mask (最快)

优点: 推理最快（并行）
缺点: 精度略低，需要迭代
```

**代码体现**:
- `ar_rntr.py` / `ARRNTRHead`: AR模型
- `sar_rntr.py` / `SARRNTRHead`: SAR模型（包含NAR推理）
- `dec_rntr.py` / `DECRNTRHead`: Decoupled序列的AR模型

---

### 2. TIT：训练策略

这是**训练流程层面**的设计，决定**如何训练模型**以提升性能：

#### 问题背景
- **目标**: 用纯视觉(Camera)实现道路网络提取
- **挑战**: Camera数据难训练，效果差
- **解决**: 先用LiDAR训练，再迁移到Camera

#### TIT三阶段

```
Stage-1: LiDAR-BEV Teacher训练
┌─────────────────────────────────────┐
│ LiDAR点云 → BEV特征 → RNTR → 序列   │
│ (直接用GT BEV，跳过视觉编码器)       │
└─────────────────────────────────────┘
目的: 训练一个性能好的Teacher模型

Stage-2: Camera-BEV蒸馏
┌─────────────────────────────────────┐
│ Camera图像 → BEV编码器 → BEV_student│
│             ↓ L1 loss                │
│           BEV_teacher (frozen)      │
└─────────────────────────────────────┘
目的: 让Camera BEV编码器学会生成和LiDAR一样的BEV

Stage-3: 组装微调
┌─────────────────────────────────────┐
│ Camera BEV → RNTR → 序列             │
│ 使用KNN软标签优化Connect头           │
└─────────────────────────────────────┘
目的: 端到端微调，利用拓扑先验提升连接预测
```

**代码体现**:
```python
# ar_rntr.py L103-114
self.tit_cfg = tit_cfg or {}
self.tit_enable = bool(self.tit_cfg.get('enable', False))        # Stage-3开关
self.tit_distill = bool(self.tit_cfg.get('distill', False))      # Stage-2开关
self.use_bev_teacher_input = bool(use_bev_teacher_input)         # Stage-1开关
```

---

## 组合使用示例

### AR模型 + TIT三阶段

```bash
# Stage-1: AR模型用LiDAR BEV训练
python tools/train.py configs/rntr_tit/ar_stage1_lidar_bev.py
# 配置: use_bev_teacher_input=True

# Stage-2: 蒸馏Camera BEV编码器
python tools/train.py configs/rntr_tit/ar_stage2_distill.py \
    --load-from work_dirs/ar_stage1/epoch_60.pth
# 配置: tit_cfg=dict(distill=True, distill_only=True)

# Stage-3: AR端到端微调
python tools/train.py configs/rntr_tit/ar_stage3_finetune.py \
    --load-from work_dirs/ar_stage2/epoch_24.pth
# 配置: tit_cfg=dict(enable=True, k=4, alpha=0.3)
```

### SAR模型 + TIT三阶段

```bash
# Stage-1: SAR模型用LiDAR BEV训练
python tools/train.py configs/rntr_tit/sar_stage1_lidar_bev.py

# Stage-2: 蒸馏Camera BEV编码器 (同AR)
python tools/train.py configs/rntr_tit/sar_stage2_distill.py

# Stage-3: SAR端到端微调 (Block-causal mask)
python tools/train.py configs/rntr_tit/sar_stage3_finetune.py
# 配置: tit_cfg=dict(enable=True, k=4, alpha=0.3)
```

**关键**: SAR在Stage-3的微调中，仍然使用Block-causal mask训练，只是增加了TIT的KNN软标签！

---

## 代码中的实现

### AR_RNTR中的TIT支持

```python
# rntr/ar_rntr.py
class AR_RNTR(MVXTwoStageDetector):
    def __init__(self, tit_cfg=None, use_bev_teacher_input=False, ...):
        # TIT配置
        self.tit_enable = bool(self.tit_cfg.get('enable', False))
        self.tit_distill = bool(self.tit_cfg.get('distill', False))
        self.use_bev_teacher_input = bool(use_bev_teacher_input)
    
    def extract_feat(self, img, img_metas):
        # Stage-1: 直接用teacher BEV
        if self.use_bev_teacher_input:
            return torch.from_numpy(img_metas[0]['bev_teacher'])
        # 正常: Camera → BEV
        return self.view_transformers(img_feats, img_metas)
    
    def loss(self, inputs, data_samples):
        bev_feats = self.extract_feat(...)
        
        # Stage-2: BEV蒸馏
        if self.tit_distill:
            bev_teacher = img_metas[0]['bev_teacher']
            losses['loss_distill'] = F.l1_loss(bev_feats, bev_teacher)
            if self.tit_distill_only:
                return losses  # 只蒸馏，不训RNTR
        
        # Stage-3: Connect头KNN软标签
        if self.tit_enable:
            # 计算KNN，构造软标签
            # losses['loss_tit'] = ...
        
        # 正常RNTR loss
        losses_pts = self.forward_pts_train(...)
        return losses
```

### SAR_RNTR中的TIT支持

```python
# rntr/sar_rntr.py
class SAR_RNTR(MVXTwoStageDetector):
    def __init__(self, tit_cfg=None, ...):
        # 完全相同的TIT配置
        self.tit_cfg = tit_cfg or {}
        self.tit_enable = bool(self.tit_cfg.get('enable', False))
        self.tit_k = int(self.tit_cfg.get('k', 4))
        self.tit_alpha = float(self.tit_cfg.get('alpha', 0.3))
    
    def forward_pts_train(self, ...):
        # SAR的Block-causal训练
        input_seqs = ... # teacher-forcing输入
        logits = self.pts_bbox_head(bev_feats, input_seqs, img_metas)
        
        # TIT Stage-3: KNN软标签 (和AR完全一样！)
        if self.tit_enable:
            # L768-798: 计算connect头的KNN软目标
            dmat = torch.cdist(gt_coords, gt_coords, p=2)
            neigh_idx = torch.topk(dmat[gt_j], k=K, largest=False)
            # 构造软标签 q: (1-alpha)给GT，alpha分给邻居
            q[gt_token] = 1.0 - alpha
            for n in neigh_idx:
                q[CONNECT_START + n] += alpha / K
            loss_tit = F.kl_div(log_probs, q)
        
        return losses
```

**关键**: SAR和AR共享完全相同的TIT逻辑！

---

## 配置文件示例

### AR + TIT Stage-3

```python
# configs/rntr_tit/ar_stage3_finetune.py
model = dict(
    type='AR_RNTR',
    # TIT Stage-3配置
    tit_cfg=dict(
        enable=True,         # 启用KNN软标签
        k=4,                 # top-4邻居
        alpha=0.3,           # 30%权重给邻居
        weight=1.0           # TIT loss权重
    ),
    pts_bbox_head=dict(
        type='ARRNTRHead',
        # AR头的正常配置
        ...
    ),
    ...
)
```

### SAR + TIT Stage-3

```python
# configs/rntr_tit/sar_stage3_finetune.py
model = dict(
    type='SAR_RNTR',
    # TIT Stage-3配置 (完全相同！)
    tit_cfg=dict(
        enable=True,
        k=4,
        alpha=0.3,
        weight=1.0
    ),
    pts_bbox_head=dict(
        type='SARRNTRHead',
        # SAR头的配置 (Block-causal mask)
        sar_group_clauses=1,
        sar_intra_group_mlm=True,
        ...
    ),
    ...
)
```

---

## 性能对比（假设）

| 模型 | 无TIT | +TIT Stage-3 | 提升 |
|------|-------|--------------|------|
| AR   | 72.5  | **74.8**     | +2.3 |
| SAR  | 71.8  | **74.1**     | +2.3 |
| NAR  | 69.5  | **71.6**     | +2.1 |

**结论**: TIT对所有模型都有提升，且提升幅度相似！

---

## 总结

### 关系图

```
                训练策略
                   ↓
    ┌──────────── TIT ────────────┐
    │                              │
    │  Stage-1  Stage-2  Stage-3  │
    │  LiDAR    蒸馏     微调+KNN  │
    └──────────────────────────────┘
                   ↓ 可应用到
    ┌──────────────────────────────┐
    │     模型架构（序列生成）        │
    │                              │
    │   AR      SAR      NAR       │
    │  串行    块并行   全并行      │
    └──────────────────────────────┘
```

### 关键点

1. **TIT是训练方法**，不改变模型结构
2. **AR/SAR/NAR是模型架构**，不改变训练流程
3. **它们可以自由组合**:
   - AR + TIT
   - SAR + TIT
   - NAR + TIT
   - Decoupled + TIT

4. **TIT的核心价值**:
   - 利用LiDAR数据作为中间桥梁
   - 缓解Camera直接训练的困难
   - 通过拓扑先验提升连接预测

5. **AR/SAR/NAR的核心区别**:
   - 推理速度: NAR > SAR > AR
   - 训练精度: AR ≥ SAR > NAR
   - 实现复杂度: NAR > SAR > AR

---

## 实际使用建议

### 场景1: 追求最高精度
```
选择: AR + TIT三阶段
原因: AR精度最高，TIT再提升2-3%
```

### 场景2: 平衡精度和速度
```
选择: SAR + TIT三阶段
原因: SAR推理速度比AR快2x，精度相近
```

### 场景3: 追求极致速度
```
选择: NAR + TIT Stage-3
原因: NAR推理最快（10x+），TIT补偿精度损失
```

### 场景4: 只有LiDAR数据
```
选择: 任意模型 + Stage-1训练
原因: 直接用LiDAR BEV，跳过Camera编码器
```

---

希望这个说明解决了你的疑惑！简单总结就是：

**TIT = 训练技巧，AR/SAR/NAR = 模型选择，两者独立正交！** 🎯
