# ------------------------------------------------------------------------
# RoadNet Vocabulary Constants
# Unified token ranges and special tokens for AR/SAR/NAR/Decoupled models
# ------------------------------------------------------------------------


class VocabConfig:
    """Unified vocabulary configuration for RoadNet sequence models.
    
    Total vocabulary size: 576 tokens
    
    Token allocation:
    - Coordinates (x, y): [0..199]  # 200 tokens for BEV grid positions
    - Categories: [200..249]         # 50 tokens (4 used: start, continue, fork, merge)
    - Connect indices: [250..349]    # 100 tokens for parent-child connections
    - Bezier coefficients: [350..549] # 200 tokens for control point offsets
    - Reserved: [550..566]           # 17 tokens (future use)
    - Special tokens: [567..575]     # 9 tokens for sequence control
    """
    
    # ========== Coordinate Tokens ==========
    COORD_START = 0
    COORD_RANGE = 200
    # Note: actual range depends on BEV grid size (NX, NY)
    # Typically NX=NY=200 for grid_conf with 0.5m resolution and 100m range
    
    # ========== Category Tokens ==========
    CATEGORY_START = 200
    CATEGORY_RANGE = 50
    NUM_CATEGORIES = 4
    # Category semantics (as token indices):
    CATEGORY_START_NODE = CATEGORY_START + 0  # 200: graph start node
    CATEGORY_CONTINUE = CATEGORY_START + 1    # 201: continuation edge
    CATEGORY_FORK = CATEGORY_START + 2        # 202: fork/branch point
    CATEGORY_MERGE = CATEGORY_START + 3       # 203: merge point
    
    # ========== Connect Tokens ==========
    CONNECT_START = 250
    CONNECT_RANGE = 100
    # Connect token = CONNECT_START + parent_node_index
    # Used to encode parent-child topology in sequence
    
    # ========== Coefficient Tokens ==========
    COEFF_START = 350
    COEFF_RANGE = 200
    # Coefficient token = COEFF_START + grid_bin_index
    # Used for Bezier control point offsets in discretized grid
    
    # ========== Reserved ==========
    RESERVED_START = 550
    RESERVED_RANGE = 17
    
    # ========== Special Tokens ==========
    # Decoupled sequence separators
    TOK_SPLIT = 567      # Separator between edge groups in decoupled format
    TOK_EOE = 568        # End of Edge sequence
    TOK_EOV = 569        # End of Vertex sequence
    
    # Reserved special tokens
    TOK_RESERVED_1 = 570
    TOK_RESERVED_2 = 571
    TOK_RESERVED_3 = 572
    
    # Core sequence control
    TOK_END = 573        # End of sequence (AR/SAR termination)
    TOK_START = 574      # Start of sequence (beginning token)
    TOK_NO_KNOWN = 575   # Padding / mask token / unknown
    
    # ========== Total Vocabulary ==========
    VOCAB_SIZE = 576
    
    @classmethod
    def get_token_type(cls, token_id: int) -> str:
        """Get semantic type of a token ID.
        
        Args:
            token_id: integer token ID
        
        Returns:
            str: one of ['coord', 'category', 'connect', 'coeff', 'special', 'reserved', 'invalid']
        """
        token_id = int(token_id)
        if 0 <= token_id < cls.COORD_START + cls.COORD_RANGE:
            return 'coord'
        elif cls.CATEGORY_START <= token_id < cls.CATEGORY_START + cls.CATEGORY_RANGE:
            return 'category'
        elif cls.CONNECT_START <= token_id < cls.CONNECT_START + cls.CONNECT_RANGE:
            return 'connect'
        elif cls.COEFF_START <= token_id < cls.COEFF_START + cls.COEFF_RANGE:
            return 'coeff'
        elif cls.RESERVED_START <= token_id < cls.RESERVED_START + cls.RESERVED_RANGE:
            return 'reserved'
        elif token_id in (cls.TOK_SPLIT, cls.TOK_EOE, cls.TOK_EOV, 
                         cls.TOK_END, cls.TOK_START, cls.TOK_NO_KNOWN,
                         cls.TOK_RESERVED_1, cls.TOK_RESERVED_2, cls.TOK_RESERVED_3):
            return 'special'
        else:
            return 'invalid'
    
    @classmethod
    def decode_coord(cls, token_id: int) -> int:
        """Decode coordinate token to grid index."""
        return int(token_id) - cls.COORD_START
    
    @classmethod
    def decode_category(cls, token_id: int) -> int:
        """Decode category token to category index [0..3]."""
        return int(token_id) - cls.CATEGORY_START
    
    @classmethod
    def decode_connect(cls, token_id: int) -> int:
        """Decode connect token to parent node index."""
        return int(token_id) - cls.CONNECT_START
    
    @classmethod
    def decode_coeff(cls, token_id: int) -> int:
        """Decode coefficient token to grid bin index."""
        return int(token_id) - cls.COEFF_START


class TITConfig:
    """Topology-Inherited Training (TIT) default configurations."""
    
    # Stage-1: LiDAR-BEV Teacher
    STAGE1_EPOCHS = 60
    STAGE1_LR = 2e-4
    
    # Stage-2: Camera-BEV Distillation
    STAGE2_EPOCHS = 24
    STAGE2_LR = 2e-4
    STAGE2_DISTILL_WEIGHT = 1.0
    STAGE2_LOSS_TYPE = 'L1'  # or 'L2', 'SmoothL1'
    
    # Stage-3: Assemble & Finetune
    STAGE3_EPOCHS = 100
    STAGE3_LR = 2e-4
    STAGE3_KNN_K = 4          # number of nearest neighbors
    STAGE3_KNN_ALPHA = 0.3    # soft target smoothing weight
    STAGE3_TIT_WEIGHT = 1.0   # TIT loss weight
    
    # KNN distance metric
    KNN_METRIC = 'euclidean'  # or 'graph', 'hybrid'


class NARConfig:
    """Non-Autoregressive (NAR) training and inference configurations."""
    
    # MLM training
    MASK_RATIO = 0.9          # ratio of tokens to mask (following BERT)
    MIN_MASKED_PER_SAMPLE = 1 # ensure at least 1 masked token per sample
    
    # Iterative refinement
    MAX_ITERS = 10            # maximum refinement iterations
    CONF_THRESH = 0.5         # confidence threshold for keeping predictions
    KEEP_RATIO = 0.0          # top-k keep ratio (0 = threshold-only)
    
    # Decoding strategy
    DECODE_STRATEGY = 'iterative'  # or 'one-shot'


class SARConfig:
    """Semi-Autoregressive (SAR) configurations."""
    
    # Block/group settings
    GROUP_CLAUSES = 1         # number of clauses per group (1 = per-clause parallel)
    GROUP_STRATEGY = 'contiguous'  # or 'meta_groups'
    INTRA_GROUP_MLM = True    # allow full visibility within group (MLM-style)
    
    # Keypoint prompt
    KP_NUM_QUERY = 200
    KP_TOPK = 50              # top-K keypoints for prompt
    KP_PROMPT_DETACH = True   # detach gradient from KP to main sequence


class EvalConfig:
    """Evaluation metric configurations."""
    
    # Landmark thresholds (in grid units, multiply by grid resolution for meters)
    LANDMARK_THRESHOLDS = [1, 3, 5, 8, 10]  # default: [0.5m, 1.5m, 2.5m, 4m, 5m] @ 0.5m/grid
    
    # Reachability thresholds
    REACH_THRESHOLDS = [1, 2, 3, 4, 5]      # default: [0.5m, 1m, 1.5m, 2m, 2.5m] @ 0.5m/grid
    
    # Grid resolution
    GRID_RESOLUTION = 0.5  # meters per grid cell


# Convenience exports
__all__ = [
    'VocabConfig',
    'TITConfig', 
    'NARConfig',
    'SARConfig',
    'EvalConfig'
]
