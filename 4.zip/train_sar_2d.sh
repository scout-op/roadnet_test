#!/bin/bash

# SAR 2D Paper-Aligned Training Script
# Usage: bash train_sar_2d.sh

# Set port to avoid conflicts
export PORT=29501

# Training configuration
GPUS=2
CONFIG="projects/RoadNetwork/configs/rntr_sar_roadseq/lss_sar_rntr_2d_paper.py"
WORK_DIR="./work_dirs/sar_2d_mini_test"
DATA_ROOT="./data/nuscenes_mini"

echo "=========================================="
echo "SAR 2D Training"
echo "=========================================="
echo "GPUs: $GPUS"
echo "Config: $CONFIG"
echo "Work Dir: $WORK_DIR"
echo "Data Root: $DATA_ROOT"
echo "Port: $PORT"
echo "=========================================="

# Run training
bash tools/dist_train.sh \
    $CONFIG \
    $GPUS \
    --work-dir $WORK_DIR \
    --cfg-options \
        data_root=$DATA_ROOT \
        train_dataloader.dataset.data_root=$DATA_ROOT \
        train_dataloader.dataset.ann_file=nuscenes_centerline_infos_pon_train.pkl \
        val_dataloader.dataset.data_root=$DATA_ROOT \
        val_dataloader.dataset.ann_file=nuscenes_centerline_infos_pon_val.pkl \
        val_evaluator.ann_file=$DATA_ROOT/nuscenes_centerline_infos_pon_val.pkl \
        train_dataloader.batch_size=4 \
        train_dataloader.num_workers=4 \
        train_cfg.max_epochs=10 \
        train_cfg.val_interval=2 \
        model.swanlab_enable=True \
        model.swanlab_project=RoadNet_Test \
        model.swanlab_run_name=sar_2d_mini_test

echo "=========================================="
echo "Training completed!"
echo "=========================================="
