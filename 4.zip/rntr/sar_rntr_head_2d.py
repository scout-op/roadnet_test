# ------------------------------------------------------------------------
# 2D SAR-RNTR Head: Paper-aligned implementation with 2D sequences
# Implements M×L structure with column-parallel inference
# ------------------------------------------------------------------------

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import Linear
from mmdet3d.registry import MODELS, TASK_UTILS
import numpy as np
from einops import rearrange
from mmengine.model import BaseModule

from .ar_rntr_head import PryDecoderEmbeddings, MLP


@MODELS.register_module()
class SARRNTRHead2D(BaseModule):
    """2D SAR-RNTR Head with Axial attention for paper-aligned implementation.
    
    Key differences from 1D SAR:
    - Input: [B, M, L] 2D sequences instead of [B, T] 1D
    - Transformer: Axial (Intra/Inter-seq) attention
    - Inference: Column-parallel generation
    - Prompt: Per-subsequence keypoint prompts
    """
    
    def __init__(self,
                 num_classes,
                 in_channels,
                 max_center_len=601,
                 num_center_classes=576,
                 embed_dims=256,
                 num_query=900,
                 # Axial transformer
                 transformer=None,
                 # BEV positional encoding
                 bev_positional_encoding=None,
                 # Losses
                 loss_coords=dict(type='mmdet.CrossEntropyLoss'),
                 loss_labels=dict(type='mmdet.CrossEntropyLoss'),
                 loss_connects=dict(type='mmdet.CrossEntropyLoss'),
                 loss_coeffs=dict(type='mmdet.CrossEntropyLoss'),
                 # 2D SAR params
                 max_subseq=50,
                 max_len_per_subseq=100,
                 # KP branch
                 kp_num_query=34,
                 kp_num_classes=4,
                 kp_transformer=None,
                 kp_prompt_enable=True,
                 kp_prompt_type='cross',  # 'add', 'cross', or 'none'
                 kp_prompt_detach=True,
                 kp_prompt_topk=34,
                 # Inference
                 max_iteration=600,
                 init_cfg=None,
                 **kwargs):
        super().__init__(init_cfg=init_cfg)
        
        self.num_classes = num_classes
        self.in_channels = in_channels
        
        self.max_center_len = max_center_len
        self.num_center_classes = num_center_classes
        self.embed_dims = embed_dims
        self.num_query = num_query
        self.max_iteration = max_iteration
        
        # 2D params
        self.max_subseq = max_subseq
        self.max_len_per_subseq = max_len_per_subseq
        
        # Vocab constants
        self.box_range = 200
        self.coeff_range = 200
        self.category_start = 200
        self.connect_start = 250
        self.coeff_start = 350
        self.no_known = 575
        self.start = 574
        self.end = 573
        
        # Embeddings
        self.embedding = PryDecoderEmbeddings(
            vocab_size=num_center_classes,
            hidden_dim=embed_dims,
            max_position_embeddings=num_query
        )
        
        # 2D positional encodings
        # Row (subsequence index i)
        self.row_pos_embed = nn.Embedding(max_subseq, embed_dims)
        # Column (step index j)
        self.col_pos_embed = nn.Embedding(max_len_per_subseq, embed_dims)
        
        # BEV projection (must be Conv2d for 4D BEV features [B, C, H, W])
        if self.in_channels != self.embed_dims:
            self.bev_proj = nn.Conv2d(in_channels, embed_dims, kernel_size=1, stride=1, padding=0)
        else:
            self.bev_proj = nn.Identity()
        
        # BEV positional encoding
        if bev_positional_encoding is not None:
            self.bev_position_encoding = TASK_UTILS.build(bev_positional_encoding)
        else:
            self.bev_position_encoding = None
        
        # Transformer (Axial SAR)
        if transformer is None:
            transformer = dict(
                type='AxialSARTransformer',
                decoder=dict(
                    type='AxialSARDecoder',
                    num_layers=6,
                    embed_dims=embed_dims,
                    num_heads=8,
                    feedforward_channels=embed_dims * 4,
                    dropout=0.1,
                    return_intermediate=True
                )
            )
        self.transformer = MODELS.build(transformer)
        
        # Keypoint branch
        self.kp_num_query = kp_num_query
        self.kp_num_classes = kp_num_classes
        self.kp_prompt_enable = kp_prompt_enable
        self.kp_prompt_type = kp_prompt_type
        self.kp_prompt_detach = kp_prompt_detach
        self.kp_prompt_topk = kp_prompt_topk
        
        if kp_transformer is None:
            kp_transformer = dict(type='KeypointTransformer', decoder=dict(...))  # Default
        try:
            self.kp_transformer = MODELS.build(kp_transformer)
        except:
            # Fallback: reuse main transformer structure but with set prediction queries
            self.kp_transformer = None
        
        if self.kp_transformer is not None or self.kp_prompt_enable:
            self.kp_query_embed = nn.Embedding(kp_num_query, embed_dims)
            self.kp_cls_head = Linear(embed_dims, kp_num_classes)
            self.kp_reg_head = MLP(embed_dims, embed_dims, 2, 3)
            
            if self.kp_prompt_type == 'add':
                self.kp_prompt_adapter = nn.Sequential(
                    nn.Linear(embed_dims, embed_dims),
                    nn.ReLU(inplace=True),
                    nn.Linear(embed_dims, embed_dims)
                )
            self.kp_pos_mlp = nn.Sequential(
                nn.Linear(2, embed_dims),
                nn.ReLU(inplace=True),
                nn.Linear(embed_dims, embed_dims)
            )
        
        # Output head
        self.vocab_embed = Linear(embed_dims, num_center_classes)
        
        # Losses
        self.loss_coords = MODELS.build(loss_coords)
        self.loss_labels = MODELS.build(loss_labels)
        self.loss_connects = MODELS.build(loss_connects)
        self.loss_coeffs = MODELS.build(loss_coeffs)
    
    def _get_2d_positional_encoding(self, M, L, device):
        """Generate 2D positional encoding for [B, M, L, D].
        
        Returns:
            [M, L, D] positional encoding
        """
        # Row indices: [M, 1]
        row_ids = torch.arange(M, device=device).unsqueeze(1).expand(M, L)
        # Column indices: [M, L]
        col_ids = torch.arange(L, device=device).unsqueeze(0).expand(M, L)
        
        # Embed
        row_embed = self.row_pos_embed(row_ids)  # [M, L, D]
        col_embed = self.col_pos_embed(col_ids)  # [M, L, D]
        
        # Combine (simple addition; can also try concatenation + projection)
        pos_2d = row_embed + col_embed  # [M, L, D]
        return pos_2d
    
    def forward(self, mlvl_feats, input_seqs=None, img_metas=None):
        """Forward pass for 2D SAR sequences.
        
        Args:
            mlvl_feats: [B, C, H, W] BEV features
            input_seqs: (ignored, for compatibility with 1D head call signature)
            img_metas: list of dict containing 'sar_sequences_2d', 'sar_2d_mask', etc.
        
        Returns:
            logits: [num_layers, B, M, L, V] for training
        """
        # Handle flexible call signature
        if img_metas is None and isinstance(input_seqs, list):
            img_metas = input_seqs  # Caller passed img_metas as second arg
        x = mlvl_feats
        x = self.bev_proj(x)
        if self.bev_position_encoding is not None:
            pos_embed = self.bev_position_encoding(x)
        else:
            pos_embed = torch.zeros_like(x)
        
        B, _, H, W = x.shape
        device = x.device
        
        # Extract 2D sequences from img_metas
        sar_2d_list = []
        sar_mask_list = []
        M_list = []
        L_list = []
        
        for meta in img_metas:
            sar_2d = meta.get('sar_sequences_2d', None)  # [M, L]
            sar_mask = meta.get('sar_2d_mask', None)     # [M, L]
            if sar_2d is None:
                # Fallback to dummy
                print("[SAR2D WARNING] sar_sequences_2d not found in meta! Using dummy data.")
                M, L = 1, 6  # minimal
                sar_2d = torch.zeros((M, L), dtype=torch.long, device=device)
                sar_mask = torch.ones((M, L), dtype=torch.bool, device=device)
            else:
                sar_2d = torch.as_tensor(sar_2d, device=device, dtype=torch.long)
                sar_mask = torch.as_tensor(sar_mask, device=device, dtype=torch.bool)
                M, L = sar_2d.shape
            
            sar_2d_list.append(sar_2d)
            sar_mask_list.append(sar_mask)
            M_list.append(M)
            L_list.append(L)
        
        # Pad to max M and L in batch
        M_max = max(M_list)
        L_max = max(L_list)
        
        print(f"[SAR2D] forward: B={B}, M_max={M_max}, L_max={L_max}, M_list={M_list}, L_list={L_list}")
        
        sar_2d_batch = torch.zeros((B, M_max, L_max), dtype=torch.long, device=device)
        sar_mask_batch = torch.zeros((B, M_max, L_max), dtype=torch.bool, device=device)
        
        for i in range(B):
            M, L = M_list[i], L_list[i]
            sar_2d_batch[i, :M, :L] = sar_2d_list[i]
            sar_mask_batch[i, :M, :L] = sar_mask_list[i]
        
        # Embed tokens: [B, M, L] -> [B, M, L, D]
        # Flatten for embedding
        sar_2d_flat = sar_2d_batch.reshape(B, M_max * L_max)
        tgt_flat = self.embedding.word_embeddings(sar_2d_flat)  # [B, M*L, D]
        tgt = tgt_flat.reshape(B, M_max, L_max, self.embed_dims)
        
        # Add 2D positional encoding
        pos_2d = self._get_2d_positional_encoding(M_max, L_max, device)  # [M, L, D]
        pos_2d = pos_2d.unsqueeze(0).expand(B, -1, -1, -1)  # [B, M, L, D]
        tgt = tgt + pos_2d
        
        print(f"[SAR2D] tgt.shape: {tgt.shape}")
        
        # Prepare memory
        memory = x.flatten(2).permute(2, 0, 1)  # [H*W, B, D]
        memory_pos = pos_embed.flatten(2).permute(2, 0, 1)  # [H*W, B, D]
        memory_mask = torch.zeros(B, H*W, dtype=torch.bool, device=device)
        
        # Optional: KP prompt
        prompt, prompt_pos = None, None
        if self.kp_prompt_enable and self.kp_transformer is not None:
            try:
                kp_q = self.kp_query_embed.weight.unsqueeze(1).expand(-1, B, -1)  # [Q, B, D]
                kp_dec, _ = self.kp_transformer(x, memory_mask, kp_q, pos_embed)
                kp_feats = kp_dec[-1].permute(1, 0, 2)  # [B, Q, D]
                kp_cls_logits = self.kp_cls_head(kp_feats)
                kp_coords_norm = torch.sigmoid(self.kp_reg_head(kp_feats))  # [B, Q, 2]
                
                with torch.no_grad():
                    kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]
                    k = min(self.kp_prompt_topk, kp_scores.shape[1])
                    _, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
                
                gather_idx_d = topk_idx.unsqueeze(-1).expand(-1, -1, kp_feats.shape[-1])
                gather_idx_p = topk_idx.unsqueeze(-1).expand(-1, -1, 2)
                prompt = torch.gather(kp_feats, 1, gather_idx_d)  # [B, k, D]
                prompt_coords = torch.gather(kp_coords_norm, 1, gather_idx_p)
                prompt_pos = self.kp_pos_mlp(prompt_coords)  # [B, k, D]
                
                if self.kp_prompt_detach:
                    prompt = prompt.detach()
                    prompt_pos = prompt_pos.detach()
            except Exception as e:
                print(f"[SAR2D] KP prompt error: {e}")
                prompt, prompt_pos = None, None
        
        # Transformer forward
        out_dec = self.transformer(tgt, memory, pos_2d, memory_pos, memory_mask,
                                    prompt, prompt_pos)
        # out_dec: [num_layers, B, M, L, D]
        
        # Vocab projection
        out = self.vocab_embed(out_dec)  # [num_layers, B, M, L, V]
        
        return out
    
    def loss(self, out, img_metas):
        """Compute loss for 2D sequences.
        
        Args:
            out: [num_layers, B, M, L, V] logits
            img_metas: list of dict with GT sequences
        
        Returns:
            dict of losses
        """
        device = out.device
        B = out.shape[1]
        num_layers = out.shape[0]
        
        # Extract GT and build targets
        # GT format: same sar_sequences_2d from meta, [M, L] of token ids
        loss_dict = {}
        
        total_loss_coords = 0.0
        total_loss_labels = 0.0
        total_loss_connects = 0.0
        total_loss_coeffs = 0.0
        
        for layer_idx in range(num_layers):
            out_layer = out[layer_idx]  # [B, M, L, V]
            
            for b in range(B):
                sar_2d_gt = img_metas[b].get('sar_sequences_2d', None)
                sar_mask = img_metas[b].get('sar_2d_mask', None)
                n_control = img_metas[b].get('n_control', 3)
                clause_length = 4 + 2 * (n_control - 2)
                
                if sar_2d_gt is None or sar_mask is None:
                    continue
                
                sar_2d_gt = torch.as_tensor(sar_2d_gt, device=device, dtype=torch.long)
                sar_mask = torch.as_tensor(sar_mask, device=device, dtype=torch.bool)
                M_gt, L_gt = sar_2d_gt.shape
                
                # Flatten predictions and targets
                pred_flat = out_layer[b, :M_gt, :L_gt, :].reshape(-1, out_layer.shape[-1])
                tgt_flat = sar_2d_gt.reshape(-1)
                mask_flat = sar_mask.reshape(-1)
                
                # Only compute loss on valid tokens
                valid_idx = mask_flat.nonzero(as_tuple=True)[0]
                if len(valid_idx) == 0:
                    continue
                
                pred_valid = pred_flat[valid_idx]
                tgt_valid = tgt_flat[valid_idx]
                
                # Parse by clause
                # Assume tgt_valid length is multiple of clause_length
                num_clauses = len(tgt_valid) // clause_length
                if num_clauses == 0:
                    continue
                
                tgt_valid = tgt_valid[:num_clauses * clause_length]
                pred_valid = pred_valid[:num_clauses * clause_length]
                
                # Extract coordinates, labels, connects, coeffs by position in clause
                coords_x_gt = tgt_valid[0::clause_length]
                coords_y_gt = tgt_valid[1::clause_length]
                # For label/connect/coeff tokens, targets are full vocab indices (no offset subtraction)
                labels_gt = tgt_valid[2::clause_length]
                connects_gt = tgt_valid[3::clause_length]
                
                coords_x_pred = pred_valid[0::clause_length]
                coords_y_pred = pred_valid[1::clause_length]
                labels_pred = pred_valid[2::clause_length]
                connects_pred = pred_valid[3::clause_length]
                
                # Coords loss
                total_loss_coords += self.loss_coords(coords_x_pred, coords_x_gt)
                total_loss_coords += self.loss_coords(coords_y_pred, coords_y_gt)
                
                # Labels loss
                total_loss_labels += self.loss_labels(labels_pred, labels_gt)
                
                # Connects loss
                total_loss_connects += self.loss_connects(connects_pred, connects_gt)
                
                # Coeffs loss
                if clause_length > 4:
                    for k in range(4, clause_length):
                        coeffs_gt_k = tgt_valid[k::clause_length]
                        coeffs_pred_k = pred_valid[k::clause_length]
                        total_loss_coeffs += self.loss_coeffs(coeffs_pred_k, coeffs_gt_k)
        
        # Normalize by layers and batch
        norm = max(num_layers * B, 1)
        loss_dict['loss_coords'] = total_loss_coords / norm
        loss_dict['loss_labels'] = total_loss_labels / norm
        loss_dict['loss_connects'] = total_loss_connects / norm
        loss_dict['loss_coeffs'] = total_loss_coeffs / norm
        
        return loss_dict
    
    def forward_keypoints(self, mlvl_feats, img_metas):
        """Forward keypoint detection branch.
        
        Args:
            mlvl_feats: [B, C, H, W] BEV features
            img_metas: list of dict
        
        Returns:
            kp_cls_logits: [B, Q, num_classes] classification logits
            kp_coords_norm: [B, Q, 2] normalized coordinates in [0, 1]
        """
        if self.kp_transformer is None:
            raise RuntimeError("Keypoint transformer not initialized")
        
        x = mlvl_feats
        x = self.bev_proj(x)
        if self.bev_position_encoding is not None:
            pos_embed = self.bev_position_encoding(x)
        else:
            pos_embed = torch.zeros_like(x)
        
        B, _, H, W = x.shape
        device = x.device
        memory_mask = torch.zeros(B, H*W, dtype=torch.bool, device=device)
        
        # KP detection
        kp_q = self.kp_query_embed.weight.unsqueeze(1).expand(-1, B, -1)  # [Q, B, D]
        kp_dec, _ = self.kp_transformer(x, memory_mask, kp_q, pos_embed)
        kp_feats = kp_dec[-1].permute(1, 0, 2)  # [B, Q, D]
        
        kp_cls_logits = self.kp_cls_head(kp_feats)  # [B, Q, num_classes]
        kp_coords_norm = torch.sigmoid(self.kp_reg_head(kp_feats))  # [B, Q, 2]
        
        return kp_cls_logits, kp_coords_norm
    
    def simple_test_pts(self, pts_feats, img_metas):
        """Column-parallel inference for 2D SAR.
        
        At each step j, generate tokens for all M subsequences in parallel.
        This achieves the paper's M-way parallel generation.
        """
        x = pts_feats
        x = self.bev_proj(x)
        if self.bev_position_encoding is not None:
            pos_embed = self.bev_position_encoding(x)
        else:
            pos_embed = torch.zeros_like(x)
        
        B, _, H, W = x.shape
        device = x.device
        
        # Prepare memory
        memory = x.flatten(2).permute(2, 0, 1)  # [H*W, B, D]
        memory_pos = pos_embed.flatten(2).permute(2, 0, 1)
        memory_mask = torch.zeros(B, H*W, dtype=torch.bool, device=device)
        
        # Get M from metadata or use default
        M = self.max_subseq  # Can be overridden by metadata
        n_control = img_metas[0].get('n_control', 3)
        clause_length = 4 + 2 * (n_control - 2)
        
        # Maximum steps per subsequence
        max_steps = self.max_len_per_subseq // clause_length
        
        # Initialize sequences: [B, M, max_steps*clause_length]
        # Start with START token for all subsequences
        seq_2d = torch.full((B, M, max_steps * clause_length), self.no_known, 
                           dtype=torch.long, device=device)
        
        # Column-parallel generation
        # At each step j, we generate clause_length tokens for all M subsequences
        for step_j in range(max_steps):
            # Current sequence length
            curr_len = (step_j + 1) * clause_length
            
            # Get current sequence [B, M, curr_len]
            seq_curr = seq_2d[:, :, :curr_len]
            
            # Embed
            seq_flat = seq_curr.reshape(B, M * curr_len)
            tgt_flat = self.embedding.word_embeddings(seq_flat)
            tgt = tgt_flat.reshape(B, M, curr_len, self.embed_dims)
            
            # Add 2D positional encoding
            # For inference, we dynamically compute pos for current length
            L_curr = curr_len
            pos_2d = self._get_2d_positional_encoding(M, L_curr, device)
            pos_2d = pos_2d.unsqueeze(0).expand(B, -1, -1, -1)
            tgt = tgt + pos_2d
            
            # Optional: KP prompt (computed once, reused)
            if step_j == 0:
                prompt, prompt_pos = None, None
                if self.kp_prompt_enable and self.kp_transformer is not None:
                    try:
                        kp_q = self.kp_query_embed.weight.unsqueeze(1).expand(-1, B, -1)
                        kp_dec, _ = self.kp_transformer(x, memory_mask, kp_q, pos_embed)
                        kp_feats = kp_dec[-1].permute(1, 0, 2)
                        kp_cls_logits = self.kp_cls_head(kp_feats)
                        kp_coords_norm = torch.sigmoid(self.kp_reg_head(kp_feats))
                        
                        with torch.no_grad():
                            kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]
                            k = min(self.kp_prompt_topk, kp_scores.shape[1])
                            _, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
                        
                        gather_idx_d = topk_idx.unsqueeze(-1).expand(-1, -1, kp_feats.shape[-1])
                        gather_idx_p = topk_idx.unsqueeze(-1).expand(-1, -1, 2)
                        prompt = torch.gather(kp_feats, 1, gather_idx_d)
                        prompt_coords = torch.gather(kp_coords_norm, 1, gather_idx_p)
                        prompt_pos = self.kp_pos_mlp(prompt_coords)
                        
                        if self.kp_prompt_detach:
                            prompt = prompt.detach()
                            prompt_pos = prompt_pos.detach()
                    except:
                        prompt, prompt_pos = None, None
            
            # Forward through transformer
            out_dec = self.transformer(tgt, memory, pos_2d, memory_pos, memory_mask,
                                      prompt, prompt_pos)
            # out_dec: [num_layers, B, M, L_curr, D]
            
            # Get predictions for the last step (step_j)
            # We only predict tokens at positions [step_j*clause_length : (step_j+1)*clause_length]
            last_layer = out_dec[-1]  # [B, M, L_curr, D]
            
            # Extract features for current step's clause
            step_start = step_j * clause_length
            step_end = (step_j + 1) * clause_length
            step_feats = last_layer[:, :, step_start:step_end, :]  # [B, M, clause_length, D]
            
            # Vocab projection
            step_logits = self.vocab_embed(step_feats)  # [B, M, clause_length, V]
            
            # Sample (greedy for now)
            step_tokens = step_logits.argmax(dim=-1)  # [B, M, clause_length]
            
            # Update sequence
            seq_2d[:, :, step_start:step_end] = step_tokens
            
            # Note: stop condition is dataset/task-specific; by default we rely on max_steps
        
        # Convert 2D sequences to 1D results for compatibility
        results = []
        for b in range(B):
            # Flatten M subsequences into single sequence
            # Simple concatenation (can be improved with proper merging)
            seq_b = seq_2d[b]  # [M, L]
            
            # Find valid subsequences (non-empty)
            valid_subseqs = []
            for m in range(M):
                subseq_m = seq_b[m]
                # Find END token or first no_known run
                valid_len = 0
                for idx in range(0, len(subseq_m), clause_length):
                    if idx + 2 < len(subseq_m):
                        label_token = subseq_m[idx + 2]
                        if label_token == (self.end - self.category_start) or subseq_m[idx] == self.no_known:
                            break
                        valid_len = idx + clause_length
                
                if valid_len > 0:
                    valid_subseqs.append(subseq_m[:valid_len])
            
            # Concatenate all valid subsequences
            if len(valid_subseqs) > 0:
                final_seq = torch.cat(valid_subseqs, dim=0)
            else:
                final_seq = torch.zeros(0, dtype=torch.long, device=device)
            
            # Post-process: decode to node list (placeholder)
            # Real implementation would use av2seq2bznodelist or similar
            results.append(dict(
                line_seqs=final_seq.cpu(),
                pred_node_lists=[]  # TODO: decode seq to node list
            ))
        
        return results
