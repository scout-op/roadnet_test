# ------------------------------------------------------------------------
# Axial SAR Transformer: Two-directional attention for 2D SAR sequences
# Implements Intra-seq (column-wise) and Inter-seq (row-wise) self-attention
# to achieve O(M^2 + L^2) complexity instead of O((M*L)^2)
# ------------------------------------------------------------------------

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import build_norm_layer
from mmdet3d.registry import MODELS
from mmengine.model import BaseModule
from einops import rearrange
from torch.utils.checkpoint import checkpoint


def generate_square_subsequent_mask(sz, device):
    """Generate a causal mask for autoregressive decoding."""
    mask = (torch.triu(torch.ones(sz, sz, device=device)) == 1).transpose(0, 1)
    mask = mask.float().masked_fill(mask == 0, float('-inf')).masked_fill(mask == 1, float(0.0))
    return mask


@MODELS.register_module()
class AxialSARDecoderLayer(BaseModule):
    """Axial SAR decoder layer with two-directional self-attention.
    
    Sequence: [column-wise (Intra-seq), row-wise (Inter-seq), cross-attn, FFN]
    - Intra-seq: tokens at same step j across all M subsequences attend to each other
    - Inter-seq: tokens within same subsequence i attend to history (causal)
    
    This reduces complexity from O((M*L)^2*D) to O(M^2*L*D + M*L^2*D).
    """
    
    def __init__(self,
                 embed_dims=256,
                 num_heads=8,
                 feedforward_channels=1024,
                 dropout=0.1,
                 norm_cfg=dict(type='LN'),
                 use_checkpoint=False,
                 init_cfg=None):
        super().__init__(init_cfg=init_cfg)
        self.embed_dims = embed_dims
        self.num_heads = num_heads
        self.use_checkpoint = use_checkpoint
        
        # Intra-seq (column-wise) self-attention
        self.intra_seq_attn = nn.MultiheadAttention(
            embed_dims, num_heads, dropout=dropout, batch_first=True)
        self.intra_norm = build_norm_layer(norm_cfg, embed_dims)[1]
        
        # Inter-seq (row-wise) causal self-attention
        self.inter_seq_attn = nn.MultiheadAttention(
            embed_dims, num_heads, dropout=dropout, batch_first=True)
        self.inter_norm = build_norm_layer(norm_cfg, embed_dims)[1]
        
        # Cross-attention to BEV memory
        self.cross_attn = nn.MultiheadAttention(
            embed_dims, num_heads, dropout=dropout, batch_first=True)
        self.cross_norm = build_norm_layer(norm_cfg, embed_dims)[1]
        
        # FFN
        self.ffn = nn.Sequential(
            nn.Linear(embed_dims, feedforward_channels),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(feedforward_channels, embed_dims),
            nn.Dropout(dropout)
        )
        self.ffn_norm = build_norm_layer(norm_cfg, embed_dims)[1]
        
        self.dropout = nn.Dropout(dropout)
    
    def forward(self, tgt, memory, tgt_pos=None, memory_pos=None, 
                memory_key_padding_mask=None, prompt=None, prompt_pos=None):
        """Forward pass with axial attention.
        
        Args:
            tgt: [B, M, L, D] query tokens (2D SAR sequences)
            memory: [N, B, D] BEV memory from encoder
            tgt_pos: [B, M, L, D] positional encoding for tgt
            memory_pos: [N, B, D] positional encoding for memory
            memory_key_padding_mask: [B, N] mask for memory
            prompt: [B, K, D] optional prompt (e.g. keypoints)
            prompt_pos: [B, K, D] positional encoding for prompt
        
        Returns:
            [B, M, L, D] updated tokens
        """
        B, M, L, D = tgt.shape
        
        # 1. Intra-seq (column-wise) self-attention: tokens at same j attend across M
        # Reshape to [B*L, M, D]
        tgt_col = rearrange(tgt, 'b m l d -> (b l) m d')
        if tgt_pos is not None:
            tgt_pos_col = rearrange(tgt_pos, 'b m l d -> (b l) m d')
            q_col = k_col = tgt_col + tgt_pos_col
        else:
            q_col = k_col = tgt_col
        
        attn_col, _ = self.intra_seq_attn(q_col, k_col, tgt_col)
        tgt_col = tgt_col + self.dropout(attn_col)
        tgt_col = self.intra_norm(tgt_col)
        
        # Reshape back to [B, M, L, D]
        tgt = rearrange(tgt_col, '(b l) m d -> b m l d', b=B, l=L)
        
        # 2. Inter-seq (row-wise) causal self-attention: within each subsequence i
        # Reshape to [B*M, L, D]
        tgt_row = rearrange(tgt, 'b m l d -> (b m) l d')
        if tgt_pos is not None:
            tgt_pos_row = rearrange(tgt_pos, 'b m l d -> (b m) l d')
            q_row = k_row = tgt_row + tgt_pos_row
        else:
            q_row = k_row = tgt_row
        
        # Apply causal mask
        causal_mask = generate_square_subsequent_mask(L, tgt.device)
        attn_row, _ = self.inter_seq_attn(q_row, k_row, tgt_row, attn_mask=causal_mask)
        tgt_row = tgt_row + self.dropout(attn_row)
        tgt_row = self.inter_norm(tgt_row)
        
        # Reshape back to [B, M, L, D]
        tgt = rearrange(tgt_row, '(b m) l d -> b m l d', b=B, m=M)
        
        # 3. Cross-attention to BEV memory
        # Flatten to [B*M*L, D] or [B, M*L, D]
        tgt_flat = rearrange(tgt, 'b m l d -> b (m l) d')
        memory_t = memory.permute(1, 0, 2)  # [B, N, D]
        
        if tgt_pos is not None:
            tgt_pos_flat = rearrange(tgt_pos, 'b m l d -> b (m l) d')
            q_cross = tgt_flat + tgt_pos_flat
        else:
            q_cross = tgt_flat
        
        if memory_pos is not None:
            k_cross = memory_t + memory_pos.permute(1, 0, 2)
        else:
            k_cross = memory_t
        
        # Optional: incorporate prompt into cross-attention
        if prompt is not None and prompt_pos is not None:
            # Concatenate prompt to memory
            k_cross = torch.cat([prompt + prompt_pos, k_cross], dim=1)
            v_cross = torch.cat([prompt, memory_t], dim=1)
            if memory_key_padding_mask is not None:
                prompt_mask = torch.zeros(B, prompt.shape[1], dtype=torch.bool, device=prompt.device)
                cross_mask = torch.cat([prompt_mask, memory_key_padding_mask], dim=1)
            else:
                cross_mask = None
        else:
            v_cross = memory_t
            cross_mask = memory_key_padding_mask
        
        attn_cross, _ = self.cross_attn(q_cross, k_cross, v_cross, key_padding_mask=cross_mask)
        tgt_flat = tgt_flat + self.dropout(attn_cross)
        tgt_flat = self.cross_norm(tgt_flat)
        
        # Reshape back to [B, M, L, D]
        tgt = rearrange(tgt_flat, 'b (m l) d -> b m l d', m=M, l=L)
        
        # 4. FFN
        # Apply to flattened version for efficiency
        tgt_flat = rearrange(tgt, 'b m l d -> (b m l) d')
        tgt_flat = tgt_flat + self.ffn(tgt_flat)
        tgt_flat = self.ffn_norm(tgt_flat)
        tgt = rearrange(tgt_flat, '(b m l) d -> b m l d', b=B, m=M, l=L)
        
        return tgt


@MODELS.register_module()
class AxialSARDecoder(BaseModule):
    """Stack of AxialSARDecoderLayer."""
    
    def __init__(self, 
                 num_layers=6,
                 embed_dims=256,
                 num_heads=8,
                 feedforward_channels=1024,
                 dropout=0.1,
                 return_intermediate=False,
                 norm_cfg=dict(type='LN'),
                 init_cfg=None):
        super().__init__(init_cfg=init_cfg)
        self.num_layers = num_layers
        self.return_intermediate = return_intermediate
        
        self.layers = nn.ModuleList([
            AxialSARDecoderLayer(
                embed_dims=embed_dims,
                num_heads=num_heads,
                feedforward_channels=feedforward_channels,
                dropout=dropout,
                norm_cfg=norm_cfg
            ) for _ in range(num_layers)
        ])
    
    def forward(self, tgt, memory, tgt_pos=None, memory_pos=None,
                memory_key_padding_mask=None, prompt=None, prompt_pos=None):
        """Forward through all layers.
        
        Args:
            tgt: [B, M, L, D]
            memory: [N, B, D]
            
        Returns:
            If return_intermediate: [num_layers, B, M, L, D]
            Else: [B, M, L, D]
        """
        intermediate = []
        for layer in self.layers:
            tgt = layer(tgt, memory, tgt_pos, memory_pos, 
                       memory_key_padding_mask, prompt, prompt_pos)
            if self.return_intermediate:
                intermediate.append(tgt)
        
        if self.return_intermediate:
            return torch.stack(intermediate)
        return tgt.unsqueeze(0)  # [1, B, M, L, D] for consistency


@MODELS.register_module()
class AxialSARTransformer(BaseModule):
    """Complete Axial SAR Transformer for 2D sequence-to-sequence."""
    
    def __init__(self,
                 decoder=dict(
                     type='AxialSARDecoder',
                     num_layers=6,
                     embed_dims=256,
                     num_heads=8,
                     feedforward_channels=1024,
                     dropout=0.1,
                     return_intermediate=True
                 ),
                 init_cfg=None):
        super().__init__(init_cfg=init_cfg)
        self.decoder = MODELS.build(decoder)
        self.embed_dims = self.decoder.layers[0].embed_dims
    
    def forward(self, tgt, memory, tgt_pos, memory_pos, memory_mask,
                prompt=None, prompt_pos=None):
        """Forward function.
        
        Args:
            tgt: [B, M, L, D] embedded 2D sequences
            memory: [N, B, D] BEV memory
            tgt_pos: [B, M, L, D] positional encoding
            memory_pos: [N, B, D] memory positional encoding
            memory_mask: [B, N] key padding mask
            prompt: [B, K, D] optional prompt
            prompt_pos: [B, K, D] prompt positional encoding
        
        Returns:
            [num_layers, B, M, L, D] or [1, B, M, L, D]
        """
        out = self.decoder(tgt, memory, tgt_pos, memory_pos, memory_mask,
                          prompt, prompt_pos)
        return out
