"""
Custom Checkpoint Hook that allows saving checkpoints to a separate directory
while keeping logs in the original work_dir.

Usage in config:
    custom_hooks = [
        dict(
            type='CustomCheckpointHook',
            enable_custom_path=True,  # Set to True to use custom path
            custom_checkpoint_dir='/path/to/your/checkpoints',  # Your custom path
            interval=10,  # Save every N epochs
            by_epoch=True,
            max_keep_ckpts=5,
            save_last=True,
            save_best='auto',  # or specify metric like 'Reachability_F1'
        ),
    ]
"""

import os
import os.path as osp
from typing import Optional, Sequence, Union

from mmengine.hooks import CheckpointHook
from mmengine.registry import HOOKS

# Debug: Print when this module is imported
print(f"[DEBUG] Importing CustomCheckpointHook from {__file__}")

@HOOKS.register_module()
class CustomCheckpointHook(CheckpointHook):
    """Enhanced CheckpointHook with custom path support.
    
    Allows saving checkpoints to a user-specified directory while keeping
    all other logs (tensorboard, text logs, etc.) in the original work_dir.
    
    Args:
        enable_custom_path (bool): Whether to use custom checkpoint path.
            Default: False (use original work_dir).
        custom_checkpoint_dir (str): Custom directory to save checkpoints.
            Only used when enable_custom_path=True. Can be absolute or relative.
            If None when enabled, falls back to work_dir.
        interval (int): Save checkpoint every interval epochs/iters.
        by_epoch (bool): Whether interval is epoch-based. Default: True.
        max_keep_ckpts (int): Maximum checkpoints to keep. -1 means unlimited.
        save_last (bool): Whether to save the last checkpoint.
        save_best (str or Sequence[str]): Metric(s) to evaluate best checkpoint.
            Use 'auto' to automatically infer from validation metrics.
        rule (str or Sequence[str]): Comparison rule for save_best.
            'greater' for metrics where higher is better (e.g., F1, AP).
            'less' for metrics where lower is better (e.g., loss).
        **kwargs: Other arguments passed to CheckpointHook.
    
    Examples:
        # Example 1: Disabled (default behavior)
        dict(type='CustomCheckpointHook', interval=10)
        
        # Example 2: Save to custom absolute path
        dict(
            type='CustomCheckpointHook',
            enable_custom_path=True,
            custom_checkpoint_dir='/data/my_checkpoints/experiment_1',
            interval=10,
            max_keep_ckpts=5,
        )
        
        # Example 3: Save to custom relative path (relative to work_dir parent)
        dict(
            type='CustomCheckpointHook',
            enable_custom_path=True,
            custom_checkpoint_dir='../shared_checkpoints/ar_rntr',
            interval=5,
            save_best='Reachability_F1',
            rule='greater',
        )
    """
    
    def __init__(self,
                 enable_custom_path: bool = False,
                 custom_checkpoint_dir: Optional[str] = None,
                 interval: int = -1,
                 by_epoch: bool = True,
                 max_keep_ckpts: int = -1,
                 save_last: bool = True,
                 save_best: Union[str, Sequence[str], None] = None,
                 rule: Union[str, Sequence[str], None] = None,
                 **kwargs):
        
        super().__init__(
            interval=interval,
            by_epoch=by_epoch,
            max_keep_ckpts=max_keep_ckpts,
            save_last=save_last,
            save_best=save_best,
            rule=rule,
            **kwargs
        )
        
        self.enable_custom_path = enable_custom_path
        self.custom_checkpoint_dir = custom_checkpoint_dir
        self._original_out_dir = None
    
    def before_train(self, runner) -> None:
        """Setup custom checkpoint directory if enabled."""
        if self.enable_custom_path and self.custom_checkpoint_dir is not None:
            # Store original out_dir
            self._original_out_dir = self.out_dir
            
            # Resolve custom path
            if osp.isabs(self.custom_checkpoint_dir):
                custom_dir = self.custom_checkpoint_dir
            else:
                # Relative to work_dir's parent
                work_dir = runner.work_dir
                custom_dir = osp.join(osp.dirname(work_dir), self.custom_checkpoint_dir)
            
            # Create directory
            os.makedirs(custom_dir, exist_ok=True)
            
            # Override out_dir for this hook only
            self.out_dir = custom_dir
            
            runner.logger.info(f'🔧 CustomCheckpointHook: Checkpoints will be saved to: {custom_dir}')
            runner.logger.info(f'📝 Logs remain in: {runner.work_dir}')
        else:
            runner.logger.info(f'💾 CustomCheckpointHook: Using default checkpoint path: {self.out_dir}')
        
        # Call parent's before_train
        super().before_train(runner)
    
    def after_train_epoch(self, runner) -> None:
        """Save checkpoint after training epoch."""
        # Just call parent's method - it will use self.out_dir which we've already set
        super().after_train_epoch(runner)
    
    def after_train_iter(self, runner, batch_idx: int, data_batch=None, outputs=None) -> None:
        """Save checkpoint after training iteration."""
        # Just call parent's method - it will use self.out_dir which we've already set
        super().after_train_iter(runner, batch_idx, data_batch, outputs)
