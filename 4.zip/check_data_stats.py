#!/usr/bin/env python
"""检查数据集中的序列长度分布，帮助确定合理的max_subseq和max_len_per_subseq"""

import pickle
import numpy as np
from collections import defaultdict

def analyze_dataset(ann_file):
    print(f"\n{'='*60}")
    print(f"分析文件: {ann_file}")
    print(f"{'='*60}\n")
    
    with open(ann_file, 'rb') as f:
        data = pickle.load(f)
    
    # 检查数据结构
    print(f"📦 数据类型: {type(data)}")
    if isinstance(data, dict):
        print(f"📦 顶层键: {list(data.keys())[:10]}")
    
    # 统计子序列数量 (M)
    num_subseq_list = []
    seq_lengths_per_sample = []
    max_seq_len_list = []
    
    # 假设clause_length=6 (n_control=3: 4 + 2*(3-2) = 6)
    clause_length = 6
    
    # 尝试不同的数据结构
    samples = None
    if isinstance(data, dict):
        if 'data_list' in data:
            samples = data['data_list']
        elif 'infos' in data:
            samples = data['infos']
        elif 'samples' in data:
            samples = data['samples']
        else:
            # 可能直接是样本字典
            samples = [data]
    elif isinstance(data, list):
        samples = data
    
    if samples is None:
        print(f"❌ 无法识别数据格式")
        return
    
    print(f"✅ 找到 {len(samples)} 个样本\n")
    
    for sample in samples:
        # 尝试不同的字段路径
        meta = sample.get('ann_info', sample.get('anns', sample))
        
        # 尝试从不同字段获取信息
        if 'centerline_sequence' in meta:
            seq = meta['centerline_sequence']
            total_len = len(seq)
            
            # 估算子序列数（如果没有明确的group信息）
            # 这里简单假设每个子序列平均长度
            estimated_clauses = total_len // clause_length
            
        if 'sar_sequences_2d' in meta:
            sar_2d = meta['sar_sequences_2d']  # [M, L]
            M, L = sar_2d.shape
            num_subseq_list.append(M)
            
            # 统计每个子序列的实际长度
            if 'sar_seq_lengths' in meta:
                actual_lens = meta['sar_seq_lengths']
                seq_lengths_per_sample.extend(actual_lens)
                max_seq_len_list.append(max(actual_lens))
    
    if len(num_subseq_list) == 0:
        print("\n⚠️ 数据中没有sar_sequences_2d字段")
        print("💡 这可能是因为：")
        print("   1. 数据还没有经过2D SAR预处理")
        print("   2. 数据管线中没有使用 TransformOrderedBzLane2GraphSAR(enable_2d=True)")
        print("\n📝 查看第一个样本的可用字段:")
        if samples and len(samples) > 0:
            first_sample = samples[0]
            meta = first_sample.get('ann_info', first_sample.get('anns', first_sample))
            available_fields = list(meta.keys())
            print(f"   {available_fields}")
            
            # 检查是否有基本的序列数据
            if 'centerline_sequence' in meta:
                seq = meta['centerline_sequence']
                print(f"\n✅ 找到 centerline_sequence (1D序列)")
                print(f"   长度: {len(seq)}")
                print(f"   预估节点数: {len(seq) // clause_length}")
        return
    
    # 统计
    num_subseq_arr = np.array(num_subseq_list)
    seq_lengths_arr = np.array(seq_lengths_per_sample)
    max_seq_len_arr = np.array(max_seq_len_list)
    
    print("【子序列数量统计 (M)】")
    print(f"  样本数: {len(num_subseq_arr)}")
    print(f"  最小值: {num_subseq_arr.min()}")
    print(f"  最大值: {num_subseq_arr.max()}")
    print(f"  平均值: {num_subseq_arr.mean():.1f}")
    print(f"  中位数: {np.median(num_subseq_arr):.1f}")
    print(f"  50%分位: {np.percentile(num_subseq_arr, 50):.1f}")
    print(f"  75%分位: {np.percentile(num_subseq_arr, 75):.1f}")
    print(f"  90%分位: {np.percentile(num_subseq_arr, 90):.1f}")
    print(f"  95%分位: {np.percentile(num_subseq_arr, 95):.1f}")
    print(f"  99%分位: {np.percentile(num_subseq_arr, 99):.1f}")
    
    print("\n【每个子序列的长度统计 (L per subseq)】")
    print(f"  总子序列数: {len(seq_lengths_arr)}")
    print(f"  最小值: {seq_lengths_arr.min()}")
    print(f"  最大值: {seq_lengths_arr.max()}")
    print(f"  平均值: {seq_lengths_arr.mean():.1f}")
    print(f"  中位数: {np.median(seq_lengths_arr):.1f}")
    print(f"  50%分位: {np.percentile(seq_lengths_arr, 50):.1f}")
    print(f"  75%分位: {np.percentile(seq_lengths_arr, 75):.1f}")
    print(f"  90%分位: {np.percentile(seq_lengths_arr, 90):.1f}")
    print(f"  95%分位: {np.percentile(seq_lengths_arr, 95):.1f}")
    print(f"  99%分位: {np.percentile(seq_lengths_arr, 99):.1f}")
    
    print("\n【每个样本的最长子序列 (Max L per sample)】")
    print(f"  平均值: {max_seq_len_arr.mean():.1f}")
    print(f"  中位数: {np.median(max_seq_len_arr):.1f}")
    print(f"  95%分位: {np.percentile(max_seq_len_arr, 95):.1f}")
    
    # 覆盖率分析
    print("\n" + "="*60)
    print("【配置建议 - 基于95%覆盖率】")
    print("="*60)
    
    m_95 = int(np.ceil(np.percentile(num_subseq_arr, 95)))
    l_95 = int(np.ceil(np.percentile(seq_lengths_arr, 95)))
    
    # 向上取整到clause_length的倍数
    l_95_aligned = ((l_95 + clause_length - 1) // clause_length) * clause_length
    
    print(f"\n✅ 推荐配置 (95%数据无截断):")
    print(f"   max_subseq = {m_95}")
    print(f"   max_len_per_subseq = {l_95_aligned}")
    
    # 计算截断损失
    for m_test, l_test in [(20, 300), (15, 240), (30, 400), (m_95, l_95_aligned)]:
        truncated_m = (num_subseq_arr > m_test).sum()
        truncated_l = (seq_lengths_arr > l_test).sum()
        pct_m = 100 * truncated_m / len(num_subseq_arr)
        pct_l = 100 * truncated_l / len(seq_lengths_arr)
        
        print(f"\n📊 M={m_test}, L={l_test}:")
        print(f"   超出M的样本: {truncated_m}/{len(num_subseq_arr)} ({pct_m:.1f}%)")
        print(f"   超出L的子序列: {truncated_l}/{len(seq_lengths_arr)} ({pct_l:.1f}%)")
        
        if pct_m < 5 and pct_l < 10:
            print(f"   ✅ 影响较小，可接受")
        elif pct_m < 10 and pct_l < 20:
            print(f"   ⚠️ 有一定影响，需权衡")
        else:
            print(f"   ❌ 影响较大，不推荐")

if __name__ == '__main__':
    import sys
    
    # 默认路径
    train_file = './data/nuscenes_mini/nuscenes_centerline_infos_pon_train.pkl'
    val_file = './data/nuscenes_mini/nuscenes_centerline_infos_pon_val.pkl'
    
    if len(sys.argv) > 1:
        train_file = sys.argv[1]
    if len(sys.argv) > 2:
        val_file = sys.argv[2]
    
    try:
        analyze_dataset(train_file)
    except FileNotFoundError:
        print(f"❌ 文件不存在: {train_file}")
        print("用法: python check_data_stats.py [train_pkl] [val_pkl]")
    except Exception as e:
        print(f"❌ 分析训练集失败: {e}")
    
    try:
        analyze_dataset(val_file)
    except:
        pass
