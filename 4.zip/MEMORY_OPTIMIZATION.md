# 2D SAR 显存优化指南

## 当前显存消耗分析

### 配置
```python
max_subseq = 50           # M
max_len_per_subseq = 600  # L
batch_size = 4
embed_dims = 256
num_vocab = 576
```

### 显存消耗 (单样本)

| 组件 | 形状 | 大小 | 说明 |
|------|------|------|------|
| **Embedding** | `[B, M, L, D]` | `[4, 50, 600, 256]` = 122M 参数 × 4字节 = **488MB** | 2D序列表示 |
| **Intra-Attn中间** | `[B*L, M, D]` | `[2400, 50, 256]` = 31M × 4 = **124MB** | 列向注意力 |
| **Inter-Attn中间** | `[B*M, L, D]` | `[200, 600, 256]` = 31M × 4 = **124MB** | 行向注意力 |
| **Transformer输出** | `[6, B, M, L, V]` | `[6, 4, 50, 600, 576]` = 415M × 4 = **1.66GB** | 6层中间结果 |
| **梯度** | 同上 | - | **×2** (反向传播) |
| **优化器状态** | 同上 | - | **×2** (Adam: momentum + variance) |

**总计**: ~488MB + 124MB + 124MB + 1.66GB = **~2.4GB** (前向)  
**包括梯度和优化器**: **~10GB** (每个样本！)

### 与1D SAR对比

| 配置 | 1D SAR | 2D SAR | 倍数 |
|------|--------|--------|------|
| 序列长度 | T=600 | M×L=50×600=30000 | **50x** |
| Embedding | `[B, 600, 256]` | `[B, 50, 600, 256]` | **50x** |
| 输出 | `[6, B, 600, 576]` | `[6, B, 50, 600, 576]` | **50x** |
| 总显存 | ~0.2GB/样本 | ~10GB/样本 | **50x** |

## 优化方案

### 方案1：减小序列尺寸 ⭐⭐⭐⭐⭐

**最直接有效！立即可用！**

```python
# 配置文件修改
# configs/rntr_sar_roadseq/lss_sar_rntr_2d_paper.py

pts_bbox_head=dict(
    type='SARRNTRHead2D',
    max_subseq=20,           # ← 从50降到20
    max_len_per_subseq=300,  # ← 从600降到300
    ...
)

# 数据管线修改
dict(type='TransformOrderedBzLane2GraphSAR', 
     n_control=3, 
     orderedDFS=True, 
     enable_2d=True, 
     max_subseq=20,          # ← 从50降到20
     max_len_per_subseq=300) # ← 从600降到300
```

**效果**:
- M: 50 → 20 (降低2.5x)
- L: 600 → 300 (降低2x)
- 显存: **2.4GB → 0.38GB** (降低6.3x)

**优点**: 无需改代码，直接生效  
**缺点**: 可能丢失长序列信息

---

### 方案2：不返回中间层 ⭐⭐⭐⭐

**显存大户！必须优化！**

```python
# 配置文件修改
transformer=dict(
    type='AxialSARTransformer',
    decoder=dict(
        type='AxialSARDecoder',
        num_layers=6,
        return_intermediate=False,  # ← 改为False (默认True)
        ...
    ))
```

**效果**:
- Transformer输出: `[6, B, M, L, V]` → `[1, B, M, L, V]`
- 显存节省: **1.66GB → 0.28GB** (降低83%)

**优点**: 大幅减少显存，推理时建议使用  
**缺点**: 训练时无法使用中间层监督（大多数情况不需要）

---

### 方案3：梯度检查点 ⭐⭐⭐

**用时间换空间**

```python
# 配置文件修改
transformer=dict(
    type='AxialSARTransformer',
    decoder=dict(
        type='AxialSARDecoder',
        use_checkpoint=True,  # ← 启用梯度检查点
        ...
    ))
```

**效果**:
- 显存节省: **~40%**
- 训练速度: **-20%**

**原理**: 前向时不存储中间激活，反向时重新计算

---

### 方案4：混合精度训练 ⭐⭐⭐⭐

**已启用！无需修改！**

```python
# 配置文件中已有
optim_wrapper = dict(
    type='AmpOptimWrapper',  # ← 自动混合精度
    loss_scale='dynamic',
    ...
)
```

**效果**:
- 显存节省: **~40%**
- 速度提升: **~20%**

---

### 方案5：减少batch size ⭐⭐

**最后手段**

```bash
# 训练命令中修改
--cfg-options train_dataloader.batch_size=2  # 从4降到2
```

**效果**:
- 显存线性降低
- 训练速度线性降低

---

### 方案6：降低embed_dims ⭐⭐

```python
transformer_dims = 128  # 从256降到128
```

**效果**:
- 显存降低: **~50%**
- 模型容量降低，可能影响精度

---

## 推荐组合方案

### 组合A：平衡方案（推荐）

```python
# 配置修改
max_subseq = 20          # ↓ 2.5x
max_len_per_subseq = 300 # ↓ 2x
return_intermediate = False  # ↓ 83%
batch_size = 4
```

**预计显存**: ~2GB/样本 → ~0.25GB/样本 = **1GB总计 (4卡)**  
**适用**: A100-40GB, V100-32GB

---

### 组合B：激进方案（极限显存）

```python
max_subseq = 15          # ↓ 3.3x
max_len_per_subseq = 240 # ↓ 2.5x
return_intermediate = False
use_checkpoint = True
batch_size = 2
```

**预计显存**: ~2GB/样本 → ~0.15GB/样本 = **0.3GB总计 (2卡)**  
**适用**: RTX 3090-24GB, RTX 4090-24GB

---

### 组合C：精度优先（大显存）

```python
max_subseq = 30
max_len_per_subseq = 400
return_intermediate = True  # 训练时保留
batch_size = 2
```

**预计显存**: ~6GB/样本  
**适用**: A100-80GB, H100

---

## 实际应用建议

### Step 1: 先用方案1测试

```bash
# 修改配置文件
max_subseq=20
max_len_per_subseq=300

# 运行smoke test
PORT=29501 bash tools/dist_train.sh \
    configs/.../lss_sar_rntr_2d_paper.py \
    2 \
    --cfg-options train_dataloader.batch_size=2 ...
```

### Step 2: 观察日志

```
[SAR2D] tgt.shape: torch.Size([2, 20, 300, 256])  # M=20, L=300
GPU 0: Memory 8GB / 24GB (33%)  # 显存占用正常
```

### Step 3: 根据显存调整

- **显存充足**: 增大 M, L, batch_size
- **显存紧张**: 启用 `return_intermediate=False` 或 `use_checkpoint=True`
- **显存爆炸**: 使用组合B

---

## FAQ

**Q: 为什么2D SAR比1D SAR显存大这么多？**

A: 因为序列长度从 T=600 膨胀到 M×L=30000（50倍）。虽然注意力复杂度降低了（O(M²+L²) vs O(T²)），但存储的中间张量大幅增加。

**Q: 减小 M 和 L 会影响精度吗？**

A: 会有一定影响，但合理范围内影响较小：
- `max_subseq=20` 对应平均每个场景20个子图，足够覆盖大部分场景
- `max_len_per_subseq=300` 对应50个节点（300/6=50），足够表示复杂拓扑

**Q: 如何选择合适的 M 和 L？**

A: 查看数据统计：
```python
# 在数据加载时打印
print(f"M={sar_num_subseq}, actual_lens={sar_seq_lengths}")
# 输出: M=15, actual_lens=[180, 120, 240, ...]
```
根据95百分位数设置上限。

**Q: return_intermediate 有什么用？**

A: 训练时可以对每层输出计算损失（深度监督），但通常不需要。推理时必须关闭。

---

## 总结

**当前问题**: 2D SAR 显存消耗是 1D SAR 的 **50倍**

**根本原因**: 2D 序列表示 `[B, M, L, D]` 的维度膨胀

**最佳方案**: 
1. 减小 M 和 L (立即生效，显存降低6x)
2. 关闭 return_intermediate (显存降低83%)
3. 启用 AMP (已启用，显存降低40%)

**预期效果**: 从 **10GB/样本** 降到 **0.25GB/样本**，可在RTX 3090上运行！

---

*生成时间: 2025-10-21*
