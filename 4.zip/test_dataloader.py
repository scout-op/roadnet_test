#!/usr/bin/env python
"""测试数据加载器，查看实际生成的2D序列统计"""

import sys
sys.path.insert(0, '.')

from mmengine.config import Config
import numpy as np

def test_dataloader(config_path):
    """测试数据加载器并统计2D序列"""
    
    cfg = Config.fromfile(config_path)
    
    # 构建数据集
    from mmdet3d.registry import DATASETS
    dataset = DATASETS.build(cfg.train_dataloader.dataset)
    
    print(f"\n{'='*60}")
    print(f"数据集大小: {len(dataset)}")
    print(f"{'='*60}\n")
    
    # 统计前100个样本
    num_samples = min(100, len(dataset))
    
    m_list = []
    l_per_subseq = []
    max_l_per_sample = []
    
    print("🔄 正在统计前100个样本的2D序列...")
    for i in range(num_samples):
        if i % 20 == 0:
            print(f"  进度: {i}/{num_samples}")
        
        try:
            data = dataset[i]
            
            # 从data_samples中获取
            if hasattr(data, 'data_samples'):
                meta = data.data_samples.metainfo
            elif isinstance(data, dict) and 'data_samples' in data:
                meta = data['data_samples'].metainfo
            else:
                meta = data.get('img_metas', {})
            
            if 'sar_sequences_2d' in meta:
                sar_2d = meta['sar_sequences_2d']
                M, L = sar_2d.shape
                m_list.append(M)
                max_l_per_sample.append(L)
                
                # 获取每个子序列的实际长度
                if 'sar_seq_lengths' in meta:
                    actual_lens = meta['sar_seq_lengths']
                    l_per_subseq.extend(actual_lens)
        except Exception as e:
            print(f"  ⚠️ 样本{i}出错: {e}")
            continue
    
    if len(m_list) == 0:
        print("\n❌ 没有找到sar_sequences_2d字段")
        print("💡 请检查配置文件中的数据管线是否包含:")
        print("   TransformOrderedBzLane2GraphSAR(enable_2d=True, ...)")
        return
    
    # 统计
    m_arr = np.array(m_list)
    l_arr = np.array(l_per_subseq)
    max_l_arr = np.array(max_l_per_sample)
    
    print(f"\n{'='*60}")
    print("【子序列数量统计 (M)】")
    print(f"{'='*60}")
    print(f"  样本数: {len(m_arr)}")
    print(f"  最小值: {m_arr.min()}")
    print(f"  最大值: {m_arr.max()}")
    print(f"  平均值: {m_arr.mean():.1f}")
    print(f"  中位数: {np.median(m_arr):.1f}")
    print(f"  75%分位: {np.percentile(m_arr, 75):.1f}")
    print(f"  90%分位: {np.percentile(m_arr, 90):.1f}")
    print(f"  95%分位: {np.percentile(m_arr, 95):.1f}")
    
    print(f"\n{'='*60}")
    print("【每个子序列的长度统计 (L per subseq)】")
    print(f"{'='*60}")
    print(f"  总子序列数: {len(l_arr)}")
    print(f"  最小值: {l_arr.min()}")
    print(f"  最大值: {l_arr.max()}")
    print(f"  平均值: {l_arr.mean():.1f}")
    print(f"  中位数: {np.median(l_arr):.1f}")
    print(f"  75%分位: {np.percentile(l_arr, 75):.1f}")
    print(f"  90%分位: {np.percentile(l_arr, 90):.1f}")
    print(f"  95%分位: {np.percentile(l_arr, 95):.1f}")
    
    print(f"\n{'='*60}")
    print("【每个样本的最大L (Max L per sample)】")
    print(f"{'='*60}")
    print(f"  平均值: {max_l_arr.mean():.1f}")
    print(f"  95%分位: {np.percentile(max_l_arr, 95):.1f}")
    
    # 推荐配置
    m_95 = int(np.ceil(np.percentile(m_arr, 95)))
    l_95 = int(np.ceil(np.percentile(l_arr, 95)))
    
    # 对齐到clause_length=6的倍数
    clause_length = 6
    l_95_aligned = ((l_95 + clause_length - 1) // clause_length) * clause_length
    
    print(f"\n{'='*60}")
    print("【推荐配置 - 基于95%覆盖率】")
    print(f"{'='*60}")
    print(f"\n✅ 覆盖95%数据的配置:")
    print(f"   max_subseq = {m_95}")
    print(f"   max_len_per_subseq = {l_95_aligned}")
    
    # 评估不同配置
    configs_to_test = [
        (15, 240, "激进（显存优先）"),
        (20, 300, "平衡（推荐）"),
        (25, 360, "保守（精度优先）"),
        (m_95, l_95_aligned, "数据驱动（95%覆盖）")
    ]
    
    for m_test, l_test, desc in configs_to_test:
        truncated_m = (m_arr > m_test).sum()
        truncated_l = (l_arr > l_test).sum()
        pct_m = 100 * truncated_m / len(m_arr)
        pct_l = 100 * truncated_l / len(l_arr)
        
        print(f"\n📊 {desc}: M={m_test}, L={l_test}")
        print(f"   超出M的样本: {truncated_m}/{len(m_arr)} ({pct_m:.1f}%)")
        print(f"   超出L的子序列: {truncated_l}/{len(l_arr)} ({pct_l:.1f}%)")
        
        if pct_m < 5 and pct_l < 10:
            print(f"   ✅ 影响小，推荐")
        elif pct_m < 10 and pct_l < 20:
            print(f"   ⚠️ 有影响，可接受")
        else:
            print(f"   ❌ 影响大，不推荐")

if __name__ == '__main__':
    config_path = 'projects/RoadNetwork/configs/rntr_sar_roadseq/lss_sar_rntr_2d_paper.py'
    
    if len(sys.argv) > 1:
        config_path = sys.argv[1]
    
    print(f"📝 使用配置: {config_path}\n")
    test_dataloader(config_path)
