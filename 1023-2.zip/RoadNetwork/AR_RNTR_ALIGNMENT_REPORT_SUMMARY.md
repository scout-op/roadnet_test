# AR-RNTR代码与论文对齐检查报告 - 总结与建议

## 总体对齐评分

| 模块 | 对齐度 | 权重 | 加权得分 |
|------|--------|------|----------|
| Token编码方案 | 100% | 15% | 15.0 |
| 序列构造逻辑 | 100% | 20% | 20.0 |
| 损失函数定义 | 70% | 15% | 10.5 |
| Transformer架构 | 100% | 20% | 20.0 |
| 训练目标函数 | 95% | 15% | 14.25 |
| 推理约束 | N/A | 5% | 4.0 (估算) |
| TIT训练策略 | 50% | 10% | 5.0 |
| **总计** | **88.75%** | 100% | **88.75** |

**综合评价**: 代码实现**基本对齐**论文描述（88.75%），核心算法正确，但存在若干策略性偏离和工程增强。

---

## 关键差异汇总

### 🔴 Critical Issues (必须说明)

#### 1. TIT训练策略默认未启用 ❌
- **论文**: TIT是核心创新，Section 3.11专门介绍
- **代码**: `tit_enable=False`, `use_bev_teacher_input=False`
- **影响**: 无法直接复现论文TIT实验
- **建议**: 
  - 提供TIT配置文件示例
  - 补充LiDAR BEV数据准备脚本
  - 在论文中明确说明TIT的可选性

#### 2. 损失权重策略相反 ⚠️
- **论文**: "下调高频类（Lineal、connect=0）"
- **代码**: "保持Lineal=1.0，上调稀有类（Offshoot×3, Clone×1.5）"
- **理由**: 代码注释说明实验发现下调主导类会损害性能
- **建议**: 论文Revision更新权重策略描述，补充消融实验

#### 3. KNN软监督公式未明确 ⚠️
- **论文**: 仅提及"distance-aware smoothing"
- **代码**: 实现了KNN+KL散度算法（alpha=0.3, k=4）
- **问题**: 无法验证实现是否为论文原意
- **建议**: 在论文中补充完整数学公式

### ⚠️ Important Enhancements (应补充说明)

#### 4. 推理约束未提及 ⚠️
- **代码**: 实现6类推理约束（坐标/类别/系数裁剪、DAG/Lineal约束、Slot词汇约束）
- **论文**: 未提及任何后处理约束
- **必要性**: 约束1-3工程必需（防崩溃），约束4-6提升质量
- **建议**: 在Appendix补充"推理约束与后处理"章节，提供消融实验

#### 5. 4分支独立损失 ⚠️
- **论文**: 统一的MLE loss
- **代码**: coords/labels/connects/coeffs四个独立分类头
- **理由**: 不同slot有不同token空间和权重需求
- **建议**: 说明多分支设计的动机

#### 6. 动态损失权重调度 ⚠️
- **代码**: 两阶段训练（Stage1提升coords/coeffs，Stage2增强coeffs）
- **论文**: 未提及
- **建议**: 补充训练策略说明

---

## 完整对齐细节表

### ✅ 完全对齐项 (100%)

| 项目 | 论文描述 | 代码实现 | 验证 |
|------|---------|---------|------|
| Token范围 | 0-573, 574类 | num_center_classes=574 | ✅ |
| coords范围 | 0-199 | box_range=200 | ✅ |
| label范围 | 200-249 | category_start=200 | ✅ |
| connect范围 | 250-349 | connect_start=250 | ✅ |
| coeff范围 | 350-569 | coeff_start=350 | ✅ |
| Special tokens | Start=572, EOS=571, n/a=573, noise=570 | 完全一致 | ✅ |
| Clause结构 | [x,y,label,connect,coeff_x,coeff_y] | 6-integer clause | ✅ |
| BEV Encoder | Lift-Splat-Shoot | LiftSplatShootEgo | ✅ |
| Decoder架构 | Self-Attn → Cross-Attn → FFN | 标准Transformer | ✅ |
| 自回归训练 | Teacher forcing | input_seqs包含GT前缀 | ✅ |
| 噪声对象技术 | Synthetic noise objects | random_box_label | ✅ |
| n/a masking | 不计算loss | mask != no_known | ✅ |

### ⚠️ 部分对齐项 (50%-95%)

| 项目 | 对齐度 | 差异描述 |
|------|--------|----------|
| 损失权重 | 70% | Lineal保持1.0（论文建议下调），上调稀有类 |
| 训练目标 | 95% | 增加4分支独立损失 |
| TIT实现 | 50% | 代码实现正确，但**默认关闭** |
| KNN软监督 | N/A | 论文未给公式，代码实现KNN+KL散度 |

### ❌ 论文未提及项 (代码增强)

| 项目 | 代码实现 | 建议 |
|------|---------|------|
| 推理约束 | 6类约束（坐标/类别/系数/DAG/Lineal/Slot） | Appendix补充 |
| 动态权重 | 两阶段调度Hook | 说明训练策略 |
| SwanLab日志 | 实时可视化 | 可选功能，不影响论文 |
| AMP监控 | Loss spike检测 | 工程实践，不影响论文 |
| 调试日志 | 详细训练日志 | 工程实践，不影响论文 |

---

## 代码质量评价

### ✅ 优点

1. **高可配置性**: 所有关键参数可通过config配置
2. **工程鲁棒性**: 完善的NaN/Inf检测、梯度监控、AMP监控
3. **可维护性**: 详细的调试日志、注释完善
4. **可扩展性**: 支持可变n_control、动态clause_length
5. **实验友好**: SwanLab集成、可视化支持

### ⚠️ 待改进项

1. **文档完整性**: 
   - TIT使用说明缺失
   - 推理约束配置说明不足
   - 数据准备流程需补充

2. **可复现性风险**:
   - TIT默认关闭，无法直接复现论文实验
   - 权重策略偏离论文描述
   - 推理约束影响性能但论文未提及

3. **代码整洁度**:
   - 大量调试print语句（可通过hook管理）
   - 部分配置硬编码（如spike_threshold=15.0）

---

## 论文Revision建议

### 高优先级 (必须补充)

#### 1. 更新Section 3.5 (训练目标)
```latex
\noindent \textbf{Loss Function.}
We optimize a multi-branch maximum likelihood objective:
\begin{equation}
\mathcal{L} = \mathcal{L}_{\text{coords}} + w_{\text{label}}\mathcal{L}_{\text{labels}} 
            + w_{\text{connect}}\mathcal{L}_{\text{connects}} + \mathcal{L}_{\text{coeffs}}
\end{equation}
where each branch uses cross-entropy loss with class weights.
For label branch, we up-weight rare classes (Offshoot, Clone) 
rather than down-weighting dominant class (Lineal), 
as empirical studies show the latter harms performance.
```

#### 2. 新增Appendix A: 推理约束
```latex
\section{Inference Constraints and Post-processing}
To ensure valid road network generation, we apply the following constraints:
\begin{itemize}
\item \textbf{Coordinate Clamping}: Restrict coordinates to BEV grid range.
\item \textbf{DAG Constraint}: Enforce $v_d < i$ to maintain directed acyclic structure.
\item \textbf{Lineal Semantic Constraint}: Force Lineal nodes to connect to $i-1$.
\end{itemize}
```

#### 3. 补充Section 3.11 (TIT)
```latex
\noindent \textbf{KNN Soft Supervision.}
To smooth topology learning, we apply KNN-based soft labels on connect logits:
\begin{equation}
q_j = \begin{cases}
1 - \alpha & \text{if } j = \text{GT target} \\
\alpha / K & \text{if } j \in \text{KNN}_K(\text{GT target}) \\
0 & \text{otherwise}
\end{cases}
\end{equation}
where $K=4$, $\alpha=0.3$, and we minimize $\text{KL}(\log p \| q)$.
```

### 中优先级 (建议补充)

#### 4. 补充消融实验
- 权重策略消融: Lineal下调 vs 保持1.0 vs 稀有类上调
- 推理约束消融: 逐一禁用约束的性能影响
- TIT组件消融: Stage1/2/3和KNN软监督的独立贡献

#### 5. 补充实现细节
- 4分支独立损失的设计动机
- 动态权重调度策略
- Synthetic noise objects的详细构造规则

### 低优先级 (可选)

#### 6. 补充工程实践
- 训练稳定性技术（AMP监控、梯度裁剪）
- 可视化工具（SwanLab、拓扑图渲染）

---

## 代码改进建议

### 高优先级

#### 1. 提供TIT配置示例
```python
# configs/rntr_tit/stage1_lidar_bev.py
model = dict(
    type='AR_RNTR',
    use_bev_teacher_input=True,  # Stage 1: Use LiDAR BEV
    tit_cfg=dict(
        enable=True,
        k=4,
        alpha=0.3,
        weight=1.0
    ),
    ...
)
```

#### 2. 补充数据准备脚本
```python
# tools/prepare_lidar_bev.py
"""Extract LiDAR BEV features for TIT training."""
# 生成 bev_teacher 字段
```

#### 3. 完善README
```markdown
## Training with TIT

### Stage 1: Train on LiDAR BEV
```bash
./tools/dist_train.sh configs/rntr_tit/stage1_lidar_bev.py 8
```

### Stage 2: Distill to Camera BEV
...
```

### 中优先级

#### 4. 配置文件规范化
- 将硬编码参数移到config（spike_threshold, log_interval等）
- 统一命名规范（loss_weight vs loss_connects.loss_weight）

#### 5. 调试系统优化
- 将所有debug_print移到DebugLoggerHook
- 支持动态开关调试输出

### 低优先级

#### 6. 代码重构
- 提取`_construct_sequences`函数（lines 500-543）
- 提取`_apply_inference_constraints`函数（lines 976-1039）
- 减少代码重复

---

## 验证清单 (Checklist)

### 对于论文作者
- [ ] 更新损失权重策略描述（Section 3.5）
- [ ] 补充推理约束说明（Appendix A）
- [ ] 明确KNN软监督公式（Section 3.11）
- [ ] 补充TIT数据准备流程（Section 3.11）
- [ ] 添加消融实验（Section 4）
- [ ] 更新公式：统一MLE → 多分支损失

### 对于代码维护者
- [ ] 提供TIT配置文件（3个stage）
- [ ] 编写数据准备脚本（prepare_lidar_bev.py）
- [ ] 更新README（TIT使用说明）
- [ ] 补充消融实验配置（禁用各约束）
- [ ] 规范化config参数
- [ ] 添加单元测试（序列构造、约束逻辑）

### 对于用户
- [ ] 阅读配置文件注释理解各参数
- [ ] 如需TIT，准备LiDAR BEV数据
- [ ] 根据数据集调整权重配置
- [ ] 理解推理约束对拓扑质量的影响

---

## 结论

AR-RNTR代码实现与论文**基本对齐**（88.75%），核心算法（Token编码、序列构造、Transformer架构、MLE训练）**完全正确**。

**主要差异**源于:
1. **实验调优**: 权重策略基于实验反馈调整
2. **工程增强**: 推理约束保证生成质量
3. **可选功能**: TIT默认关闭（需显式配置）

**建议**: 论文补充实现细节和消融实验，代码提供TIT使用文档。

**可复现性**: 
- ✅ 核心AR-RNTR可复现
- ⚠️ TIT需额外配置
- ⚠️ 推理约束影响性能（建议保持默认）

---

## 附录: 快速对照表

| 论文Section | 对应代码文件 | 对齐度 | 关键差异 |
|-------------|-------------|--------|----------|
| 3.2 Sequence构造 | ar_rntr.py:500-543 | ✅ 100% | 无 |
| 3.5 AR-RNTR | ar_rntr.py, ar_rntr_head.py | ⚠️ 85% | 权重策略、4分支损失 |
| 3.11 TIT | ar_rntr.py:191-201,645-684,876-895 | ❌ 50% | 默认关闭，KNN公式未明确 |
| Table 1 Embedding | ar_rntr.py:129-138 | ✅ 100% | 无 |
| Eq. 1 MLE Loss | ar_rntr_head.py:630-658 | ✅ 95% | 多分支增强 |

**文件路径**:
- 主模型: `/home/subobo/ro/1023/RoadNetwork/rntr/ar_rntr.py`
- Head: `/home/subobo/ro/1023/RoadNetwork/rntr/ar_rntr_head.py`
- 配置: `/home/subobo/ro/1023/RoadNetwork/configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py`

**论文路径**:
- v3: `/home/subobo/ro/1023/arXiv-2402.08207v3/main_pure.tex`
- Method: `/home/subobo/ro/1023/arXiv-2402.08207v3/file/3-method.tex`
- TIT: `/home/subobo/ro/1023/arXiv-2402.08207v3/file/3-new-method.tex`
