"""
Quick script to replace print statements with debug_print in ar_rntr.py
"""
import re

# Read the file
with open('rntr/ar_rntr.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Replace all print( with debug_print(
# But skip the ones inside the debug_print function definition itself
lines = content.split('\n')
new_lines = []
in_debug_print_def = False

for i, line in enumerate(lines):
    # Check if we're in the debug_print function definition
    if 'def debug_print(' in line:
        in_debug_print_def = True
    elif in_debug_print_def and line.strip() and not line.startswith(' '):
        in_debug_print_def = False
    
    # Replace print with debug_print if not in the function definition
    if not in_debug_print_def and '    print(' in line:
        new_line = line.replace('    print(', '    debug_print(')
        new_lines.append(new_line)
    else:
        new_lines.append(line)

new_content = '\n'.join(new_lines)

# Write back
with open('rntr/ar_rntr.py', 'w', encoding='utf-8') as f:
    f.write(new_content)

print("✅ Replaced all print statements with debug_print!")
print(f"Modified {len([l for l in lines if '    print(' in l and 'def debug_print' not in lines[max(0, lines.index(l)-5):lines.index(l)]])} lines")
