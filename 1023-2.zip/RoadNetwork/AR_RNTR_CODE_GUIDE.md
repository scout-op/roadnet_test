# AR-RNTR 代码架构与训练流程

## 📁 一、核心文件结构

```
RoadNetwork/
├── configs/rntr_ar_roadseq/           # 配置文件
│   └── lss_ar_rntr_debug_fp32.py
├── rntr/
│   ├── ar_rntr.py                     # 主模型 ⭐
│   ├── ar_rntr_head.py                # AR解码头 ⭐
│   ├── LiftSplatShoot.py              # 多视角→BEV ⭐
│   ├── rntr_transformer.py            # Transformer
│   ├── centerline_nuscenes_dataset.py # 数据集
│   └── core/centerline/structures/
│       └── av2_ordered_bz_centerline.py  # 序列↔拓扑转换
```

## 🔄 二、训练流程图

```
数据加载 → 特征提取 → 序列解码 → Loss计算 → 反向传播
   ↓           ↓           ↓          ↓
Dataset  →  BEV Feat  → Transformer → 4-Branch Loss
```

### 完整调用链

```python
# 1. 数据加载
CenterlineNuScenesDataset.load_data_list()
  → parse_data_info()  # 解析图像、相机参数、GT中心线
  → pipeline: [Load图像 → 增强 → 归一化]

# 2. 训练前向
AR_RNTR.forward_train(img, img_metas, **gt)
  │
  ├─ extract_feat(img)
  │   ├─ img_backbone(ResNetV1c)     # [B*6, 3, 128, 352] → [B*6, 256, H/8, W/8]
  │   ├─ img_neck(CPFPN)             # 特征融合
  │   └─ view_transformers(LSS)      # [B*6, 256, H, W] → [B, 256, 128, 192] BEV
  │
  └─ forward_pts_train(bev_feats, gt_coords, gt_labels, gt_connects, gt_coeffs)
      │
      ├─ 【Step 1】构造训练序列
      │   positive_clause = [x, y, label+200, connect+250, coeff+304]
      │   negative_clause = [random_x, random_y, noise_label, no_known, no_known]
      │   input_seq  = [START] + positive + negative
      │   output_seq = positive + [END] + negative_masked
      │
      ├─ 【Step 2】Transformer解码
      │   ARRNTRHead.forward(bev_feats, input_seq)
      │     ├─ seq_embedding(input_seq)        # [B, T, 256]
      │     ├─ seq_refine(Transformer)         # 6层 Decoder
      │     │   └─ Self-Attention + Cross-Attention(BEV) + FFN
      │     └─ 4个分类头
      │         ├─ coords_classifier  → [B, T, 574]
      │         ├─ labels_classifier  → [B, T, 574]
      │         ├─ connect_classifier → [B, T, 574]
      │         └─ coeffs_classifier  → [B, T, 574]
      │
      └─ 【Step 3】计算Loss
          # 按clause切分序列（每个节点占 4+num_coeff*2 个token）
          pos_x = preds[0::clause_length]
          pos_y = preds[1::clause_length]
          label = preds[2::clause_length]
          connect = preds[3::clause_length]
          coeffs = preds[4::clause_length]
          
          # 过滤no_known（负样本mask）
          loss_coords = CE(pos[mask], gt_pos[mask])
          loss_labels = CE(label[mask], gt_label[mask])
          loss_connects = CE(connect[mask], gt_connect[mask])
          loss_coeffs = CE(coeffs[mask], gt_coeffs[mask])
          
          # 动态权重 + TIT
          total_loss = w1*L1 + w2*L2 + w3*L3 + w4*L4 + w_tit*L_tit
```

## 🧩 三、核心模块详解

### 3.1 AR_RNTR (主模型)

**关键方法：**

| 方法 | 作用 | 输入 | 输出 |
|------|------|------|------|
| `extract_feat` | 图像→BEV特征 | img [B*6,3,H,W] | bev [B,256,128,192] |
| `forward_pts_train` | 训练逻辑 | bev + GT | losses dict |
| `simple_test_pts` | 推理（自回归） | bev | node_list |

**Token空间设计：**

```python
0     : START
1     : END
2-199 : Coords (X/Y坐标，共享编码)
200-203: Labels (Ancestor=200, Lineal=201, Offshoot=202, Clone=203)
250-349: Connects (连接到哪个节点，最多100个节点)
304-573: Coeffs (Bezier控制点系数，2*(n_control-2)*bins)
```

### 3.2 ARRNTRHead (解码头)

```python
class ARRNTRHead:
    def __init__():
        self.seq_embedding = nn.Embedding(574, 256)     # Token嵌入
        self.seq_refine = LssSeqLineTransformer(...)    # Transformer
        self.coords_classifier = MLP(256, 574)          # 4个分类头
        self.labels_classifier = MLP(256, 574)
        self.connect_classifier = MLP(256, 574)
        self.coeffs_classifier = MLP(256, 574)
    
    def forward(bev_feats, input_seqs):
        # 1. Token嵌入
        seq_feat = self.seq_embedding(input_seqs)  # [B, T, 256]
        
        # 2. Transformer Decoder
        hidden = self.seq_refine(seq_feat, bev_feats)  # [6, B, T, 256]
        
        # 3. 分类
        return [coords_logits, labels_logits, connect_logits, coeffs_logits]
```

### 3.3 LiftSplatShoot (BEV变换)

```python
def forward(img_feats, img_metas):
    # 步骤1: 预测深度概率
    depth_prob = softmax(depth_net(img_feats))  # [B*6, D=44, H, W]
    
    # 步骤2: 像素→3D点云（伪LiDAR）
    for cam in 6_cameras:
        for (u, v) in pixels:
            for d in depth_bins:
                xyz = pixel2world(u, v, d, intrinsic, extrinsic)
                volume[xyz] += img_feats[u,v] * depth_prob[d]
    
    # 步骤3: 投影到BEV平面（Z轴max pooling）
    bev = volume.max(dim=Z)  # [B, 256, NY=128, NX=192]
    return bev
```

## 🎯 四、推理流程

```python
def simple_test_pts(bev_feats, img_metas):
    pred_seq = [START]  # token=0
    
    # 自回归生成
    while len(pred_seq) < 610:
        logits = pts_bbox_head(bev_feats, pred_seq)  # [1, B, T, 574]
        next_token = argmax(logits[-1, :, -1, :])
        
        if next_token == END:
            break
        
        pred_seq.append(next_token)
    
    # 序列→拓扑图
    node_list = av2seq2bznodelist(pred_seq, n_control=3)
    # [{coord:[x,y], sque_type:'start'}, {coord:[x,y], sque_type:'fork', fork_from:0}, ...]
    
    return node_list
```

## ⚙️ 五、关键配置

```python
# configs/rntr_ar_roadseq/lss_ar_rntr_debug_fp32.py
model = dict(
    type='AR_RNTR',
    img_backbone=dict(type='ResNetV1c', depth=50),
    img_neck=dict(type='CPFPN', out_channels=256),
    
    grid_conf=dict(
        xbound=[-48, 48, 0.5],   # BEV: 96m × 64m, 0.5m分辨率
        ybound=[-32, 32, 0.5],
    ),
    
    pts_bbox_head=dict(
        type='ARRNTRHead',
        num_center_classes=574,
        max_center_len=610,
        embed_dims=256,
        seq_cfg=dict(type='LssSeqLineTransformer', num_layers=6),
    ),
    
    tit_cfg=dict(enable=True, k_neighbors=3),  # TIT拓扑软监督
    swanlab_enable=True,                       # 实验追踪
)

# 优化器
optim_wrapper = dict(
    type='AmpOptimWrapper',  # 混合精度
    optimizer=dict(type='AdamW', lr=2e-4),
    clip_grad=dict(max_norm=35),
)
```

## 📊 六、Loss组成

```python
# 基础Loss（4个分支）
loss_coords   = CE(coords_pred, coords_gt)      # 节点坐标
loss_labels   = CE(labels_pred, labels_gt)      # 节点类型
loss_connects = CE(connect_pred, connect_gt)    # 连接关系
loss_coeffs   = CE(coeffs_pred, coeffs_gt)      # Bezier系数

# TIT拓扑软监督（可选）
tit_loss = soft_CE_with_knn_weights(connect_pred, knn_targets)

# 动态权重（训练阶段调整）
total_loss = w1*L_coords + w2*L_labels + w3*L_connects + w4*L_coeffs + w_tit*L_tit
```

## 🚀 七、启动命令

```bash
# 训练
./tools/dist_train.sh configs/rntr_ar_roadseq/lss_ar_rntr_debug_fp32.py 8

# 验证
python tools/test_with_stats.py configs/.../config.py work_dirs/.../latest.pth
```
