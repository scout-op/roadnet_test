# AR-RNTR代码与论文对齐检查报告 (Part 2)

## 4. Transformer架构对齐检查 ✅ (100%)

### 论文描述 (Section 3.5: Architecture)

引用原文:
> "We apply the same encoder-decoder architecture as [Pix2Seq].
> The encoder is responsible for extracting BEV feature $\mathcal{F}$ from multiple onboard cameras such as Lift-Splat-Shoot.
> For decoder, we use the same Transformer decoder as [Pix2Seq] which includes a **self-attention layer**, a **cross-attention layer** and a **MLP layer**."

### 代码实现验证

#### 4.1 BEV Encoder (ar_rntr.py)

**Backbone + Neck** (lines 61-76):
```python
img_backbone=dict(
    type='ResNetV1c',
    depth=50,              # ✅ ResNet-50
    num_stages=4,
    out_indices=(1, 2, 3)  # ✅ 多尺度特征
)
img_neck=dict(
    type='CPFPN',          # ✅ FPN
    in_channels=[512, 1024, 2048],
    out_channels=256       # ✅ transformer_dims
)
```

**LSS View Transform** (line 102):
```python
self.view_transformers = LiftSplatShootEgo(
    grid_conf, data_aug_conf, 
    return_bev=True, 
    **lss_cfg
)
```

**BEV Feature提取流程** (lines 390-394):
```python
def extract_feat(self, img, img_metas):
    img_feats = self.extract_img_feat(img, img_metas)  # ResNet50 → [B,N,C,H,W]
    largest_feat_shape = img_feats[0].shape[3]
    down_level = int(np.log2(self.downsample // (self.final_dim[0] // largest_feat_shape)))
    bev_feats = self.view_transformers(img_feats[down_level], img_metas)  # LSS → [B,C,H,W]
    return bev_feats
```

#### 4.2 Transformer Decoder (config + ar_rntr_head.py)

**配置** (lss_ar_rntr_changeloss_test_fp16_torch2.py, lines 109-140):
```python
transformer=dict(
    type='LssSeqLineTransformer',
    decoder=dict(
        type='PETRTransformerLineDecoder',
        return_intermediate=True,
        num_layers=6,  # ✅ 6层decoder
        transformerlayers=dict(
            type='PETRLineTransformerDecoderLayer',
            attn_cfgs=[
                dict(
                    type='RNTR2MultiheadAttention',  # Self-attention
                    embed_dims=256,
                    num_heads=8,
                    dropout=0.1
                ),
                dict(
                    type='RNTR2MultiheadAttention',  # Cross-attention
                    embed_dims=256,
                    num_heads=8,
                    dropout=0.1
                ),
            ],
            ffn_cfgs=dict(
                type='FFN',                         # MLP
                embed_dims=256,
                feedforward_channels=1024,          # 4倍扩展
                num_fcs=2,
                ffn_drop=0.1,
                act_cfg=dict(type='ReLU', inplace=True),
            ),
            operation_order=('self_attn', 'norm', 'cross_attn', 'norm', 'ffn', 'norm')
        )
    )
)
```

**Forward流程** (ar_rntr_head.py, lines 502-507):
```python
if self.training:
    tgt = self.embedding(input_seqs.long())  # [B, T] → [B, T, 256]
    query_embed = self.embedding.position_embeddings.weight  # [max_len, 256]
    outs_dec, _ = self.transformer(tgt, x, masks, query_embed, pos_embed)
    outs_dec = torch.nan_to_num(outs_dec)  # [6, B, T, 256] - 6层输出
    out = self.vocab_embed(outs_dec)  # [6, B, T, 574] - 映射到词汇表
```

**Embedding层** (ar_rntr_head.py, lines 341-342):
```python
self.embedding = PryDecoderEmbeddings(num_center_classes, self.embed_dims, max_center_len)
# Word embedding + Positional embedding + LayerNorm
self.vocab_embed = MLP(self.embed_dims, self.embed_dims, num_center_classes, 3)
# 3层MLP映射到词汇表
```

### 架构对齐表

| 组件 | 论文要求 | 代码实现 | 对齐度 |
|------|---------|---------|--------|
| BEV Encoder | LSS | LiftSplatShootEgo | ✅ 100% |
| Backbone | 未明确 | ResNet-50 | ✅ |
| Decoder层数 | 未明确 | 6层 | ✅ |
| Self-Attention | ✅ 要求 | RNTR2MultiheadAttention | ✅ 100% |
| Cross-Attention | ✅ 要求 | RNTR2MultiheadAttention | ✅ 100% |
| FFN/MLP | ✅ 要求 | FFN (4x expansion) | ✅ 100% |
| Operation Order | Self→Cross→FFN | self_attn→cross_attn→ffn | ✅ 100% |
| Token Embedding | Word+Position | PryDecoderEmbeddings | ✅ 100% |
| Vocab Projection | MLP | 3-layer MLP | ✅ 100% |

**结论**: ✅ **完全对齐**，标准Transformer Encoder-Decoder架构。

---

## 5. 训练目标函数对齐检查 ✅ (95%)

### 论文公式 (Section 3.5, Equation 1)

$$\max \sum_{i=1}^{L} w_i \log{P(\hat{y}_i|y_{<i}, \mathcal{F})}$$

其中:
- $y_i$: 第i个token
- $y_{<i}$: 所有前置token (teacher forcing)
- $\mathcal{F}$: BEV特征
- $w_i$: 类别权重

### 代码实现 (ar_rntr.py, lines 563-749)

#### 5.1 自回归训练序列

**Input序列** (包含前缀，实现teacher forcing):
```python
# [START] + [GT positive clauses] + [synthetic noise clauses]
input_seq = torch.cat([
    torch.ones(1) * self.start,       # 572 (START)
    box_label.flatten(),               # GT clauses
    random_box_label.flatten()         # Noise clauses
])
```

**Output序列** (监督信号):
```python
# [GT positive clauses] + [EOS] + [noise clauses with special tokens]
output_seq = torch.cat([
    box_label.flatten(),               # GT clauses (真实坐标、类别、连接、系数)
    torch.ones(1) * self.end,          # 571 (EOS)
    output_noise_seq.flatten()         # coords/connect/coeffs→n/a, label→noise_label
])
```

#### 5.2 4分支独立损失

**Slot切分逻辑** (lines 602-618):
```python
# 1. Coords branch (x, y)
pos_x_logits = preds_i[0::clause_length, :]
pos_y_logits = preds_i[1::clause_length, :]
outputs_pos_i = torch.cat([pos_x_logits, pos_y_logits], dim=0)

# 2. Labels branch (v_c)
outputs_cls_i = preds_i[2::clause_length, :]

# 3. Connects branch (v_d)
outputs_conn_i = preds_i[3::clause_length, :]

# 4. Coeffs branch (e_px, e_py)
for k in range(4, clause_length):
    coeff_logits_list.append(preds_i[k::clause_length, :])
outputs_coeffs_i = torch.cat(coeff_logits_list, dim=0)
```

**n/a掩码过滤** (lines 621-624):
```python
mask_pos = (inputs_pos_i != self.no_known)        # 过滤掉n/a token
mask_cls = (inputs_cls_i != self.no_known)
mask_conn = (inputs_conn_i != self.no_known)
mask_coeff = (inputs_coeffs_i != self.no_known)
```

**损失计算** (ar_rntr_head.py, lines 630-658):
```python
def loss_by_feat_single(self, preds_coords, preds_labels, preds_connects, preds_coeffs,
                        gt_coords, gt_labels, gt_connects, gt_coeffs):
    loss_coords = self.loss_coords(preds_coords, gt_coords)      # CE loss
    loss_labels = self.loss_labels(preds_labels, gt_labels)      # CE + class_weight
    loss_connects = self.loss_connects(preds_connects, gt_connects)  # CE + class_weight
    loss_coeffs = self.loss_coeffs(preds_coeffs, gt_coeffs)      # CE loss
    
    # Sanitize NaN/Inf
    loss_coords = torch.nan_to_num(loss_coords)
    loss_labels = torch.nan_to_num(loss_labels)
    loss_connects = torch.nan_to_num(loss_connects)
    loss_coeffs = torch.nan_to_num(loss_coeffs)
    
    return loss_coords, loss_labels, loss_connects, loss_coeffs
```

### 对齐分析

| 对比项 | 论文描述 | 代码实现 | 对齐度 |
|--------|---------|---------|--------|
| 自回归训练 | $P(\hat{y}_i \| y_{<i}, \mathcal{F})$ | `input_seqs`包含GT前缀 | ✅ 100% |
| Teacher Forcing | 使用GT前缀 | ✅ 实现 | ✅ 100% |
| MLE损失 | Cross-Entropy | Cross-Entropy | ✅ 100% |
| EOS token | 目标序列末尾 | `torch.ones(1) * self.end` | ✅ 100% |
| 噪声对象技术 | Synthetic noise objects | random + noise tokens | ✅ 100% |
| n/a masking | 不计算loss | `mask != self.no_known` | ✅ 100% |
| **多分支损失** | **未明确说明** | **4个独立分支** | ⚠️ **代码增强** |

**结论**: ✅ **基本对齐 (95%)**，核心MLE目标一致，代码实现更精细。

**代码增强点**:
1. **4分支独立监督**: 代码将6-integer clause拆分为coords/labels/connects/coeffs四个分类头，而论文仅提及统一的MLE loss
2. **硬负样本策略**: noise clause的label使用`noise_label=570`作为hard negative，而非n/a
3. **EOS位置处理**: 代码在拼接后移除EOS token位置的监督（line 591-595），避免模型过早停止

**理论依据**: 多分支设计可能源于:
- 不同slot有不同的token空间（coords: 200, labels: 4, connects: 100, coeffs: 220）
- 独立的class_weight配置需求（labels/connects需要权重调整）

---

## 6. 推理约束与解码策略对齐检查 ⚠️ (N/A)

### 论文描述

论文Section 3.5仅说明推理复杂度:
> "The inference time complexity should be $\mathcal{O}(|\mathcal{E}|\cdot \mathcal{T}_s)$"

**未提及任何后处理约束或解码策略**。

### 代码实现 (ar_rntr.py + ar_rntr_head.py)

#### 6.1 配置化推理约束系统 (lines 85-92)

```python
inference_constraints=dict(
    clamp_coords=True,       # 约束1: 坐标裁剪到BEV网格
    clamp_classes=True,      # 约束2: 类别裁剪到[0,3]
    clamp_coeffs=True,       # 约束3: 系数裁剪到训练范围
    clamp_connect=True,      # 约束4: 连接索引<当前节点（DAG约束）
    force_lineal_prev=True,  # 约束5: 强制Lineal连接i-1
)
```

#### 6.2 约束详细实现

**约束1: 坐标裁剪** (lines 983-989)
```python
if self.inference_constraints.get('clamp_coords', True):
    xbound = self.view_transformers.grid_conf['xbound']  # e.g., [-48, 48, 0.5]
    ybound = self.view_transformers.grid_conf['ybound']  # e.g., [-32, 32, 0.5]
    NX = int((xbound[1] - xbound[0]) / xbound[2])  # 192
    NY = int((ybound[1] - ybound[0]) / ybound[2])  # 128
    pred_line_seq[0::clause_length] = pred_line_seq[0::clause_length].clamp(0, NX - 1)
    pred_line_seq[1::clause_length] = pred_line_seq[1::clause_length].clamp(0, NY - 1)
```

**约束2: 类别裁剪** (lines 994-995)
```python
if self.inference_constraints.get('clamp_classes', True):
    pred_line_seq[2::clause_length] = pred_line_seq[2::clause_length].clamp(0, self.num_classes - 1)
    # 确保label ∈ [0, 3]
```

**约束3: 系数裁剪** (lines 1001-1004)
```python
if self.inference_constraints.get('clamp_coeffs', True):
    if self.coeff_range is not None and self.coeff_range > 0:
        for k in range(4, clause_length):
            pred_line_seq[k::clause_length] = pred_line_seq[k::clause_length].clamp(0, self.coeff_range - 1)
```

**约束4: DAG拓扑约束** (lines 1025-1026)
```python
if self.inference_constraints.get('clamp_connect', True):
    conn_idx = max(0, min(conn_idx, i - 1))  # 确保 connect ∈ [0, i-1]
```

**约束5: Lineal语义约束** (lines 1031-1033)
```python
if self.inference_constraints.get('force_lineal_prev', True):
    if lbl == 1:  # Lineal = "沿当前路径继续"
        conn_idx = i - 1  # 强制连接到前一个节点
```

#### 6.3 Decoder层面的Slot词汇约束 (ar_rntr_head.py, lines 349-394)

```python
def _apply_slot_constraints_step(self, step_logits, t, clause_length):
    """Apply slot-wise legal vocabulary constraints on current-step logits."""
    slot = (t - 1) % clause_length
    
    if slot == 2:  # label slot
        # 只允许200-203（Ancestor/Lineal/Offshoot/Clone）
        mask = torch.ones(V, dtype=torch.bool)
        mask[200:204] = False
        step_logits = step_logits.masked_fill(mask, float('-inf'))
    
    elif slot == 3:  # connect slot
        # 只允许250-(250+i-1)（当前节点的前序节点）
        i = (t - 1) // clause_length
        upper = max(0, i - 1)
        mask = torch.ones(V, dtype=torch.bool)
        mask[250:250+upper+1] = False
        step_logits = step_logits.masked_fill(mask, float('-inf'))
    
    elif slot >= 4:  # coeff slots
        # 只允许350-569（Bezier系数范围）
        mask = torch.ones(V, dtype=torch.bool)
        mask[350:570] = False
        step_logits = step_logits.masked_fill(mask, float('-inf'))
    
    return step_logits
```

### 约束必要性分析

| 约束类型 | 论文是否提及 | 必要性 | 理由 |
|----------|-------------|--------|------|
| 坐标裁剪 | ❌ | **REQUIRED** | 防止index out of bounds错误 |
| 类别裁剪 | ❌ | **REQUIRED** | 防止非法类别索引 |
| 系数裁剪 | ❌ | **REQUIRED** | 保证Bezier系数在训练值域内 |
| DAG约束 | ❌ | **RECOMMENDED** | 确保生成的图是有效DAG（无环） |
| Lineal语义 | ❌ | **OPTIONAL** | 对齐类别语义定义，提升拓扑质量 |
| Slot词汇约束 | ❌ | **RECOMMENDED** | 减少非法token，加速收敛 |

**对齐结论**: ⚠️ **代码显著增强，论文未详述**

**影响分析**:
1. **工程必要性**: 约束1-3是工程实践必需的（防止崩溃），但论文未说明
2. **拓扑质量提升**: 约束4-5显著提升生成图的拓扑有效性
3. **可复现性风险**: 这些约束对最终性能有影响，但论文未提供消融实验
4. **配置灵活性**: 代码支持通过config禁用约束，便于消融研究

**建议**:
1. 在论文Appendix补充"推理约束与后处理"章节
2. 提供消融实验量化各约束的贡献
3. 说明哪些约束是"必需"vs"推荐"

---

## 7. TIT训练策略对齐检查 ❌ (50%)

### 论文描述 (Section 3.11: Topology-Inherited Training)

引用原文:
> "TIT decomposes the original objective function into a three-stage optimization process:
> 
> **Stage 1**: Train RNTR on LiDAR BEV  
> $$\min_{\theta_g} \mathbb{E}_{(x_L,y) \sim D_L} \mathcal{L}_{\text{CE}}(g(f_L(x_L)), y)$$
> 
> **Stage 2**: Distill camera BEV from LiDAR BEV  
> $$\min_{\theta_f} \mathbb{E}_{(x, x_L) \sim D} \| f_I(x) - f_L(x_L) \|_1$$
> 
> **Stage 3**: Joint fine-tuning"

论文强调TIT是**关键创新**之一，用于解决BEV感知误差传播问题。

### 代码实现 (ar_rntr.py)

#### 7.1 TIT配置 (lines 191-201)
```python
self.tit_cfg = tit_cfg or {}
self.tit_enable = bool(self.tit_cfg.get('enable', False))  # ❌ 默认关闭
self.tit_k = int(self.tit_cfg.get('k', 4))                 # KNN邻居数
self.tit_alpha = float(self.tit_cfg.get('alpha', 0.3))     # 平滑权重
self.tit_weight = float(self.tit_cfg.get('weight', 1.0))   # 损失权重

self.tit_distill = bool(self.tit_cfg.get('distill', False))      # Stage-2开关
self.tit_distill_only = bool(self.tit_cfg.get('distill_only', False))
self.tit_distill_weight = float(self.tit_cfg.get('distill_weight', 1.0))

self.use_bev_teacher_input = bool(use_bev_teacher_input)  # Stage-1开关
```

#### 7.2 Stage 1: LiDAR BEV输入 (lines 376-388)
```python
def extract_feat(self, img, img_metas):
    # Stage-1 bypass: 使用teacher BEV直接作为输入
    if self.use_bev_teacher_input:
        if 'bev_teacher' not in img_metas[0]:
            raise ValueError("use_bev_teacher_input=True but 'bev_teacher' not found")
        bev_list = []
        for m in img_metas:
            bev_np = m.get('bev_teacher', None)
            bev_t = torch.from_numpy(bev_np).to(device).float()
            bev_list.append(bev_t)
        bev_feats = torch.stack(bev_list, dim=0)  # [B, C, H, W]
        return bev_feats
    # Normal LSS path
    return self.view_transformers(img_feats, img_metas)
```

#### 7.3 Stage 2: BEV蒸馏 (lines 881-895)
```python
if hasattr(self, 'tit_distill') and self.tit_distill:
    if 'bev_teacher' not in img_metas[0]:
        raise ValueError("tit_distill=True but 'bev_teacher' not found")
    teacher_list = []
    for m in img_metas:
        bev_np = m.get('bev_teacher', None)
        teacher_list.append(torch.from_numpy(bev_np).to(bev_feats.device).float())
    bev_teacher = torch.stack(teacher_list, dim=0)
    
    if bev_teacher.shape[-2:] != bev_feats.shape[-2:]:
        bev_teacher = F.interpolate(bev_teacher, size=bev_feats.shape[-2:], ...)
    
    losses['loss_distill'] = F.l1_loss(bev_feats, bev_teacher) * self.tit_distill_weight
    
    if self.tit_distill_only:
        return losses  # ⚠️ 仅蒸馏，不计算RNTR loss
```

#### 7.4 KNN软监督 (lines 645-684)
```python
if self.tit_enable and mask_conn.sum().item() > 1:
    try:
        logits_conn_valid = outputs_conn_i[mask_conn]  # [P, V]
        labels_conn_valid = inputs_conn_i[mask_conn]   # [P]
        
        # 构建KNN图
        gt_coords_sample = torch.tensor(gt_lines_coords[bi]).float().view(-1, 2)
        dmat = torch.cdist(gt_coords_sample, gt_coords_sample, p=2)  # [N, N]
        diag_idx = torch.arange(dmat.shape[0])
        dmat[diag_idx, diag_idx] = 1e6  # 避免自连接
        
        K = min(self.tit_k, dmat.shape[0] - 1)
        log_probs = F.log_softmax(logits_conn_valid, dim=-1)
        
        for r in range(P):
            gt_token = int(labels_conn_valid[r].item())
            gt_j = gt_token - self.connect_start
            
            # 找到KNN邻居
            neigh_idx = torch.topk(dmat[gt_j], k=K, largest=False).indices.tolist()
            neigh_idx = [n for n in neigh_idx if n != gt_j]
            
            # 构建软目标: (1-alpha)在GT + alpha平分给邻居
            q = torch.zeros(V)
            q[self.connect_start + gt_j] = 1.0 - self.tit_alpha
            if len(neigh_idx) > 0 and self.tit_alpha > 0:
                share = self.tit_alpha / len(neigh_idx)
                for n in neigh_idx:
                    q[self.connect_start + int(n)] += share
            
            # KL散度损失
            tit_loss_total += F.kl_div(log_probs[r], q, reduction='batchmean')
            tit_count += 1
    except Exception:
        pass  # Never break training
```

### 对齐分析

| TIT组件 | 论文描述 | 代码实现 | 对齐度 | 问题 |
|---------|---------|---------|--------|------|
| Stage 1: LiDAR BEV训练 | ✅ 核心步骤 | `use_bev_teacher_input=True` | ✅ | **默认False** |
| Stage 2: L1蒸馏 | ✅ 核心步骤 | `F.l1_loss(bev_feats, bev_teacher)` | ✅ | **默认关闭** |
| Stage 3: Joint FT | ✅ 核心步骤 | `tit_distill_only=False` | ✅ | 实现正确 |
| KNN软监督 | ⚠️ **未明确公式** | ✅ KNN+KL散度 | ⚠️ | 论文未详述 |
| **默认启用** | ✅ **论文主线方法** | ❌ **False** | ❌ | **关键差异** |
| **数据流** | 需要LiDAR BEV | 需要`bev_teacher`字段 | ⚠️ | **未说明如何获取** |

**关键问题**:

1. **TIT默认未启用** ❌
   - 代码: `tit_enable=False`, `use_bev_teacher_input=False`
   - 论文: 强调TIT是关键创新，用于提升性能
   - **影响**: 默认配置无法复现论文的TIT实验结果

2. **KNN软监督公式未明确** ⚠️
   - 论文: 仅提及"distance-aware smoothing"和"topology-inherited training"
   - 代码: 实现了KNN+KL散度的具体算法:
     ```
     soft_target[gt] = 1.0 - alpha
     soft_target[neighbors] = alpha / K
     loss_tit = KL(log_probs, soft_target)
     ```
   - **问题**: 无法验证此实现是否为论文原意

3. **数据准备流程缺失** ⚠️
   - TIT需要`bev_teacher`字段（LiDAR BEV特征）
   - 标准数据加载流程未包含此字段
   - **影响**: 用户无法直接启用TIT

**结论**: ❌ **部分对齐（50%），存在关键差异**

**建议**:
1. **论文Revision**:
   - 补充KNN软监督的完整数学公式
   - 说明如何生成`bev_teacher`（LiDAR BEV特征）
   - 提供TIT的数据准备pipeline

2. **代码改进**:
   - 提供TIT专用配置文件（启用TIT的完整示例）
   - 补充TIT数据准备脚本
   - 在README说明TIT的使用方法

---
