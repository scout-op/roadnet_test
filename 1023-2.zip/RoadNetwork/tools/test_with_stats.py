#!/usr/bin/env python
"""Test script with prediction distribution statistics.

Usage:
    python tools/test_with_stats.py CONFIG CHECKPOINT --work-dir WORK_DIR [other options]
"""

import argparse
import os
import os.path as osp
import sys

from mmengine.config import Config, DictAction
from mmengine.runner import Runner
from mmengine.hooks import Hook

# Add project path
sys.path.insert(0, osp.join(osp.dirname(__file__), '..'))


def parse_args():
    parser = argparse.ArgumentParser(description='Test with prediction statistics')
    parser.add_argument('config', help='test config file path')
    parser.add_argument('checkpoint', help='checkpoint file')
    parser.add_argument('--work-dir', help='the directory to save logs and models')
    parser.add_argument(
        '--cfg-options',
        nargs='+',
        action=DictAction,
        help='override some settings in the used config, the key-value pair '
        'in xxx=yyy format will be merged into config file.')
    parser.add_argument(
        '--launcher',
        choices=['none', 'pytorch', 'slurm', 'mpi'],
        default='none',
        help='job launcher')
    parser.add_argument('--local_rank', type=int, default=0)
    args = parser.parse_args()
    if 'LOCAL_RANK' not in os.environ:
        os.environ['LOCAL_RANK'] = str(args.local_rank)
    return args


class TestHook(Hook):
    """Hook to print prediction statistics after testing.
    
    Inherits from mmengine.hooks.Hook to properly integrate with Runner.
    """
    
    priority = 'VERY_LOW'  # Run last
    
    def before_test_epoch(self, runner):
        """Called before test epoch starts. Initialize statistics."""
        try:
            model = runner.model
            if hasattr(model, 'module'):
                model = model.module
            
            if hasattr(model, 'pts_bbox_head'):
                head = model.pts_bbox_head
                # Initialize empty statistics lists
                head._pred_label_stats = []
                head._pred_connect_stats = []
                print("\n✅ Initialized prediction statistics collection")
        except Exception as e:
            print(f"⚠️  Warning: Could not initialize statistics: {e}")
    
    def after_test_epoch(self, runner, metrics=None):
        """Called after test epoch. Print accumulated statistics."""
        print("\n" + "="*80)
        print("🔍 Printing Prediction Distribution Statistics...")
        print("="*80)
        
        # Try to access the model's head
        try:
            model = runner.model
            if hasattr(model, 'module'):
                model = model.module
            
            if hasattr(model, 'pts_bbox_head'):
                head = model.pts_bbox_head
                if hasattr(head, 'print_prediction_distribution'):
                    head.print_prediction_distribution()
                else:
                    print("⚠️  Model head doesn't have print_prediction_distribution method")
            else:
                print("⚠️  Model doesn't have pts_bbox_head")
        except Exception as e:
            print(f"❌ Error printing stats: {e}")
            import traceback
            traceback.print_exc()


def main():
    args = parse_args()

    # Load config
    cfg = Config.fromfile(args.config)
    
    # Override config with command line options
    if args.cfg_options is not None:
        cfg.merge_from_dict(args.cfg_options)
    
    # Set work dir
    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    elif cfg.get('work_dir', None) is None:
        cfg.work_dir = osp.join('./work_dirs',
                                osp.splitext(osp.basename(args.config))[0])
    
    # Force test mode
    cfg.test_dataloader.dataset.test_mode = True
    
    # Build runner
    runner = Runner.from_cfg(cfg)
    
    # Load checkpoint
    runner.load_checkpoint(args.checkpoint)
    
    # Register custom hook
    runner.register_hook(TestHook(), priority='VERY_LOW')
    
    print("\n" + "="*80)
    print("🚀 Starting testing with prediction statistics...")
    print(f"   Config: {args.config}")
    print(f"   Checkpoint: {args.checkpoint}")
    print(f"   Work dir: {cfg.work_dir}")
    print("="*80 + "\n")
    
    # Run test
    runner.test()
    
    print("\n✅ Testing completed!\n")


if __name__ == '__main__':
    main()
