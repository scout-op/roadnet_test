"""
AR-RNTR 验证配置 - 启用可视化

基于: lss_ar_rntr_changeloss_test_fp16_torch2.py
用途: 验证时生成拓扑图可视化，用于调试 Reachable Recall

使用方法:
    python tools/test.py \
        configs/rntr_ar_roadseq/lss_ar_rntr_val_with_vis.py \
        work_dirs/lss_ar_rntr_changeloss_test_fp16_torch2/epoch_60.pth \
        --launcher pytorch

输出:
    - 评测指标: 终端输出
    - 可视化图像: vis/val_epoch60_debug/*.png
"""

_base_ = './lss_ar_rntr_changeloss_test_fp16_torch2.py'

# 启用可视化（仅修改这一项）
model = dict(
    vis_cfg=dict(
        path='val_epoch60_debug'  # 可视化保存到 vis/val_epoch60_debug/
    ),
)

# 可选：只验证少量样本以快速调试
# val_dataloader = dict(
#     batch_size=1,
#     dataset=dict(
#         # 只验证前20个样本
#         indices=range(20),
#     )
# )
