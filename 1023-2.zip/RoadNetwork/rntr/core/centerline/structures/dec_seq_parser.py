# ------------------------------------------------------------------------
# Decoupled Sequence Parser
# Parse flattened decoupled sequence back to graph structure for evaluation
# ------------------------------------------------------------------------
import numpy as np


def parse_dec_seq_to_graph(dec_seq, n_control, epsilon,
                           CONNECT_START=250, COEFF_START=350,
                           TOK_START=574, TOK_EOV=569, TOK_SPLIT=567, TOK_EOE=568):
    """Parse decoupled sequence back to node list for Reachability evaluation.
    
    Decoupled sequence format:
        [START] + (x, y)*N + <EOV> + 
        [CONNECT+child_idx, COEFF_START+cx, COEFF_START+cy]*K + <Split> ... + <EOE>
    
    Args:
        dec_seq: numpy array or list, flattened token sequence
        n_control: number of Bezier control points (default 3)
        epsilon: tolerance for coordinate matching (unused, kept for API compatibility)
        CONNECT_START: base token index for connect tokens
        COEFF_START: base token index for coefficient tokens
        TOK_START: START token ID
        TOK_EOV: End-of-Vertex token ID
        TOK_SPLIT: edge group separator token ID
        TOK_EOE: End-of-Edge token ID
    
    Returns:
        node_list: list[dict] compatible with seq2bznodelist() output, where each
                   dict has keys: 'sque_index', 'sque_type', 'fork_from',
                   'merge_with', 'coord', 'coeff'.
    """
    dec_seq = np.array(dec_seq, dtype=np.int64)
    
    # Safety: sequence too short
    if len(dec_seq) < 3:  # at least [START, <EOV>, <EOE>]
        return []
    
    # 1. Find EOV position to split vertex and edge sequences
    eov_idx = np.where(dec_seq == TOK_EOV)[0]
    if len(eov_idx) == 0:
        # Invalid sequence: no EOV found
        return []
    eov_pos = int(eov_idx[0])
    
    # 2. Parse vertex sequence (skip START token at position 0)
    vertex_seq = dec_seq[1:eov_pos]
    if len(vertex_seq) % 2 != 0:
        # Truncate to even length
        vertex_seq = vertex_seq[:len(vertex_seq)//2*2]
    
    num_vertices = len(vertex_seq) // 2
    if num_vertices == 0:
        return []
    
    vertices = []
    for i in range(num_vertices):
        x = int(vertex_seq[2*i])
        y = int(vertex_seq[2*i + 1])
        vertices.append((x, y))
    
    # 3. Find EOE position
    eoe_idx = np.where(dec_seq == TOK_EOE)[0]
    if len(eoe_idx) == 0:
        edge_end = len(dec_seq)
    else:
        edge_end = int(eoe_idx[0])
    
    # 4. Parse edge sequence
    edge_seq = dec_seq[eov_pos + 1:edge_end]
    
    # Build adjacency: parent_idx -> [(child_idx, coeff)]
    # where coeff is (cx, cy) in grid coordinates
    adjacency = {}
    current_parent = 0
    i = 0
    
    while i < len(edge_seq) and current_parent < num_vertices:
        if edge_seq[i] == TOK_SPLIT:
            # End of current parent's edges, move to next parent
            current_parent += 1
            i += 1
            continue
        
        # Parse edge triplet: [CONNECT+child_idx, COEFF_START+cx, COEFF_START+cy]
        if i + 2 < len(edge_seq):
            connect_token = int(edge_seq[i])
            cx_token = int(edge_seq[i + 1])
            cy_token = int(edge_seq[i + 2])
            
            # Decode child index
            if connect_token >= CONNECT_START:
                child_idx = connect_token - CONNECT_START
                
                # Decode coefficients
                cx = cx_token - COEFF_START if cx_token >= COEFF_START else 0
                cy = cy_token - COEFF_START if cy_token >= COEFF_START else 0
                
                # Validate child_idx
                if 0 <= child_idx < num_vertices:
                    if current_parent not in adjacency:
                        adjacency[current_parent] = []
                    adjacency[current_parent].append((child_idx, (cx, cy)))
            
            i += 3
        else:
            # Incomplete edge triplet, skip
            break
    
    # 5. Build reverse adjacency: child -> list of (parent, coeff)
    parents_map = {}
    for p, edges in adjacency.items():
        for (c, coeff) in edges:
            parents_map.setdefault(c, []).append((p, coeff))

    # 6. Convert to list[dict] compatible with eval utilities
    node_list = []
    for idx, (x, y) in enumerate(vertices):
        node = {
            'sque_index': idx,
            'sque_type': None,
            'fork_from': None,
            'merge_with': None,
            'coord': [int(x), int(y)],
            'coeff': []
        }

        if idx == 0:
            node['sque_type'] = 'start'
            node_list.append(node)
            continue

        # Prefer continue: parent idx-1 -> idx
        cont_coeff = None
        if (idx - 1) in adjacency:
            for (c, coeff) in adjacency[idx - 1]:
                if c == idx:
                    cont_coeff = coeff
                    break

        if cont_coeff is not None:
            node['sque_type'] = 'continue'
            node['coeff'] = np.array(cont_coeff, dtype=np.int64)
            node_list.append(node)
            continue

        # Then try fork: some parent p < idx -> idx
        fork_parent = None
        fork_coeff = None
        if idx in parents_map:
            # choose the nearest previous parent (max p < idx)
            candidates = [(p, coeff) for (p, coeff) in parents_map[idx] if p < idx]
            if len(candidates) > 0:
                fork_parent, fork_coeff = max(candidates, key=lambda t: t[0])

        if fork_parent is not None:
            node['sque_type'] = 'fork'
            node['fork_from'] = int(fork_parent)
            node['coeff'] = np.array(fork_coeff, dtype=np.int64)
            node_list.append(node)
            continue

        # Finally try merge: idx -> some child j < idx
        merge_with = None
        merge_coeff = None
        if idx in adjacency:
            earlier_children = [(c, coeff) for (c, coeff) in adjacency[idx] if c < idx]
            if len(earlier_children) > 0:
                # choose the nearest earlier child (max c < idx)
                merge_with, merge_coeff = max(earlier_children, key=lambda t: t[0])

        if merge_with is not None:
            node['sque_type'] = 'merge'
            node['merge_with'] = int(merge_with)
            node['coeff'] = np.array(merge_coeff, dtype=np.int64)
            node_list.append(node)
            continue

        # Fallback: mark as continue with zero coeff to keep connectivity
        node['sque_type'] = 'continue'
        node['coeff'] = np.array([0, 0], dtype=np.int64)
        node_list.append(node)

    return node_list


def dec_seq_to_bznodelist(dec_seq, n_control, epsilon):
    """Wrapper function with same signature as seq2bznodelist for compatibility.
    
    This is a convenience wrapper that matches the API of existing seq2bznodelist
    functions used in the codebase.
    """
    return parse_dec_seq_to_graph(
        dec_seq, 
        n_control=n_control, 
        epsilon=epsilon,
        CONNECT_START=250,
        COEFF_START=350,
        TOK_START=574,
        TOK_EOV=569,
        TOK_SPLIT=567,
        TOK_EOE=568
    )
