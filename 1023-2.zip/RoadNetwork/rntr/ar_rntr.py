import os
import cv2
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmengine.structures import InstanceData
import numpy as np
import time
import torch.distributed as dist

# Optional: SwanLab real-time experiment tracking
try:
    import swanlab  # pip install swanlab
    _SWANLAB_AVAILABLE = True
except Exception:
    swanlab = None
    _SWANLAB_AVAILABLE = False

from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector
from mmdet3d.registry import MODELS
from mmdet3d.structures.ops import bbox3d2result
from .grid_mask import GridMask
from .LiftSplatShoot import LiftSplatShootEgo
from .core import seq2nodelist, seq2bznodelist, seq2plbznodelist, av2seq2bznodelist
from .debug_logger_hook import get_debug_logger
from .topology_visualizer import render_topology_graph

def debug_print(*args, **kwargs):
    """Print to console and debug file simultaneously."""
    # Print to console
    print(*args, **kwargs)
    
    # Also write to debug file if available
    debug_logger = get_debug_logger()
    if debug_logger and debug_logger.is_active():
        # Convert args to string
        import io
        buffer = io.StringIO()
        print(*args, **kwargs, file=buffer)
        message = buffer.getvalue()
        debug_logger.write(message, flush=False)

@MODELS.register_module()
class AR_RNTR(MVXTwoStageDetector):
    """Petr3D. nan for all token except label"""
    def __init__(self,
                 use_grid_mask=False,
                 pts_voxel_layer=None,
                 pts_middle_encoder=None,
                 pts_fusion_layer=None,
                 img_backbone=None,
                 pts_backbone=None,
                 img_neck=None,
                 pts_neck=None,
                 lss_cfg=None,
                 grid_conf=None,
                 bz_grid_conf=None,
                 data_aug_conf=None,
                 pts_bbox_head=None,
                 img_roi_head=None,
                 img_rpn_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 vis_cfg=None,
                 freeze_pretrain=True,
                 bev_scale=1.0,
                 epsilon=2,
                 max_box_num=100,
                 num_center_classes=574,
                 init_cfg=None,
                 data_preprocessor=None,
                 # SwanLab optional params
                 swanlab_enable=False,
                 swanlab_project='RoadNet',
                 swanlab_run_name=None,
                 swanlab_log_interval=50,
                 swanlab_image_interval=200,
                 tit_cfg=None,
                 # TIT options
                 use_bev_teacher_input=False,
                 # Inference constraints configuration
                 inference_constraints=None,
                 ):
        super(AR_RNTR, self).__init__(pts_voxel_layer, pts_middle_encoder,
                                                        pts_fusion_layer, img_backbone, pts_backbone,
                                                        img_neck, pts_neck, pts_bbox_head, img_roi_head,
                                                        img_rpn_head, train_cfg, test_cfg, init_cfg,
                                                        data_preprocessor)
        self.grid_mask = GridMask(True, True, rotate=1, offset=False, ratio=0.5, mode=1, prob=0.7)
        self.use_grid_mask = use_grid_mask
        # data_aug_conf = {
        #     'final_dim': (128, 352),
        #     'H': 900, 'W': 1600,
        # }
        # self.up = Up(512, 256, scale_factor=2)
        # view_transformers = []
        # view_transformers.append(
        #     LiftSplatShoot(grid_conf, data_aug_conf, downsample=16, d_in=256, d_out=256, return_bev=True))
        # self.view_transformers = nn.ModuleList(view_transformers)
        # self.view_transformers = LiftSplatShoot(grid_conf, data_aug_conf, downsample=16, d_in=256, d_out=256, return_bev=True)
        self.view_transformers = LiftSplatShootEgo(grid_conf, data_aug_conf, return_bev=True, **lss_cfg)
        self.downsample = lss_cfg['downsample']
        self.final_dim = data_aug_conf['final_dim']
        # Keep grid configs
        self.grid_conf = grid_conf
        self.bz_grid_conf = bz_grid_conf if bz_grid_conf is not None else grid_conf

        # FIX: Read from config instead of hardcoding
        self.num_center_classes = int(num_center_classes)
        self.box_range = 200
        # Align coeff_range to Bezier grid resolution (fallback to 200)
        try:
            bx = self.bz_grid_conf.get('xbound', None) if isinstance(self.bz_grid_conf, dict) else None
            by = self.bz_grid_conf.get('ybound', None) if isinstance(self.bz_grid_conf, dict) else None
            if bx is None or by is None:
                bx = grid_conf['xbound'] if isinstance(grid_conf, dict) else None
                by = grid_conf['ybound'] if isinstance(grid_conf, dict) else None
            if bx is not None and by is not None:
                rx = int(np.floor((bx[1] - bx[0]) / bx[2]))
                ry = int(np.floor((by[1] - by[0]) / by[2]))
                self.coeff_range = int(max(1, min(rx, ry)))
            else:
                self.coeff_range = 200
            if self.coeff_range <= 0:
                self.coeff_range = 200
        except Exception:
            self.coeff_range = 200
        self.num_classes=4
        self.category_start = 200
        self.connect_start = 250
        self.coeff_start = 350
        self.no_known = 573  # n/a (aligned with paper Table)
        self.start = 572     # Start token (aligned with paper Table)
        self.end = 571       # EOS token (aligned with paper Table)
        self.noise_connect = 570  # noise token for connect slot
        self.noise_label = 570    # noise token for label slot (same as noise_coeff)
        self.noise_coeff = 570    # noise category token (aligned with paper Table)
        self.vis_cfg = vis_cfg
        self.bev_scale = bev_scale
        self.epsilon = epsilon
        self.max_box_num = max_box_num
        
        # Inference constraints configuration (configurable via config file)
        # Default values ensure backward compatibility
        default_constraints = dict(
            clamp_coords=True,       # REQUIRED: prevent index out of bounds
            clamp_classes=True,      # REQUIRED: prevent invalid class indices
            clamp_coeffs=True,       # REQUIRED: prevent invalid coefficient values
            clamp_connect=True,      # RECOMMENDED: enforce DAG topology (connect < i)
            force_lineal_prev=True,  # OPTIONAL: force Lineal to connect to i-1
        )
        if inference_constraints is None:
            inference_constraints = {}
        self.inference_constraints = {**default_constraints, **inference_constraints}
        # Propagate slot constants to head for constrained decoding
        try:
            if hasattr(self, 'pts_bbox_head') and self.pts_bbox_head is not None:
                if hasattr(self.pts_bbox_head, 'category_start'):
                    self.pts_bbox_head.category_start = int(self.category_start)
                if hasattr(self.pts_bbox_head, 'connect_start'):
                    self.pts_bbox_head.connect_start = int(self.connect_start)
                if hasattr(self.pts_bbox_head, 'coeff_start'):
                    self.pts_bbox_head.coeff_start = int(self.coeff_start)
                if hasattr(self.pts_bbox_head, 'coeff_range'):
                    self.pts_bbox_head.coeff_range = int(self.coeff_range)
                if hasattr(self.pts_bbox_head, 'label_num_classes'):
                    self.pts_bbox_head.label_num_classes = int(self.num_classes)
        except Exception:
            pass
        
        # FIX: Verify consistency with head's embedding size
        try:
            if hasattr(self, 'pts_bbox_head') and self.pts_bbox_head is not None:
                if hasattr(self.pts_bbox_head, 'embedding'):
                    actual_vocab_size = self.pts_bbox_head.embedding.num_embeddings
                    if actual_vocab_size != self.num_center_classes:
                        import logging
                        logger = logging.getLogger(__name__)
                        logger.warning(
                            f"[AR-RNTR] Vocab size mismatch detected! "
                            f"AR_RNTR.num_center_classes={self.num_center_classes} but "
                            f"Head.embedding.num_embeddings={actual_vocab_size}. "
                            f"Using Head's size: {actual_vocab_size}"
                        )
                        self.num_center_classes = int(actual_vocab_size)
        except Exception as e:
            pass
        
        # Topology-Inherited Training (TIT) config (disabled by default)
        self.tit_cfg = tit_cfg or {}
        self.tit_enable = bool(self.tit_cfg.get('enable', False))
        self.tit_k = int(self.tit_cfg.get('k', 4))              # top-K nearest neighbors
        self.tit_alpha = float(self.tit_cfg.get('alpha', 0.3))  # neighbor smoothing weight
        self.tit_weight = float(self.tit_cfg.get('weight', 1.0))
        # Distillation (stage-2) controls
        self.tit_distill = bool(self.tit_cfg.get('distill', False))
        self.tit_distill_only = bool(self.tit_cfg.get('distill_only', False))
        self.tit_distill_weight = float(self.tit_cfg.get('distill_weight', 1.0))
        # Stage-1: use LiDAR BEV (teacher) as direct BEV input
        self.use_bev_teacher_input = bool(use_bev_teacher_input)

        # SwanLab runtime config (only active when enabled and package available)
        self.swanlab_enable = bool(swanlab_enable) or (os.getenv('SWANLAB_ENABLE', '0').lower() in ('1', 'true', 'yes'))
        self.swanlab_project = swanlab_project
        self.swanlab_run_name = swanlab_run_name
        self.swanlab_log_interval = max(1, int(swanlab_log_interval))
        self.swanlab_image_interval = max(1, int(swanlab_image_interval))
        self._swanlab_ready = False
        self._global_step = 0
        self._swanlab_img_step = 0

        if freeze_pretrain:
            self.freeze_pretrain()
    
    def freeze_pretrain(self):
        for m in self.img_backbone.parameters():
            m.requires_grad=False
        for m in self.img_neck.parameters():
            m.requires_grad=False
        for m in self.view_transformers.parameters():
            m.requires_grad=False

    # ---------------------- SwanLab utils ----------------------
    def _is_main_process(self):
        try:
            if not dist.is_available() or not dist.is_initialized():
                return True
            return dist.get_rank() == 0
        except Exception:
            return True

    def _init_swanlab(self, cfg: dict = None):
        if self._swanlab_ready:
            return
        if not self.swanlab_enable or not _SWANLAB_AVAILABLE:
            return
        if not self._is_main_process():
            return
        run_name = self.swanlab_run_name or f'AR_RNTR_{int(time.time())}'
        try:
            swanlab.init(project=self.swanlab_project,
                         experiment_name=run_name,
                         config=cfg or {})
            self._swanlab_ready = True
        except Exception:
            # Fail-safe: do not crash training if init fails
            self._swanlab_ready = False

    @staticmethod
    def _to_float(value):
        try:
            if isinstance(value, (list, tuple)):
                vals = []
                for v in value:
                    if torch.is_tensor(v):
                        vals.append(v.detach().float().mean().item())
                    else:
                        try:
                            vals.append(float(v))
                        except Exception:
                            pass
                return sum(vals) / len(vals) if len(vals) > 0 else None
            if torch.is_tensor(value):
                return value.detach().float().mean().item()
            return float(value)
        except Exception:
            return None

    def _render_bev_overlay(self, gt_coords_sample, pred_tokens_sample, clause_length, canvas_size=200):
        try:
            # Prepare canvas
            H = W = int(canvas_size)
            canvas = np.zeros((H, W, 3), dtype=np.uint8)
            # GT coords
            gt = np.array(gt_coords_sample, dtype=np.int32)
            if gt.ndim == 1:
                gt = gt.reshape(-1, 2)
            # Draw GT points (green)
            for (x, y) in gt:
                if 0 <= x < W and 0 <= y < H:
                    cv2.circle(canvas, (int(x), int(y)), 1, (0, 255, 0), -1)
            # Pred coords from tokens
            pred_xy = []
            T = int(pred_tokens_sample.shape[0])
            max_nodes = T // clause_length
            for i in range(max_nodes):
                idx_x = i * clause_length + 0
                idx_y = i * clause_length + 1
                if idx_y >= T:
                    break
                x = int(pred_tokens_sample[idx_x].item())
                y = int(pred_tokens_sample[idx_y].item())
                x = max(0, min(W - 1, x))
                y = max(0, min(H - 1, y))
                pred_xy.append((x, y))
            # Draw Pred points (red)
            for (x, y) in pred_xy:
                cv2.circle(canvas, (x, y), 1, (0, 0, 255), -1)
            # Put legend
            cv2.rectangle(canvas, (0, 0), (110, 28), (32, 32, 32), -1)
            cv2.putText(canvas, 'GT: green', (4, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)
            cv2.putText(canvas, 'Pred: red', (4, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 255), 1, cv2.LINE_AA)
            return canvas
        except Exception:
            return None

    def _swanlab_log_image(self, name: str, img: np.ndarray, step: int):
        if not (self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process() and self._swanlab_ready):
            return
        try:
            # Convert BGR->RGB
            rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            # Try different SwanLab image logging APIs for compatibility
            if hasattr(swanlab, 'Image'):
                try:
                    im = swanlab.Image(rgb)
                    swanlab.log({name: im}, step=step)
                    return
                except Exception:
                    pass
            if hasattr(swanlab, 'log_image'):
                try:
                    swanlab.log_image(name, rgb, step=step)
                    return
                except Exception:
                    pass
            # Fallback: save temp file and log its path as text
            tmp_dir = '/tmp/swanlab_vis'
            os.makedirs(tmp_dir, exist_ok=True)
            tmp_path = os.path.join(tmp_dir, f'{name.replace("/", "_")}_{step}.png')
            cv2.imwrite(tmp_path, img)
            try:
                swanlab.log({f'{name}_path': tmp_path}, step=step)
            except Exception:
                pass
        except Exception:
            pass

    def extract_img_feat(self, img, img_metas):
        """Extract features of images."""
        # print(img[0].size())
        if isinstance(img, list):
            img = torch.stack(img, dim=0)

        B = img.size(0)
        if img is not None:
            input_shape = img.shape[-2:]
            # update real input shape of each single img
            for img_meta in img_metas:
                img_meta.update(input_shape=input_shape)
            if img.dim() == 5:
                if img.size(0) == 1 and img.size(1) != 1:
                    img.squeeze_()
                else:
                    B, N, C, H, W = img.size()
                    img = img.view(B * N, C, H, W)
            if self.use_grid_mask:
                img = self.grid_mask(img)
            img_feats = self.img_backbone(img)
            if isinstance(img_feats, dict):
                img_feats = list(img_feats.values())
        else:
            return None
        if self.with_img_neck:
            img_feats = self.img_neck(img_feats)
        img_feats_reshaped = []
        for img_feat in img_feats:
            BN, C, H, W = img_feat.size()
            img_feats_reshaped.append(img_feat.view(B, int(BN / B), C, H, W))
        return img_feats_reshaped

    def extract_feat(self, img, img_metas):
        """Extract BEV features; optionally bypass with teacher BEV."""
        # Stage-1 bypass: use teacher BEV directly as input BEV
        if self.use_bev_teacher_input:
            if len(img_metas) == 0 or 'bev_teacher' not in img_metas[0]:
                raise ValueError("use_bev_teacher_input=True but 'bev_teacher' not found in img_metas")
            bev_list = []
            for m in img_metas:
                bev_np = m.get('bev_teacher', None)
                if bev_np is None:
                    bev_np = img_metas[0]['bev_teacher']
                # expect [C,H,W]
                bev_t = torch.from_numpy(bev_np).to(self.img_backbone.conv1.weight.device).float()
                bev_list.append(bev_t)
            bev_feats = torch.stack(bev_list, dim=0)  # [B,C,H,W]
            return bev_feats
        # Normal LSS path
        img_feats = self.extract_img_feat(img, img_metas)
        largest_feat_shape = img_feats[0].shape[3]
        down_level = int(np.log2(self.downsample // (self.final_dim[0] // largest_feat_shape)))
        bev_feats = self.view_transformers(img_feats[down_level], img_metas)
        return bev_feats

    def forward_pts_train(self,
                          bev_feats,
                          gt_lines_coords,
                          gt_lines_labels,
                          gt_lines_connects,
                          gt_lines_coeffs,
                          img_metas,
                          num_coeff,
                          current_epoch=None,  # 添加epoch参数
                          current_iter=None, ):
        """Forward function for point cloud branch.
        Args:
            pts_feats (list[torch.Tensor]): Features of point cloud branch
            gt_bboxes_3d (list[:obj:`BaseInstance3DBoxes`]): Ground truth
                boxes for each sample.
            gt_labels_3d (list[torch.Tensor]): Ground truth labels for
                boxes of each sampole
            img_metas (list[dict]): Meta information of samples.
            gt_bboxes_ignore (list[torch.Tensor], optional): Ground truth
                boxes to be ignored. Defaults to None.
        Returns:
            dict: Losses of each branch.
        """
        # ============= DEBUG 1: 输入 GT 数据检查 =============
        # 只在 rank 0 打印，避免分布式训练日志混乱
        if self._is_main_process():
            debug_print("\n" + "="*80)
            debug_print("[AR-RNTR DEBUG] Step 1: GT Input Data")
            debug_print("="*80)
            debug_print(f"Batch size: {len(gt_lines_coords)}")
            for bi in range(len(gt_lines_coords)):
                debug_print(f"  Sample {bi}: coords={len(gt_lines_coords[bi])}, labels={len(gt_lines_labels[bi])}, "
                      f"connects={len(gt_lines_connects[bi])}, coeffs={len(gt_lines_coeffs[bi])}")
                if len(gt_lines_coords[bi]) > 0:
                    debug_print(f"    First coord: {gt_lines_coords[bi][0]}, First label: {gt_lines_labels[bi][0]}")
            debug_print(f"num_coeff: {num_coeff}")
            debug_print(f"Token constants: start={self.start}, end={self.end}, no_known={self.no_known}, "
                  f"noise_label={self.noise_label}")
            
            # ============= 添加：GT Label 分布统计（每11个batch循环统计） =============
            # 初始化累积器
            if not hasattr(self, '_gt_label_accumulator'):
                self._gt_label_accumulator = []
                self._gt_label_batch_count = 0
                self._gt_label_total_batches = 0
            
            # 累积数据
            for bi in range(len(gt_lines_labels)):
                self._gt_label_accumulator.extend(gt_lines_labels[bi])
            self._gt_label_batch_count += 1
            self._gt_label_total_batches += 1
            
            # 每10个batch打印统计
            if self._gt_label_batch_count == 10:
                from collections import Counter
                label_counts = Counter(self._gt_label_accumulator)
                total = len(self._gt_label_accumulator)
                
                # 估算当前epoch（假设每epoch 11个batch）
                estimated_epoch = (self._gt_label_total_batches - 1) // 11 + 1
                
                debug_print("\n" + "="*80)
                debug_print(f"[GT LABEL DISTRIBUTION] Estimated Epoch {estimated_epoch} - Batches {self._gt_label_total_batches-9} to {self._gt_label_total_batches}")
                debug_print("="*80)
                debug_print(f"Total GT nodes (10 batches): {total}")
                debug_print(f"Average nodes per batch: {total / 10:.1f}")
                label_names = ["Ancestor", "Lineal", "Offshoot", "Clone"]
                for lbl in range(4):
                    count = label_counts.get(lbl, 0)
                    pct = 100.0 * count / total if total > 0 else 0
                    debug_print(f"  {label_names[lbl]:10s} (label={lbl}): {count:6d} ({pct:5.1f}%)")
                
                debug_print("\n  Analysis:")
                # 分析是否平衡
                if label_counts.get(1, 0) / total > 0.5:
                    debug_print(f"  ⚠️  Lineal占{100.0*label_counts.get(1,0)/total:.1f}% - 占主导地位")
                if label_counts.get(2, 0) / total < 0.1:
                    debug_print(f"  ⚠️  Offshoot仅占{100.0*label_counts.get(2,0)/total:.1f}% - 稀有类别")
                if label_counts.get(3, 0) / total < 0.2:
                    debug_print(f"  ⚠️  Clone仅占{100.0*label_counts.get(3,0)/total:.1f}% - 相对稀有")
                
                # 建议权重配置
                debug_print("\n  Recommended class_weight configuration:")
                if label_counts.get(2, 0) / total < 0.1:  # Offshoot稀有
                    debug_print(f"    label_class_weight[202] = 3.0  # Offshoot (currently {100.0*label_counts.get(2,0)/total:.1f}%)")
                if label_counts.get(1, 0) / total > 0.5:  # Lineal占多数
                    debug_print(f"    label_class_weight[201] = 1.0  # Lineal (currently {100.0*label_counts.get(1,0)/total:.1f}%, DON'T downweight!)")
                if label_counts.get(3, 0) / total < 0.2:  # Clone稀有
                    debug_print(f"    label_class_weight[203] = 1.5  # Clone (currently {100.0*label_counts.get(3,0)/total:.1f}%)")
                
                debug_print("="*80 + "\n")
            
            # 每11个batch重置（假设每epoch 11个batch）
            if self._gt_label_batch_count >= 11:
                self._gt_label_accumulator = []
                self._gt_label_batch_count = 0
        
        device = bev_feats[0].device
        box_labels = []
        input_seqs = []
        output_seqs = []
        max_box = max([len(target) for target in gt_lines_coords])
        num_box = max(max_box + 2, self.max_box_num)  # 100
        coeff_dim = num_coeff * 2
        for bi in range(len(gt_lines_coords)):
            box = torch.tensor(gt_lines_coords[bi], device=device).long()
            box = box.reshape(-1,2)
            label = torch.tensor(gt_lines_labels[bi], device=device).long() + self.category_start  # [8,1]
            label = label.reshape(-1,1)
            connect = torch.tensor(gt_lines_connects[bi], device=device).long() + self.connect_start  # [8,1]
            connect = connect.reshape(-1,1)
            coeff = torch.tensor(gt_lines_coeffs[bi], device=device).long() + self.coeff_start  # [8,1]
            coeff = coeff.reshape(-1, coeff_dim)
            box_label = torch.cat([box, label, connect, coeff], dim=-1)  # [8, 5]

            random_box = torch.rand(num_box - box_label.shape[0], 2).to(device)
            random_box = (random_box * (self.box_range - 1)).int()
            random_label = torch.randint(0, self.num_classes, (num_box - box_label.shape[0], 1)).to(label)
            random_label = random_label + self.category_start
            random_connect = torch.randint(0, num_box, (num_box - box_label.shape[0], 1)).to(label)
            random_connect = random_connect + self.connect_start
            random_coeff = torch.rand(num_box - box_label.shape[0], coeff_dim).to(device)
            random_coeff = (random_coeff * (self.coeff_range - 1)).int()
            random_coeff = random_coeff + self.coeff_start
            random_box_label = torch.cat([random_box, random_label.int(), random_connect.int(), random_coeff.int()], dim=-1)  # [92, 5]

            # decoder input sequence: [START] + [positive clauses + sampled negatives]
            input_seq = torch.cat([box_label, random_box_label], dim=0)
            input_seq = torch.cat([torch.ones(1).to(box_label) * self.start, input_seq.flatten()])  # [1 + num_box*clause_length]
            input_seqs.append(input_seq.unsqueeze(0))

            # Build negative clauses aligned to [x, y, label, connect, coeffs...]
            # - coords (x,y): fill with no_known to mask out from coord supervision
            # - label: use noise_label to provide hard negative for label classifier
            # - connect/coeff: fill with no_known
            output_na_x = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known
            output_na_y = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known
            output_noise_label = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.noise_label
            output_noise_connect = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known
            output_noise_coeff = torch.ones(num_box - box_label.shape[0], coeff_dim).to(input_seq) * self.no_known
            # Note: do NOT place END token inside a clause; keep END only as a standalone token if needed
            output_seq = torch.cat(
                [output_na_x, output_na_y, output_noise_label, output_noise_connect, output_noise_coeff], dim=-1
            )

            # Supervision sequence: [positive clauses] + [END] + [negative clauses]
            output_seq = torch.cat([box_label.flatten(), torch.ones(1).to(box_label) * self.end, output_seq.flatten()])
            output_seqs.append(output_seq.unsqueeze(0))
        input_seqs = torch.cat(input_seqs, dim=0)  # [B, 1 + num_box*clause_length]
        output_seqs = torch.cat(output_seqs, dim=0)  # [B, 1 + (pos + neg)*clause_length]
        
        # ============= DEBUG 2: 序列构造检查 =============
        if self._is_main_process():
            debug_print("\n" + "="*80)
            debug_print("[AR-RNTR DEBUG] Step 2: Sequence Construction")
            debug_print("="*80)
            debug_print(f"max_box: {max_box}, num_box: {num_box}, coeff_dim: {coeff_dim}")
            debug_print(f"clause_length: {4 + coeff_dim}")
            debug_print(f"input_seqs shape: {input_seqs.shape}")
            debug_print(f"output_seqs shape: {output_seqs.shape}")
            debug_print(f"input_seqs[0][:10]: {input_seqs[0][:10].tolist()}")
            debug_print(f"output_seqs[0][:10]: {output_seqs[0][:10].tolist()}")
            # 检查 END token 位置
            for bi in range(min(2, output_seqs.shape[0])):
                end_positions = (output_seqs[bi] == self.end).nonzero(as_tuple=True)[0]
                debug_print(f"  Sample {bi}: END token at positions {end_positions.tolist()}")
        
        outputs_logits = self.pts_bbox_head(bev_feats, input_seqs, img_metas)[-1, :, :-1, :]  # [B, T-1, V]
        
        # ============= DEBUG 3: 模型输出检查 =============
        if self._is_main_process():
            debug_print("\n" + "="*80)
            debug_print("[AR-RNTR DEBUG] Step 3: Model Output")
            debug_print("="*80)
            debug_print(f"outputs_logits shape: {outputs_logits.shape}")
            debug_print(f"outputs_logits finite ratio: {torch.isfinite(outputs_logits).float().mean().item():.4f}")
            debug_print(f"outputs_logits min/max: {outputs_logits.min().item():.4f} / {outputs_logits.max().item():.4f}")
            if torch.isnan(outputs_logits).any():
                debug_print("  WARNING: outputs_logits contains NaN!")
            if torch.isinf(outputs_logits).any():
                debug_print("  WARNING: outputs_logits contains Inf!")

        clause_length = 4 + coeff_dim
        all_outputs_pos, all_inputs_pos = [], []
        all_outputs_cls, all_inputs_cls = [], []
        all_outputs_connects, all_inputs_connects = [], []
        all_outputs_coeffs, all_inputs_coeffs = [], []
        # TIT accumulators
        tit_loss_total = outputs_logits.new_tensor(0.0)
        tit_count = 0

        for bi in range(outputs_logits.shape[0]):
            labels_i = output_seqs[bi, :-1]  # [T-1]
            preds_i = outputs_logits[bi]     # [T-1, V]
            # remove the single END token position from supervision
            end_mask = (labels_i == self.end)
            if end_mask.any():
                keep = ~end_mask
                labels_i = labels_i[keep]
                preds_i = preds_i[keep]
            # ensure length is multiple of clause_length
            valid_len = (labels_i.numel() // clause_length) * clause_length
            labels_i = labels_i[:valid_len]
            preds_i = preds_i[:valid_len]

            # slice by clause
            pos_x_logits = preds_i[0::clause_length, :]
            pos_y_logits = preds_i[1::clause_length, :]
            outputs_pos_i = torch.cat([pos_x_logits, pos_y_logits], dim=0)
            inputs_pos_i = torch.cat([labels_i[0::clause_length], labels_i[1::clause_length]], dim=0)

            outputs_cls_i = preds_i[2::clause_length, :]
            inputs_cls_i = labels_i[2::clause_length]

            outputs_conn_i = preds_i[3::clause_length, :]
            inputs_conn_i = labels_i[3::clause_length]

            coeff_logits_list, coeff_labels_list = [], []
            for k in range(4, clause_length):
                coeff_logits_list.append(preds_i[k::clause_length, :])
                coeff_labels_list.append(labels_i[k::clause_length])
            outputs_coeffs_i = torch.cat(coeff_logits_list, dim=0) if coeff_logits_list else preds_i.new_zeros((0, preds_i.shape[-1]))
            inputs_coeffs_i = torch.cat(coeff_labels_list, dim=0) if coeff_labels_list else labels_i.new_zeros((0,), dtype=labels_i.dtype)

            # filter out no_known targets
            mask_pos = (inputs_pos_i != self.no_known)
            mask_cls = (inputs_cls_i != self.no_known)
            mask_conn = (inputs_conn_i != self.no_known)
            mask_coeff = (inputs_coeffs_i != self.no_known)
            
            # ============= DEBUG 4: 每个样本的监督切分检查 =============
            if bi == 0 and self._is_main_process():  # 只打印第一个样本
                debug_print("\n" + "="*80)
                debug_print(f"[AR-RNTR DEBUG] Step 4: Sample {bi} Supervision Slicing")
                debug_print("="*80)
                debug_print(f"  labels_i numel (after END removal): {labels_i.numel()}")
                debug_print(f"  valid_len (aligned to clause): {valid_len}")
                debug_print(f"  clause_length: {clause_length}")
                debug_print(f"  num_clauses: {valid_len // clause_length}")
                debug_print(f"  inputs_pos_i: numel={inputs_pos_i.numel()}, unique={inputs_pos_i.unique().tolist()[:20]}")
                debug_print(f"  inputs_cls_i: numel={inputs_cls_i.numel()}, unique={inputs_cls_i.unique().tolist()}")
                debug_print(f"  inputs_conn_i: numel={inputs_conn_i.numel()}, unique={inputs_conn_i.unique().tolist()[:20]}")
                debug_print(f"  inputs_coeffs_i: numel={inputs_coeffs_i.numel()}")
                debug_print(f"  mask_pos sum: {mask_pos.sum().item()}")
                debug_print(f"  mask_cls sum: {mask_cls.sum().item()}")
                debug_print(f"  mask_conn sum: {mask_conn.sum().item()}")
                debug_print(f"  mask_coeff sum: {mask_coeff.sum().item()}")

            # TIT: distance-aware soft supervision on connect logits
            if self.tit_enable and mask_conn.sum().item() > 1:
                try:
                    # Valid connect logits/labels for positives only
                    logits_conn_valid = outputs_conn_i[mask_conn]  # [P, V]
                    labels_conn_valid = inputs_conn_i[mask_conn]   # [P]
                    # Build KNN neighbors from GT coords
                    gt_coords_sample = torch.tensor(gt_lines_coords[bi], device=preds_i.device).long().view(-1, 2).float()
                    P = logits_conn_valid.shape[0]
                    V = logits_conn_valid.shape[-1]
                    if gt_coords_sample.shape[0] >= 2 and P >= 2:
                        # Pairwise distances
                        dmat = torch.cdist(gt_coords_sample, gt_coords_sample, p=2)  # [N,N]
                        # Avoid self
                        diag_idx = torch.arange(dmat.shape[0], device=dmat.device)
                        dmat[diag_idx, diag_idx] = 1e6
                        K = int(min(max(self.tit_k, 1), max(1, dmat.shape[0] - 1)))
                        log_probs = F.log_softmax(logits_conn_valid, dim=-1)
                        for r in range(P):
                            gt_token = int(labels_conn_valid[r].item())
                            # Ensure target is a valid connect token
                            if gt_token < self.connect_start or gt_token >= self.connect_start + gt_coords_sample.shape[0]:
                                continue
                            gt_j = gt_token - self.connect_start
                            # KNN neighbors around GT target node gt_j
                            neigh_idx = torch.topk(dmat[gt_j], k=K, largest=False).indices.tolist()
                            # Exclude GT to avoid double counting in smoothing
                            neigh_idx = [n for n in neigh_idx if n != gt_j]
                            q = logits_conn_valid.new_zeros((V,))
                            alpha = float(self.tit_alpha)
                            q[self.connect_start + gt_j] = 1.0 - alpha
                            if len(neigh_idx) > 0 and alpha > 0:
                                share = alpha / float(len(neigh_idx))
                                for n in neigh_idx:
                                    q[self.connect_start + int(n)] += share
                            # KL divergence between predicted log-probs and soft target q
                            tit_loss_total = tit_loss_total + F.kl_div(log_probs[r], q, reduction='batchmean')
                            tit_count += 1
                except Exception:
                    # TIT is best-effort; never break training
                    pass

            all_outputs_pos.append(outputs_pos_i[mask_pos])
            all_inputs_pos.append(inputs_pos_i[mask_pos])

            all_outputs_cls.append(outputs_cls_i[mask_cls])
            all_inputs_cls.append(inputs_cls_i[mask_cls])

            all_outputs_connects.append(outputs_conn_i[mask_conn])
            all_inputs_connects.append(inputs_conn_i[mask_conn])

            all_outputs_coeffs.append(outputs_coeffs_i[mask_coeff])
            all_inputs_coeffs.append(inputs_coeffs_i[mask_coeff])

        # concat across batch
        outputs_pos = torch.cat(all_outputs_pos, dim=0) if len(all_outputs_pos) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_pos = torch.cat(all_inputs_pos, dim=0) if len(all_inputs_pos) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        outputs_cls = torch.cat(all_outputs_cls, dim=0) if len(all_outputs_cls) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_cls = torch.cat(all_inputs_cls, dim=0) if len(all_inputs_cls) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        outputs_connects = torch.cat(all_outputs_connects, dim=0) if len(all_outputs_connects) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_connects = torch.cat(all_inputs_connects, dim=0) if len(all_inputs_connects) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        outputs_coeffs = torch.cat(all_outputs_coeffs, dim=0) if len(all_outputs_coeffs) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_coeffs = torch.cat(all_inputs_coeffs, dim=0) if len(all_inputs_coeffs) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        gt_coords = [inputs_pos.long()]
        gt_labels = [inputs_cls.long()]
        gt_connects = [inputs_connects.long()]
        gt_coeffs = [inputs_coeffs.long()]
        
        preds_dicts = dict(
            preds_coords=[outputs_pos],
            preds_labels=[outputs_cls],
            preds_connects=[outputs_connects],
            preds_coeffs=[outputs_coeffs]
        )
        
        # ============= DEBUG 5: 拼接后的全局监督数量 =============
        if self._is_main_process():
            debug_print("\n" + "="*80)
            debug_print("[AR-RNTR DEBUG] Step 5: Batch-wide Supervision Counts")
            debug_print("="*80)
            debug_print(f"  coords: preds={outputs_pos.shape}, targets={inputs_pos.shape}")
            debug_print(f"  labels: preds={outputs_cls.shape}, targets={inputs_cls.shape}")
            debug_print(f"  connects: preds={outputs_connects.shape}, targets={inputs_connects.shape}")
            debug_print(f"  coeffs: preds={outputs_coeffs.shape}, targets={inputs_coeffs.shape}")
            if inputs_cls.numel() > 0:
                debug_print(f"  inputs_cls range: min={inputs_cls.min().item()}, max={inputs_cls.max().item()}")
                debug_print(f"  inputs_cls unique (first 20): {inputs_cls.unique().tolist()[:20]}")
            else:
                debug_print("  WARNING: inputs_cls is empty!")
            
            debug_print(f"\n  Checking for empty branches (will cause NaN):")
            if outputs_pos.numel() == 0:
                debug_print("    coords branch is EMPTY")
            if outputs_cls.numel() == 0:
                debug_print("    labels branch is EMPTY")
            if outputs_connects.numel() == 0:
                debug_print("    connects branch is EMPTY")
            if outputs_coeffs.numel() == 0:
                debug_print("    coeffs branch is EMPTY")

        loss_inputs = [gt_coords, gt_labels, gt_connects, gt_coeffs, preds_dicts]
        losses = self.pts_bbox_head.loss_by_feat(*loss_inputs)
        
        # ============= DEBUG 5.5: Loss Spike Detection & Diagnostics =============
        if self._is_main_process():
            # Helper function to extract loss value from tensor or list
            def get_loss_val(loss_key):
                if loss_key not in losses:
                    return 0.0
                val = losses[loss_key]
                if isinstance(val, list):
                    val = val[0] if len(val) > 0 else 0.0
                if torch.is_tensor(val):
                    return val.item() if val.numel() == 1 else val.mean().item()
                return float(val)
            
            # Check for abnormal loss values
            loss_coords_val = get_loss_val('loss_coords')
            loss_labels_val = get_loss_val('loss_labels')
            loss_connects_val = get_loss_val('loss_connects')
            loss_coeffs_val = get_loss_val('loss_coeffs')
            
            # Spike detection thresholds
            SPIKE_THRESHOLD = 15.0
            WARNING_THRESHOLD = 10.0
            
            total_loss = loss_coords_val + loss_labels_val + loss_connects_val + loss_coeffs_val
            
            if total_loss > SPIKE_THRESHOLD or loss_connects_val > 10.0:
                debug_print("\n" + "🔴"*40)
                debug_print("[CRITICAL WARNING] LOSS SPIKE DETECTED!")
                debug_print("🔴"*40)
                debug_print(f"  Total Loss: {total_loss:.4f} (threshold: {SPIKE_THRESHOLD})")
                debug_print(f"  loss_coords:   {loss_coords_val:.4f}")
                debug_print(f"  loss_labels:   {loss_labels_val:.4f}")
                debug_print(f"  loss_connects: {loss_connects_val:.4f} {'← SPIKE!' if loss_connects_val > 10.0 else ''}")
                debug_print(f"  loss_coeffs:   {loss_coeffs_val:.4f}")
                
                # Diagnostic info
                debug_print("\n  Possible causes:")
                debug_print("  1. AMP loss_scale adjustment (check if using dynamic scaling)")
                debug_print("  2. Gradient explosion from high loss_weight")
                debug_print("  3. Abnormal batch data")
                debug_print("  4. Weight corruption from previous spike")
                
                # Check for NaN/Inf in model weights
                debug_print("\n  Weight Health Check:")
                nan_params = []
                inf_params = []
                for name, param in self.named_parameters():
                    if param is not None and param.requires_grad:
                        if torch.isnan(param).any():
                            nan_params.append(name)
                        if torch.isinf(param).any():
                            inf_params.append(name)
                
                if nan_params:
                    debug_print(f"  ❌ Parameters with NaN: {nan_params[:5]}...")
                if inf_params:
                    debug_print(f"  ❌ Parameters with Inf: {inf_params[:5]}...")
                if not nan_params and not inf_params:
                    debug_print("  ✓ No NaN/Inf in model weights (yet)")
                
                debug_print("🔴"*40 + "\n")
            
            elif total_loss > WARNING_THRESHOLD:
                debug_print(f"\n⚠️  WARNING: High loss detected ({total_loss:.4f} > {WARNING_THRESHOLD})")
        
        # ============= DEBUG 6: 最终损失值 =============
        if self._is_main_process():
            debug_print("\n" + "="*80)
            debug_print("[AR-RNTR DEBUG] Step 6: Final Losses")
            debug_print("="*80)
            for k, v in losses.items():
                if torch.is_tensor(v):
                    val = v.item() if v.numel() == 1 else v.mean().item()
                    is_finite = torch.isfinite(v).all().item()
                    debug_print(f"  {k}: {val:.6f} (finite={is_finite})")
                else:
                    debug_print(f"  {k}: {v}")
        # Append TIT loss if enabled
        if self.tit_enable and tit_count > 0:
            losses['loss_tit'] = tit_loss_total / float(tit_count) * self.tit_weight

        # SwanLab logging (rank-0 only, optional)
        try:
            if self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process():
                if not self._swanlab_ready:
                    self._init_swanlab(cfg=dict(model='AR_RNTR', n_control=num_coeff + 2))
                self._global_step += 1
                if (self._global_step % self.swanlab_log_interval) == 0:
                    metrics = {}
                    for k, v in losses.items():
                        val = self._to_float(v)
                        if val is not None:
                            metrics[k] = val
                    # Optionally log sequence stats
                    metrics['seq_max_box'] = float(max_box)
                    metrics['seq_num_box'] = float(num_box)
                    if len(metrics) > 0:
                        swanlab.log(metrics, step=self._global_step)
                # Periodically log BEV overlay (first sample)
                if (self._global_step % self.swanlab_image_interval) == 0:
                    try:
                        pred_tokens0 = outputs_logits[0].detach().argmax(dim=-1)
                        bev_img = self._render_bev_overlay(gt_lines_coords[0], pred_tokens0, clause_length=clause_length, canvas_size=self.box_range)
                        if bev_img is not None:
                            self._swanlab_log_image('vis/bev_overlay', bev_img, step=self._global_step)
                        
                        # Also log topology graph
                        topo_img = render_topology_graph(pred_tokens0, clause_length, box_range=self.box_range, canvas_size=500)
                        if topo_img is not None:
                            self._swanlab_log_image('vis/topology_graph', topo_img, step=self._global_step)
                    except Exception:
                        pass
        except Exception:
            pass  # never break training due to logging

        return losses
    
    def loss(self,
             inputs=None,
             data_samples=None,**kwargs):

        img = inputs['img']
        img_metas = [ds.metainfo for ds in data_samples]

        bev_feats = self.extract_feat(img=img, img_metas=img_metas)
        if self.bev_scale != 1.0:
            b, c, h, w = bev_feats.shape
            bev_feats = F.interpolate(bev_feats, (int(h * self.bev_scale), int(w * self.bev_scale)))
        losses = dict()
        # Optional BEV distillation (TIT stage-2)
        if hasattr(self, 'tit_distill') and self.tit_distill:
            if 'bev_teacher' not in img_metas[0]:
                raise ValueError("tit_distill=True but 'bev_teacher' not found in img_metas")
            teacher_list = []
            for m in img_metas:
                bev_np = m.get('bev_teacher', None)
                if bev_np is None:
                    bev_np = img_metas[0]['bev_teacher']
                teacher_list.append(torch.from_numpy(bev_np).to(bev_feats.device).float())
            bev_teacher = torch.stack(teacher_list, dim=0)
            if bev_teacher.shape[-2:] != bev_feats.shape[-2:]:
                bev_teacher = F.interpolate(bev_teacher, size=bev_feats.shape[-2:], mode='bilinear', align_corners=False)
            losses['loss_distill'] = F.l1_loss(bev_feats, bev_teacher) * float(getattr(self, 'tit_distill_weight', 1.0))
            if getattr(self, 'tit_distill_only', False):
                return losses
        gt_lines_coords = [img_meta['centerline_coord'] for img_meta in img_metas]
        gt_lines_labels = [img_meta['centerline_label'] for img_meta in img_metas]
        gt_lines_connects = [img_meta['centerline_connect'] for img_meta in img_metas]
        gt_lines_coeffs = [img_meta['centerline_coeff'] for img_meta in img_metas]
        n_control = img_metas[0]['n_control']
        num_coeff = n_control - 2
        losses_pts = self.forward_pts_train(bev_feats, gt_lines_coords, gt_lines_labels, 
                                            gt_lines_connects, gt_lines_coeffs,
                                            img_metas, num_coeff)
        losses.update(losses_pts)
        return losses
    
    def predict(self, batch_inputs_dict, batch_data_samples, **kwargs):
        """Forward of testing.

        Args:
            batch_inputs_dict (dict): The model input dict which include
                'points' keys.

                - points (list[torch.Tensor]): Point cloud of each sample.
            batch_data_samples (List[:obj:`Det3DDataSample`]): The Data
                Samples. It usually includes information such as
                `gt_instance_3d`.

        Returns:
            list[:obj:`Det3DDataSample`]: Detection results of the
            input sample. Each Det3DDataSample usually contain
            'pred_instances_3d'. And the ``pred_instances_3d`` usually
            contains following keys.

            - scores_3d (Tensor): Classification scores, has a shape
                (num_instances, )
            - labels_3d (Tensor): Labels of bboxes, has a shape
                (num_instances, ).
            - bbox_3d (:obj:`BaseInstance3DBoxes`): Prediction of bboxes,
                contains a tensor with shape (num_instances, 7).
        """
        batch_input_metas = [item.metainfo for item in batch_data_samples]
        batch_input_imgs = batch_inputs_dict['img']
        # Run inference on the full batch instead of slicing to the first sample
        return self.simple_test(batch_input_metas, batch_input_imgs)

    def simple_test_pts(self, pts_feats, img_metas):
        """Test function of point cloud branch."""
        n_control = img_metas[0]['n_control']
        num_coeff = n_control - 2
        clause_length = 4 + num_coeff * 2
        # gt_node_list = self.seq2nodelist(gt_lines_seqs[0])
        # self.vis_from_nodelist(gt_node_list, img_metas[0], self.vis_cfg['path'], 'gt')
        device = pts_feats[0].device
        B = len(img_metas)
        
        # ============= DEBUG INF-1: 推理开始配置 =============
        if self._is_main_process():
            debug_print("\n" + "="*80)
            debug_print("[AR-RNTR INFERENCE DEBUG] Step INF-1: Inference Configuration")
            debug_print("="*80)
            debug_print(f"Batch size: {B}")
            debug_print(f"BEV features shape: {pts_feats.shape if isinstance(pts_feats, torch.Tensor) else [f.shape for f in pts_feats]}")
            debug_print(f"n_control: {n_control}, num_coeff: {num_coeff}, clause_length: {clause_length}")
            debug_print(f"Token constants: start={self.start}, end={self.end}, no_known={self.no_known}")
            debug_print(f"Inference constraints: {self.inference_constraints}")
        
        input_seqs = (torch.ones(B, 1, device=device) * self.start).long()
        outs = self.pts_bbox_head(pts_feats, input_seqs, img_metas)
        output_seqs, values = outs
        line_results = []
        for bi in range(output_seqs.shape[0]):
            pred_line_seq = output_seqs[bi]
            pred_line_seq = pred_line_seq[1:]
            if (pred_line_seq == self.end).any():
                stop_idx = (pred_line_seq == self.end).nonzero(as_tuple=True)[0][0]
            else:
                stop_idx = len(pred_line_seq)
            stop_idx = stop_idx // clause_length * clause_length
            pred_line_seq = pred_line_seq[:stop_idx]
            pred_line_seq[2::clause_length] = pred_line_seq[2::clause_length] - self.category_start
            pred_line_seq[3::clause_length] = pred_line_seq[3::clause_length] - self.connect_start
            for k in range(4, clause_length):
                pred_line_seq[k::clause_length] = pred_line_seq[k::clause_length] - self.coeff_start
            # ============ CONFIGURABLE INFERENCE CONSTRAINTS ============
            # Apply post-processing constraints based on inference_constraints config
            # See config file for detailed explanation of each constraint
            try:
                # Constraint 1: Clamp coordinates to BEV grid range
                # Purpose: Prevent index out of bounds errors
                # Status: REQUIRED (always recommended)
                if self.inference_constraints.get('clamp_coords', True):
                    xbound = self.view_transformers.grid_conf['xbound']
                    ybound = self.view_transformers.grid_conf['ybound']
                    NX = int((xbound[1] - xbound[0]) / xbound[2])
                    NY = int((ybound[1] - ybound[0]) / ybound[2])
                    pred_line_seq[0::clause_length] = pred_line_seq[0::clause_length].clamp(0, NX - 1)
                    pred_line_seq[1::clause_length] = pred_line_seq[1::clause_length].clamp(0, NY - 1)

                # Constraint 2: Clamp class labels to valid range
                # Purpose: Prevent invalid class indices
                # Status: REQUIRED (always recommended)
                if self.inference_constraints.get('clamp_classes', True):
                    pred_line_seq[2::clause_length] = pred_line_seq[2::clause_length].clamp(0, self.num_classes - 1)

                # Constraint 3: Clamp Bezier coefficients to training range
                # Purpose: Prevent out-of-range coefficient values
                # Status: REQUIRED (always recommended)
                # Note: coeffs are interleaved as (cx, cy, cx, cy, ...)
                if self.inference_constraints.get('clamp_coeffs', True):
                    if self.coeff_range is not None and self.coeff_range > 0:
                        for k in range(4, clause_length):
                            pred_line_seq[k::clause_length] = pred_line_seq[k::clause_length].clamp(0, self.coeff_range - 1)

                # Constraint 4: Enforce topological constraints on connect indices
                # Purpose: Ensure generated road network forms a valid DAG
                # Status: RECOMMENDED for topology validity, OPTIONAL for ablation study
                if self.inference_constraints.get('clamp_connect', True) or self.inference_constraints.get('force_lineal_prev', True):
                    num_nodes = pred_line_seq.numel() // clause_length
                    if num_nodes > 0:
                        # Work on a clone to avoid dtype/device issues when assigning Python ints
                        seq_clone = pred_line_seq.clone()
                        for i in range(num_nodes):
                            lbl = int(seq_clone[2 + i * clause_length].item())  # 0:Ancestor,1:Lineal,2:Offshoot,3:Clone
                            conn_pos = 3 + i * clause_length
                            if i == 0:
                                # First node should be Ancestor; set connect to 0
                                seq_clone[conn_pos] = 0
                                continue
                            conn_idx = int(seq_clone[conn_pos].item())
                            
                            # Constraint 4a: Connect index must point to a previous node [0..i-1]
                            # This ensures the generated graph is a valid DAG (no forward/self loops)
                            if self.inference_constraints.get('clamp_connect', True):
                                conn_idx = max(0, min(conn_idx, i - 1))
                            
                            # Constraint 4b: Force Lineal nodes to connect to immediate predecessor
                            # Rationale: By definition, Lineal means "continue along current path"
                            # If a node connects to non-predecessor, it should be Offshoot/Clone, not Lineal
                            if self.inference_constraints.get('force_lineal_prev', True):
                                if lbl == 1:  # Lineal
                                    conn_idx = i - 1
                            
                            seq_clone[conn_pos] = conn_idx
                        pred_line_seq = seq_clone
            except Exception:
                # Never break inference due to sanitation
                pass
            
            # ============= DEBUG INF-4: Token 范围验证 =============
            if self._is_main_process() and bi == 0:  # 只打印第一个样本
                debug_print("\n" + "="*80)
                debug_print(f"[AR-RNTR INFERENCE DEBUG] Step INF-4: Token Range Validation (Sample {bi})")
                debug_print("="*80)
                
                # 获取网格范围
                try:
                    xbound = self.view_transformers.grid_conf['xbound']
                    ybound = self.view_transformers.grid_conf['ybound']
                    NX = int((xbound[1] - xbound[0]) / xbound[2])
                    NY = int((ybound[1] - ybound[0]) / ybound[2])
                    
                    # 检查各slot的token范围
                    num_nodes = pred_line_seq.numel() // clause_length
                    if num_nodes > 0:
                        coords_x = pred_line_seq[0::clause_length]
                        coords_y = pred_line_seq[1::clause_length]
                        labels = pred_line_seq[2::clause_length]
                        connects = pred_line_seq[3::clause_length]
                        
                        debug_print(f"  Generated nodes: {num_nodes}")
                        debug_print(f"  Coords X range: [{coords_x.min().item()}, {coords_x.max().item()}] (expected: [0, {NX-1}])")
                        debug_print(f"  Coords Y range: [{coords_y.min().item()}, {coords_y.max().item()}] (expected: [0, {NY-1}])")
                        debug_print(f"  Labels range: [{labels.min().item()}, {labels.max().item()}] (expected: [0, {self.num_classes-1}])")
                        debug_print(f"  Connects range: [{connects.min().item()}, {connects.max().item()}]")
                        
                        if num_coeff > 0:
                            coeffs = pred_line_seq[4::clause_length]
                            debug_print(f"  Coeffs range: [{coeffs.min().item()}, {coeffs.max().item()}] (expected: [0, {self.coeff_range-1}])")
                        
                        # 检查是否有越界
                        if coords_x.max() >= NX or coords_x.min() < 0:
                            debug_print(f"  ⚠️ WARNING: Coords X out of range!")
                        if coords_y.max() >= NY or coords_y.min() < 0:
                            debug_print(f"  ⚠️ WARNING: Coords Y out of range!")
                        if labels.max() >= self.num_classes or labels.min() < 0:
                            debug_print(f"  ⚠️ WARNING: Labels out of range!")
                except Exception as e:
                    debug_print(f"  Error in token range validation: {e}")
            
            # ============= DEBUG INF-5: 拓扑结构检查 =============
            if self._is_main_process() and bi == 0:  # 只打印第一个样本
                debug_print("\n" + "="*80)
                debug_print(f"[AR-RNTR INFERENCE DEBUG] Step INF-5: Topology Validation (Sample {bi})")
                debug_print("="*80)
                
                num_nodes = pred_line_seq.numel() // clause_length
                if num_nodes > 0:
                    # 统计各类型节点数量
                    label_counts = {0: 0, 1: 0, 2: 0, 3: 0}  # Ancestor, Lineal, Offshoot, Clone
                    invalid_connections = 0
                    
                    for i in range(num_nodes):
                        lbl = int(pred_line_seq[2 + i * clause_length].item())
                        if lbl in label_counts:
                            label_counts[lbl] += 1
                        
                        # 检查连接合法性（除了第一个节点）
                        if i > 0:
                            conn = int(pred_line_seq[3 + i * clause_length].item())
                            if conn >= i:  # 前向连接或自连接
                                invalid_connections += 1
                    
                    debug_print(f"  Total nodes: {num_nodes}")
                    debug_print(f"  Node types: Ancestor={label_counts[0]}, Lineal={label_counts[1]}, "
                          f"Offshoot={label_counts[2]}, Clone={label_counts[3]}")
                    
                    # 计算百分比
                    for lbl, name in enumerate(["Ancestor", "Lineal", "Offshoot", "Clone"]):
                        pct = 100.0 * label_counts[lbl] / num_nodes if num_nodes > 0 else 0
                        if label_counts[lbl] == 0 and lbl in [1, 2]:  # Lineal or Offshoot
                            debug_print(f"  ⚠️ WARNING: {name} = 0 ({pct:.1f}%) - possibly abnormal!")
                    
                    if invalid_connections > 0:
                        debug_print(f"  ⚠️ WARNING: {invalid_connections} invalid connections (forward/self loops detected!)")
                    else:
                        debug_print(f"  ✅ All connections valid (DAG topology preserved)")
                else:
                    debug_print(f"  WARNING: No nodes generated!")
                
                debug_print("="*80 + "\n")
            
            # ============= DEBUG INF-6: Label Prediction Logits 分析 =============
            if self._is_main_process() and bi == 0:
                debug_print("\n" + "="*80)
                debug_print(f"[AR-RNTR INFERENCE DEBUG] Step INF-6: Label Prediction Analysis (Sample {bi})")
                debug_print("="*80)
                
                try:
                    # 获取label slot的logits [T, V]
                    # outputs_logits_i shape: [T, V] where T is sequence length
                    outputs_i = outputs_logits[bi]  # [T, V]
                    
                    # Label预测在clause的第3个位置（index 2）
                    # 提取所有label slot的logits
                    label_slot_indices = list(range(2, outputs_i.shape[0], clause_length))
                    if len(label_slot_indices) > 0:
                        # 提取label类别的logits (200-203)
                        label_logits = outputs_i[label_slot_indices, 200:204]  # [N, 4]
                        label_probs = torch.softmax(label_logits, dim=-1)  # [N, 4]
                        
                        # 计算平均概率
                        avg_probs = label_probs.mean(dim=0)
                        debug_print(f"  Label prediction probabilities (average over {len(label_slot_indices)} nodes):")
                        label_names = ["Ancestor", "Lineal", "Offshoot", "Clone"]
                        for lbl_idx, name in enumerate(label_names):
                            prob = avg_probs[lbl_idx].item()
                            debug_print(f"    {name:10s}: {prob:.4f} ({prob*100:.1f}%)")
                        
                        # 显示前5个节点的详细概率
                        debug_print(f"\n  Detailed probs for first 5 nodes:")
                        for i in range(min(5, label_probs.shape[0])):
                            probs = label_probs[i]
                            pred_lbl = torch.argmax(probs).item()
                            debug_print(f"    Node {i}: A={probs[0]:.3f}, L={probs[1]:.3f}, O={probs[2]:.3f}, C={probs[3]:.3f} → {label_names[pred_lbl]}")
                        
                        # 检查是否有类别概率异常低
                        if avg_probs[2] < 0.01:  # Offshoot
                            debug_print(f"\n  🔴 CRITICAL: Offshoot avg prob = {avg_probs[2]:.4f} (< 1%) - Model rarely predicts Offshoot!")
                        if avg_probs[1] < 0.05:  # Lineal
                            debug_print(f"  ⚠️ WARNING: Lineal avg prob = {avg_probs[1]:.4f} (< 5%) - Model rarely predicts Lineal!")
                        
                except Exception as e:
                    debug_print(f"  Error analyzing label logits: {e}")
                
                debug_print("="*80 + "\n")
            
            pred_node_list = av2seq2bznodelist(pred_line_seq.detach().cpu().numpy(), n_control, self.epsilon)

            line_results.append(dict(
                line_seqs = pred_line_seq.detach().cpu(),
                pred_node_lists = pred_node_list
            ))
        
        # Optional visualization (controlled by vis_cfg in config)
        if self.vis_cfg is not None:
            for bi, line_result in enumerate(line_results):
                # Visualize predicted topology
                pred_node_list = line_result['pred_node_lists']
                self.vis_from_nodelist(pred_node_list, img_metas[bi], self.vis_cfg['path'], 'pred')
                
                # Visualize GT topology (if available)
                if 'centerline_coord' in img_metas[bi]:
                    try:
                        gt_node_list = self._build_gt_nodelist(img_metas[bi], n_control)
                        self.vis_from_nodelist(gt_node_list, img_metas[bi], self.vis_cfg['path'], 'gt')
                    except Exception as e:
                        # Don't break visualization if GT conversion fails
                        pass
        
        return line_results

    def _build_gt_nodelist(self, img_meta, n_control):
        """
        Convert GT data from img_meta to nodelist format for visualization.
        
        Args:
            img_meta: Metadata dict containing 'centerline_coord', 'centerline_label', 
                     'centerline_connect', 'centerline_coeff'
            n_control: Number of Bezier control points
        
        Returns:
            list: GT node list in the same format as av2seq2bznodelist output
        """
        # Extract GT data
        gt_coords = np.array(img_meta['centerline_coord'])  # [N, 2]
        gt_labels = np.array(img_meta['centerline_label'])  # [N]
        gt_connects = np.array(img_meta['centerline_connect'])  # [N]
        gt_coeffs = np.array(img_meta['centerline_coeff'])  # [N, num_coeff*2]
        
        # Build sequence in the same format as model output
        num_coeff = n_control - 2
        clause_length = 4 + num_coeff * 2
        
        gt_seq = []
        for i in range(len(gt_coords)):
            # Format: [vx, vy, vc, vd, e_px, e_py, ...]
            node_seq = [
                gt_coords[i][0],      # x
                gt_coords[i][1],      # y
                gt_labels[i],         # category
                gt_connects[i],       # connection
            ]
            # Add coefficients
            if len(gt_coeffs[i]) > 0:
                node_seq.extend(gt_coeffs[i])
            else:
                # If no coefficients, pad with zeros
                node_seq.extend([0] * (num_coeff * 2))
            gt_seq.append(node_seq)
        
        # Convert to numpy array
        gt_seq_array = np.array(gt_seq)
        
        # Use the same conversion function as prediction
        gt_node_list = av2seq2bznodelist(gt_seq_array, n_control, self.epsilon)
        
        return gt_node_list

    def vis_linepts(self, pred_points, pred_labels, img_meta, path, aux_name):
        """Visualize predicted points with colors indicating their labels."""
        import cv2
        
        label_color = [[255, 0, 0], [0, 0, 230], [35, 244, 232], [70, 70, 70], [102, 102, 156],
               [190, 153, 153], [153, 153, 153], [250, 170, 30], [220, 220, 0],
               [107, 142, 35], [152, 251, 152], [70, 130, 180], [220, 20, 60],
               [255, 0, 0], [0, 0, 142], [0, 0, 70], [0, 60, 100],
               [0, 80, 100],  [119, 11, 32]]
        bev_img = np.zeros((200, 200, 3), np.uint8)
        for i in range(len(pred_points)):
            try:
                bev_img = cv2.circle(bev_img, (int(pred_points[i][0]), int(pred_points[i][1])), 
                                    1, label_color[int(pred_labels[i])], 2)
            except:
                pass
        name = img_meta['filename'][0].split('/')[-1].split('.jpg')[0]
        save_dir = f"vis/{path}/"
        if not os.path.exists(save_dir):
            os.makedirs(save_dir, exist_ok=True)
        cv2.imwrite(os.path.join(save_dir, f"{name}_{aux_name}.png"), bev_img)
        return
    
    def vis_from_nodelist(self, nodelist, img_meta, path, aux_name):
        """
        Visualize road network topology from node list.
        
        Args:
            nodelist: List of nodes, each with 'coord', 'sque_type', 'fork_from', 'merge_with'
            img_meta: Image metadata containing 'filename'
            path: Subdirectory name under 'vis/'
            aux_name: Suffix for the output filename (e.g., 'gt' or 'pred')
        
        Color scheme:
            - start: red (0, 0, 255)
            - fork: green (0, 255, 0)
            - continue: yellow (0, 255, 255)
            - merge: blue (255, 0, 0)
        """
        import cv2
        
        # ============ FIX: 从配置动态读取图像尺寸，而非硬编码 ============
        try:
            xbound = self.view_transformers.grid_conf['xbound']
            ybound = self.view_transformers.grid_conf['ybound']
            NX = int((xbound[1] - xbound[0]) / xbound[2])  # 例如: 192
            NY = int((ybound[1] - ybound[0]) / ybound[2])  # 例如: 128
        except Exception:
            # Fallback to default if config not available
            NX, NY = 200, 200
        
        # 创建匹配BEV配置的图像（矩形，而非正方形）
        image = np.zeros([NY, NX, 3], dtype=np.uint8)
        
        point_color_map = {
            "start": (0, 0, 255),      # Red
            'fork': (0, 255, 0),       # Green
            "continue": (0, 255, 255), # Yellow
            "merge": (255, 0, 0)       # Blue
        }

        for idx, node in enumerate(nodelist):
            # ============ FIX: 添加坐标边界检查 ============
            coord = node.get('coord')
            if coord is None:
                continue
            
            # 确保坐标在图像范围内
            x, y = int(coord[0]), int(coord[1])
            if not (0 <= x < NX and 0 <= y < NY):
                continue  # 跳过越界坐标
            
            coord_tuple = (x, y)
            
            if node['sque_type'] == 'start':
                cv2.circle(image, coord_tuple, 1, color=point_color_map['start'], thickness=2)
            
            elif node['sque_type'] == 'continue':
                cv2.circle(image, coord_tuple, 1, color=point_color_map['continue'], thickness=2)
                # Draw arrow from previous node
                if idx > 0:
                    prev_coord = nodelist[idx - 1].get('coord')
                    if prev_coord is not None:
                        prev_x, prev_y = int(prev_coord[0]), int(prev_coord[1])
                        if 0 <= prev_x < NX and 0 <= prev_y < NY:
                            cv2.arrowedLine(image, (prev_x, prev_y), coord_tuple, 
                                          color=point_color_map['continue'],
                                          thickness=1, tipLength=0.1)
            
            elif node['sque_type'] == 'fork':
                fork_from = node.get('fork_from')
                if fork_from is None:
                    continue
                
                # ============ FIX: 根据 sque_index 查找源节点，而非简单-1 ============
                source_node = None
                for n in nodelist[:idx]:  # 只在历史节点中查找
                    if n.get('sque_index') == fork_from:
                        source_node = n
                        break
                
                if source_node is not None:
                    src_coord = source_node.get('coord')
                    if src_coord is not None:
                        src_x, src_y = int(src_coord[0]), int(src_coord[1])
                        if 0 <= src_x < NX and 0 <= src_y < NY:
                            cv2.circle(image, coord_tuple, 1, color=point_color_map['fork'], thickness=2)
                            cv2.arrowedLine(image, (src_x, src_y), coord_tuple,
                                          color=point_color_map['fork'],
                                          thickness=1, tipLength=0.1)
            
            elif node['sque_type'] == 'merge':
                merge_with = node.get('merge_with')
                if merge_with is None:
                    continue
                
                # ============ FIX: 根据 sque_index 查找目标节点 ============
                target_node = None
                for n in nodelist[:idx]:  # 只在历史节点中查找
                    if n.get('sque_index') == merge_with:
                        target_node = n
                        break
                
                if target_node is not None:
                    tgt_coord = target_node.get('coord')
                    if tgt_coord is not None:
                        tgt_x, tgt_y = int(tgt_coord[0]), int(tgt_coord[1])
                        if 0 <= tgt_x < NX and 0 <= tgt_y < NY:
                            cv2.circle(image, coord_tuple, 1, color=point_color_map['merge'], thickness=2)
                            cv2.arrowedLine(image, (tgt_x, tgt_y), coord_tuple,
                                          color=point_color_map['merge'], thickness=1, tipLength=0.1)

        name = img_meta['filename'][0].split('/')[-1].split('.jpg')[0]
        save_dir = f"vis/{path}/"
        if not os.path.exists(save_dir):
            os.makedirs(save_dir, exist_ok=True)
        cv2.imwrite(os.path.join(save_dir, f"{name}_{aux_name}.png"), image)

    def simple_test(self, img_metas, img=None):
        """Test function without augmentaiton."""
        bev_feats = self.extract_feat(img=img, img_metas=img_metas)
        bbox_list = [dict() for i in range(len(img_metas))]
        line_results = self.simple_test_pts(
            bev_feats, img_metas)
        for result_dict, line_result, img_meta in zip(bbox_list, line_results, img_metas):
            result_dict['line_results'] = line_result
            result_dict['token'] = img_meta['token']
        # Optionally log validation BEV overlay (first sample)
        try:
            if self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process():
                if not self._swanlab_ready:
                    self._init_swanlab(cfg=dict(model='AR_RNTR', phase='val'))
                self._swanlab_img_step += 1
                if (self._swanlab_img_step % self.swanlab_image_interval) == 0:
                    try:
                        n_control = img_metas[0].get('n_control', 3)
                        clause_length = 4 + (int(n_control) - 2) * 2
                        pred_tokens0 = line_results[0]['line_seqs']
                        gt_coords0 = img_metas[0].get('centerline_coord', None)
                        bev_img = self._render_bev_overlay(gt_coords0 if gt_coords0 is not None else [],
                                                           pred_tokens0,
                                                           clause_length=clause_length,
                                                           canvas_size=self.box_range)
                        if bev_img is not None:
                            self._swanlab_log_image('vis/val_bev_overlay', bev_img, step=self._swanlab_img_step)
                    except Exception:
                        pass
        except Exception:
            pass
        return bbox_list