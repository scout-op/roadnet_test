"""
Custom Hook to write detailed DEBUG logs to a separate file.
"""
import os
import logging
from datetime import datetime
from mmengine.hooks import Hook
from mmengine.registry import HOOKS


@HOOKS.register_module()
class DebugLoggerHook(Hook):
    """
    Write detailed debug information to a separate log file.
    
    This keeps the main training log clean while preserving all debug info.
    
    Args:
        log_dir (str): Directory to save debug logs. Default: 'work_dirs/debug_logs'.
        log_name (str): Name prefix for log file. If None, use timestamp.
        flush_interval (int): Flush file every N iterations. Default: 10.
    """
    
    def __init__(self, log_dir='work_dirs/debug_logs', log_name=None, flush_interval=10):
        self.log_dir = log_dir
        self.log_name = log_name
        self.flush_interval = flush_interval
        self.debug_file = None
        self.iter_count = 0
        
    def before_run(self, runner):
        """Initialize debug log file before training starts."""
        # Create log directory
        os.makedirs(self.log_dir, exist_ok=True)
        
        # Generate log filename
        if self.log_name is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'debug_train_{timestamp}.log'
        else:
            filename = f'{self.log_name}_debug.log'
        
        log_path = os.path.join(self.log_dir, filename)
        
        # Open file in append mode
        self.debug_file = open(log_path, 'a', encoding='utf-8')
        
        # Write header
        self.debug_file.write("="*100 + "\n")
        self.debug_file.write(f"DEBUG LOG - Training started at {datetime.now()}\n")
        self.debug_file.write("="*100 + "\n\n")
        self.debug_file.flush()
        
        runner.logger.info(f"[DebugLogger] Saving debug logs to: {log_path}")
        
    def after_train_iter(self, runner, batch_idx, data_batch=None, outputs=None):
        """Write debug info after each iteration."""
        self.iter_count += 1
        
        # Flush file periodically
        if self.iter_count % self.flush_interval == 0:
            if self.debug_file is not None:
                self.debug_file.flush()
    
    def after_run(self, runner):
        """Close debug log file after training ends."""
        if self.debug_file is not None:
            self.debug_file.write("\n" + "="*100 + "\n")
            self.debug_file.write(f"Training ended at {datetime.now()}\n")
            self.debug_file.write("="*100 + "\n")
            self.debug_file.close()
            runner.logger.info("[DebugLogger] Debug log file closed.")


class DebugFileHandler:
    """
    Global debug file handler that can be accessed from anywhere.
    
    Usage in ar_rntr.py:
        from rntr.debug_logger_hook import get_debug_logger
        debug_log = get_debug_logger()
        if debug_log:
            debug_log.write("[DEBUG] Some message\n")
    """
    _instance = None
    _file = None
    
    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    @classmethod
    def set_file(cls, file_handle):
        """Set the debug file handle (called by DebugLoggerHook)."""
        cls._file = file_handle
    
    @classmethod
    def write(cls, message, flush=False):
        """Write message to debug file."""
        if cls._file is not None:
            try:
                cls._file.write(message)
                if flush:
                    cls._file.flush()
            except:
                pass  # Fail silently if file is closed
    
    @classmethod
    def is_active(cls):
        """Check if debug logging is active."""
        return cls._file is not None


def get_debug_logger():
    """
    Get the debug file handler instance.
    
    Returns:
        DebugFileHandler instance, or None if not initialized.
    """
    return DebugFileHandler.get_instance() if DebugFileHandler.is_active() else None


# Modify DebugLoggerHook to register file handler
@HOOKS.register_module()
class DebugLoggerHookV2(Hook):
    """
    Enhanced version that registers a global file handler.
    """
    
    def __init__(self, log_dir='work_dirs/debug_logs', log_name=None, flush_interval=10):
        self.log_dir = log_dir
        self.log_name = log_name
        self.flush_interval = flush_interval
        self.debug_file = None
        self.iter_count = 0
        
    def before_run(self, runner):
        """Initialize debug log file before training starts."""
        os.makedirs(self.log_dir, exist_ok=True)
        
        if self.log_name is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'debug_train_{timestamp}.log'
        else:
            filename = f'{self.log_name}_debug.log'
        
        log_path = os.path.join(self.log_dir, filename)
        self.debug_file = open(log_path, 'a', encoding='utf-8')
        
        # Register global file handler
        DebugFileHandler.set_file(self.debug_file)
        
        # Write header
        self.debug_file.write("="*100 + "\n")
        self.debug_file.write(f"DEBUG LOG - Training started at {datetime.now()}\n")
        self.debug_file.write(f"Config: {runner.cfg.filename if hasattr(runner.cfg, 'filename') else 'N/A'}\n")
        self.debug_file.write("="*100 + "\n\n")
        self.debug_file.flush()
        
        runner.logger.info(f"[DebugLogger] Saving debug logs to: {log_path}")
        
    def after_train_iter(self, runner, batch_idx, data_batch=None, outputs=None):
        """Write iteration summary."""
        self.iter_count += 1
        
        # Write iteration marker
        if batch_idx % 10 == 0:  # Every 10 iters
            epoch = runner.epoch if hasattr(runner, 'epoch') else 'N/A'
            self.debug_file.write(f"\n{'='*80}\n")
            self.debug_file.write(f"Epoch {epoch}, Iter {batch_idx} - {datetime.now()}\n")
            self.debug_file.write(f"{'='*80}\n")
        
        # Flush periodically
        if self.iter_count % self.flush_interval == 0:
            self.debug_file.flush()
    
    def after_run(self, runner):
        """Close debug log file."""
        if self.debug_file is not None:
            self.debug_file.write("\n" + "="*100 + "\n")
            self.debug_file.write(f"Training ended at {datetime.now()}\n")
            self.debug_file.write("="*100 + "\n")
            self.debug_file.close()
            DebugFileHandler.set_file(None)
            runner.logger.info("[DebugLogger] Debug log file closed.")
