# 🎯 Real Root Cause - Vocabulary Size Mismatch

**Date**: 2025-11-11  
**Status**: ✅ FIXED

---

## 💡 The Real Problem

The CUDA index error `srcIndex < srcSelectDimSize` was NOT about token value ranges in data, but about a **vocabulary size mismatch** between input and output!

### Architecture Overview

```
Input Tokens → Embedding (577 dims) → Transformer → vocab_embed (576 dims) → Output
    [0-576]        [0, 576]                           [0, 575]
```

**The Mismatch**:
- **Input Embedding**: Extended to 577 dimensions to support mask token (576)
  ```python
  self.embedding = PryDecoderEmbeddings(
      num_center_classes + 1,  # 577 dimensions
      embed_dims, 
      max_center_len
  )
  ```

- **Output Vocabulary**: Inherited from parent, only 576 dimensions (0-575)
  ```python
  self.vocab_embed = MLP(
      self.embed_dims, 
      self.embed_dims, 
      num_center_classes,  # 576 dimensions - inherited from ARRNTRHead
      3
  )
  ```

### Where It Breaks

In `forward_bd_branch()`:

```python
# Line 193: Input clamped to [0, 576] - OK for embedding
input_seqs_safe = input_seqs.clamp(0, 576)

# Line 275: vocab_embed outputs [B, L, 576] - indices [0, 575]
logits = self.vocab_embed(outs_dec)

# Line 304 (OLD - WRONG): targets may contain 576!
targets_for_loss = input_seqs_safe.clone()  # May have value 576

# Line 314: Cross-entropy tries to compute loss
layer_loss = F.cross_entropy(
    layer_logits,      # shape: [*, 576] - valid indices [0, 575]
    targets_for_loss,  # may contain 576 - OUT OF BOUNDS!
    ...
)
```

**CUDA Error**: When `targets_for_loss` contains 576, `F.cross_entropy` tries to index `logits[:, 576]`, but logits only has 576 columns (indices 0-575) → `srcIndex >= srcSelectDimSize` → CRASH!

---

## ✅ The Fix

### Key Insight

Block Diffusion should:
1. **Accept mask token (576) as INPUT** - for transformer to process
2. **Never predict mask token as OUTPUT** - vocab only has [0, 575]

### Applied Changes

**File**: `bd_rntr_head.py`

#### Change 1: Separate Input/Output Limits (Lines 175-193)

```python
# CRITICAL FIX: Handle mask token correctly
# - Input embedding supports [0, 576] (mask token = 576)
# - Output vocab_embed only outputs [0, 575] (576 classes, indices 0-575)
# - So we need different handling for input vs target

max_input_token = self.mask_token_id  # 576 - for embedding input
max_output_token = self.num_center_classes - 1  # 575 - for vocab output

# Clamp to [0, 576] for embedding input (can include mask token)
input_seqs_safe = input_seqs.clamp(0, max_input_token)
```

#### Change 2: Clamp Targets to Output Range (Lines 301-305)

```python
# Prepare targets for cross-entropy
# CRITICAL: Clamp to [0, 575] for OUTPUT vocab, not [0, 576]!
# Cross-entropy expects targets in [0, num_classes-1] where num_classes=576
targets_for_loss = input_seqs_safe.clamp(0, max_output_token)  # Clamp to [0, 575]
targets_for_loss[~loss_mask] = -100  # Ignore invalid positions
```

---

## 🔍 Why My Previous Approach Was Wrong

I was focused on:
- ❌ Token value ranges in data (0-199, 250-349, 350-569)
- ❌ Data preprocessing bugs
- ❌ Regenerating dataset pkl files

But the real issue was:
- ✅ **Vocabulary dimension mismatch** in the model itself
- ✅ Input can be [0, 576], but output must be [0, 575]

---

## 📊 Correct Token Flow

### Training (BD Branch)

```
Original:   [50, 100, 250, 350, 400, 571, ...]
                ↓ q_xt_geom_only()
Noised:     [576, 576, 250, 576, 576, 571, ...]  ← Contains mask token 576
                ↓ embedding (577 dims)
Embedded:   [embed1, embed2, ...]  ← Valid
                ↓ transformer
Features:   [feat1, feat2, ...]
                ↓ vocab_embed (576 dims)
Logits:     [logits with 576 classes]  ← Indices [0, 575]
                ↓ cross_entropy
Targets:    [50, 100, ..., 571, ...]  ← MUST be in [0, 575]!
                            ❌ NOT 576!
```

### Why It Works Now

1. **Input Processing**: `input_seqs_safe = input_seqs.clamp(0, 576)`
   - Can contain mask token 576 ✅
   - Embedding layer handles it ✅

2. **Target Processing**: `targets_for_loss = input_seqs_safe.clamp(0, 575)`
   - Removes any 576 values ✅
   - All targets in valid range [0, 575] ✅
   - Cross-entropy won't crash ✅

---

## 🧪 Verification

### Expected Behavior

```bash
CUDA_LAUNCH_BLOCKING=1 python tools/train.py \
    ./projects/SeqGrowGraph/configs/seq_grow_graph/block_diffusion_config.py \
    --work-dir work_dirs/bd_test
```

**Should see**:
```
[BD DEBUG] Input stats:
  input_seqs: shape=torch.Size([B, L]), range=[0, 576]  # OK - can have mask token
  is_geom: X/L geometry tokens
  block_ids: range=[0, N]

✅ No CUDA errors
✅ loss_bd: finite value
✅ loss_coords: finite value
```

---

## 🎓 Lessons Learned

### 1. Input ≠ Output Vocabulary

Just because a model can **accept** a token as input doesn't mean it can **predict** it as output!

- Mask tokens are **input-only**
- Output vocabulary is defined by the classification head

### 2. Check Tensor Dimensions First

Before diving into data preprocessing:
1. Check model architecture
2. Verify input/output dimensions
3. Ensure dimension consistency

### 3. CUDA Errors Are Tricky

The error reported at line 280 (`if num_valid_tokens == 0`) was misleading - the actual error was in the cross-entropy call at line 314!

---

## 📝 Final Architecture

```
Component          | Dimension | Token Range
-------------------|-----------|-------------
Input Tokens       | Variable  | [0, 576]
Embedding Layer    | 577       | [0, 576] ✅
Transformer        | Hidden    | N/A
vocab_embed Output | 576       | [0, 575] ✅
Cross-entropy      | 576       | targets ∈ [0, 575] ✅
```

**Key Constraint**: `targets.max() < vocab_embed.output_dim`

---

## ✅ Files Modified

| File | Lines | Change |
|------|-------|--------|
| `bd_rntr_head.py` | 175-193 | Separate input/output token limits |
| `bd_rntr_head.py` | 301-305 | Clamp targets to [0, 575] |

---

**Status**: 🟢 Root Cause Fixed

The vocabulary dimension mismatch has been resolved by properly separating input token range [0, 576] from output target range [0, 575].
