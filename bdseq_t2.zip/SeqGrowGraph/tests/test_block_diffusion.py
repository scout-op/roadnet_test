"""
Unit tests for Block Diffusion components.
Tests the entire pipeline from noise scheduling to mask generation to training.
"""
import unittest
import torch
import torch.nn as nn
from mmengine.config import Config


class TestNoiseSchedule(unittest.TestCase):
    """Test noise schedule implementations."""
    
    def test_loglinear_noise(self):
        """Test LogLinearNoise schedule."""
        from seq_grow_graph.noise_schedule import LogLinearNoise
        
        noise_fn = LogLinearNoise(eps=1e-3)
        t = torch.tensor([0.0, 0.5, 1.0])
        
        loss_scale, move_prob = noise_fn(t)
        
        # Check shapes
        self.assertEqual(loss_scale.shape, t.shape)
        self.assertEqual(move_prob.shape, t.shape)
        
        # Check ranges
        self.assertTrue(torch.all(move_prob >= 0))
        self.assertTrue(torch.all(move_prob <= 1))
        self.assertTrue(torch.all(torch.isfinite(loss_scale)))
        
        # Check monotonicity (move_prob should increase with t)
        self.assertTrue(move_prob[0] < move_prob[1] < move_prob[2])
        
    def test_cosine_noise(self):
        """Test CosineNoise schedule."""
        from seq_grow_graph.noise_schedule import CosineNoise
        
        noise_fn = CosineNoise(eps=1e-3)
        t = torch.linspace(0.1, 0.9, 10)
        
        loss_scale, move_prob = noise_fn(t)
        
        # Check no NaN/Inf
        self.assertTrue(torch.all(torch.isfinite(loss_scale)))
        self.assertTrue(torch.all(torch.isfinite(move_prob)))
        
        # Check positive
        self.assertTrue(torch.all(loss_scale > 0))
        self.assertTrue(torch.all(move_prob > 0))


class TestBlockDiffusionUtils(unittest.TestCase):
    """Test block diffusion utility functions."""
    
    def test_sample_t_per_block(self):
        """Test timestep sampling per block."""
        from seq_grow_graph.block_diffusion_utils import sample_t_per_block
        
        B, num_blocks = 4, 10
        t = sample_t_per_block(B, num_blocks, 0.5, 1.0, device='cpu', antithetic=True)
        
        # Check shape
        self.assertEqual(t.shape, (B, num_blocks))
        
        # Check range
        self.assertTrue(torch.all(t >= 0.5))
        self.assertTrue(torch.all(t <= 1.0))
        
    def test_create_block_causal_mask(self):
        """Test block causal mask generation."""
        from seq_grow_graph.block_diffusion_utils import create_block_causal_mask
        
        L = 50
        is_geom = torch.rand(L) > 0.3
        block_ids = torch.arange(L) // 5  # 10 blocks
        
        mask = create_block_causal_mask(L, block_size=1, block_ids=block_ids,
                                       is_geom=is_geom, device='cpu')
        
        # Check shape
        self.assertEqual(mask.shape, (2*L, 2*L))
        
        # Check dtype
        self.assertEqual(mask.dtype, torch.float32)
        
        # Check no NaN/Inf except -inf
        finite_or_neginf = torch.isfinite(mask) | (mask == float('-inf'))
        self.assertTrue(torch.all(finite_or_neginf))
        
        # Check diagonal blocks are accessible (not all -inf)
        for i in range(0, 2*L, 10):
            block = mask[i:i+10, i:i+10]
            self.assertTrue(torch.any(block > float('-inf')))
    
    def test_q_xt_geom_only(self):
        """Test geometry-only noise application."""
        from seq_grow_graph.block_diffusion_utils import q_xt_geom_only
        
        B, L = 4, 50
        x0 = torch.randint(0, 576, (B, L))
        move_prob = torch.ones(B, L) * 0.8
        is_geom = torch.rand(L) > 0.5
        mask_index = 576
        
        xt = q_xt_geom_only(x0, move_prob, is_geom, mask_index)
        
        # Check shape
        self.assertEqual(xt.shape, x0.shape)
        
        # Check that only geometry tokens can be masked
        non_geom_changed = ((xt != x0) & ~is_geom.unsqueeze(0)).any()
        self.assertFalse(non_geom_changed, "Non-geometry tokens should not be masked")
        
    def test_resample_q_xt_per_block(self):
        """Test mask rate resampling."""
        from seq_grow_graph.block_diffusion_utils import resample_q_xt_per_block
        
        B, L = 4, 100
        x0 = torch.randint(0, 576, (B, L))
        xt = torch.randint(0, 577, (B, L))  # Some masked
        move_prob = torch.ones(B, L) * 0.7
        is_geom = torch.rand(L) > 0.3
        block_ids = torch.arange(L) // 10  # 10 blocks
        mask_index = 576
        
        xt_resampled = resample_q_xt_per_block(
            x0, xt, move_prob, is_geom, block_ids,
            mask_index, 0.5, 1.0, max_iter=10
        )
        
        # Check shape
        self.assertEqual(xt_resampled.shape, x0.shape)
        
        # Check mask rates per block (should be within bounds)
        for block_id in torch.unique(block_ids):
            block_mask = (block_ids == block_id)
            geom_in_block = block_mask & is_geom
            
            if geom_in_block.sum() > 0:
                masked = (xt_resampled == mask_index) & geom_in_block.unsqueeze(0)
                mask_rate = masked.float().sum(dim=1) / geom_in_block.float().sum()
                
                # Allow some tolerance
                self.assertTrue(torch.all(mask_rate >= 0.45))
                self.assertTrue(torch.all(mask_rate <= 1.05))


class TestBDRNTRHead(unittest.TestCase):
    """Test BDRNTRHead functionality."""
    
    def test_annotate_tokens(self):
        """Test token annotation logic."""
        from seq_grow_graph.bd_rntr_head import BDRNTRHead
        
        # Create mock head (minimal init)
        # Just test the static annotate_tokens method logic
        L = 100
        input_seqs = torch.randint(0, 576, (2, L))
        
        # Inject some special tokens
        special_tokens = {
            'split_connect': 571,
            'split_node': 572,
            'end': 573,
            'start': 574,
            'pad': 575,
        }
        
        # Manually set some tokens
        input_seqs[0, 0] = special_tokens['start']
        input_seqs[0, 10] = special_tokens['split_node']
        input_seqs[0, 20] = special_tokens['split_connect']
        input_seqs[0, 30] = special_tokens['split_node']
        input_seqs[0, -1] = special_tokens['end']
        
        # Mock head instance
        class MockHead:
            @staticmethod
            def annotate_tokens(input_seqs, special_tokens):
                from seq_grow_graph.bd_rntr_head import BDRNTRHead
                # Use the actual method from BDRNTRHead
                head = BDRNTRHead.__new__(BDRNTRHead)
                return head.annotate_tokens(input_seqs, special_tokens)
        
        # This test just ensures no crashes
        # Full test would require proper initialization
        print("  [INFO] Token annotation test requires full head initialization")
        print("  [INFO] Skipping detailed checks, just verifying import works")


class TestIntegration(unittest.TestCase):
    """Integration tests for the full pipeline."""
    
    def test_config_loading(self):
        """Test that BD config can be loaded."""
        try:
            cfg = Config.fromfile('configs/seq_grow_graph/block_diffusion_config.py')
            
            # Check key fields exist
            self.assertIn('model', cfg)
            self.assertIn('pts_bbox_head', cfg.model)
            
            head_cfg = cfg.model.pts_bbox_head
            self.assertEqual(head_cfg.type, 'BDRNTRHead')
            
            print("  ✓ Config loaded successfully")
        except FileNotFoundError:
            print("  [SKIP] Config file not found, skipping config test")
        except Exception as e:
            self.fail(f"Config loading failed: {e}")
    
    def test_mask_generation_pipeline(self):
        """Test the full mask generation pipeline."""
        from seq_grow_graph.block_diffusion_utils import (
            sample_t_per_block,
            q_xt_geom_only,
            create_block_causal_mask
        )
        from seq_grow_graph.noise_schedule import get_noise
        
        # Setup
        B, L = 2, 60
        num_blocks = 6
        is_geom = torch.rand(L) > 0.3
        block_ids = torch.arange(L) // 10
        
        # Sample timesteps
        t = sample_t_per_block(B, num_blocks, 0.5, 1.0, device='cpu')
        self.assertEqual(t.shape, (B, num_blocks))
        
        # Get move probabilities
        noise_fn = get_noise('loglinear', eps=1e-3)
        
        # Expand t to match sequence
        t_per_token = torch.zeros(B, L)
        for b in range(B):
            for i in range(L):
                t_per_token[b, i] = t[b, block_ids[i]]
        
        loss_scale, move_prob = noise_fn(t_per_token)
        
        # Apply noise
        x0 = torch.randint(0, 576, (B, L))
        xt = q_xt_geom_only(x0, move_prob, is_geom, mask_index=576)
        
        # Generate mask
        mask = create_block_causal_mask(L, 1, block_ids, is_geom, device='cpu')
        
        # Verify shapes
        self.assertEqual(xt.shape, (B, L))
        self.assertEqual(mask.shape, (2*L, 2*L))
        
        print("  ✓ Full pipeline executed successfully")


def run_tests():
    """Run all tests and print summary."""
    print("\n" + "="*60)
    print("Running Block Diffusion Unit Tests")
    print("="*60 + "\n")
    
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add test classes
    suite.addTests(loader.loadTestsFromTestCase(TestNoiseSchedule))
    suite.addTests(loader.loadTestsFromTestCase(TestBlockDiffusionUtils))
    suite.addTests(loader.loadTestsFromTestCase(TestBDRNTRHead))
    suite.addTests(loader.loadTestsFromTestCase(TestIntegration))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Print summary
    print("\n" + "="*60)
    if result.wasSuccessful():
        print("✓ All tests passed!")
    else:
        print(f"✗ {len(result.failures)} test(s) failed")
        print(f"✗ {len(result.errors)} test(s) had errors")
    print("="*60 + "\n")
    
    return result.wasSuccessful()


if __name__ == '__main__':
    success = run_tests()
    exit(0 if success else 1)
