# 🔧 CUDA Index Error Fix

**Error**: `Assertion 'srcIndex < srcSelectDimSize' failed` in cross_entropy loss

---

## 🔍 Root Cause

The error occurred because **target token values exceeded the vocabulary size** during loss calculation.

### Issue Details

1. **Vocabulary Size**: `num_center_classes = 576` (valid indices: 0-575)
2. **Mask Token ID**: `576` (added for Block Diffusion)
3. **Embedding Size**: Extended to 577 to include mask token
4. **Vocab Head Output**: Still 576 classes (0-575)

### The Problem

In `forward_bd_branch()`, when computing cross-entropy loss:

```python
# BEFORE (WRONG):
layer_loss = F.cross_entropy(
    layer_logits,      # [B*L, 576] - outputs 576 classes
    input_seqs,        # May contain values >= 576!
    reduction='none'
)
```

If `input_seqs` contains:
- Special tokens (571-575) ✅ OK (< 576)
- Mask token (576) ❌ **OUT OF RANGE**
- Any corrupted token > 575 ❌ **OUT OF RANGE**

---

## ✅ Applied Fixes

### Fix #1: Target Validation & Clamping

**File**: `seq_grow_graph/bd_rntr_head.py` (line 242-265)

```python
# Compute loss only on geometry tokens that were masked
masked_positions = (xt == self.mask_token_id) & is_geom.unsqueeze(0)

# Also ensure targets are within valid range (< num_center_classes)
# This prevents CUDA index errors from special tokens
valid_targets = (input_seqs >= 0) & (input_seqs < self.num_center_classes)
loss_mask = masked_positions & valid_targets

# Clamp targets to valid range for safety
targets_clamped = input_seqs.clamp(0, self.num_center_classes - 1)

# Calculate BD loss
bd_loss = 0
for layer_idx in range(bd_logits.shape[0]):
    layer_logits = bd_logits[layer_idx]  # [B, L, vocab]
    layer_loss = F.cross_entropy(
        layer_logits.reshape(-1, layer_logits.shape[-1]),
        targets_clamped.reshape(-1),  # ✅ Now clamped to [0, 575]
        reduction='none'
    )
    layer_loss = layer_loss.reshape(B, L)
    
    # Apply loss scale and mask (only on valid masked geometry tokens)
    layer_loss = layer_loss * loss_scale * loss_mask.float()
    bd_loss += layer_loss.sum() / (loss_mask.sum() + 1e-8)
```

**Key Changes**:
1. ✅ Added `valid_targets` check: only compute loss on tokens < 576
2. ✅ Clamp targets to [0, 575] to prevent index errors
3. ✅ Updated `loss_mask` to exclude invalid targets

### Fix #2: Explicit num_center_classes Storage

**File**: `seq_grow_graph/bd_rntr_head.py` (line 64-65)

```python
# Store num_center_classes explicitly for BD branch
self.num_center_classes = num_center_classes
```

Ensures the value is always accessible in BD branch.

---

## 🧪 Debugging Steps (If Error Persists)

If you still see CUDA index errors, run with debugging enabled:

```bash
# Enable CUDA assertions and blocking
CUDA_LAUNCH_BLOCKING=1 python tools/train.py \
    configs/seq_grow_graph/block_diffusion_config.py \
    --work-dir work_dirs/bd_debug
```

### Add Temporary Debug Prints

In `bd_rntr_head.py`, add before loss computation (line 250):

```python
# Temporary debug - remove after fixing
print(f"[DEBUG] input_seqs stats:")
print(f"  - min: {input_seqs.min().item()}")
print(f"  - max: {input_seqs.max().item()}")
print(f"  - num_center_classes: {self.num_center_classes}")
print(f"  - mask_token_id: {self.mask_token_id}")
print(f"  - tokens >= 576: {(input_seqs >= 576).sum().item()}")
print(f"  - masked positions: {masked_positions.sum().item()}")
print(f"  - valid targets: {valid_targets.sum().item()}")
```

This will help identify if there are unexpected token values.

---

## 🎯 Expected Behavior After Fix

### Training Should Now:

1. ✅ **Not crash** with CUDA index errors
2. ✅ **Only compute loss** on valid geometry tokens (0-199, 350-569)
3. ✅ **Ignore** special tokens (570-575) in BD loss
4. ✅ **Safely handle** any edge cases with clamping

### Monitor These Metrics:

```bash
# In training logs, watch for:
tail -f work_dirs/bd_exp/*/log.txt

# Expected:
# - loss_bd: Should decrease (not NaN/Inf)
# - loss_coords: AR loss on coordinates
# - loss_total: Combined loss
# - No CUDA errors
```

---

## 🔄 If Error Still Occurs

### Possible Additional Issues:

1. **Data Corruption**: Some samples may have corrupted token sequences
   - **Solution**: Add data validation in dataloader

2. **Embedding Mismatch**: Embedding size doesn't match data
   - **Check**: Verify config has correct `num_center_classes=576`

3. **Special Token Conflict**: Token ranges overlap unexpectedly
   - **Verify**: All tokens should be in [0, 575] range

### Quick Validation Script:

```python
# Run this in Python console to verify config:
import torch
from mmengine.config import Config

cfg = Config.fromfile('configs/seq_grow_graph/block_diffusion_config.py')
print(f"num_center_classes: {cfg.model.pts_bbox_head.num_center_classes}")
print(f"Expected: 576")
```

---

## 📊 Summary of Changes

| File | Line | Change | Purpose |
|------|------|--------|---------|
| `bd_rntr_head.py` | 65 | Added `self.num_center_classes` | Explicit storage |
| `bd_rntr_head.py` | 244-245 | Added target validation | Filter invalid targets |
| `bd_rntr_head.py` | 248 | Added `targets_clamped` | Prevent index overflow |
| `bd_rntr_head.py` | 256 | Use clamped targets | Safe cross-entropy |
| `bd_rntr_head.py` | 262 | Updated loss mask | Only valid tokens |

---

## ✅ Next Steps

1. **Retry training** with the fixed code
2. **Monitor logs** for the first few iterations
3. **Verify** both AR and BD losses are decreasing
4. **Remove debug prints** once stable

If the error persists, please share:
- The full error message
- Token statistics from debug prints
- Config file content

---

**Status**: 🟢 Fix Applied - Ready to Retry Training
