"""
Block Diffusion RNTR Head for lane graph generation.
Extends ARRNTRHead with block diffusion training capabilities.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmdet3d.registry import MODELS, TASK_UTILS
import numpy as np

from .ar_rntr_head import ARRNTRHead, MLP, PryDecoderEmbeddings
from .noise_schedule import get_noise
from .block_diffusion_utils import (
    sample_t_per_block, q_xt_geom_only, resample_q_xt_per_block,
    create_block_causal_mask, _sample_categorical
)


@MODELS.register_module()
class BDRNTRHead(ARRNTRHead):
    """
    Block Diffusion RNTR Head.
    Supports both AR training (for connections) and BD training (for geometry).
    """
    
    def __init__(self,
                 # Inherit all ARRNTRHead parameters
                 num_classes,
                 in_channels,
                 num_center_classes,
                 max_center_len=601,
                 embed_dims=256,
                 # Block Diffusion specific parameters
                 use_block_diffusion=True,
                 bd_loss_weight=0.1,
                 noise_schedule='loglinear',
                 noise_eps=1e-3,
                 sampling_eps_min=0.5,
                 sampling_eps_max=1.0,
                 use_resample=True,
                 mask_token_id=None,  # If None, will use num_center_classes
                 num_denoising_steps=1,  # Number of BD refinement steps at inference
                 # Rest of ARRNTRHead parameters
                 **kwargs):
        
        # Initialize parent
        super().__init__(
            num_classes=num_classes,
            in_channels=in_channels,
            num_center_classes=num_center_classes,
            max_center_len=max_center_len,
            embed_dims=embed_dims,
            **kwargs
        )
        
        # Block Diffusion parameters
        self.use_block_diffusion = use_block_diffusion
        self.bd_loss_weight = bd_loss_weight
        self.sampling_eps_min = sampling_eps_min
        self.sampling_eps_max = sampling_eps_max
        self.use_resample = use_resample
        self.num_denoising_steps = num_denoising_steps
        
        # Store num_center_classes explicitly for BD branch
        self.num_center_classes = num_center_classes
        
        # Mask token
        if mask_token_id is None:
            self.mask_token_id = num_center_classes  # Use vocab_size as [MASK]
            # Extend embedding to include mask token for inputs only
            self.embedding = PryDecoderEmbeddings(
                num_center_classes + 1, embed_dims, max_center_len)
            # Keep vocab head unchanged to output original vocab size (AR path compatibility)
        else:
            self.mask_token_id = mask_token_id
        
        # Noise schedule
        self.noise_schedule = get_noise(noise_schedule, eps=noise_eps)
        
        # Loss for BD branch
        self.loss_bd = nn.CrossEntropyLoss(reduction='none')
    
    def annotate_tokens(self, input_seqs, special_tokens):
        """
        Annotate token types: geometry vs connection.
        
        Token ranges in SeqGrowGraph:
        - 0-199: Node coordinates (x, y) - GEOMETRY
        - 250-349: Node indices - TOPOLOGY
        - 350-569: Bézier control points - GEOMETRY
        - 570-575: Special tokens - STRUCTURE
        
        Args:
            input_seqs: [B, L] token sequences
            special_tokens: dict with 'split_node', 'split_connect', etc.
        
        Returns:
            is_geom: [L] boolean tensor marking geometry tokens
            block_ids: [L] integer tensor with block IDs
        """
        B, L = input_seqs.shape
        device = input_seqs.device

        split_connect_id = special_tokens.get('split_connect', 571)
        split_node_id = special_tokens.get('split_node', 572)
        end_id = special_tokens.get('end', 573)
        start_id = special_tokens.get('start', 574)
        pad_id = special_tokens.get('pad', 575)
        summary_split = special_tokens.get('summary_split', 570)
        split_lines = special_tokens.get('split_lines', 569)

        # Token range boundaries
        COORD_MIN = 0
        COORD_MAX = 199
        NODE_IDX_MIN = 250
        NODE_IDX_MAX = 349
        COEFF_MIN = 350
        COEFF_MAX = 569

        is_geom = torch.zeros(L, dtype=torch.bool, device=device)
        block_ids = torch.zeros(L, dtype=torch.long, device=device)

        # Use the first sample in batch to infer structure (attn mask shared across batch)
        seq = input_seqs[0]
        cur_block = 0
        
        for i in range(L):
            tok = int(seq[i].item())
            
            # Assign block id
            block_ids[i] = cur_block
            if tok == split_node_id:
                cur_block += 1

            # Classify token based on value range (not position!)
            if tok in (start_id, end_id, split_connect_id, split_node_id, 
                       pad_id, summary_split, split_lines):
                # Special tokens: not geometry
                is_geom[i] = False
            elif COORD_MIN <= tok <= COORD_MAX:
                # Node coordinates (x, y): GEOMETRY
                is_geom[i] = True
            elif NODE_IDX_MIN <= tok <= NODE_IDX_MAX:
                # Node indices: TOPOLOGY (not geometry)
                is_geom[i] = False
            elif COEFF_MIN <= tok <= COEFF_MAX:
                # Bézier control points: GEOMETRY
                # This is the critical fix - these were previously missed!
                is_geom[i] = True
            else:
                # Unknown tokens: treat as non-geometry
                is_geom[i] = False

        return is_geom, block_ids
    
    def forward_bd_branch(self, mlvl_feats, input_seqs, img_metas, 
                         is_geom, block_ids):
        """
        Block Diffusion training branch.
        
        Args:
            mlvl_feats: BEV features
            input_seqs: [B, L] clean token sequences
            img_metas: meta information
            is_geom: [L] geometry token flags
            block_ids: [L] block IDs
        
        Returns:
            bd_loss: Block diffusion loss
            bd_logits: Predicted logits for noised positions
        """
        B, L = input_seqs.shape
        device = input_seqs.device
        
        # CRITICAL FIX: Handle mask token correctly
        # - Input embedding supports [0, 576] (mask token = 576)
        # - Output vocab_embed only outputs [0, 575] (576 classes, indices 0-575)
        # - So we need different handling for input vs target
        
        max_input_token = self.mask_token_id  # 576 - for embedding input
        max_output_token = self.num_center_classes - 1  # 575 - for vocab output
        
        # Check for invalid tokens BEFORE clamping (for debugging)
        try:
            input_min = input_seqs.min().item()
            input_max = input_seqs.max().item()
            if input_max > max_input_token:
                print(f"[WARNING] Found tokens > {max_input_token}: max={input_max}, clamping...")
        except:
            print(f"[WARNING] Could not check input_seqs range, proceeding with clamping")
        
        # Clamp to [0, 576] for embedding input (can include mask token)
        input_seqs_safe = input_seqs.clamp(0, max_input_token)
        
        # DEBUG: Print input stats (remove after fixing)
        if torch.cuda.current_device() == 0:  # Only print on rank 0
            try:
                print(f"[BD DEBUG] Input stats:")
                print(f"  input_seqs: shape={input_seqs.shape}, range=[{input_seqs_safe.min()}, {input_seqs_safe.max()}]")
                print(f"  is_geom: {is_geom.sum()}/{len(is_geom)} geometry tokens")
                print(f"  block_ids: range=[{block_ids.min()}, {block_ids.max()}]")
            except Exception as e:
                print(f"[BD DEBUG] Error printing stats: {e}")
        
        # Sample timesteps per block
        num_blocks = int(block_ids.max().item()) + 1
        
        t = sample_t_per_block(
            B, num_blocks, 
            self.sampling_eps_min, self.sampling_eps_max,
            device=device, antithetic=True
        )
        
        # Expand t to per-token - CRITICAL: block_ids must be < num_blocks and < t.shape[1]
        # t shape: [B, num_blocks], block_ids shape: [L]
        # Result: [B, L] where each position gets its block's timestep
        # Additional safety: clamp block_ids against t.shape[1]-1
        max_block_idx = t.shape[1] - 1
        if block_ids.max() > max_block_idx or block_ids.min() < 0:
            print(f"[BD WARN] Clamping block_ids to [0, {max_block_idx}] for t gather."
                  f" got range=[{int(block_ids.min().item())}, {int(block_ids.max().item())}]")
            block_ids = block_ids.clamp(0, max_block_idx)
        t_expanded = t[:, block_ids]  # [B, L]
        
        # Get move probability from noise schedule
        loss_scale, move_prob = self.noise_schedule(t_expanded)
        
        # Apply noise only to geometry tokens (use safe version)
        xt = q_xt_geom_only(input_seqs_safe, move_prob, is_geom, self.mask_token_id)
        
        # DEBUG: Check xt range
        try:
            xt_min, xt_max = xt.min().item(), xt.max().item()
            if xt_max > max_input_token or xt_min < 0:
                print(f"[WARNING] xt after q_xt_geom_only out of range: [{xt_min}, {xt_max}], clamping...")
        except:
            pass
        
        # Resample to ensure mask rate in [eps_min, eps_max]
        if self.use_resample:
            xt = resample_q_xt_per_block(
                input_seqs_safe, xt, move_prob, is_geom, block_ids,
                self.mask_token_id, self.sampling_eps_min, self.sampling_eps_max
            )
            # DEBUG: Check after resample
            try:
                xt_min, xt_max = xt.min().item(), xt.max().item()
                if xt_max > max_input_token or xt_min < 0:
                    print(f"[WARNING] xt after resample out of range: [{xt_min}, {xt_max}], clamping...")
            except:
                pass
        
        # CRITICAL: Ensure xt is also within valid embedding range
        # q_xt_geom_only may produce values outside [0, 576] in edge cases
        xt = xt.clamp(0, max_input_token)
        
        # Concatenate [xt, x0] - both now use safe clamped version
        x_input = torch.cat([xt, input_seqs_safe], dim=1)  # [B, 2*L]
        
        # CRITICAL: Final safety check before embedding
        # This is the LAST line of defense before CUDA crash
        x_input = x_input.clamp(0, max_input_token)
        
        # Process BEV features
        x = mlvl_feats
        if self.in_channels != self.embed_dims:
            x = self.bev_proj(x)
        pos_embed = self.bev_position_encoding(x)
        B_feat, _, H, W = x.shape
        masks = torch.zeros(B_feat, H, W).bool().to(x.device)
        
        # Embed concatenated sequence - NOW SAFE (manual to support 2*L > max_position_embeddings)
        # 1) Word embeddings
        word_embeds = self.embedding.word_embeddings(x_input.long())  # [B, 2*L, D]
        # 2) Position embeddings with tiling when needed
        base_pos = self.embedding.position_embeddings.weight  # [P, D]
        P = base_pos.shape[0]
        total_len = x_input.shape[1]
        if total_len <= P:
            pos_seq = base_pos[:total_len, :]
        else:
            # Tile positions cyclically for sequences longer than P
            repeat_times = (total_len + P - 1) // P
            pos_seq = base_pos.repeat(repeat_times, 1)[:total_len, :]
            if torch.cuda.current_device() == 0:
                try:
                    print(f"[BD DEBUG] PosEmbed tiled: total_len={total_len}, P={P}, repeat_times={repeat_times}")
                except Exception:
                    pass
        # Expand to batch and add
        pos_embeds = pos_seq.unsqueeze(0).expand(word_embeds.shape[0], -1, -1)
        tgt = self.embedding.LayerNorm(word_embeds + pos_embeds)  # [B, 2*L, D]
        # Build query positional encodings for transformer (same tiling logic)
        query_embed = pos_seq
        
        # Create block diffusion mask
        bd_mask = create_block_causal_mask(
            L, block_size=1, block_ids=block_ids, 
            is_geom=is_geom, device=device
        )  # [2*L, 2*L]
        
        # Forward through transformer with BD mask
        # Requires rntr_transformer LssSeqLineTransformer/LssSeqLineFlashTransformer to accept custom mask
        outs_dec, _ = self.transformer(
            tgt, x, masks, query_embed, pos_embed, custom_tgt_mask=bd_mask
        )
        outs_dec = torch.nan_to_num(outs_dec)
        
        # Get logits
        logits = self.vocab_embed(outs_dec)  # [num_layers, B, 2*L, vocab]
        
        # Extract logits for noised positions (first L tokens)
        bd_logits = logits[:, :, :L, :]  # [num_layers, B, L, vocab]
        
        # Compute loss only on geometry tokens that were masked
        masked_positions = (xt == self.mask_token_id) & is_geom.unsqueeze(0)
        
        # CRITICAL: Ensure targets are within OUTPUT vocabulary range [0, 575]
        # vocab_embed outputs 576 classes (indices 0-575)
        # input_seqs_safe may contain 576 (mask token), but we can't predict it
        # Geometry tokens should be in [0-199] or [350-569], all < 576
        valid_targets = (input_seqs_safe >= 0) & (input_seqs_safe < self.num_center_classes)
        
        # Final loss mask: only on masked geometry tokens with valid targets
        loss_mask = masked_positions & valid_targets
        
        # Safety check: if no valid tokens, skip loss computation
        num_valid_tokens = loss_mask.sum()
        if num_valid_tokens == 0:
            return torch.tensor(0.0, device=device, requires_grad=True), bd_logits
        
        # Prepare targets for cross-entropy
        # CRITICAL: Clamp to [0, 575] for OUTPUT vocab, not [0, 576]!
        # Cross-entropy expects targets in [0, num_classes-1] where num_classes=576
        targets_for_loss = input_seqs_safe.clamp(0, max_output_token)  # Clamp to [0, 575]
        targets_for_loss[~loss_mask] = -100  # Ignore invalid positions
        
        # Calculate BD loss
        bd_loss = 0
        for layer_idx in range(bd_logits.shape[0]):
            layer_logits = bd_logits[layer_idx]  # [B, L, vocab]
            
            # Compute cross-entropy with ignore_index=-100
            # This safely handles invalid targets without CUDA errors
            layer_loss = F.cross_entropy(
                layer_logits.reshape(-1, layer_logits.shape[-1]),
                targets_for_loss.reshape(-1),
                reduction='none',
                ignore_index=-100
            )
            layer_loss = layer_loss.reshape(B, L)
            
            # Apply loss scaling on valid positions
            # Note: positions with ignore_index already have loss=0 from cross_entropy
            layer_loss = layer_loss * loss_scale
            bd_loss += layer_loss.sum() / num_valid_tokens
        
        bd_loss = bd_loss / bd_logits.shape[0]  # Average over layers
        
        return bd_loss, bd_logits
    
    def forward(self, mlvl_feats, input_seqs, img_metas):
        """
        Forward with both AR and BD branches during training.
        """
        if not self.training or not self.use_block_diffusion:
            # Inference or AR-only mode
            return super().forward(mlvl_feats, input_seqs, img_metas)
        
        # Annotate token types
        special_tokens = {
            'split_connect': 571,
            'split_node': 572,
            'end': 573,
            'start': 574,
        }
        is_geom, block_ids = self.annotate_tokens(input_seqs, special_tokens)
        
        # Standard AR forward
        ar_logits = super().forward(mlvl_feats, input_seqs, img_metas)
        
        # BD forward
        bd_loss, bd_logits = self.forward_bd_branch(
            mlvl_feats, input_seqs, img_metas,
            is_geom, block_ids
        )
        
        # Return both for loss computation
        return {
            'ar_logits': ar_logits,
            'bd_loss': bd_loss,
            'bd_logits': bd_logits,
        }

    @torch.no_grad()
    def inference_bd(self, mlvl_feats, input_seqs, img_metas, num_steps=None):
        """
        Simple BD inference by refining geometry tokens after AR draft generation.
        1) Run AR to generate a draft sequence.
        2) Run num_steps BD refinement on geometry tokens using [xt, x0] concatenation and BD mask.
        Returns: (refined_seq, None)
        """
        if isinstance(mlvl_feats, (list, tuple)):
            device = mlvl_feats[0].device
        else:
            device = mlvl_feats.device
        B = input_seqs.shape[0]
        if num_steps is None:
            num_steps = getattr(self, 'num_denoising_steps', 1)

        # Step 1: AR draft
        draft_out = super().forward(mlvl_feats, input_seqs, img_metas)
        if isinstance(draft_out, tuple) or isinstance(draft_out, list):
            draft_seq, _ = draft_out
        else:
            # Fallback: if unexpected, just return AR
            return draft_out

        # Prepare BEV features
        x = mlvl_feats
        if self.in_channels != self.embed_dims:
            x = self.bev_proj(x)
        pos_embed = self.bev_position_encoding(x)
        B_feat, _, H, W = x.shape
        masks = torch.zeros(B_feat, H, W).bool().to(device)

        # Use special tokens
        special_tokens = {
            'split_connect': 571,
            'split_node': 572,
            'end': 573,
            'start': 574,
            'pad': 575,
            'summary_split': 570,
            'split_lines': 569,
        }

        # Step 2: BD refinement on geometry tokens
        refined_seq = draft_seq.clone()
        B, L = refined_seq.shape
        is_geom, block_ids = self.annotate_tokens(refined_seq, special_tokens)

        # Positional embeddings table (2D) for length 2L
        base_pos = self.embedding.position_embeddings.weight  # [P, D]
        P = base_pos.shape[0]

        for _ in range(num_steps):
            # Build [xt, x0]
            x0 = refined_seq
            xt = refined_seq.clone()
            xt[:, is_geom] = self.mask_token_id
            x_input = torch.cat([xt, x0], dim=1)  # [B, 2L]

            # Embed
            tgt = self.embedding(x_input.long())  # [B, 2L, D]
            total_len = x_input.shape[1]
            if total_len <= P:
                query_embed = base_pos[:total_len, :]
            else:
                repeat_times = (total_len + P - 1) // P
                query_embed = base_pos.repeat(repeat_times, 1)[:total_len, :]

            # Mask
            bd_mask = create_block_causal_mask(L, block_size=1, block_ids=block_ids,
                                               is_geom=is_geom, device=device)

            # Forward
            outs_dec, _ = self.transformer(
                tgt, x, masks, query_embed, pos_embed, custom_tgt_mask=bd_mask
            )
            outs_dec = torch.nan_to_num(outs_dec)
            logits = self.vocab_embed(outs_dec)  # [num_layers, B, 2L, V]
            last_layer = logits[-1]
            bd_logits = last_layer[:, :L, :]  # [B, L, V]
            preds = bd_logits.argmax(dim=-1)

            # Update only geometry tokens
            refined_seq[:, is_geom] = preds[:, is_geom]

        return refined_seq, None
    
    def loss_by_feat_bd(self, preds_dict, gt_coords_list):
        """
        Compute combined AR + BD loss.
        
        Args:
            preds_dict: dict with 'ar_logits', 'bd_loss', 'bd_logits'
            gt_coords_list: ground truth sequences
        
        Returns:
            loss_dict: dict with all losses
        """
        if isinstance(preds_dict, dict) and 'bd_loss' in preds_dict:
            # BD training mode
            ar_logits = preds_dict['ar_logits']
            bd_loss = preds_dict['bd_loss']
            
            # Compute AR loss using parent method
            loss_dict = self.loss_by_feat_seq(ar_logits, gt_coords_list[0])
            
            # Add BD loss
            loss_dict['loss_bd'] = bd_loss * self.bd_loss_weight
            loss_dict['loss_total'] = loss_dict['loss_coords'] + loss_dict['loss_bd']
            
            return loss_dict
        else:
            # Standard AR loss
            return self.loss_by_feat_seq(preds_dict, gt_coords_list[0])
