"""
Simple script to check token ranges - minimal dependencies.
Run from mmdetection3d root: python ./projects/SeqGrowGraph/scripts/simple_check.py
"""
import torch
import pickle
import os
from pathlib import Path

print("="*60)
print("Simple Token Range Checker")
print("="*60)

# Try to load some cached data files
data_root = './data/nuscenes'
cache_files = [
    './data/nuscenes/nuscenes_infos_train.pkl',
    './data/nuscenes/nuscenes_infos_val.pkl',
]

found_data = False

for cache_file in cache_files:
    if os.path.exists(cache_file):
        print(f"\n✓ Found: {cache_file}")
        try:
            with open(cache_file, 'rb') as f:
                data = pickle.load(f)
            
            print(f"  Type: {type(data)}")
            
            if isinstance(data, dict):
                print(f"  Keys: {list(data.keys())[:5]}...")
                if 'infos' in data:
                    data = data['infos']
            
            if isinstance(data, list):
                print(f"  Number of samples: {len(data)}")
                
                # Check first few samples
                max_token = 0
                min_token = float('inf')
                
                for i, sample in enumerate(data[:min(10, len(data))]):
                    # Try to find sequence data
                    seq = None
                    
                    # Common keys where sequences might be stored
                    possible_keys = [
                        'centerline_sequence',
                        'gt_labels_3d', 
                        'sequence',
                        'tokens',
                        'lane_sequence'
                    ]
                    
                    for key in possible_keys:
                        if key in sample:
                            seq = sample[key]
                            break
                    
                    if seq is not None:
                        if not isinstance(seq, torch.Tensor):
                            seq = torch.tensor(seq)
                        
                        s_min = seq.min().item()
                        s_max = seq.max().item()
                        max_token = max(max_token, s_max)
                        min_token = min(min_token, s_min)
                        
                        status = "✅" if s_max <= 576 else "❌"
                        print(f"  {status} Sample {i}: range [{s_min}, {s_max}]")
                        found_data = True
                
                if found_data:
                    print(f"\n{'='*60}")
                    print(f"Global range: [{min_token}, {max_token}]")
                    print(f"Expected: [0, 576]")
                    if max_token <= 576:
                        print("✅ All tokens in valid range!")
                    else:
                        print(f"❌ INVALID: Found tokens > 576!")
                    print(f"{'='*60}")
                    break
                    
        except Exception as e:
            print(f"  Error loading: {e}")
            continue

if not found_data:
    print("\n" + "="*60)
    print("⚠️  Could not find or parse dataset files")
    print("="*60)
    print("\nAlternative: Run training with debug output enabled")
    print("The debug prints in bd_rntr_head.py will show token ranges:")
    print("  [BD DEBUG] Input stats:")
    print("    input_seqs: range=[min, max]")
    print("\nIf max > 576, there's a data preprocessing issue.")
    print("="*60)
