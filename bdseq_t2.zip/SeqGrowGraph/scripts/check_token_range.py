"""
Debug script to check token ranges in dataset.
Run from mmdetection3d root: python ./projects/SeqGrowGraph/scripts/check_token_range.py
"""
import sys
import os

import torch
import numpy as np
from mmengine.config import Config

# Add project to path
project_dir = os.path.join(os.path.dirname(__file__), '..')
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

# Load config
config_path = './projects/SeqGrowGraph/configs/seq_grow_graph/block_diffusion_config.py'
cfg = Config.fromfile(config_path)

# Import registry
from mmdet3d.registry import DATASETS

# Build dataset
dataset_cfg = cfg.train_dataloader.dataset
dataset = DATASETS.build(dataset_cfg)

print(f"Dataset loaded: {len(dataset)} samples")
print("Checking token ranges...\n")

max_token_global = 0
min_token_global = float('inf')
invalid_samples = []

for i in range(min(100, len(dataset))):
    try:
        data = dataset[i]
        
        # Get sequence - the key might vary
        seq = None
        if 'centerline_sequence' in data:
            seq = data['centerline_sequence']
        elif 'gt_labels_3d' in data:
            seq = data['gt_labels_3d']
        elif 'input_seqs' in data:
            seq = data['input_seqs']
        else:
            print(f"Sample {i}: Cannot find sequence key in {data.keys()}")
            continue
        
        if isinstance(seq, torch.Tensor):
            seq_min = seq.min().item()
            seq_max = seq.max().item()
        else:
            seq = torch.tensor(seq)
            seq_min = seq.min().item()
            seq_max = seq.max().item()
        
        max_token_global = max(max_token_global, seq_max)
        min_token_global = min(min_token_global, seq_min)
        
        if seq_max > 576:
            invalid_samples.append((i, seq_min, seq_max))
            print(f"⚠️  Sample {i}: range [{seq_min}, {seq_max}] - INVALID!")
        else:
            if i < 10:  # Print first 10
                print(f"✅ Sample {i}: range [{seq_min}, {seq_max}]")
                
    except Exception as e:
        print(f"Error processing sample {i}: {e}")
        continue

print(f"\n{'='*60}")
print(f"Dataset Statistics:")
print(f"{'='*60}")
print(f"Global token range: [{min_token_global}, {max_token_global}]")
print(f"Expected range: [0, 576]")
print(f"Total samples checked: {min(100, len(dataset))}")

if invalid_samples:
    print(f"\n❌ Found {len(invalid_samples)} samples with INVALID tokens (>576):")
    for idx, min_val, max_val in invalid_samples[:10]:
        print(f"  Sample {idx}: [{min_val}, {max_val}]")
    print(f"\n🔧 ACTION NEEDED: Fix data preprocessing to ensure all tokens ≤ 576")
else:
    print(f"\n✅ All tokens in valid range!")

print(f"{'='*60}")
