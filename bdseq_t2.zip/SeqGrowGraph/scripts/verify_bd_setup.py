"""
Verification script for Block Diffusion setup.
Checks if all components are properly installed and configured.
"""
import sys
import torch
from mmengine.config import Config

def check_imports():
    """Check if all required modules can be imported."""
    print("=" * 60)
    print("Checking imports...")
    print("=" * 60)
    
    try:
        from seq_grow_graph import BDRNTRHead
        print("✓ BDRNTRHead imported successfully")
    except ImportError as e:
        print(f"✗ Failed to import BDRNTRHead: {e}")
        return False
    
    try:
        from seq_grow_graph.noise_schedule import get_noise, LogLinearNoise
        print("✓ Noise schedule modules imported successfully")
    except ImportError as e:
        print(f"✗ Failed to import noise schedule: {e}")
        return False
    
    try:
        from seq_grow_graph.block_diffusion_utils import (
            create_block_causal_mask, 
            sample_t_per_block,
            q_xt_geom_only,
            resample_q_xt_per_block
        )
        print("✓ Block diffusion utilities imported successfully")
    except ImportError as e:
        print(f"✗ Failed to import block diffusion utils: {e}")
        return False
    
    try:
        from seq_grow_graph import BlockDiffusionTransformer
        print("✓ BlockDiffusionTransformer imported successfully")
    except ImportError as e:
        print(f"⚠ BlockDiffusionTransformer not imported (optional): {e}")
    
    return True


def check_config(config_path):
    """Check if config file loads correctly."""
    print("\n" + "=" * 60)
    print(f"Checking config: {config_path}")
    print("=" * 60)
    
    try:
        cfg = Config.fromfile(config_path)
        print(f"✓ Config loaded successfully")
        
        # Check critical fields
        if 'model' in cfg and 'pts_bbox_head' in cfg.model:
            head_cfg = cfg.model.pts_bbox_head
            if head_cfg.get('type') == 'BDRNTRHead':
                print(f"✓ Head type is BDRNTRHead")
                print(f"  - use_block_diffusion: {head_cfg.get('use_block_diffusion', False)}")
                print(f"  - bd_loss_weight: {head_cfg.get('bd_loss_weight', 'N/A')}")
                print(f"  - noise_schedule: {head_cfg.get('noise_schedule', 'N/A')}")
                print(f"  - sampling_eps_min: {head_cfg.get('sampling_eps_min', 'N/A')}")
                print(f"  - sampling_eps_max: {head_cfg.get('sampling_eps_max', 'N/A')}")
                print(f"  - num_denoising_steps: {head_cfg.get('num_denoising_steps', 'N/A')}")
            else:
                print(f"⚠ Head type is {head_cfg.get('type')}, not BDRNTRHead")
        else:
            print(f"✗ Model or pts_bbox_head not found in config")
            return False
        
        return True
    except Exception as e:
        print(f"✗ Failed to load config: {e}")
        return False


def test_basic_functionality():
    """Test basic BD functionality."""
    print("\n" + "=" * 60)
    print("Testing basic functionality...")
    print("=" * 60)
    
    try:
        from seq_grow_graph.noise_schedule import get_noise
        from seq_grow_graph.block_diffusion_utils import (
            create_block_causal_mask,
            sample_t_per_block,
            q_xt_geom_only
        )
        
        # Test noise schedule
        noise_fn = get_noise('loglinear', eps=1e-3)
        t = torch.tensor([0.5, 0.7, 0.9])
        loss_scale, move_prob = noise_fn(t)
        assert loss_scale.shape == t.shape, "Loss scale shape mismatch"
        assert move_prob.shape == t.shape, "Move prob shape mismatch"
        assert torch.all(move_prob >= 0) and torch.all(move_prob <= 1), "Move prob out of range"
        print("✓ Noise schedule works correctly")
        
        # Test timestep sampling
        t = sample_t_per_block(batch_size=4, num_blocks=10, 
                               sampling_eps_min=0.5, sampling_eps_max=1.0,
                               device='cpu', antithetic=True)
        assert t.shape == (4, 10), f"Timestep shape mismatch: {t.shape}"
        assert torch.all(t >= 0.5) and torch.all(t <= 1.0), "Timesteps out of range"
        print("✓ Timestep sampling works correctly")
        
        # Test mask generation
        L = 50
        is_geom = torch.rand(L) > 0.3  # Random geometry flags
        block_ids = torch.arange(L) // 5  # 10 blocks
        mask = create_block_causal_mask(L, block_size=1, block_ids=block_ids,
                                       is_geom=is_geom, device='cpu')
        assert mask.shape == (2*L, 2*L), f"Mask shape mismatch: {mask.shape}"
        assert torch.all(torch.isfinite(mask)), "Mask contains NaN/Inf"
        print("✓ Mask generation works correctly")
        
        # Test noise application
        x0 = torch.randint(0, 576, (4, L))
        move_prob = torch.rand(4, L) * 0.5 + 0.5
        xt = q_xt_geom_only(x0, move_prob, is_geom, mask_index=576)
        assert xt.shape == x0.shape, "Noised sequence shape mismatch"
        # Check that only geometry tokens can be masked
        non_geom_changed = ((xt != x0) & ~is_geom.unsqueeze(0)).any()
        assert not non_geom_changed, "Non-geometry tokens were masked"
        print("✓ Noise application works correctly")
        
        return True
    except Exception as e:
        print(f"✗ Functionality test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all verification checks."""
    print("\n" + "=" * 60)
    print("Block Diffusion Setup Verification")
    print("=" * 60 + "\n")
    
    all_passed = True
    
    # Check imports
    if not check_imports():
        all_passed = False
        print("\n⚠ Import checks failed. Please ensure all modules are in PYTHONPATH.")
    
    # Check config
    config_path = 'configs/seq_grow_graph/block_diffusion_config.py'
    try:
        if not check_config(config_path):
            all_passed = False
            print(f"\n⚠ Config check failed for {config_path}")
    except Exception as e:
        print(f"\n⚠ Could not check config (file may not exist): {e}")
    
    # Test functionality
    if not test_basic_functionality():
        all_passed = False
        print("\n⚠ Functionality tests failed.")
    
    # Final summary
    print("\n" + "=" * 60)
    if all_passed:
        print("✓ All checks passed! Block Diffusion is ready to use.")
        print("\nTo start training:")
        print("  python scripts/train_block_diffusion.py \\")
        print("      configs/seq_grow_graph/block_diffusion_config.py \\")
        print("      --work-dir work_dirs/bd_exp")
    else:
        print("✗ Some checks failed. Please fix the issues above.")
        sys.exit(1)
    print("=" * 60 + "\n")


if __name__ == '__main__':
    main()
