"""
Training script for Block Diffusion lane graph generation.
"""
import argparse
import os
import torch
from mmengine.config import Config
from mmengine.runner import Runner


def parse_args():
    parser = argparse.ArgumentParser(description='Train Block Diffusion model')
    parser.add_argument('config', help='train config file path')
    parser.add_argument('--work-dir', help='the dir to save logs and models')
    parser.add_argument('--resume-from', help='the checkpoint file to resume from')
    parser.add_argument('--seed', type=int, default=0, help='random seed')
    parser.add_argument('--deterministic', action='store_true',
                       help='whether to set deterministic options for CUDNN backend.')
    parser.add_argument('--launcher', choices=['none', 'pytorch', 'slurm', 'mpi'],
                       default='none', help='job launcher')
    parser.add_argument('--local_rank', type=int, default=0)
    args = parser.parse_args()
    return args


def main():
    args = parse_args()
    
    # Load config
    cfg = Config.fromfile(args.config)
    
    # Set work directory
    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    elif cfg.get('work_dir', None) is None:
        cfg.work_dir = os.path.join('./work_dirs',
                                   os.path.splitext(os.path.basename(args.config))[0])
    
    # Resume from checkpoint
    if args.resume_from is not None:
        cfg.resume_from = args.resume_from
    
    # Set random seed
    cfg.seed = args.seed
    
    # Set deterministic
    if args.deterministic:
        cfg.deterministic = True
    
    # Build runner
    runner = Runner.from_cfg(cfg)
    
    # Start training
    runner.train()


if __name__ == '__main__':
    main()
