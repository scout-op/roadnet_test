# 🔧 Data Preprocessing Fix - Token Range Overflow

**Root Cause Found**: Token values exceeding 576 due to missing clipping in data preprocessing!

---

## 🎯 Root Cause Analysis

### Token Value Breakdown (Expected)

| Token Range | Usage | Expected Max |
|-------------|-------|--------------|
| 0-199 | Node coordinates (x, y) | 199 ✅ |
| 250-349 | Node indices | 349 ✅ |
| 350-569 | Bézier coefficients | 569 ✅ |
| 570-575 | Special tokens | 575 ✅ |
| 576 | Mask token (BD only) | 576 ✅ |

**Total vocabulary**: 577 tokens (0-576)

### Where Things Went Wrong

**File**: `seq_grow_graph/transforms/loading.py`

#### Problem 1: Node Coordinates (Line 843, OLD)
```python
# OLD (WRONG):
seq = node.position[:2].astype(int).tolist()  # No clipping!
```

After data augmentation (rotation, scaling), coordinates could exceed grid bounds:
- `grid_conf`: xbound=[-48, 48, 0.5] → expected [0, 191]
- But rotation can push nodes outside → values > 200 → **OVERFLOW!**

#### Problem 2: Node Indices (Line 848, OLD)
```python
# OLD (WRONG):
seq.append(node.sque_index)  # No clipping before adding idx_start=250!
```

If `node.sque_index > 99`, then after `+250` in `seqlist2seq_with_start()`, the result > 349 → **OVERFLOW!**

#### Problem 3: Final Token Assembly (Line 904-919, OLD)
```python
# OLD (WRONG):
seq += [x, y, idx+self.idx_start]  # No final safety check
coeff = coeff + self.coeff_start  # No clipping
seq += coeff.tolist()  # If coeff is corrupted → OVERFLOW!
```

---

## ✅ Applied Fixes

### Fix 1: Clip Node Coordinates

**File**: `loading.py`, Lines 843-847

```python
# CRITICAL FIX: Clip coordinates to valid range [0, 199]
# After data augmentation (rotation, scaling), coordinates may exceed grid bounds
node_x = int(np.clip(node.position[0], 0, 199))
node_y = int(np.clip(node.position[1], 0, 199))
seq = [node_x, node_y]  # x y
```

**Why**: Ensures coordinates always in [0, 199] even after data augmentation

### Fix 2: Clip Node Indices

**File**: `loading.py`, Lines 848-851

```python
# CRITICAL FIX: Clip node index to prevent overflow when idx_start=250 is added
# Valid range for indices before adding idx_start should be [0, 99] to result in [250, 349]
node_idx_clipped = int(np.clip(node.sque_index, 0, 99))
seq.append(node_idx_clipped)  # cls
```

**Why**: `node.sque_index` can grow arbitrarily large in complex graphs. Clipping to [0, 99] ensures final tokens in [250, 349]

### Fix 3: Comprehensive Final Safety Checks

**File**: `loading.py`, Lines 906-937 (`seqlist2seq_with_start`)

```python
def seqlist2seq_with_start(self, gt_lines_sequence_list):
    seq = []
    for gt_lines_sequence in gt_lines_sequence_list:
        x, y, idx, father_seqs, child_seqs = gt_lines_sequence
        
        # CRITICAL FIX: Ensure all tokens stay within valid vocabulary range [0, 576]
        # Double-check coordinates
        x = min(max(x, 0), 199)
        y = min(max(y, 0), 199)
        node_idx_token = min(max(idx + self.idx_start, 250), 349)  # idx_start=250
        seq += [x, y, node_idx_token]
        
        for father_seq in father_seqs:
            idx, coeff = father_seq
            idx_token = min(max(idx + self.idx_start, 250), 349)
            seq.append(idx_token)
            # Coefficients: final range [350, 569]
            coeff_tokens = np.clip(coeff + self.coeff_start, 350, 569).tolist()
            seq += coeff_tokens
        seq.append(self.split_connect)  # 571
    
        for child_seq in child_seqs:
            idx, coeff = child_seq
            idx_token = min(max(idx + self.idx_start, 250), 349)
            seq.append(idx_token)
            coeff_tokens = np.clip(coeff + self.coeff_start, 350, 569).tolist()
            seq += coeff_tokens
        seq.append(self.split_node)  # 572

    return seq
```

**Why**: Final safety net to catch any edge cases

---

## 🧪 Testing

### Step 1: Rebuild Dataset Cache

The pkl files contain pre-computed sequences. After fixing the code, you need to regenerate them:

```bash
cd /data/roadnet_data/BDSEQ/mmdetection3d

# Backup old cache
mv data/nuscenes/nuscenes_infos_train.pkl data/nuscenes/nuscenes_infos_train.pkl.backup

# Regenerate
python tools/create_data.py nuscenes \
    --root-path ./data/nuscenes \
    --out-dir ./data/nuscenes \
    --extra-tag nuscenes
```

### Step 2: Verify Token Ranges

```bash
# Run the check script
python ./projects/SeqGrowGraph/scripts/simple_check.py
```

**Expected output**:
```
✅ Sample 0: range [0, 575]
✅ Sample 1: range [0, 572]
...
✅ All tokens in valid range!
```

### Step 3: Train

```bash
# Start training
CUDA_LAUNCH_BLOCKING=1 python tools/train.py \
    ./projects/SeqGrowGraph/configs/seq_grow_graph/block_diffusion_config.py \
    --work-dir work_dirs/bd_test
```

**Watch for debug output**:
```
[BD DEBUG] Input stats:
  input_seqs: shape=torch.Size([B, L]), range=[0, 575]  # ✅ Max ≤ 576!
  is_geom: X/L geometry tokens
  block_ids: range=[0, N]
```

---

## 🔄 Alternative: Quick Patch Without Regenerating Dataset

If you can't regenerate the dataset right now, the **runtime clipping in bd_rntr_head.py** will handle it:

```python
# Line 179 in bd_rntr_head.py (already applied):
input_seqs_safe = input_seqs.clamp(0, max_valid_token)  # 576
```

This provides a safety net, but it's better to fix the root cause in data preprocessing.

---

## 📊 What Changed

| Component | Location | Change | Impact |
|-----------|----------|--------|--------|
| Node coords | `loading.py:845-846` | Added `np.clip(..., 0, 199)` | Prevents coord overflow ✅ |
| Node indices | `loading.py:850` | Added `np.clip(..., 0, 99)` | Prevents index overflow ✅ |
| Final assembly | `loading.py:913-935` | Added multiple safety clips | Comprehensive protection ✅ |
| Runtime safety | `bd_rntr_head.py:179` | Added `input_seqs.clamp()` | Last-resort protection ✅ |

---

## ⚠️ Important Notes

### Data Augmentation is the Likely Culprit

The original code worked fine without augmentation, but:

1. **CenterlineRotateScale** (Line 178 in config):
   ```python
   dict(type='CenterlineRotateScale', prob=0.5, 
        max_rotate_degree=22.5, scaling_ratio_range=(0.95, 1.05))
   ```
   - Rotation can move nodes outside grid bounds
   - Scaling can expand/contract the graph

2. **CenterlineFlip** (Line 177 in config):
   ```python
   dict(type='CenterlineFlip', prob=0.5)
   ```
   - May cause boundary issues

### Why This Wasn't Caught Earlier

- **AR-only training**: Embeddings might have been larger or had padding
- **Original dataset**: Might not have had extreme cases
- **Block Diffusion**: Stricter checks exposed the issue

---

## ✅ Verification Checklist

After applying all fixes:

- [ ] Modified `loading.py` with clipping
- [ ] Regenerated dataset pkl files (OR relying on runtime clipping)
- [ ] Ran `simple_check.py` - all tokens ≤ 576
- [ ] Training starts without CUDA errors
- [ ] Debug output shows `input_seqs` max ≤ 576
- [ ] Can train for multiple iterations

---

## 🚀 Next Steps

1. **Regenerate dataset** (recommended) OR **rely on runtime clipping** (quick fix)
2. **Run training** and monitor first few iterations
3. **Remove debug prints** in `bd_rntr_head.py` after confirming stability (Lines 176-180)
4. **Full training** with confidence

---

**Status**: 🟢 Root Cause Fixed at Data Preprocessing Level

All token generation paths now have comprehensive clipping to ensure values stay within [0, 575] range (plus mask token 576 for BD).
