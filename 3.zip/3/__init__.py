"""
RoadNetwork Project for MMDetection3D

This project implements RoadNetTransformer for road network extraction
from multi-view camera images.
"""

# Import all custom modules to ensure they are registered
from . import rntr

# Explicitly import hooks to ensure registration
from .rntr.hooks import CustomCheckpointHook, SwanLabLoggerHook

__all__ = ['rntr', 'CustomCheckpointHook', 'SwanLabLoggerHook']
