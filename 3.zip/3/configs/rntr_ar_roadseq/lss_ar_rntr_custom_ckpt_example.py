"""
AR-RNTR Example Config with Enhanced Visualization and Custom Checkpoint Path

Key Features:
1. ✅ Enhanced BEV visualization with Bezier curves (colored by edge type)
2. ✅ Custom checkpoint save path (logs remain in work_dir)

Usage:
    # Basic training (checkpoints in work_dir)
    SWANLAB_ENABLE=1 ./tools/dist_train.sh \
      configs/rntr_ar_roadseq/lss_ar_rntr_custom_ckpt_example.py 4 \
      --work-dir ./work_dirs/ar_custom_example

    # Training with custom checkpoint path
    SWANLAB_ENABLE=1 ./tools/dist_train.sh \
      configs/rntr_ar_roadseq/lss_ar_rntr_custom_ckpt_example.py 4 \
      --work-dir ./work_dirs/ar_custom_example \
      --cfg-options \
        custom_hooks.0.enable_custom_path=True \
        custom_hooks.0.custom_checkpoint_dir=/your/path/to/checkpoints
"""

_base_ = ['./lss_ar_rntr_changeloss_test_fp16_torch2.py']

# ==============================================================================
# 📌 Custom Checkpoint Hook Configuration
# ==============================================================================
# Replace the default checkpoint hook with CustomCheckpointHook
default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=1),
    param_scheduler=dict(type='ParamSchedulerHook'),
    # Use CustomCheckpointHook instead of CheckpointHook
    checkpoint=dict(
        type='CustomCheckpointHook',
        # 🔧 Enable/Disable custom path
        enable_custom_path=False,  # Set to True to use custom path
        # 📁 Custom checkpoint directory (absolute or relative)
        custom_checkpoint_dir=None,  # e.g., '/data/my_checkpoints/ar_rntr'
        # Standard checkpoint options
        interval=10,  # Save every 10 epochs
        by_epoch=True,
        max_keep_ckpts=5,  # Keep only latest 5 checkpoints
        save_last=True,
        save_best='auto',  # Auto-detect best metric (e.g., Reachability_F1)
    ),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='Det3DVisualizationHook')
)

# ==============================================================================
# 📊 SwanLab Visualization (Enhanced BEV with Bezier curves)
# ==============================================================================
custom_hooks = [
    dict(
        type='SwanLabLoggerHook',
        enable=True,
        project='RoadNet',
        run_name='ar_rntr_custom_ckpt',
        log_interval=50,
        image_interval=100,  # Save BEV visualization every 100 steps
    ),
]

# ==============================================================================
# 📝 Usage Examples
# ==============================================================================
"""
Example 1: Default behavior (checkpoints in work_dir)
------------------------------------------------------
SWANLAB_ENABLE=1 ./tools/dist_train.sh \\
  configs/rntr_ar_roadseq/lss_ar_rntr_custom_ckpt_example.py 4 \\
  --work-dir ./work_dirs/ar_test

Result:
  - Checkpoints: ./work_dirs/ar_test/epoch_*.pth
  - Logs: ./work_dirs/ar_test/*.log
  - SwanLab vis: vis/bev_overlay (with Bezier curves!)


Example 2: Custom absolute checkpoint path
-------------------------------------------
SWANLAB_ENABLE=1 ./tools/dist_train.sh \\
  configs/rntr_ar_roadseq/lss_ar_rntr_custom_ckpt_example.py 4 \\
  --work-dir ./work_dirs/ar_test \\
  --cfg-options \\
    default_hooks.checkpoint.enable_custom_path=True \\
    default_hooks.checkpoint.custom_checkpoint_dir=/data/shared_ckpts/ar_rntr

Result:
  - Checkpoints: /data/shared_ckpts/ar_rntr/epoch_*.pth
  - Logs: ./work_dirs/ar_test/*.log (unchanged)
  - SwanLab vis: vis/bev_overlay


Example 3: Custom relative checkpoint path
-------------------------------------------
SWANLAB_ENABLE=1 ./tools/dist_train.sh \\
  configs/rntr_ar_roadseq/lss_ar_rntr_custom_ckpt_example.py 4 \\
  --work-dir ./work_dirs/ar_exp1 \\
  --cfg-options \\
    default_hooks.checkpoint.enable_custom_path=True \\
    default_hooks.checkpoint.custom_checkpoint_dir=../shared_checkpoints/ar_exp1

Result:
  - Checkpoints: ./work_dirs/shared_checkpoints/ar_exp1/epoch_*.pth
  - Logs: ./work_dirs/ar_exp1/*.log


Example 4: Save best checkpoint by specific metric
---------------------------------------------------
SWANLAB_ENABLE=1 ./tools/dist_train.sh \\
  configs/rntr_ar_roadseq/lss_ar_rntr_custom_ckpt_example.py 4 \\
  --work-dir ./work_dirs/ar_test \\
  --cfg-options \\
    default_hooks.checkpoint.enable_custom_path=True \\
    default_hooks.checkpoint.custom_checkpoint_dir=/data/my_ckpts \\
    default_hooks.checkpoint.save_best=Reachability_F1 \\
    default_hooks.checkpoint.max_keep_ckpts=3

Result:
  - Saves best_Reachability_F1.pth + last 3 checkpoints
"""
