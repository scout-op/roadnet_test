"""
Block Diffusion utilities for lane graph generation.
Includes mask generation, resampling, and helper functions.
"""
import torch
import torch.nn.functional as F


def block_diff_mask(q_idx, kv_idx, block_ids, is_geom, n, block_size):
    """
    Constructs the block diffusion attention mask for training.
    Adapted from bd3lms but customized for geometry/topology split.
    
    Three component masks:
    - M_BD (Block Diagonal): Self-attention within noised geometry blocks
    - M_OBC (Offset Block Causal): Cross-attention from noised to clean prefix
    - M_BC (Block Causal): Attention within clean blocks
    - M_AR (Autoregressive): For connection tokens
    
    Args:
        q_idx: Query indices [seq_len*2]
        kv_idx: Key indices [seq_len*2]
        block_ids: Block ID for each position [seq_len]
        is_geom: Whether each position is geometry token [seq_len]
        n: Original sequence length (before concatenation)
        block_size: Block size for diffusion
    
    Returns:
        Boolean attention mask [seq_len*2, seq_len*2]
    """
    # Determine if token belongs to noised (xt) or clean (x0) segment
    xt_flag_q = (q_idx < n)
    x0_flag_q = (~xt_flag_q)
    xt_flag_kv = (kv_idx < n)
    x0_flag_kv = (~xt_flag_kv)

    # Compute safe base indices into original [0, n-1]
    idx_q_base = q_idx - x0_flag_q.long() * n  # [2L,1], values in [0, n-1]
    idx_kv_base = kv_idx - x0_flag_kv.long() * n  # [1,2L]

    # Get geometry flags for q and kv (broadcast to 2D)
    geom_q = is_geom[idx_q_base].to(torch.bool)  # [2L,1]
    geom_kv = is_geom[idx_kv_base].to(torch.bool)  # [1,2L]

    # Compute block indices for q and kv (broadcast to 2D)
    block_q = block_ids[idx_q_base]  # [2L,1]
    block_kv = block_ids[idx_kv_base]  # [1,2L]
    
    # Only geometry tokens in xt segment are actually noised
    noised_q = xt_flag_q & geom_q
    noised_kv = xt_flag_kv & geom_kv
    
    # 1. Block Diagonal (M_BD): noised geometry blocks attend to themselves
    M_BD = noised_q & noised_kv & (block_q == block_kv)
    
    # 2. Offset Block Causal (M_OBC): noised blocks attend to clean prefix
    M_OBC = noised_q & x0_flag_kv & (block_q > block_kv)
    
    # 3. Block Causal (M_BC): clean blocks attend to clean prefix (block causal)
    M_BC = x0_flag_q & x0_flag_kv & (block_q >= block_kv)
    
    # 4. Connection tokens in xt segment (not noised) use standard causal
    conn_q = xt_flag_q & (~geom_q)
    M_CONN = conn_q & (q_idx >= kv_idx)
    
    # Combine all masks
    return M_BD | M_OBC | M_BC | M_CONN


def create_block_causal_mask(seq_len, block_size, block_ids, is_geom, device='cuda'):
    """
    Create block-causal attention mask for training with concatenated [xt, x0].
    
    Args:
        seq_len: Original sequence length
        block_size: Not used here (using block_ids instead)
        block_ids: Block ID tensor [seq_len]
        is_geom: Geometry flag tensor [seq_len]
        device: torch device
    
    Returns:
        Attention mask [2*seq_len, 2*seq_len]
    """
    total_len = seq_len * 2
    q_idx = torch.arange(total_len, device=device)[:, None]
    kv_idx = torch.arange(total_len, device=device)[None, :]
    
    block_ids = block_ids.to(device)
    is_geom = is_geom.to(device)
    
    mask = block_diff_mask(q_idx, kv_idx, block_ids, is_geom, 
                          seq_len, block_size)
    
    # Convert to float mask for attention (True -> 0, False -> -inf)
    float_mask = torch.zeros_like(mask, dtype=torch.float32)
    float_mask.masked_fill_(~mask, float('-inf'))
    
    return float_mask


def sample_t_per_block(batch_size, num_blocks, sampling_eps_min, sampling_eps_max, 
                       device='cuda', antithetic=True):
    """
    Sample diffusion timesteps per block with optional antithetic sampling.
    
    Args:
        batch_size: Batch size
        num_blocks: Number of blocks in sequence
        sampling_eps_min: Minimum mask rate (clipped schedule)
        sampling_eps_max: Maximum mask rate (clipped schedule)
        device: torch device
        antithetic: Use antithetic sampling to reduce variance
    
    Returns:
        Timesteps tensor [batch_size, num_blocks]
    """
    _eps_b = torch.rand((batch_size, num_blocks), device=device)
    
    # Antithetic sampling along blocks & batches
    if antithetic:
        total_samples = batch_size * num_blocks
        offset_b = torch.arange(total_samples, device=device) / total_samples
        offset_b = offset_b.view(batch_size, num_blocks)
        _eps_b = (_eps_b / total_samples + offset_b) % 1
    
    # Scale to [sampling_eps_min, sampling_eps_max]
    t = _eps_b * (sampling_eps_max - sampling_eps_min) + sampling_eps_min
    
    return t


def q_xt_geom_only(x0, move_prob, is_geom, mask_index):
    """
    Apply noise to geometry tokens only.
    
    Args:
        x0: Clean tokens [B, L]
        move_prob: Mask probability per token [B, L]
        is_geom: Geometry flag [L] or [B, L]
        mask_index: Index for [MASK] token
    
    Returns:
        xt: Noised tokens [B, L]
    """
    # Expand is_geom to batch if needed
    if is_geom.dim() == 1:
        is_geom = is_geom.unsqueeze(0).expand_as(x0)
    
    # Sample which tokens to mask
    move_indices = (torch.rand_like(x0, dtype=torch.float32) < move_prob) & is_geom
    
    # Apply mask only to geometry tokens
    xt = torch.where(move_indices, mask_index, x0)
    
    return xt


def resample_q_xt_per_block(x0, xt, move_prob, is_geom, block_ids, 
                             mask_index, sampling_eps_min, sampling_eps_max,
                             max_iter=100):
    """
    Resample xt to ensure each block's mask rate is within [eps_min, eps_max].
    Adapted from bd3lms/_resample_q_xt.
    
    Args:
        x0: Clean tokens [B, L]
        xt: Initial noised tokens [B, L]
        move_prob: Move probability [B, L]
        is_geom: Geometry flags [L]
        block_ids: Block IDs [L]
        mask_index: [MASK] token index
        sampling_eps_min: Min mask rate per block
        sampling_eps_max: Max mask rate per block
        max_iter: Maximum resampling iterations
    
    Returns:
        xt: Resampled tokens [B, L]
    """
    B, L = x0.shape
    device = x0.device
    
    if is_geom.dim() == 1:
        is_geom = is_geom.unsqueeze(0).expand(B, L)
    if block_ids.dim() == 1:
        block_ids = block_ids.unsqueeze(0).expand(B, L)
    
    unique_blocks = torch.unique(block_ids[0])  # Assume same blocks across batch
    
    for _ in range(max_iter):
        need_resample = torch.zeros(B, dtype=torch.bool, device=device)
        
        for block_id in unique_blocks:
            block_mask = (block_ids == block_id)
            geom_in_block = block_mask & is_geom

            # Skip entire block if across all samples there are no geometry tokens
            if not geom_in_block.any():
                continue

            # Per-sample counts
            denom = geom_in_block.float().sum(dim=1)  # [B]
            masked_in_block = (xt == mask_index) & geom_in_block
            numer = masked_in_block.float().sum(dim=1)  # [B]

            # Avoid division by zero; for denom==0, treat as already valid (no resample)
            safe_denom = torch.clamp(denom, min=1.0)
            mask_rate = numer / safe_denom

            # Only consider samples with denom>0
            valid = denom > 0
            block_needs_resample = valid & ((mask_rate < sampling_eps_min) | (mask_rate > sampling_eps_max))
            need_resample |= block_needs_resample
        
        if not need_resample.any():
            break
        
        # Resample for those that need it
        new_move_indices = (torch.rand_like(x0, dtype=torch.float32) < move_prob) & is_geom
        need_resample_expanded = need_resample.unsqueeze(1).expand_as(x0)
        # For samples needing resample, regenerate xt using new_move_indices; others remain unchanged
        xt = torch.where(need_resample_expanded & new_move_indices, mask_index,
                         torch.where(need_resample_expanded, x0, xt))
    
    return xt


def _sample_categorical(categorical_probs):
    """Sample from categorical distribution using Gumbel-max trick."""
    gumbel_norm = (1e-10 - (torch.rand_like(categorical_probs) + 1e-10).log())
    samples = (categorical_probs / gumbel_norm).argmax(dim=-1)
    return samples
