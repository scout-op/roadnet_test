"""
Noise schedules for block diffusion training.
Adapted from bd3lms/noise_schedule.py
"""
import abc
import torch
import torch.nn as nn


class Noise(abc.ABC, nn.Module):
    """Base class for noise schedules."""
    
    def forward(self, t):
        return self.compute_loss_scaling_and_move_chance(t)
    
    @abc.abstractmethod
    def compute_loss_scaling_and_move_chance(self, t):
        """Compute loss scaling and move chance (mask probability) at time t."""
        pass


class LogLinearNoise(Noise):
    """Log Linear noise schedule.
    
    Built such that 1 - 1/e^(n(t)) interpolates between 0 and ~1 
    when t varies from 0 to 1.
    """
    def __init__(self, eps=1e-3):
        super().__init__()
        self.eps = eps
        self.sigma_max = self.total_noise(torch.tensor(1.0))
        self.sigma_min = self.eps + self.total_noise(torch.tensor(0.0))

    def rate_noise(self, t):
        return (1 - self.eps) / (1 - (1 - self.eps) * t)

    def total_noise(self, t):
        return -torch.log1p(-(1 - self.eps) * t)

    def compute_loss_scaling_and_move_chance(self, t):
        t = torch.as_tensor(t, dtype=torch.float32, device=t.device)
        move_chance = t.clamp(min=self.eps, max=1.0 - self.eps)
        loss_scaling = 1.0 / move_chance
        return loss_scaling, move_chance


class CosineNoise(Noise):
    """Cosine noise schedule."""
    def __init__(self, eps=1e-3):
        super().__init__()
        self.eps = eps

    def compute_loss_scaling_and_move_chance(self, t):
        t = torch.as_tensor(t, dtype=torch.float32, device=t.device)
        cos = torch.cos(t * torch.pi / 2)
        sin = torch.sin(t * torch.pi / 2)
        move_chance = (1 - self.eps) * (1 - cos)
        move_chance = move_chance.clamp(min=self.eps, max=1.0 - self.eps)
        loss_scaling = (sin.abs() + self.eps) / (move_chance + self.eps) * (torch.pi / 2)
        return loss_scaling, move_chance


class ExpNoise(Noise):
    """Exponential noise schedule."""
    def __init__(self, exp=2, eps=1e-3):
        super().__init__()
        self.eps = eps
        self.exp = exp
    
    def compute_loss_scaling_and_move_chance(self, t):
        t = torch.as_tensor(t, dtype=torch.float32, device=t.device)
        move_chance = torch.pow(t.clamp(min=self.eps), self.exp)
        move_chance = torch.clamp(move_chance, min=self.eps, max=1.0 - self.eps)
        loss_scaling = (self.exp * torch.pow(t.clamp(min=self.eps), self.exp - 1)) / (move_chance + self.eps)
        return loss_scaling.abs(), move_chance


def get_noise(noise_type='loglinear', **kwargs):
    """Factory function to get noise schedule."""
    if noise_type == 'loglinear':
        return LogLinearNoise(**kwargs)
    elif noise_type == 'cosine':
        return CosineNoise(**kwargs)
    elif noise_type == 'square':
        return ExpNoise(exp=2, **kwargs)
    elif noise_type == 'square_root':
        return ExpNoise(exp=0.5, **kwargs)
    else:
        raise ValueError(f'{noise_type} is not a valid noise type')
