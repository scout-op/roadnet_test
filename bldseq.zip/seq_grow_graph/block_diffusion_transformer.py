"""
Block Diffusion Transformer for lane graph generation.
Supports concatenated [xt, x0] input with block diffusion mask.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import Linear, build_norm_layer
from mmdet3d.registry import MODELS
from mmengine.model import BaseModule
from typing import Optional
import math


class BlockDiffusionDecoderLayer(nn.Module):
    """
    Transformer decoder layer with support for:
    - Block diffusion attention mask
    - KV caching for inference
    """
    
    def __init__(self, d_model=256, nhead=8, dim_feedforward=2048, 
                 dropout=0.1, activation='relu'):
        super().__init__()
        self.self_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=True)
        self.multihead_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=True)
        
        # Feedforward
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(dim_feedforward, d_model)
        
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.norm3 = nn.LayerNorm(d_model)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.dropout3 = nn.Dropout(dropout)
        
        self.activation = F.relu if activation == 'relu' else F.gelu
        
        # KV cache for inference
        self.kv_cache_self = None
        self.kv_cache_cross = None
        self.cache_idx = 0
    
    def forward(self, tgt, memory, tgt_mask=None, memory_mask=None,
                tgt_key_padding_mask=None, memory_key_padding_mask=None,
                pos=None, query_pos=None, use_cache=False, store_cache=False):
        """
        Args:
            tgt: [B, L, D] target sequence
            memory: [B, M, D] memory from encoder
            tgt_mask: [L, L] or [B, L, L] attention mask for self-attention
            memory_mask: [L, M] attention mask for cross-attention
            pos: [B, M, D] positional encoding for memory
            query_pos: [B, L, D] positional encoding for query
            use_cache: Whether to use cached KV
            store_cache: Whether to store KV to cache
        """
        # Self-attention with residual
        q = k = tgt + query_pos if query_pos is not None else tgt
        
        if use_cache and self.kv_cache_self is not None:
            # Use cached KV for self-attention
            tgt2 = self.self_attn(q, self.kv_cache_self, self.kv_cache_self,
                                 attn_mask=tgt_mask,
                                 key_padding_mask=tgt_key_padding_mask)[0]
        else:
            tgt2 = self.self_attn(q, k, tgt,
                                 attn_mask=tgt_mask,
                                 key_padding_mask=tgt_key_padding_mask)[0]
        
        if store_cache:
            self.kv_cache_self = k.detach()
        
        tgt = tgt + self.dropout1(tgt2)
        tgt = self.norm1(tgt)
        
        # Cross-attention with memory
        if memory is not None:
            q = tgt + query_pos if query_pos is not None else tgt
            k = memory + pos if pos is not None else memory
            
            tgt2 = self.multihead_attn(q, k, memory,
                                      attn_mask=memory_mask,
                                      key_padding_mask=memory_key_padding_mask)[0]
            tgt = tgt + self.dropout2(tgt2)
            tgt = self.norm2(tgt)
        
        # Feedforward
        tgt2 = self.linear2(self.dropout(self.activation(self.linear1(tgt))))
        tgt = tgt + self.dropout3(tgt2)
        tgt = self.norm3(tgt)
        
        return tgt
    
    def reset_cache(self):
        """Reset KV cache."""
        self.kv_cache_self = None
        self.kv_cache_cross = None
        self.cache_idx = 0


@MODELS.register_module()
class BlockDiffusionTransformerDecoder(BaseModule):
    """
    Block Diffusion Transformer Decoder.
    Supports both training (with block diffusion mask) and inference (with KV caching).
    """
    
    def __init__(self, d_model=256, nhead=8, num_layers=6, 
                 dim_feedforward=2048, dropout=0.1, 
                 activation='relu', return_intermediate=False,
                 init_cfg=None):
        super().__init__(init_cfg=init_cfg)
        
        self.layers = nn.ModuleList([
            BlockDiffusionDecoderLayer(d_model, nhead, dim_feedforward, 
                                      dropout, activation)
            for _ in range(num_layers)
        ])
        
        self.num_layers = num_layers
        self.d_model = d_model
        self.return_intermediate = return_intermediate
        self.embed_dims = d_model
    
    def forward(self, tgt, memory, tgt_mask=None, memory_mask=None,
                tgt_key_padding_mask=None, memory_key_padding_mask=None,
                pos=None, query_pos=None, use_cache=False, store_cache=False):
        """
        Args:
            tgt: [B, L, D] target sequence
            memory: [B, M, D] memory from encoder
            tgt_mask: [L, L] or [B*nhead, L, L] self-attention mask
            memory_mask: [L, M] cross-attention mask
            pos: [B, M, D] positional encoding for memory
            query_pos: [B, L, D] positional encoding for query
            use_cache: Use KV cache (inference)
            store_cache: Store to KV cache (inference)
        
        Returns:
            output: [num_layers, B, L, D] if return_intermediate else [1, B, L, D]
        """
        output = tgt
        intermediate = []
        
        for layer in self.layers:
            output = layer(output, memory, tgt_mask, memory_mask,
                          tgt_key_padding_mask, memory_key_padding_mask,
                          pos, query_pos, use_cache, store_cache)
            if self.return_intermediate:
                intermediate.append(output)
        
        if self.return_intermediate:
            return torch.stack(intermediate)
        
        return output.unsqueeze(0)
    
    def reset_cache(self):
        """Reset KV cache for all layers."""
        for layer in self.layers:
            layer.reset_cache()


@MODELS.register_module()
class BlockDiffusionTransformer(BaseModule):
    """
    Complete Block Diffusion Transformer with encoder and decoder.
    For lane graph generation with BD training.
    """
    
    def __init__(self, encoder=None, decoder=None, init_cfg=None):
        super().__init__(init_cfg=init_cfg)
        
        # Build decoder (encoder can be shared from existing BEV encoder)
        if isinstance(decoder, dict):
            self.decoder = BlockDiffusionTransformerDecoder(**decoder)
        else:
            self.decoder = decoder
        
        self.embed_dims = self.decoder.embed_dims
        self.encoder = None  # Use existing BEV features as memory
    
    def init_weights(self):
        """Initialize weights."""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.LayerNorm):
                nn.init.constant_(m.bias, 0)
                nn.init.constant_(m.weight, 1.0)
        self._is_init = True
    
    def forward(self, tgt, memory, memory_mask=None, 
                query_pos=None, pos_embed=None,
                tgt_mask=None, use_cache=False, store_cache=False):
        """
        Forward pass for block diffusion transformer.
        
        Args:
            tgt: [B, L, D] target embeddings (can be [xt, x0] concatenated)
            memory: [B, H*W, D] BEV features
            memory_mask: [B, H*W] padding mask for memory
            query_pos: [B, L, D] query positional embeddings
            pos_embed: [B, H*W, D] positional embeddings for memory
            tgt_mask: [L, L] or [B, L, L] block diffusion mask
            use_cache: Use KV cache (inference mode)
            store_cache: Store KV cache (inference mode)
        
        Returns:
            output: [num_layers, B, L, D] or [1, B, L, D] decoder output
        """
        # Decoder forward
        output = self.decoder(
            tgt=tgt,
            memory=memory,
            tgt_mask=tgt_mask,
            memory_mask=None,
            tgt_key_padding_mask=None,
            memory_key_padding_mask=memory_mask,
            pos=pos_embed,
            query_pos=query_pos,
            use_cache=use_cache,
            store_cache=store_cache
        )
        
        return output
    
    def reset_cache(self):
        """Reset KV cache in decoder."""
        self.decoder.reset_cache()
