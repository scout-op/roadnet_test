# Block Diffusion for Lane Graph Generation

## Overview

This implementation adds **Block Diffusion (BD)** capabilities to SeqGrowGraph for lane graph generation. The approach combines:
- **Block Diffusion** for geometry tokens (coordinates, Bézier parameters) - enables parallel generation
- **Autoregressive** for topology tokens (connections) - maintains graph consistency

Based on the bd3lms paper and adapted for structured graph generation.

## Key Components

### 1. Core Modules

#### `noise_schedule.py`
Noise schedules for diffusion training:
- `LogLinearNoise` - Default schedule
- `CosineNoise` - Alternative cosine schedule
- `ExpNoise` - Exponential schedules (square, square_root)

#### `block_diffusion_utils.py`
Utility functions:
- `block_diff_mask()` - Creates 3-part attention mask (M_BD, M_OBC, M_BC)
- `sample_t_per_block()` - Samples timesteps with clipped schedule
- `q_xt_geom_only()` - Applies noise only to geometry tokens
- `resample_q_xt_per_block()` - Resamples to enforce mask rate bounds

#### `block_diffusion_transformer.py`
Transformer with BD support:
- `BlockDiffusionDecoderLayer` - Decoder layer with KV caching
- `BlockDiffusionTransformerDecoder` - Full decoder
- `BlockDiffusionTransformer` - Complete transformer

#### `bd_rntr_head.py`
Main head extending `ARRNTRHead`:
- Dual-branch training: AR + BD losses
- Token type annotation (geometry vs connection)
- Block-level mask rate control with resampling

### 2. Configuration

`configs/seq_grow_graph/block_diffusion_config.py`:
```python
block_diffusion = dict(
    enabled=True,
    noise_type='loglinear',
    sampling_eps_min=0.5,  # Min mask rate
    sampling_eps_max=1.0,  # Max mask rate
    bd_loss_weight=0.1,    # BD loss weight
    num_denoising_steps=4, # Inference steps
)
```

## Quick Start

### Installation & Dependencies

Ensure all modules are properly registered:
```python
# Verify imports
from seq_grow_graph import BDRNTRHead, BlockDiffusionTransformer
from seq_grow_graph.noise_schedule import get_noise
from seq_grow_graph.block_diffusion_utils import create_block_causal_mask
```

### Training

```bash
# Basic training
python scripts/train_block_diffusion.py configs/seq_grow_graph/block_diffusion_config.py

# With custom work directory
python scripts/train_block_diffusion.py configs/seq_grow_graph/block_diffusion_config.py --work-dir work_dirs/bd_exp

# Resume from checkpoint
python scripts/train_block_diffusion.py configs/seq_grow_graph/block_diffusion_config.py --resume-from work_dirs/bd_exp/latest.pth

# Multi-GPU distributed training
BASH_ENV=~/.bashrc bash tools/dist_train.sh configs/seq_grow_graph/block_diffusion_config.py 4
```

### Inference

#### Standard Inference (AR + BD Refinement)
```python
# Inference with BD geometry refinement enabled
# Set num_denoising_steps > 0 in config to enable BD refinement
results = model.predict(test_data)
```

#### AR-Only Inference (Fallback)
```python
# To use pure AR without BD refinement, set num_denoising_steps=0
# Or use the original ARRNTRHead configuration
```

#### Programmatic Inference
```python
import torch
from mmengine.config import Config
from mmengine.runner import Runner

cfg = Config.fromfile('configs/seq_grow_graph/block_diffusion_config.py')
runner = Runner.from_cfg(cfg)

# Load checkpoint
runner.load_checkpoint('work_dirs/bd_exp/best.pth')

# Run inference
with torch.no_grad():
    for data_batch in test_dataloader:
        results = runner.model.predict(data_batch)
        # Process results...
```

## Hyperparameter Tuning Guide

### Key Parameters

| Parameter | Default | Range | Effect |
|-----------|---------|-------|--------|
| `bd_loss_weight` | 0.1 | 0.05-0.5 | Weight of BD loss vs AR loss. Higher = more focus on geometry quality |
| `sampling_eps_min` | 0.5 | 0.3-0.7 | Minimum mask rate per block. Lower = more masked tokens |
| `sampling_eps_max` | 1.0 | 0.8-1.0 | Maximum mask rate per block. Keep close to 1.0 |
| `noise_type` | 'loglinear' | loglinear/cosine/square | Noise schedule type. Loglinear is most stable |
| `num_denoising_steps` | 4 | 1-8 | BD refinement steps at inference. More steps = better but slower |
| `use_resample` | True | True/False | Enable mask rate resampling. Reduces variance but slower |

### Training Tips

1. **Start with conservative settings**:
   - `bd_loss_weight=0.1`, `sampling_eps_min=0.5`, `sampling_eps_max=1.0`
   - Monitor both `loss_coords` (AR) and `loss_bd` in logs

2. **Gradually increase BD weight**:
   - If geometry quality is poor, increase `bd_loss_weight` to 0.2-0.3
   - If topology breaks, decrease `bd_loss_weight` to 0.05

3. **Adjust clipping interval**:
   - If training loss is unstable, widen interval: `[0.3, 1.0]`
   - For more aggressive masking, narrow interval: `[0.6, 0.9]`

4. **Learning rate**:
   - Start with 2e-4 (lower than AR-only 4e-4)
   - Use warmup for first 500 iterations
   - Cosine annealing with restarts works well

### Monitoring Training

Watch these metrics in TensorBoard/logs:
```python
# Good training:
- loss_coords: steadily decreasing (AR branch)
- loss_bd: decreasing but may fluctuate (BD branch)
- loss_total: smooth decrease
- Landmark/Reachability metrics: improving

# Bad training:
- loss_bd spikes or NaN → reduce bd_loss_weight or lr
- loss_coords increases → AR branch is suffering, reduce bd_loss_weight
- Both losses stuck → increase lr or check data pipeline
```

## Troubleshooting

### Common Issues

#### 1. **Training loss NaN/Inf**
**Symptoms**: Loss becomes NaN after a few iterations

**Solutions**:
- ✓ Check `noise_eps` parameter (should be 1e-3, not 0)
- ✓ Enable gradient clipping: `clip_grad=dict(max_norm=35, norm_type=2)`
- ✓ Reduce learning rate to 1e-4
- ✓ Check for corrupted data samples
- ✓ Ensure `move_chance` is clamped in noise schedule

#### 2. **Memory OOM errors**
**Symptoms**: CUDA out of memory during training

**Solutions**:
- ✓ Reduce `batch_size` (try 8 → 4)
- ✓ Reduce `max_center_len` (try 700 → 500)
- ✓ Shorten sequences by filtering long samples
- ✓ Use `with_cp=True` in transformer config (gradient checkpointing)
- ✓ Reduce number of transformer layers or hidden dims

#### 3. **Slow training speed**
**Symptoms**: <0.5 it/s or slower than AR baseline

**Solutions**:
- ✓ Disable `use_resample=False` for 20-30% speedup
- ✓ Reduce `num_blocks` by limiting graph complexity
- ✓ Use FlashAttention: `LssSeqLineFlashTransformer` instead of `LssSeqLineTransformer`
- ✓ Enable mixed precision training (AMP)
- ✓ Profile with `torch.profiler` to find bottlenecks

#### 4. **BD loss not decreasing**
**Symptoms**: `loss_bd` stays high while `loss_coords` decreases

**Solutions**:
- ✓ Check token annotation: verify `annotate_tokens` correctly marks geometry vs connection
- ✓ Increase `bd_loss_weight` to 0.2 or higher
- ✓ Verify mask is correctly applied (print mask sparsity)
- ✓ Check if geometry tokens are in valid range
- ✓ Try different noise schedule (cosine instead of loglinear)

#### 5. **Inference slower than expected**
**Symptoms**: BD inference takes >2s per sample

**Solutions**:
- ✓ Reduce `num_denoising_steps` to 1-2 for faster inference
- ✓ Use KV caching with `BlockDiffusionTransformer` (not yet enabled by default)
- ✓ Batch inference if possible
- ✓ Profile to check if BD mask generation is bottleneck

#### 6. **Geometry quality worse than AR baseline**
**Symptoms**: Bézier curves are distorted, landmarks off

**Solutions**:
- ✓ Increase `bd_loss_weight` significantly (0.3-0.5)
- ✓ Train longer (BD needs more epochs to converge)
- ✓ Check clipping interval: try wider range `[0.3, 1.0]`
- ✓ Verify positional encoding length matches input
- ✓ Ensure geometry tokens are correctly identified in `annotate_tokens`

#### 7. **Topology breaks (disconnected graphs)**
**Symptoms**: Connection accuracy drops, graphs fragmented

**Solutions**:
- ✓ Decrease `bd_loss_weight` to 0.05 (AR branch is being starved)
- ✓ Ensure connection tokens are NOT masked during BD
- ✓ Check `is_geom` flag correctness in `annotate_tokens`
- ✓ Train AR branch first, then fine-tune with BD

### Debug Utilities

```python
# Print token annotations
from seq_grow_graph.bd_rntr_head import BDRNTRHead
special_tokens = {'split_connect': 571, 'split_node': 572, ...}
is_geom, block_ids = head.annotate_tokens(input_seqs, special_tokens)
print(f"Geometry tokens: {is_geom.sum()} / {len(is_geom)}")
print(f"Blocks: {block_ids.max().item() + 1}")

# Visualize attention mask
import matplotlib.pyplot as plt
from seq_grow_graph.block_diffusion_utils import create_block_causal_mask
mask = create_block_causal_mask(L, 1, block_ids, is_geom, device)
plt.imshow(mask.cpu().numpy(), cmap='RdBu', vmin=-100, vmax=0)
plt.title('Block Diffusion Attention Mask')
plt.savefig('bd_mask.png')

# Check loss scales
from seq_grow_graph.noise_schedule import get_noise
noise_fn = get_noise('loglinear', eps=1e-3)
t = torch.linspace(0.3, 1.0, 100)
loss_scale, move_prob = noise_fn(t)
plt.plot(t, loss_scale, label='loss_scale')
plt.plot(t, move_prob, label='move_prob')
plt.legend()
plt.savefig('noise_schedule.png')
```

## Usage

### Training

```bash
cd SeqGrowGraph
python scripts/train_block_diffusion.py \
    configs/seq_grow_graph/block_diffusion_config.py \
    --work-dir work_dirs/bd_experiment
```

### Key Parameters to Tune

1. **Noise Schedule Clipping** (`sampling_eps_min/max`):
   - Start with `[0.5, 1.0]` or `[0.3, 0.8]`
   - Lower min = more aggressive masking
   - Grid search for best validation variance

2. **BD Loss Weight** (`bd_loss_weight`):
   - Start with `0.1`
   - Increase if geometry quality needs improvement
   - Decrease if topology metrics degrade

3. **Denoising Steps** (`num_denoising_steps`):
   - 1-4 steps for inference
   - More steps = better quality, slower inference
   - Balance speed vs accuracy

## Implementation Details

### Training Flow

1. **Annotate Tokens**: Mark geometry vs connection tokens
2. **Sample Timesteps**: Per-block sampling with clipped schedule U[β, ω]
3. **Apply Noise**: Only to geometry tokens, connections stay clean
4. **Resample**: Ensure each block's mask rate ∈ [β, ω]
5. **Concatenate**: Create `[x_t, x_0]` input (length 2L)
6. **Forward**: Use 3-part block diffusion mask
7. **Compute Loss**: 
   - `L_AR` on connections (standard CE)
   - `L_BD` on masked geometry (weighted CE)
   - `L_total = L_AR + λ * L_BD`

### Inference Flow (per node block)

1. **Initialize**: Geometry tokens as `[MASK]`
2. **Denoise**: 1-4 steps with block diffusion
3. **AR Generate**: Connections conditioned on geometry
4. **Update Cache**: Store KV for next block
5. **Repeat**: Until graph complete

### Three-Part Attention Mask

The block diffusion mask combines:
- **M_BD**: Noised geometry blocks attend to themselves (block diagonal)
- **M_OBC**: Noised blocks attend to clean prefix (offset block causal)
- **M_BC**: Clean blocks use standard block causal
- **M_AR**: Connection tokens use standard AR causal

## Expected Results

### Performance
- **Inference Speed**: 2-4× faster (block-level parallelization)
- **Landmark F1**: +0 to +2 points (geometry quality)
- **Reachability F1**: ±1 point (topology preserved)

### Training Stability
- Clipped schedule + resampling reduces variance
- Monitor both `loss_coords` (AR) and `loss_bd` (BD)
- Variance tracking helps optimize β, ω intervals

## Advanced Features (Future)

1. **Goal-Driven Generation** (from GoalFlow):
   - Add goal node vocabulary
   - Score and condition on target nodes
   - Reduces generation divergence

2. **Drivable Area Constraints**:
   - Use BEV segmentation to filter invalid geometry
   - Project out-of-bound tokens to nearest valid region

3. **Variance-Driven Schedule Search**:
   - Track validation loss variance per clipping interval
   - Automatically select β, ω that minimize variance

4. **Flow Matching for Geometry Refinement**:
   - Post-process with continuous flow matching
   - Smooth Bézier curves and improve continuity

## Troubleshooting

### Training Issues

**High BD Loss**:
- Increase `bd_loss_weight` gradually
- Check if geometry tokens are correctly annotated
- Verify mask rate is within [β, ω]

**Poor Topology (Reachability drops)**:
- Reduce `bd_loss_weight` (prioritize AR)
- Ensure connection tokens are NOT masked
- Check block boundaries align with `split_node`

**Training Instability**:
- Enable `use_resample=True`
- Start with wider interval like `[0.3, 1.0]`
- Reduce learning rate (try `1e-4`)

### Inference Issues

**Slow Generation**:
- Reduce `num_denoising_steps` (try 1-2)
- Enable `use_kv_cache=True`
- Check block size is reasonable

**Poor Geometry Quality**:
- Increase `num_denoising_steps` (try 6-8)
- Add drivable area constraints
- Tune sampling temperature/nucleus_p

## File Structure

```
SeqGrowGraph/
├── seq_grow_graph/
│   ├── noise_schedule.py           # NEW: Noise schedules
│   ├── block_diffusion_utils.py    # NEW: BD utilities
│   ├── block_diffusion_transformer.py  # NEW: BD transformer
│   ├── bd_rntr_head.py            # NEW: BD head
│   ├── ar_rntr_head.py            # Original AR head
│   ├── encode_centerline.py       # Graph encoding
│   └── decode_centerline.py       # Graph decoding
├── configs/
│   └── seq_grow_graph/
│       └── block_diffusion_config.py  # NEW: BD config
├── scripts/
│   └── train_block_diffusion.py   # NEW: Training script
└── BLOCK_DIFFUSION_README.md       # This file
```

## References

- BD3-LMs: [Block Diffusion Paper](https://arxiv.org/abs/2503.09573)
- GoalFlow: [Goal-Driven Planning](https://arxiv.org/abs/2503.05689)
- SeqGrowGraph: Original implementation

## Contact & Support

For issues or questions:
1. Check token annotations in `annotate_tokens()`
2. Verify config parameters match your data
3. Monitor training logs for loss trends
4. Compare with baseline AR on same data split
