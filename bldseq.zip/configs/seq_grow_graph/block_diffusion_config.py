"""
Block Diffusion Configuration for SeqGrowGraph.
Extends the default config with block diffusion parameters.
"""

"""
This config extends the default SeqGrowGraph with a Block Diffusion head.
"""

# Import base config
_base_ = ['./seq_grow_graph_default.py']

# Block Diffusion parameters
block_diffusion = dict(
    enabled=True,
    
    # Noise schedule
    noise_type='loglinear',  # 'loglinear', 'cosine', 'square', 'square_root'
    noise_eps=1e-3,
    
    # Clipped schedule (mask rate bounds)
    sampling_eps_min=0.5,  # Minimum mask rate per block
    sampling_eps_max=1.0,  # Maximum mask rate per block
    
    # Training
    use_resample=True,  # Resample to enforce mask rate bounds
    antithetic_sampling=True,  # Reduce variance
    bd_loss_weight=0.1,  # Weight for BD loss (vs AR loss)
    
    # Inference
    num_denoising_steps=4,  # Number of steps for geometry denoising
    use_kv_cache=True,  # Use KV cache for faster inference
    nucleus_p=1.0,  # Top-p sampling (1.0 = no filtering)
)

# Model head configuration
model = dict(
    # Only override the head type and BD params; inherit other fields from base
    pts_bbox_head=dict(
        type='BDRNTRHead',
        # BD-specific parameters
        use_block_diffusion=True,
        bd_loss_weight=block_diffusion['bd_loss_weight'],
        noise_schedule=block_diffusion['noise_type'],
        noise_eps=block_diffusion['noise_eps'],
        sampling_eps_min=block_diffusion['sampling_eps_min'],
        sampling_eps_max=block_diffusion['sampling_eps_max'],
        use_resample=block_diffusion['use_resample'],
        mask_token_id=None,
        num_denoising_steps=block_diffusion['num_denoising_steps'],
    )
)

# Training configuration
train_cfg = dict(
    # Add variance tracking for clipped schedule search
    track_variance=True,
    variance_intervals=[
        (0.3, 0.8),
        (0.5, 1.0),
        (0.6, 0.9),
    ],
)

# Keep optimizer/schedule from base; optionally lower LR for stability
optim_wrapper = dict(
    optimizer=dict(lr=2e-4)
)

# Additional notes for usage:
"""
To use this config:
1. Ensure all new modules are imported in __init__.py
2. Update data preprocessing to include token annotations if needed
3. Monitor both AR and BD losses during training
4. Tune bd_loss_weight and sampling_eps_min/max based on validation metrics

Expected behavior:
- Training: Both AR loss (connections) and BD loss (geometry) computed
- Inference: Geometry uses denoising, connections use AR
- Speed: 2-4x faster inference with block-level parallelization
- Accuracy: Landmark F1 +0-2pt, Reachability F1 similar to baseline
"""
