# Block Diffusion 快速开始指南

## 一、环境验证

```bash
# 1. 验证所有组件是否正确安装
cd SeqGrowGraph
python scripts/verify_bd_setup.py

# 预期输出：
# ✓ BDRNTRHead imported successfully
# ✓ Noise schedule modules imported successfully
# ✓ Block diffusion utilities imported successfully
# ✓ All checks passed!
```

## 二、训练

### 基础训练命令
```bash
# 使用默认配置训练
python scripts/train_block_diffusion.py \
    configs/seq_grow_graph/block_diffusion_config.py \
    --work-dir work_dirs/bd_exp
```

### 推荐配置参数
```python
# configs/seq_grow_graph/block_diffusion_config.py 中的关键参数：

block_diffusion = dict(
    # 训练参数
    noise_type='loglinear',        # 噪声调度类型：loglinear最稳定
    noise_eps=1e-3,                # 噪声下界，防止除零
    sampling_eps_min=0.5,          # 最小掩码率（越小=越多掩码）
    sampling_eps_max=1.0,          # 最大掩码率（保持接近1.0）
    bd_loss_weight=0.1,            # BD损失权重（几何质量 vs 拓扑连接）
    use_resample=True,             # 启用重采样降低方差（会稍慢）
    
    # 推理参数
    num_denoising_steps=4,         # BD精化步数（1-8，越多越好但越慢）
)

# 优化器
optim_wrapper = dict(
    optimizer=dict(lr=2e-4)        # 比纯AR低一些，更稳定
)
```

## 三、监控训练

### 关键指标
```bash
# 查看训练日志
tail -f work_dirs/bd_exp/*/log.txt

# 关注这些指标：
# - loss_coords  : AR分支损失（拓扑连接），应持续下降
# - loss_bd      : BD分支损失（几何token），可能有波动但趋势下降
# - loss_total   : 总损失 = loss_coords + λ * loss_bd
```

### 正常训练特征
- `loss_coords`: 稳定下降（从 ~6.0 → ~2.0）
- `loss_bd`: 初期波动较大，中后期逐渐稳定下降
- `loss_total`: 整体平滑下降
- Landmark/Reachability 指标逐步提升

### 异常情况处理
| 现象 | 原因 | 解决方案 |
|------|------|----------|
| loss_bd出现NaN | 数值不稳定 | 降低lr到1e-4，检查noise_eps>0 |
| loss_coords上升 | BD权重过大压制AR | 降低bd_loss_weight到0.05 |
| 几何质量差 | BD权重不足 | 提高bd_loss_weight到0.2-0.3 |
| 内存溢出 | 序列太长 | 减小batch_size或max_center_len |

## 四、推理与评估

### 标准推理
```bash
# 使用训练好的模型进行推理
python tools/test.py \
    configs/seq_grow_graph/block_diffusion_config.py \
    work_dirs/bd_exp/best.pth \
    --work-dir work_dirs/bd_exp/eval

# 推理时会自动使用：
# 1. AR生成拓扑连接
# 2. BD精化几何token（num_denoising_steps=4步）
```

### 调整推理速度
```python
# 快速推理（略微降低质量）
num_denoising_steps=1   # 从4改为1，速度提升4倍

# 高质量推理（较慢）
num_denoising_steps=8   # 最多8步，质量提升但耗时增加
```

## 五、核心文件说明

### 新增模块
```
SeqGrowGraph/
├── seq_grow_graph/
│   ├── bd_rntr_head.py              # 块扩散训练头（核心）
│   ├── block_diffusion_utils.py     # 工具函数（mask、采样、加噪）
│   ├── block_diffusion_transformer.py # 支持KV缓存的Transformer（可选）
│   ├── noise_schedule.py            # 噪声调度（loglinear/cosine/exp）
│   └── __init__.py                  # 已添加BDRNTRHead等导出
│
├── configs/seq_grow_graph/
│   └── block_diffusion_config.py    # BD配置文件
│
├── scripts/
│   ├── train_block_diffusion.py     # 训练启动脚本
│   └── verify_bd_setup.py           # 环境验证脚本
│
├── BLOCK_DIFFUSION_README.md        # 完整文档
└── BLOCK_DIFFUSION_QUICKSTART.md    # 本快速指南
```

### 修改的原始文件
```
seq_grow_graph/
├── __init__.py                      # 添加了BDRNTRHead等导出
├── rntr_transformer.py              # 支持custom_tgt_mask参数
└── seq_grow_graph.py                # 训练/推理支持BD分支
```

## 六、工作原理简述

### 训练阶段
1. **数据输入**: 车道图序列 `[start, geom1, geom2, ..., split_connect, conn1, conn2, ..., split_node, ...]`
2. **Token标注**: 
   - 几何token（坐标、Bézier控制点）→ `is_geom=True`
   - 连接token（拓扑边）→ `is_geom=False`
   - 按`split_node`分配block_id
3. **双分支训练**:
   - **AR分支**: 标准自回归，预测所有token（拓扑为主）
   - **BD分支**: 
     - 按块采样时刻t → 计算掩码率
     - 仅对几何token加[MASK] → 生成`xt`
     - 拼接`[xt, x0]` → 用三段式mask前向
     - 计算几何token的重建损失（加权loss_scale）
4. **损失合并**: `loss_total = loss_coords + 0.1 * loss_bd`

### 推理阶段
1. **AR草稿生成**: 先用纯AR生成完整序列
2. **BD几何精化**: 
   - 将几何token全部设为[MASK]
   - 循环num_denoising_steps次：
     - 用`[xt, x0]`和BD mask前向
     - 采样/argmax更新几何token
   - 连接token保持不变
3. **输出**: 精化后的序列转为车道图

## 七、预期效果

### 几何质量提升
- Bézier曲线更平滑
- Landmark定位精度提高 ~2-5%
- 曲线拟合误差降低

### 训练稳定性
- 使用裁剪调度 + 重采样降低方差
- Loss曲线相对平稳

### 推理效率
- 单步BD推理 ~100ms（num_steps=1）
- 多步BD推理 ~400ms（num_steps=4）
- 比纯AR略慢但质量提升明显

## 八、常见问题

**Q: 如何判断BD训练是否有效？**
A: 观察`loss_bd`是否下降，以及几何质量指标（Landmark准确率）是否提升。

**Q: BD权重怎么调？**
A: 从0.1开始，如果几何质量不满意就增加到0.2-0.3；如果拓扑准确率下降就减到0.05。

**Q: 可以只用BD不用AR吗？**
A: 不建议。连接token需要严格顺序依赖，AR更适合；几何token可以并行生成，BD更高效。

**Q: 训练多久能收敛？**
A: 与纯AR类似，约50-100 epochs。BD分支可能需要稍长时间（+10-20%）。

**Q: 推理时必须用BD吗？**
A: 不是。设置`num_denoising_steps=0`即回退到纯AR推理。

## 九、下一步优化（可选）

1. **方差驱动的区间搜索**: 自动寻找最优`[sampling_eps_min, sampling_eps_max]`
2. **KV缓存**: 使用`BlockDiffusionTransformer`加速推理
3. **更精细的token标注**: 用数据pipeline直接提供`is_geom`标签
4. **混合精度训练**: 启用AMP进一步加速

## 十、联系与支持

- 完整文档: `BLOCK_DIFFUSION_README.md`
- 验证脚本: `python scripts/verify_bd_setup.py`
- 问题反馈: 检查日志中的WARNING/ERROR信息

---

**开始训练**: `python scripts/train_block_diffusion.py configs/seq_grow_graph/block_diffusion_config.py --work-dir work_dirs/bd_exp`
