import torch
import torch.nn.functional as F
from mmdet3d.registry import MODELS
from .sar_rntr_head import SARRNTRHead


def _build_group_mask_from_ids(group_ids: torch.Tensor) -> torch.Tensor:
    """
    Build a [T, T] attention mask from group ids.
    Rule: token i can attend to any token j with group_ids[j] <= group_ids[i].
    """
    T = int(group_ids.numel())
    gids = group_ids.view(T)
    # [T, T]: allow if gj <= gi else mask
    gi = gids.view(T, 1).expand(T, T)
    gj = gids.view(1, T).expand(T, T)
    allow = (gj <= gi)
    mask = torch.full((T, T), float('-inf'), device=gids.device)
    mask[allow] = 0.0
    return mask


@MODELS.register_module()
class SARRNTRHeadV2(SARRNTRHead):
    """Paper-aligned SAR head (new channel) that supports meta-groups from data.

    - Accepts `sar_group_ids_pos` in img_metas (per-token group ids for all
      positive clauses only, excluding START and negatives).
    - Expands to full-length `sar_group_ids` using clause_length and input_seq T.
    - Builds strict meta-group block-causal mask for training/inference.

    Note: This class does not modify AR; it is a separate head type.
    """

    def _expand_group_ids(self, T: int, clause_length: int, img_meta: dict, device: torch.device) -> torch.Tensor:
        # Get pos-only group ids if available
        sar_pos = img_meta.get('sar_group_ids_pos', None)
        if sar_pos is None:
            # Fallback to contiguous blocks like base class
            return None
        if not torch.is_tensor(sar_pos):
            sar_pos = torch.as_tensor(sar_pos, device=device, dtype=torch.long)
        pos_token_count = int(sar_pos.numel())
        # total clauses (exclude the leading START token)
        total_clause_tokens = max(0, T - 1)
        if clause_length <= 0:
            return None
        total_clauses = total_clause_tokens // clause_length
        pos_clauses = pos_token_count // clause_length
        neg_clauses = max(0, total_clauses - pos_clauses)
        # Build full ids
        gids = torch.zeros((T,), device=device, dtype=torch.long)
        # START token group = 0
        # Positive tokens next
        if pos_token_count > 0:
            gids[1:1 + pos_token_count] = sar_pos
        # Remaining tokens are negatives; assign new group ids per negative clause
        if neg_clauses > 0:
            # Determine current max group id in positives
            max_gid = int(sar_pos.max().item()) if pos_token_count > 0 else 0
            base = 1 + pos_token_count
            for i in range(neg_clauses):
                s = base + i * clause_length
                e = s + clause_length
                if e > T:
                    e = T
                gids[s:e] = max_gid + 1 + i
        return gids

    def forward(self, mlvl_feats, input_seqs, img_metas):
        # Largely follows SARRNTRHead.forward, but constructs meta-group masks from sar_group_ids_pos
        x = mlvl_feats
        if self.in_channels != self.embed_dims:
            x = self.bev_proj(x)
        pos_embed = self.bev_position_encoding(x)
        B, _, H, W = x.shape
        masks = torch.zeros(B, H, W).bool().to(x.device)

        # clause length
        try:
            n_control = int(img_metas[0].get('n_control', 3))
        except Exception:
            n_control = 3
        coeff_dim = max(0, (n_control - 2) * 2)
        clause_length = 4 + coeff_dim

        tgt = self.embedding(input_seqs.long())  # [B, T, D]
        query_embed = self.embedding.position_embeddings.weight

        # optional keypoint prompt (additive)
        if self.kp_prompt_enable and self.kp_prompt_type == 'add':
            try:
                kp_q = self.kp_query_embed.weight
                kp_dec, _ = self.kp_transformer(x, masks, kp_q, pos_embed)
                kp_feats = torch.nan_to_num(kp_dec)[-1]  # [B, Q, D]
                kp_feats_cls = kp_feats.detach() if self.kp_prompt_detach else kp_feats
                kp_cls_logits = self.kp_cls_head(kp_feats_cls)
                with torch.no_grad():
                    kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]
                    k = max(1, min(self.kp_prompt_topk, kp_scores.shape[1]))
                    topk_scores, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
                gather_idx = topk_idx.unsqueeze(-1).expand(-1, -1, kp_feats.shape[-1])
                kp_feats_prompt = kp_feats.detach() if self.kp_prompt_detach else kp_feats
                kp_sel = torch.gather(kp_feats_prompt, 1, gather_idx)
                if self.kp_prompt_weighted:
                    w = topk_scores / (topk_scores.sum(dim=-1, keepdim=True) + 1e-6)
                    kp_global = (kp_sel * w.unsqueeze(-1)).sum(dim=1)
                else:
                    kp_global = kp_sel.mean(dim=1)
                kp_bias = self.kp_prompt_adapter(kp_global)
                tgt = tgt + kp_bias.unsqueeze(1)
            except Exception:
                pass

        # Build meta-group mask per-sample
        T = tgt.shape[1]
        masks_bt = []
        use_meta_groups = True
        for bi in range(B):
            gids = self._expand_group_ids(T, clause_length, img_metas[bi], device=tgt.device)
            if gids is None:
                use_meta_groups = False
                break
            m = _build_group_mask_from_ids(gids)
            masks_bt.append(m)
        if use_meta_groups and len(masks_bt) == B:
            tgt_mask = torch.stack(masks_bt, dim=0)  # [B, T, T]
        else:
            # fallback to base block causal mask
            base_mask = self._SARRNTRHead__dict__.get('_cached_block_mask', None)
            # If base class has helper; otherwise rebuild here
            tgt_mask = None
            try:
                base = torch.full((T, T), float('-inf'), device=tgt.device)
                num_blocks = (T + clause_length - 1) // clause_length
                for b in range(num_blocks):
                    start = b * clause_length
                    end = min((b + 1) * clause_length, T)
                    base[start:end, :end] = 0.0
                tgt_mask = base.unsqueeze(0).repeat(B, 1, 1)
            except Exception:
                tgt_mask = None

        # Choose transformer (support prompt cross if configured)
        transformer_name = self.transformer.__class__.__name__
        use_cross = (
            self.kp_prompt_enable and self.kp_prompt_type == 'cross'
            and transformer_name in (
                'LssPlPrySeqLineTransformer', 'LssMLMPlPrySeqLineTransformer', 'LssSARPrmSeqLineTransformer')
        )
        if use_cross:
            try:
                kp_q = self.kp_query_embed.weight
                kp_dec, _ = self.kp_transformer(x, masks, kp_q, pos_embed)
                kp_feats = torch.nan_to_num(kp_dec)[-1]
                kp_cls_logits = self.kp_cls_head(kp_feats)
                kp_coords_norm = torch.sigmoid(self.kp_reg_head(kp_feats))
                with torch.no_grad():
                    kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]
                    k = max(1, min(self.kp_prompt_topk, kp_scores.shape[1]))
                    topk_scores, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
                gather_idx_d = topk_idx.unsqueeze(-1).expand(-1, -1, kp_feats.shape[-1])
                gather_idx_p = topk_idx.unsqueeze(-1).expand(-1, -1, kp_coords_norm.shape[-1])
                prompt = torch.gather(kp_feats, 1, gather_idx_d)
                prompt_pos = torch.gather(kp_coords_norm, 1, gather_idx_p)
                prompt_pos = self.kp_pos_mlp(prompt_pos)
                if transformer_name == 'LssSARPrmSeqLineTransformer':
                    outs_dec, _ = self.transformer(tgt, x, tgt_mask, masks, query_embed, pos_embed, prompt, prompt_pos)
                else:
                    tgt_cross = tgt.unsqueeze(1)
                    outs_dec, _ = self.transformer(tgt_cross, x, prompt, masks, query_embed, pos_embed, prompt_pos)
            except Exception:
                outs_dec, _ = self.transformer(tgt, x, tgt_mask, masks, query_embed, pos_embed)
        else:
            outs_dec, _ = self.transformer(tgt, x, tgt_mask, masks, query_embed, pos_embed)

        outs_dec = torch.nan_to_num(outs_dec)
        out = self.vocab_embed(outs_dec)
        return out

    def simple_test(self, img_metas, img=None):
        # Use base-class simple_test logic (which calls simple_test_pts)
        return super().simple_test(img_metas, img)

    def simple_test_pts(self, pts_feats, img_metas):
        # Override to apply meta-group mask during AR-style step loop too
        n_control = img_metas[0].get('n_control', 3)
        num_coeff = int(n_control) - 2
        clause_length = 4 + num_coeff * 2
        device = pts_feats[0].device
        B = len(img_metas)
        seq = (torch.ones(B, 1, device=device) * self.start).long()
        values = []
        x = pts_feats
        if self.in_channels != self.embed_dims:
            x = self.bev_proj(x)
        pos_embed = self.bev_position_encoding(x)
        _, _, H, W = x.shape
        masks = torch.zeros(B, H, W).bool().to(x.device)
        query_embed = self.embedding.position_embeddings.weight

        for _ in range(self.max_iteration):
            tgt = self.embedding(seq.long())
            T = tgt.shape[1]
            # Build meta-group ids for current step
            masks_bt = []
            use_meta_groups = True
            for bi in range(B):
                gids = self._expand_group_ids(T, clause_length, img_metas[bi], device=tgt.device)
                if gids is None:
                    use_meta_groups = False
                    break
                m = _build_group_mask_from_ids(gids)
                masks_bt.append(m)
            if use_meta_groups and len(masks_bt) == B:
                tgt_mask = torch.stack(masks_bt, dim=0)
            else:
                # default block-causal per clause
                base = torch.full((T, T), float('-inf'), device=tgt.device)
                num_blocks = (T + clause_length - 1) // clause_length
                for b in range(num_blocks):
                    start = b * clause_length
                    end = min((b + 1) * clause_length, T)
                    base[start:end, :end] = 0.0
                tgt_mask = base.unsqueeze(0).repeat(B, 1, 1)

            outs_dec, _ = self.transformer(tgt, x, tgt_mask, masks, query_embed, pos_embed)
            step_feats = torch.nan_to_num(outs_dec)[-1, :, -1, :]
            step_logits = self.vocab_embed(step_feats)
            step_probs = step_logits.softmax(-1)
            value, next_token = step_probs.topk(dim=-1, k=1)
            seq = torch.cat([seq, next_token], dim=-1)
            values.append(value)
        values = torch.cat(values, dim=-1)
        # Decode tokens to lines consistent with base class
        line_results = []
        for bi in range(seq.shape[0]):
            pred_line_seq = seq[bi][1:]  # drop START
            n_control = img_metas[bi].get('n_control', 3)
            clause_len = 4 + (int(n_control) - 2) * 2
            if self.end in pred_line_seq:
                stop_idx = (pred_line_seq == self.end).nonzero(as_tuple=True)[0][0]
            else:
                stop_idx = len(pred_line_seq)
            stop_idx = stop_idx // clause_len * clause_len
            pred_line_seq = pred_line_seq[:stop_idx]
            pred_line_seq[2::clause_len] = pred_line_seq[2::clause_len] - self.category_start
            pred_line_seq[3::clause_len] = pred_line_seq[3::clause_len] - self.connect_start
            for k in range(4, clause_len):
                pred_line_seq[k::clause_len] = pred_line_seq[k::clause_len] - self.coeff_start
            try:
                xbound = self.view_transformers.grid_conf['xbound']
                ybound = self.view_transformers.grid_conf['ybound']
                NX = int((xbound[1] - xbound[0]) / xbound[2])
                NY = int((ybound[1] - ybound[0]) / ybound[2])
                pred_line_seq[0::clause_len] = pred_line_seq[0::clause_len].clamp(0, NX - 1)
                pred_line_seq[1::clause_len] = pred_line_seq[1::clause_len].clamp(0, NY - 1)
            except Exception:
                pass
            from .core import av2seq2bznodelist  # lazy import if available
            try:
                node_list = av2seq2bznodelist(pred_line_seq.detach().cpu().numpy(), int(n_control), self.epsilon)
            except Exception:
                node_list = []
            line_results.append(dict(line_seqs=pred_line_seq.detach().cpu(), pred_node_lists=node_list))
        return line_results
