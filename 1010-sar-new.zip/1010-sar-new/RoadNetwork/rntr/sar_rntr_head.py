# ------------------------------------------------------------------------
# Semi-Autoregressive RoadNetTransformer Head
# Reuses ARRNTRHead structure but plugs a block-causal attention mask and
# a transformer that accepts tgt_mask (e.g., LssPlBzTransformer).
# ------------------------------------------------------------------------
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import Linear
from mmdet3d.registry import MODELS, TASK_UTILS

from .ar_rntr_head import ARRNTRHead, PryDecoderEmbeddings, MLP


def _build_block_causal_mask(T: int, block_len: int, device) -> torch.Tensor:
    """Build a block-level causal mask of shape [T, T].

    Semantics:
    - Tokens can attend to any token in previous blocks and within the same block.
    - Tokens cannot attend to tokens in future blocks.

    Args:
        T: total sequence length.
        block_len: number of tokens per block (e.g., clause_length).
        device: torch device.
    Returns:
        mask (Tensor): [T, T], 0 for allowed, -inf for masked (as in nn.MultiheadAttention).
    """
    if T <= 0:
        return torch.zeros(0, 0, device=device)
    num_blocks = math.ceil(T / max(block_len, 1))
    mask = torch.full((T, T), float('-inf'), device=device)
    for b in range(num_blocks):
        start = b * block_len
        end = min((b + 1) * block_len, T)
        # allow attending to all tokens up to current block end
        mask[start:end, :end] = 0.0
    return mask


def _build_group_mask_from_ids(group_ids: torch.Tensor, allow_mlm_intra: bool = True) -> torch.Tensor:
    """Build a [T, T] attention mask from per-token group ids.

    Rule: token i can attend to any token j in previous groups (gj < gi), and
    within the same group either fully (MLM style) or causally (j <= i) per flag.
    Returns a float mask with 0 for allow and -inf for masked.
    """
    T = int(group_ids.numel())
    gids = group_ids.view(T)
    gi = gids.view(T, 1).expand(T, T)
    gj = gids.view(1, T).expand(T, T)
    allow = gj < gi
    same = gj == gi
    if allow_mlm_intra:
        allow = allow | same
    else:
        # causal inside group: j <= i
        idx = torch.arange(T, device=gids.device)
        causal = idx.view(1, T).expand(T, T) <= idx.view(T, 1).expand(T, T)
        allow = allow | (same & causal)
    mask = torch.full((T, T), float('-inf'), device=gids.device)
    mask[allow] = 0.0
    return mask


def _expand_group_ids_from_pos(T: int, clause_length: int, sar_group_ids_pos: torch.Tensor) -> torch.Tensor:
    """Expand positive-only per-token group ids to full length [T].

    Layout assumption: seq = [START] + POS_TOKENS + NEG_TOKENS (padded/noise).
    - Assign START group 0.
    - Copy positive token group ids to next positions (min(pos_len, T-1)).
    - Remaining tokens are negatives; assign new group ids per clause, i.e.,
      repeat id for `clause_length` tokens, increasing group id per clause.
    """
    device = sar_group_ids_pos.device
    gids = torch.zeros((T,), device=device, dtype=torch.long)
    # place positives
    pos_len = int(min(int(sar_group_ids_pos.numel()), max(0, T - 1)))
    if pos_len > 0:
        gids[1:1 + pos_len] = sar_group_ids_pos[:pos_len]
        max_gid = int(sar_group_ids_pos[:pos_len].max().item())
    else:
        max_gid = 0
    # assign negatives per clause
    neg_tokens = T - 1 - pos_len
    if clause_length <= 0 or neg_tokens <= 0:
        return gids
    num_neg_clauses = (neg_tokens + clause_length - 1) // clause_length
    base = 1 + pos_len
    for i in range(num_neg_clauses):
        s = base + i * clause_length
        e = min(s + clause_length, T)
        gids[s:e] = max_gid + 1 + i
    return gids


@MODELS.register_module()
class SARRNTRHead(ARRNTRHead):
    """Semi-Autoregressive variant of ARRNTRHead.

    Differences vs ARRNTRHead:
    - Uses a transformer that accepts tgt_mask (e.g., LssPlBzTransformer).
    - Builds a block-causal mask per batch using clause_length as block size.
    - Training: full-seq forward with block mask to enable within-block parallelism.
    - Inference: keeps token-by-token decoding for stability (can be extended to block decoding later).
    """

    def __init__(self,
                 *args,
                 sar_group_clauses: int = 1,
                 sar_group_strategy: str = 'contiguous',  # ['contiguous','meta_groups']
                 sar_intra_group_mlm: bool = True,
                 # keypoint branch configs
                 kp_num_query: int = 200,
                 kp_num_classes: int = 4,
                 kp_transformer: dict = None,
                 # prompt coupling
                 kp_prompt_enable: bool = True,
                 kp_prompt_detach: bool = True,
                 kp_prompt_type: str = 'add',  # ['add', 'none']
                 kp_prompt_topk: int = 50,
                 kp_prompt_weighted: bool = True,
                 **kwargs):
        super().__init__(*args, **kwargs)
        # number of clauses per block. default 1 (per-clause parallel intra-block)
        self.sar_group_clauses = max(1, int(sar_group_clauses))
        self.sar_group_strategy = sar_group_strategy
        self.sar_intra_group_mlm = bool(sar_intra_group_mlm)

        # ---------- Keypoint parallel branch ----------
        self.kp_num_query = int(kp_num_query)
        self.kp_num_classes = int(kp_num_classes)
        if kp_transformer is None:
            kp_transformer = dict(type='KeypointTransformer',
                                  decoder=dict(
                                      type='PETRTransformerLineDecoder',
                                      return_intermediate=True,
                                      num_layers=3,
                                      transformerlayers=dict(
                                          type='PETRLineTransformerDecoderLayer',
                                          attn_cfgs=[
                                              dict(
                                                  type='RNTR2MultiheadAttention',
                                                  embed_dims=self.embed_dims,
                                                  num_heads=8,
                                                  dropout=0.1),
                                              dict(
                                                  type='RNTR2MultiheadAttention',
                                                  embed_dims=self.embed_dims,
                                                  num_heads=8,
                                                  dropout=0.1),
                                          ],
                                          ffn_cfgs=dict(
                                              type='FFN',
                                              embed_dims=self.embed_dims,
                                              feedforward_channels=self.embed_dims * 4,
                                              num_fcs=2,
                                              ffn_drop=0.1,
                                              act_cfg=dict(type='ReLU', inplace=True),
                                          ),
                                          with_cp=False,
                                          operation_order=('self_attn', 'norm', 'cross_attn', 'norm', 'ffn', 'norm')
                                      ),
                                  ))
        self.kp_transformer = MODELS.build(kp_transformer)
        self.kp_query_embed = nn.Embedding(self.kp_num_query, self.embed_dims)
        self.kp_cls_head = Linear(self.embed_dims, self.kp_num_classes)
        self.kp_reg_head = MLP(self.embed_dims, self.embed_dims, 2, 3)
        # prompt adapter
        self.kp_prompt_enable = bool(kp_prompt_enable)
        self.kp_prompt_detach = bool(kp_prompt_detach)
        self.kp_prompt_type = kp_prompt_type
        if self.kp_prompt_enable and self.kp_prompt_type == 'add':
            self.kp_prompt_adapter = nn.Sequential(
                nn.Linear(self.embed_dims, self.embed_dims),
                nn.ReLU(inplace=True),
                nn.Linear(self.embed_dims, self.embed_dims)
            )
        # pos embedding for KP coordinates if needed in future (e.g., cross-attn prompt_pos)
        self.kp_pos_mlp = nn.Sequential(
            nn.Linear(2, self.embed_dims),
            nn.ReLU(inplace=True),
            nn.Linear(self.embed_dims, self.embed_dims)
        )
        self.kp_prompt_topk = int(kp_prompt_topk)
        self.kp_prompt_weighted = bool(kp_prompt_weighted)

    def forward(self, mlvl_feats, input_seqs, img_metas):
        """Forward function with SAR mask.

        Args:
            mlvl_feats (Tensor): BEV features, shape [B, C, H, W].
            input_seqs (Tensor): token ids, shape [B, T].
            img_metas (list[dict]): Contains 'n_control' for clause_length.
        Returns:
            If training: logits for all layers [L, B, T, V].
            If infer: (decoded_seq [B, T_out], values [B, T_steps]).
        """
        x = mlvl_feats
        if self.in_channels != self.embed_dims:
            x = self.bev_proj(x)
        pos_embed = self.bev_position_encoding(x)
        B, _, H, W = x.shape
        masks = torch.zeros(B, H, W).bool().to(x.device)

        # compute clause_length from meta
        try:
            n_control = int(img_metas[0].get('n_control', 3))
        except Exception:
            n_control = 3
        coeff_dim = max(0, (n_control - 2) * 2)
        clause_length = 4 + coeff_dim
        block_len = clause_length * self.sar_group_clauses

        if self.training:
            tgt = self.embedding(input_seqs.long())  # [B, T, D]
            query_embed = self.embedding.position_embeddings.weight  # [T_max, D]
            # Keypoint prompt (global) injection (additive baseline)
            if self.kp_prompt_enable and self.kp_prompt_type == 'add':
                try:
                    kp_q = self.kp_query_embed.weight
                    kp_dec, _ = self.kp_transformer(x, masks, kp_q, pos_embed)
                    kp_feats = torch.nan_to_num(kp_dec)[-1]  # [B, Q, D]
                    # select top-k keypoints by cls confidence if available
                    kp_feats_cls = kp_feats.detach() if self.kp_prompt_detach else kp_feats
                    kp_cls_logits = self.kp_cls_head(kp_feats_cls)  # [B, Q, C]
                    with torch.no_grad():
                        kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]  # [B, Q]
                        k = max(1, min(self.kp_prompt_topk, kp_scores.shape[1]))
                        topk_scores, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
                    # gather features
                    B = kp_feats.shape[0]
                    gather_idx = topk_idx.unsqueeze(-1).expand(-1, -1, kp_feats.shape[-1])  # [B, k, D]
                    kp_feats_prompt = kp_feats.detach() if self.kp_prompt_detach else kp_feats
                    kp_sel = torch.gather(kp_feats_prompt, 1, gather_idx)
                    if self.kp_prompt_weighted:
                        w = topk_scores / (topk_scores.sum(dim=-1, keepdim=True) + 1e-6)
                        kp_global = (kp_sel * w.unsqueeze(-1)).sum(dim=1)  # [B, D]
                    else:
                        kp_global = kp_sel.mean(dim=1)
                    kp_bias = self.kp_prompt_adapter(kp_global)  # [B, D]
                    tgt = tgt + kp_bias.unsqueeze(1)
                except Exception:
                    pass
            T = tgt.shape[1]
            # Build batch-wise block/group mask [B, T, T]
            use_meta_groups = (self.sar_group_strategy == 'meta_groups' and isinstance(img_metas, (list, tuple)))
            masks_bt = []
            if use_meta_groups:
                for bi in range(B):
                    meta = img_metas[bi] if isinstance(img_metas, (list, tuple)) else {}
                    gids_full = None
                    if isinstance(meta, dict) and 'sar_group_ids_pos' in meta:
                        sar_pos = meta['sar_group_ids_pos']
                        if not torch.is_tensor(sar_pos):
                            sar_pos = torch.as_tensor(sar_pos, device=tgt.device, dtype=torch.long)
                        gids_full = _expand_group_ids_from_pos(T, clause_length, sar_pos)
                    elif isinstance(meta, dict) and 'sar_group_ids' in meta:
                        sar_full = meta['sar_group_ids']
                        if torch.is_tensor(sar_full) and sar_full.numel() == T:
                            gids_full = sar_full.to(tgt.device).long()
                        elif isinstance(sar_full, (list, tuple)) and len(sar_full) == T:
                            gids_full = torch.as_tensor(sar_full, device=tgt.device, dtype=torch.long)
                    if gids_full is None:
                        masks_bt = []
                        break
                    m = _build_group_mask_from_ids(gids_full, allow_mlm_intra=self.sar_intra_group_mlm)
                    masks_bt.append(m)
            if len(masks_bt) == B and len(masks_bt) > 0:
                tgt_mask = torch.stack(masks_bt, dim=0)
            else:
                base_mask = _build_block_causal_mask(T, block_len, tgt.device)
                tgt_mask = base_mask.unsqueeze(0).repeat(B, 1, 1)
            # Try cross-attention prompt if requested and supported
            transformer_name = self.transformer.__class__.__name__
            use_cross = (self.kp_prompt_enable and self.kp_prompt_type == 'cross' 
                         and transformer_name in ('LssPlPrySeqLineTransformer', 'LssMLMPlPrySeqLineTransformer', 'LssSARPrmSeqLineTransformer'))
            if use_cross:
                try:
                    kp_q = self.kp_query_embed.weight
                    kp_dec, _ = self.kp_transformer(x, masks, kp_q, pos_embed)
                    kp_feats = torch.nan_to_num(kp_dec)[-1]  # [B, Q, D]
                    kp_cls_logits = self.kp_cls_head(kp_feats)  # [B, Q, C]
                    kp_coords_norm = torch.sigmoid(self.kp_reg_head(kp_feats))  # [B, Q, 2] (y_norm, x_norm)
                    with torch.no_grad():
                        kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]
                        k = max(1, min(self.kp_prompt_topk, kp_scores.shape[1]))
                        topk_scores, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
                    gather_idx_d = topk_idx.unsqueeze(-1).expand(-1, -1, kp_feats.shape[-1])
                    gather_idx_p = topk_idx.unsqueeze(-1).expand(-1, -1, kp_coords_norm.shape[-1])
                    prompt = torch.gather(kp_feats, 1, gather_idx_d)  # [B, k, D]
                    prompt_pos = torch.gather(kp_coords_norm, 1, gather_idx_p)  # [B, k, 2]
                    prompt_pos = self.kp_pos_mlp(prompt_pos)  # [B, k, D]
                    if transformer_name == 'LssSARPrmSeqLineTransformer':
                        outs_dec, _ = self.transformer(tgt, x, tgt_mask, masks, query_embed, pos_embed, prompt, prompt_pos)
                    else:
                        tgt_cross = tgt.unsqueeze(1)  # [B, 1, T, D]
                        outs_dec, _ = self.transformer(tgt_cross, x, prompt, masks, query_embed, pos_embed, prompt_pos)
                except Exception:
                    outs_dec, _ = self.transformer(tgt, x, tgt_mask, masks, query_embed, pos_embed)
            else:
                outs_dec, _ = self.transformer(tgt, x, tgt_mask, masks, query_embed, pos_embed)
            outs_dec = torch.nan_to_num(outs_dec)
            out = self.vocab_embed(outs_dec)
            return out
        else:
            # AR-style decoding with SAR mask for robustness. Future: extend to block decoding.
            values = []
            seq = input_seqs
            # Precompute KP prompt bias once per image (additive baseline)
            kp_bias = None
            if self.kp_prompt_enable and self.kp_prompt_type == 'add':
                try:
                    kp_q = self.kp_query_embed.weight
                    kp_dec, _ = self.kp_transformer(x, masks, kp_q, pos_embed)
                    kp_feats = torch.nan_to_num(kp_dec)[-1]
                    kp_feats_cls = kp_feats.detach() if self.kp_prompt_detach else kp_feats
                    kp_cls_logits = self.kp_cls_head(kp_feats_cls)
                    with torch.no_grad():
                        kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]
                        k = max(1, min(self.kp_prompt_topk, kp_scores.shape[1]))
                        topk_scores, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
                    B = kp_feats.shape[0]
                    gather_idx = topk_idx.unsqueeze(-1).expand(-1, -1, kp_feats.shape[-1])
                    kp_feats_prompt = kp_feats.detach() if self.kp_prompt_detach else kp_feats
                    kp_sel = torch.gather(kp_feats_prompt, 1, gather_idx)
                    if self.kp_prompt_weighted:
                        w = topk_scores / (topk_scores.sum(dim=-1, keepdim=True) + 1e-6)
                        kp_global = (kp_sel * w.unsqueeze(-1)).sum(dim=1)
                    else:
                        kp_global = kp_sel.mean(dim=1)
                    kp_bias = self.kp_prompt_adapter(kp_global)  # [B, D]
                except Exception:
                    kp_bias = None
            for _ in range(self.max_iteration):
                tgt = self.embedding(seq.long())
                if kp_bias is not None:
                    tgt = tgt + kp_bias.unsqueeze(1)
                query_embed = self.embedding.position_embeddings.weight
                T = tgt.shape[1]
                # Build meta-groups mask per step if available; else fallback
                use_meta_groups = (self.sar_group_strategy == 'meta_groups' and isinstance(img_metas, (list, tuple)))
                masks_bt = []
                if use_meta_groups:
                    for bi in range(B):
                        meta = img_metas[bi] if isinstance(img_metas, (list, tuple)) else {}
                        gids_full = None
                        if isinstance(meta, dict) and 'sar_group_ids_pos' in meta:
                            sar_pos = meta['sar_group_ids_pos']
                            if not torch.is_tensor(sar_pos):
                                sar_pos = torch.as_tensor(sar_pos, device=tgt.device, dtype=torch.long)
                            gids_full = _expand_group_ids_from_pos(T, clause_length, sar_pos)
                        elif isinstance(meta, dict) and 'sar_group_ids' in meta:
                            sar_full = meta['sar_group_ids']
                            if torch.is_tensor(sar_full) and sar_full.numel() == T:
                                gids_full = sar_full.to(tgt.device).long()
                            elif isinstance(sar_full, (list, tuple)) and len(sar_full) == T:
                                gids_full = torch.as_tensor(sar_full, device=tgt.device, dtype=torch.long)
                        if gids_full is None:
                            masks_bt = []
                            break
                        m = _build_group_mask_from_ids(gids_full, allow_mlm_intra=self.sar_intra_group_mlm)
                        masks_bt.append(m)
                if len(masks_bt) == B and len(masks_bt) > 0:
                    tgt_mask = torch.stack(masks_bt, dim=0)
                else:
                    base_mask = _build_block_causal_mask(T, block_len, tgt.device)
                    tgt_mask = base_mask.unsqueeze(0).repeat(B, 1, 1)
                # Try cross-attention prompt per step if requested and supported
                transformer_name = self.transformer.__class__.__name__
                use_cross = (self.kp_prompt_enable and self.kp_prompt_type == 'cross' 
                             and transformer_name in ('LssPlPrySeqLineTransformer', 'LssMLMPlPrySeqLineTransformer', 'LssSARPrmSeqLineTransformer'))
                if use_cross:
                    try:
                        kp_q = self.kp_query_embed.weight
                        kp_dec, _ = self.kp_transformer(x, masks, kp_q, pos_embed)
                        kp_feats = torch.nan_to_num(kp_dec)[-1]
                        kp_cls_logits = self.kp_cls_head(kp_feats)
                        kp_coords_norm = torch.sigmoid(self.kp_reg_head(kp_feats))
                        with torch.no_grad():
                            kp_scores = kp_cls_logits.softmax(-1).max(dim=-1)[0]
                            k = max(1, min(self.kp_prompt_topk, kp_scores.shape[1]))
                            topk_scores, topk_idx = torch.topk(kp_scores, k=k, dim=-1)
                        gather_idx_d = topk_idx.unsqueeze(-1).expand(-1, -1, kp_feats.shape[-1])
                        gather_idx_p = topk_idx.unsqueeze(-1).expand(-1, -1, kp_coords_norm.shape[-1])
                        prompt = torch.gather(kp_feats, 1, gather_idx_d)
                        prompt_pos = torch.gather(kp_coords_norm, 1, gather_idx_p)
                        prompt_pos = self.kp_pos_mlp(prompt_pos)
                        if transformer_name == 'LssSARPrmSeqLineTransformer':
                            outs_dec, _ = self.transformer(tgt, x, tgt_mask, masks, query_embed, pos_embed, prompt, prompt_pos)
                        else:
                            tgt_cross = tgt.unsqueeze(1)
                            outs_dec, _ = self.transformer(tgt_cross, x, prompt, masks, query_embed, pos_embed, prompt_pos)
                    except Exception:
                        outs_dec, _ = self.transformer(tgt, x, tgt_mask, masks, query_embed, pos_embed)
                else:
                    outs_dec, _ = self.transformer(tgt, x, tgt_mask, masks, query_embed, pos_embed)
                step_feats = torch.nan_to_num(outs_dec)[-1, :, -1, :]  # last layer, last pos features
                step_logits = self.vocab_embed(step_feats)
                step_probs = step_logits.softmax(-1)
                value, next_token = step_probs.topk(dim=-1, k=1)
                seq = torch.cat([seq, next_token], dim=-1)
                values.append(value)
            values = torch.cat(values, dim=-1)
            return seq, values

    # ---------------- Keypoint branch API ----------------
    def forward_keypoints(self, mlvl_feats, img_metas):
        """Forward keypoint parallel branch.

        Returns:
            kp_cls_logits: [B, Q, C]
            kp_coords_norm: [B, Q, 2] in [0, 1]
        """
        x = mlvl_feats
        if self.in_channels != self.embed_dims:
            x = self.bev_proj(x)
        pos_embed = self.bev_position_encoding(x)
        B, _, H, W = x.shape
        masks = torch.zeros(B, H, W).bool().to(x.device)
        query_embed = self.kp_query_embed.weight  # [Q, D]
        # Use KeypointTransformer interface
        outs_dec, _ = self.kp_transformer(x, masks, query_embed, pos_embed)
        feats = torch.nan_to_num(outs_dec)[-1]  # [B, Q, D]
        kp_cls_logits = self.kp_cls_head(feats)
        kp_coords_norm = torch.sigmoid(self.kp_reg_head(feats))
        return kp_cls_logits, kp_coords_norm
