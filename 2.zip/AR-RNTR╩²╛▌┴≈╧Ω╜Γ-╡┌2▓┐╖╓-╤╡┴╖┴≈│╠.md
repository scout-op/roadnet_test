# AR-RNTR 数据流详解（第2部分：训练流程）

## 训练数据流完整路径

```
配置文件 
  ↓
数据集加载 
  ↓
Pipeline预处理 
  ↓
Batch组装 
  ↓
模型前向 
  ↓
损失计算 
  ↓
反向传播
```

---

## 1. 入口：配置文件

**文件**：`configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py`

```python
# 定义模型
model = dict(
    type='AR_RNTR',           # 模型类名
    img_backbone=...,         # 图像骨干（ResNet50）
    img_neck=...,             # FPN
    pts_bbox_head=...,        # 解码器头
    grid_conf=...,            # BEV网格配置
)

# 定义数据集
dataset_type = 'CenterlineNuScenesDataset'
train_dataloader = dict(
    batch_size=2,
    dataset=dict(
        type=dataset_type,
        ann_file='nuscenes_centerline_infos_pon_train.pkl',
        pipeline=train_pipeline,  # 数据处理流程
    )
)
```

---

## 2. 数据集加载

**文件**：`rntr/centerline_nuscenes_dataset.py`
**类**：`CenterlineNuScenesDataset`

### 2.1 初始化
```python
def __init__(self, ann_file, pipeline, ...):
    # 加载标注文件（.pkl）
    self.data_list = self.load_annotations(ann_file)
    # data_list 包含每个样本的：
    # - token: 唯一ID
    # - images: 6个相机的图像路径
    # - lidar2img: 相机标定矩阵
    # - center_lines: 道路中心线矢量数据
```

### 2.2 获取单个样本
```python
def __getitem__(self, idx):
    data_info = self.data_list[idx]
    
    # 应用pipeline
    data = self.pipeline(data_info)
    
    return data
```

---

## 3. Pipeline 预处理

**配置**：`train_pipeline = [...]`

### 步骤详解

#### Step 1: 加载图像
```python
dict(type='OrgLoadMultiViewImageFromFiles', to_float32=True)
```
- 输入：6个图像路径
- 输出：`data['img']` = list of 6张图像 `[H, W, 3]`

#### Step 2-4: 图像预处理
```python
dict(type='ResizeCropFlipImage', ...),        # 缩放裁剪
dict(type='NormalizeMultiviewImage', ...),    # 归一化
dict(type='PadMultiViewImage', ...),          # 填充
```
- 输出：`data['img']` = Tensor `[6, 3, 128, 352]`

#### Step 5: 加载中心线
```python
dict(type='LoadNusOrderedBzCenterline', 
     grid_conf=grid_conf, 
     bz_grid_conf=bz_grid_conf)
```
**文件**：`rntr/transforms/loading.py`

作用：
1. 读取道路中心线矢量数据
2. 转换到BEV坐标系
3. 栅格化（连续坐标→离散网格索引）

输出：
```python
data['centerlines']  # 原始矢量数据（图结构）
```

#### Step 6-7: 数据增强
```python
dict(type='CenterlineFlip', prob=0.5),        # 随机翻转
dict(type='CenterlineRotateScale', ...),      # 随机旋转缩放
```

#### Step 8: 图→序列转换（最关键！）
```python
dict(type='TransformOrderedBzLane2Graph', 
     n_control=3, 
     orderedDFS=True)
```

**文件**：`rntr/transforms/loading.py`
**类**：`TransformOrderedBzLane2Graph`

**核心逻辑**：
```python
输入：图结构
  nodes = [[x1,y1], [x2,y2], ...]    # 节点坐标
  edges = [(0,1), (1,2), (1,3), ...]  # 边的连接
  labels = [0, 1, 2, ...]             # 节点类型

处理步骤：
  1. DFS遍历（深度优先），确定节点顺序
  2. 计算每个节点的父节点（connect）
  3. 拟合贝塞尔曲线，计算控制点

输出：序列数据
  centerline_coord = [x1,y1,x2,y2,...]     # 扁平化坐标
  centerline_label = [0,1,2,...]           # 节点类型
  centerline_connect = [0,0,1,1,2,...]     # 父节点索引
  centerline_coeff = [cx1,cy1,cx2,cy2,...] # 贝塞尔控制点
  n_control = 3                             # 控制点数量
```

#### Step 9: 打包数据
```python
dict(type='Pack3DDetInputs', 
     keys=['img'],
     meta_keys=(..., 'centerline_coord', 'centerline_label', ...))
```

输出：
```python
data_sample.metainfo = {
    'centerline_coord': [...],
    'centerline_label': [...],
    'centerline_connect': [...],
    'centerline_coeff': [...],
    'n_control': 3,
    ...
}
```

---

## 4. DataLoader 批量组装

PyTorch 自动把多个样本组成 batch：

```python
inputs = {
    'img': Tensor [B, 6, 3, 128, 352]  # B个样本的图像
}

data_samples = [
    DetDataSample(metainfo={...}),  # 样本1的元数据
    DetDataSample(metainfo={...}),  # 样本2的元数据
]
```

---

## 5. 模型前向传播

### 5.1 入口函数
**文件**：`rntr/ar_rntr.py`
**方法**：`AR_RNTR.loss(inputs, data_samples)`

```python
def loss(self, inputs, data_samples):
    # 1. 提取数据
    img = inputs['img']  # [B, 6, 3, H, W]
    img_metas = [ds.metainfo for ds in data_samples]
    
    # 2. BEV特征提取
    bev_feats = self.extract_feat(img, img_metas)
    # 返回: [B, 256, 200, 200]
    
    # 3. 解析GT
    gt_lines_coords = [m['centerline_coord'] for m in img_metas]
    gt_lines_labels = [m['centerline_label'] for m in img_metas]
    gt_lines_connects = [m['centerline_connect'] for m in img_metas]
    gt_lines_coeffs = [m['centerline_coeff'] for m in img_metas]
    
    # 4. 训练前向
    losses = self.forward_pts_train(
        bev_feats, 
        gt_lines_coords,
        gt_lines_labels,
        gt_lines_connects,
        gt_lines_coeffs,
        img_metas,
        img_metas[0]['n_control'] - 2  # num_coeff
    )
    
    return losses
```

### 5.2 BEV特征提取
**方法**：`extract_feat(img, img_metas)`

```python
def extract_feat(self, img, img_metas):
    # [B,6,3,H,W] → [B*6,3,H,W]（展平batch和相机维度）
    img = img.view(B*6, 3, H, W)
    
    # 图像骨干（ResNet50）
    img_feats = self.img_backbone(img)
    # 多尺度特征：[B*6, 512, H/8, W/8], [B*6, 1024, H/16, W/16], ...
    
    # FPN融合
    img_feats = self.img_neck(img_feats)
    # [B*6, 256, H/8, W/8]
    
    # 恢复形状：[B, 6, 256, H/8, W/8]
    img_feats = img_feats.view(B, 6, 256, H//8, W//8)
    
    # LSS投影到BEV
    bev_feats = self.view_transformers(img_feats, img_metas)
    # [B, 256, 200, 200]
    
    return bev_feats
```

**LSS（Lift-Splat-Shoot）原理**：
```
对每个图像像素(u,v):
  1. Lift: 预测深度分布 p(d|u,v)
  2. Splat: 根据深度d和相机参数，投影到3D空间(x,y,z)
  3. Shoot: 俯视xy平面，累积特征到BEV网格

最终得到BEV特征图：[B, 256, 200, 200]
  - 覆盖范围：x∈[-48,48]m, y∈[-32,32]m
  - 分辨率：0.5m/格
  - 网格大小：(48--48)/0.5 × (32--32)/0.5 = 192×128 ≈ 200×200
```

---

## 6. 核心函数：forward_pts_train

这是训练的**灵魂函数**！完整代码见 `rntr/ar_rntr.py` 第309-547行。

### 6.1 整体流程
```
1. 构造训练序列（正样本+负样本）
2. 解码器前向传播
3. 按子句切片logits
4. 过滤有效监督
5. 计算4个CE损失
```

### 6.2 代码框架（简化版）
```python
def forward_pts_train(self, bev_feats, gt_lines_coords, ...):
    # 计算子句长度
    coeff_dim = num_coeff * 2
    clause_length = 4 + coeff_dim  # 例如: 4+2=6
    
    input_seqs = []
    output_seqs = []
    
    # 遍历batch
    for bi in range(len(gt_lines_coords)):
        # --- 构造正样本子句 ---
        box_label = 构造([coord, label, connect, coeff])
        
        # --- 构造负样本子句 ---
        random_box_label = 随机采样()
        
        # --- 输入序列 = [START] + 正样本 + 负样本 ---
        input_seq = cat([START, box_label.flatten(), 
                         random_box_label.flatten()])
        
        # --- 监督序列 = 正样本 + [END] + 负样本占位 ---
        output_seq = cat([box_label.flatten(), END, 
                          负样本占位.flatten()])
        
        input_seqs.append(input_seq)
        output_seqs.append(output_seq)
    
    # --- 解码器前向 ---
    outputs_logits = self.pts_bbox_head(bev_feats, input_seqs, img_metas)
    # [num_layers, B, T, 576]
    outputs_logits = outputs_logits[-1, :, :-1, :]  # 取最后一层
    
    # --- 按子句切片并计算loss ---
    for bi in range(B):
        # 切片得到4组logits和targets
        outputs_pos, inputs_pos = 切片坐标()
        outputs_cls, inputs_cls = 切片类别()
        outputs_conn, inputs_conn = 切片连接()
        outputs_coeffs, inputs_coeffs = 切片系数()
        
        # 过滤no_known
        outputs_pos = outputs_pos[inputs_pos != 575]
        ...
    
    # --- 计算损失 ---
    losses = self.pts_bbox_head.loss_by_feat(...)
    return losses
```

详细解析请看代码中的中文注释！

---

下一部分将讲解推理流程。
