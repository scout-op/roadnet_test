# nuScenes 数据处理流程详解：从原始数据到训练格式

> 本文档详细解释 nuScenes 数据集如何被处理成 RoadNetTransformer (RNTR) 训练所需的序列格式。  
> 适合初学者理解整个数据流水线。

---

## 目录
1. [nuScenes 原始数据结构](#1-nuscenes-原始数据结构)
2. [数据加载流程](#2-数据加载流程)
3. [中心线提取与图构建](#3-中心线提取与图构建)
4. [序列化：图转序列](#4-序列化图转序列)
5. [SAR 专属：分组信息构建](#5-sar-专属分组信息构建)
6. [最终训练样本格式](#6-最终训练样本格式)
7. [完整代码调用链](#7-完整代码调用链)

---

## 1. nuScenes 原始数据结构

### 1.1 什么是 nuScenes？
nuScenes 是一个大型自动驾驶数据集，包含：
- **多视角相机图像**（6 个相机：前、后、左前、右前、左后、右后）
- **LiDAR 点云**
- **地图标注**：包括车道线、道路边界、人行横道等
- **3D 物体标注**：车辆、行人等

### 1.2 道路网络标注（centerlines）
nuScenes 的地图标注包含道路中心线（centerlines），存储格式：
```python
{
    'centerline_ids': [id1, id2, ...],           # 每条中心线的唯一 ID
    'centerlines': [                              # 每条中心线的坐标点列表
        [[x1, y1, z1], [x2, y2, z2], ...],       # 中心线 1
        [[x1, y1, z1], [x2, y2, z2], ...],       # 中心线 2
        ...
    ],
    'incoming_ids': [[id_a, id_b], ...],         # 每条中心线的前驱（哪些线连到它）
    'outgoing_ids': [[id_c, id_d], ...],         # 每条中心线的后继（它连到哪些线）
    'start_point_idxs': [0, 5, ...],             # 每条线的起点索引
    'end_point_idxs': [10, 15, ...]              # 每条线的终点索引
}
```

**关键点**：
- 中心线是**连续的坐标点**（密集采样）
- 通过 `incoming_ids` 和 `outgoing_ids` 描述**拓扑连接**
- 坐标在**自车坐标系**（ego coordinate）下

---

## 2. 数据加载流程

### 2.1 数据集类：`CenterlineNuScenesDataset`
代码位置：`rntr/centerline_nuscenes_dataset.py`

```python
@DATASETS.register_module()
class CenterlineNuScenesDataset(BaseDataset):
    def __init__(self, ann_file, pipeline, ...):
        # ann_file 是预处理好的 pkl 文件，包含所有场景的标注
        super().__init__(ann_file=ann_file, pipeline=pipeline, ...)
```

### 2.2 加载标注文件
```python
def load_data_list(self) -> List[dict]:
    # 从 pkl 文件加载
    annotations = load(self.ann_file)  # {'infos': [...], 'metadata': {...}}
    
    # 每个 info 包含一个场景的信息
    for raw_data_info in annotations['infos']:
        data_info = self.parse_data_info(raw_data_info)
        data_list.append(data_info)
    
    return data_list
```

### 2.3 解析单个样本
```python
def parse_data_info(self, info: dict) -> dict:
    input_dict = {
        'token': info['token'],                # 场景唯一标识
        'img_filename': image_paths,           # 6 张相机图像路径
        'lidar2img': lidar2img_rts,           # LiDAR 到图像的投影矩阵
        'center_lines': info['center_lines']   # ← 道路中心线标注（原始格式）
    }
    return input_dict
```

**此时 `center_lines` 还是原始格式**（密集坐标点 + 拓扑信息）。

---

## 3. 中心线提取与图构建

### 3.1 数据增强 Pipeline
在配置文件（如 `lss_sar_rntr_paper_fp16_torch2.py`）中定义：
```python
train_pipeline = [
    dict(type='LoadMultiViewImageFromFiles', ...),          # 加载图像
    dict(type='LoadNusOrderedBzCenterline', ...),           # ← 处理中心线
    dict(type='TransformOrderedBzLane2GraphSAR', ...),      # ← 转为序列 + SAR 分组
    dict(type='Pack3DCenterlineInputs', ...)                # 打包为训练输入
]
```

### 3.2 `LoadNusOrderedBzCenterline`：提取中心线
代码位置：`rntr/transforms/loading.py:1310`

**作用**：将原始中心线标注转换为**有序的贝塞尔曲线节点图**。

```python
class LoadNusOrderedBzCenterline(object):
    def __call__(self, results):
        # 调用 NusOrederedBzCenterLine 类处理原始 center_lines
        results['center_lines'] = NusOrederedBzCenterLine(
            results['center_lines'], 
            self.grid_conf,      # BEV 网格配置（如 192×128）
            self.bz_grid_conf    # 贝塞尔网格配置
        )
        return results
```

**`NusOrederedBzCenterLine` 内部做了什么？**（位于 `centerline_utils.py`）

1. **坐标转换**：
   - 从自车坐标系（米）→ BEV 网格坐标（像素）
   - 公式：`grid_x = (x - pc_range[0]) / dx`

2. **密集点→稀疏节点**：
   - 原始中心线有很多密集点（如每 0.5m 一个点）
   - 提取**关键节点**：起点、终点、转折点
   - 节点之间用**贝塞尔曲线**插值（论文中的 Quadratic Bézier）

3. **构建图结构**：
   ```python
   {
       'nodes': [Node1, Node2, ...],          # 所有节点
       'adjacency': [[0,1], [1,2], ...],     # 边（节点索引对）
       'subgraphs': [                        # 连通子图（用于 SAR 分组）
           [Node_a, Node_b, ...],            # 子图 1
           [Node_c, Node_d, ...],            # 子图 2
       ]
   }
   ```

**关键点**：
- 每个 **Node** 包含：
  - `position`：节点坐标 (x, y)
  - `sque_type`：节点类型（start, continue, fork, merge）
  - `coeff`：贝塞尔曲线控制点（连接到子节点的曲线）
  - `fork_from_index` / `merge_with_index`：拓扑连接索引

---

## 4. 序列化：图转序列

### 4.1 为什么要序列化？
Transformer 需要**序列输入**，但道路网络是**图结构**（有分支、合并）。  
论文中提出：**用 DFS 遍历将图展平为序列**。

### 4.2 `TransformOrderedBzLane2GraphSAR`：构建序列
代码位置：`rntr/transforms/loading.py:584`

**核心思想**（论文 Section 3.2）：
1. 将道路网络分解为**连通子图**（subgraphs）
2. 对每个子图做**有序 DFS 遍历**
3. 将遍历顺序展平为一维序列

#### 4.2.1 DFS 遍历示例
假设有如下道路拓扑：
```
    A → B → C
        ↓
        D → E
```
DFS 遍历顺序：`A → B → C → B → D → E`（回溯到分叉点 B，再走另一条路）

#### 4.2.2 序列表示（论文中的 Unified Sequence）
每个节点编码为一个**子句（clause）**，包含：
```
clause = [x, y, label, connect, coeff_x, coeff_y, ...]
         ↑  ↑    ↑       ↑        ↑--------↑
         |  |    |       |        贝塞尔控制点（可选）
         |  |    |       连接索引（用于 fork/merge）
         |  |    节点类型（0=start, 1=continue, 2=fork, 3=merge）
         |  y 坐标（网格索引）
         x 坐标（网格索引）
```

**代码实现**：
```python
def __call__(self, results):
    # 1. 提取子图
    centerlines.sub_graph_split()
    
    # 2. 对每个子图做有序 DFS
    scene_graph = OrderedBzSceneGraph(...)
    scene_sentance, scene_sentance_list = scene_graph.sequelize_new(orderedDFS=True)
    
    # 3. 展平为序列
    type_idx_map = {'start': 0, 'continue': 1, 'fork': 2, 'merge': 3}
    clause_length = 4 + 2 * (n_control - 2)  # 4 基础 + 控制点对数
    
    seq = []
    for gid, sub_sent in enumerate(scene_sentance_list, start=1):
        for node in sub_sent:
            # 坐标
            pos = (node.position - pc_range[:3]) / dx
            x_i, y_i = int(pos[0]), int(pos[1])
            seq.extend([x_i, y_i])
            
            # 类型标签
            ntype = node.sque_type
            seq.append(type_idx_map[ntype])
            
            # 连接索引（1-based，0 表示无连接）
            vd = node.fork_from_index + 1 if ntype == 'fork' else 0
            seq.append(vd)
            
            # 贝塞尔控制点
            coeff = (node.coeff - bz_pc_range[:2]) / dx[:2]
            cx, cy = int(coeff[0]), int(coeff[1])
            seq.extend([cx, cy])
    
    # 4. 切分为字段
    centerline_coord = np.stack([seq[::clause_length], seq[1::clause_length]], axis=1)
    centerline_label = np.array(seq[2::clause_length])
    centerline_connect = np.array(seq[3::clause_length])
    centerline_coeff = ...  # 控制点
    
    results['centerline_sequence'] = seq  # 完整序列
    results['centerline_coord'] = centerline_coord
    results['centerline_label'] = centerline_label
    results['centerline_connect'] = centerline_connect
    results['centerline_coeff'] = centerline_coeff
```

**输出示例**（假设 `clause_length=6`，即 `n_control=3`）：
```python
centerline_sequence = [
    # 节点 1 (start)
    50, 60, 0, 0, 55, 65,
    # 节点 2 (continue)
    60, 70, 1, 0, 65, 75,
    # 节点 3 (fork)
    70, 80, 2, 2, 75, 85,  # ← fork_from_index=1 (1-based)
    ...
]
```

---

## 5. SAR 专属：分组信息构建

### 5.1 为什么需要分组？
**SAR（Semi-Autoregressive）** 的核心思想（论文 Section 3.3）：
- **组内并行**：同一子图的节点可以并行预测
- **组间因果**：后续子图依赖前面的子图

### 5.2 分组策略
在 `TransformOrderedBzLane2GraphSAR` 中：
```python
group_ids_tokens = []  # 每个 token 的分组 ID

# 每个子图分配一个组 ID
for gid, sub_sent in enumerate(scene_sentance_list, start=1):
    for node in sub_sent:
        # ... 构建 clause ...
        # 该 clause 的所有 token 都属于 gid 组
        group_ids_tokens.extend([gid] * clause_length)

results['sar_group_ids_pos'] = np.array(group_ids_tokens)
```

**示例**（3 个子图，每个 2 个节点，`clause_length=6`）：
```python
sar_group_ids_pos = [
    1,1,1,1,1,1,  # 节点 1（子图 1）
    1,1,1,1,1,1,  # 节点 2（子图 1）
    2,2,2,2,2,2,  # 节点 3（子图 2）
    2,2,2,2,2,2,  # 节点 4（子图 2）
    3,3,3,3,3,3,  # 节点 5（子图 3）
    3,3,3,3,3,3,  # 节点 6（子图 3）
]
```

### 5.3 掩码构建（在训练时）
在 `SARRNTRHead.forward()` 中：
```python
# 从 sar_group_ids_pos 构建完整的分组掩码
for bi in range(B):
    gids_pos = img_metas[bi]['sar_group_ids_pos']  # 仅正样本的 group ID
    gids_full = _expand_group_ids_from_pos(gids_pos, T)  # 扩展到完整长度 T
    
    # 构建分组掩码：同组内可见（0），不同组因果（-inf）
    tgt_mask = _build_group_mask_from_ids(gids_full, allow_mlm_intra=True)
    # tgt_mask[i, j] = 0 if group[i] == group[j] or group[i] > group[j]
    #                 -inf otherwise
```

**掩码示例**（4 个节点，分 2 组）：
```
       node0  node1  node2  node3
node0    0      0     -inf   -inf   ← 组1 只能看组1
node1    0      0     -inf   -inf   ← 组1 只能看组1
node2    0      0      0      0     ← 组2 可看组1+组2
node3    0      0      0      0     ← 组2 可看组1+组2
```

---

## 6. 最终训练样本格式

### 6.1 `img_metas` 字段
经过 pipeline 处理后，每个样本包含：
```python
{
    'token': '场景ID',
    'img': Tensor,  # 6视角图像 [6, 3, H, W]
    'lidar2img': [...],
    
    # ========== 道路网络标注 ==========
    'centerline_sequence': [574, x1, y1, lbl1, conn1, cx1, cy1, ...],  # 完整序列（含特殊 token）
    'centerline_coord': [[x1, y1], [x2, y2], ...],      # N × 2
    'centerline_label': [0, 1, 2, ...],                 # N (类型)
    'centerline_connect': [0, 0, 2, ...],               # N (连接索引)
    'centerline_coeff': [[cx1, cy1], ...],              # N × 2 (控制点)
    'n_control': 3,                                      # 贝塞尔控制点数
    
    # ========== SAR 专属 ==========
    'sar_group_ids_pos': [1,1,1,1,1,1, 1,1,1,1,1,1, 2,2,2,2,2,2, ...],  # 每个 token 的组 ID
}
```

### 6.2 训练时的处理
在 `SAR_RNTR.forward_pts_train()` 中：
```python
# 1. 构建输入序列（加 [START]，填充负样本）
input_seqs = []
for bi in range(B):
    box_label = torch.cat([coord, label, connect, coeff], dim=-1)  # 真实节点
    random_box_label = ...  # 随机填充的负样本
    input_seq = torch.cat([torch.ones(1) * self.start, box_label.flatten(), random_box_label.flatten()])
    input_seqs.append(input_seq)
input_seqs = torch.cat(input_seqs, dim=0)  # [B, T]

# 2. 调用 head（带 SAR mask）
outs = self.pts_bbox_head(
    bev_feats, 
    input_seqs, 
    img_metas,  # ← 包含 sar_group_ids_pos
    gt_targets
)
```

---

## 7. 完整代码调用链

### 7.1 数据加载阶段
```
CenterlineNuScenesDataset.load_data_list()
  ↓
parse_data_info(info)  # 提取 center_lines（原始格式）
  ↓
Pipeline[0]: LoadMultiViewImageFromFiles()  # 加载图像
  ↓
Pipeline[1]: LoadNusOrderedBzCenterline()   # 中心线 → 图结构
  ↓ (调用)
NusOrederedBzCenterLine(center_lines, grid_conf, bz_grid_conf)
  ├─ 坐标转换（米 → 网格）
  ├─ 密集点 → 稀疏节点
  └─ 构建图（nodes + adjacency + subgraphs）
  ↓
Pipeline[2]: TransformOrderedBzLane2GraphSAR()  # 图 → 序列 + SAR 分组
  ↓ (调用)
OrderedBzSceneGraph.sequelize_new(orderedDFS=True)
  ├─ DFS 遍历每个子图
  └─ 展平为序列，记录每个 token 的 group_id
  ↓
results = {
    'centerline_sequence': [...],
    'centerline_coord': [...],
    'centerline_label': [...],
    'centerline_connect': [...],
    'centerline_coeff': [...],
    'sar_group_ids_pos': [...]  # ← SAR 分组信息
}
  ↓
Pipeline[3]: Pack3DCenterlineInputs()  # 打包为 DataContainer
```

### 7.2 训练阶段
```
SAR_RNTR.forward_pts_train(bev_feats, gt_lines_coords, ..., img_metas)
  ├─ 构建 input_seqs = [START] + 真实节点 + 随机负样本  # [B, T]
  ├─ 构建 output_seqs = 真实节点 + [END] + padding       # [B, T]
  └─ 调用 head
        ↓
SARRNTRHead.forward(bev_feats, input_seqs, img_metas, ...)
  ├─ tgt = embedding(input_seqs)  # [B, T, D]
  ├─ 从 img_metas 提取 sar_group_ids_pos
  ├─ 为每个样本构建分组掩码 tgt_mask[bi]  # [T, T]
  └─ tgt_mask = torch.stack(masks_bt, dim=0)  # [B, T, T]
        ↓
LssSARPrmSeqLineTransformer.forward(..., tgt_mask=[B,T,T], ...)
  ├─ tgt = tgt.transpose(0, 1)  # [T, B, D]
  └─ decoder(tgt, memory, attn_masks=[tgt_mask, None])
        ↓
PlPryLineTransformerDecoderLayer._forward(...)
  ├─ self_attn: 使用 tgt_mask（组内并行、组间因果）
  └─ cross_attn: 使用 None（可见所有 BEV 特征）
        ↓
RNTR2MultiheadAttention.forward(..., attn_mask=tgt_mask)
  ├─ 规范化 tgt_mask: [B, T, T] → [B*num_heads, T, T]
  └─ nn.MultiheadAttention(..., attn_mask=[B*H, T, T])
        ↓
输出 logits: [L, B, T, V]  # L 层，V=576 类
```

---

## 8. 关键概念总结

### 8.1 坐标系转换
```
世界坐标 (x_world, y_world, z_world)
  ↓ (lidar2ego)
自车坐标 (x_ego, y_ego, z_ego)
  ↓ (投影到 BEV 网格)
BEV 网格坐标 (grid_x, grid_y)
  公式: grid_x = (x_ego - pc_range[0]) / dx
```

### 8.2 贝塞尔曲线表示
论文中使用**二次贝塞尔曲线**（Quadratic Bézier）连接节点：
```
B(t) = (1-t)² * P0 + 2(1-t)t * C + t² * P1
       ↑                ↑          ↑
       起点              控制点      终点
```
- `P0`, `P1`：节点坐标（已知）
- `C`：控制点（学习的目标，存储在 `centerline_coeff`）

### 8.3 序列表示的优势（论文 Section 3.2）
| 传统方法 | RoadNet 序列表示 |
|---------|----------------|
| 分别预测节点/边 | **统一序列**：节点+拓扑一起预测 |
| 需要后处理（NMS） | **端到端**：直接输出序列 |
| 难以建模拓扑 | **DFS 顺序**隐式编码拓扑 |

### 8.4 SAR 的优势（论文 Section 3.3）
| AR（自回归） | SAR（半自回归） |
|------------|---------------|
| 完全串行（慢） | **组内并行**（快） |
| 训练稳定 | **组间因果**保持训练稳定 |
| 推理慢 | **推理快**（并行解码） |

---

## 9. 常见问题（FAQ）

### Q1: 为什么要用贝塞尔曲线？
**A**: 
- 道路通常是**平滑的曲线**，贝塞尔曲线可以用少量参数（控制点）表示
- 减少序列长度，提升效率
- 便于后处理（渲染、插值）

### Q2: `sar_group_ids_pos` 为什么只包含正样本？
**A**:
- 训练时会添加随机负样本（padding），它们不属于任何子图
- 负样本的 group ID 在 head 中动态分配（通常设为最后一组）
- 减少存储开销

### Q3: 分组掩码如何保证"组内并行、组间因果"？
**A**:
```python
# 掩码构建伪代码
for i in range(T):
    for j in range(T):
        if group[i] == group[j]:
            mask[i, j] = 0         # 同组：可见（MLM 模式）
        elif group[i] > group[j]:
            mask[i, j] = 0         # 后组可看前组（因果）
        else:
            mask[i, j] = -inf      # 前组不可看后组（mask）
```

### Q4: 为什么需要 `clause_length`？
**A**:
- 每个节点编码为固定长度的子句（如 6 个 token）
- 方便序列切片和索引（如 `seq[::clause_length]` 提取 x 坐标）
- 对齐 Transformer 的 token 粒度

---

## 10. 参考资料

### 论文
- **RoadNetTransformer** (arXiv:2402.08207)  
  Section 3.2: Unified Sequence Representation  
  Section 3.3: Semi-Autoregressive Decoding (SAR)

### 代码文件
- 数据集：`rntr/centerline_nuscenes_dataset.py`
- 中心线处理：`rntr/transforms/centerline_utils.py`
- 序列化：`rntr/transforms/loading.py`
  - `LoadNusOrderedBzCenterline` (Line 1310)
  - `TransformOrderedBzLane2GraphSAR` (Line 584)
- SAR Head：`rntr/sar_rntr_head.py`
- 训练入口：`rntr/sar_rntr.py`

### 配置示例
- `configs/rntr_sar_roadseq/lss_sar_rntr_paper_fp16_torch2.py`

---

**完成！** 🎉

如有疑问，可参考代码中的注释或直接阅读论文相关章节。
