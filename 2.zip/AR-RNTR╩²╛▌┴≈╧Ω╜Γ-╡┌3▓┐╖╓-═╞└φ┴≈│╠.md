# AR-RNTR 数据流详解（第3部分：推理流程）

## 推理 vs 训练的区别

| 对比项 | 训练 | 推理 |
|-------|------|------|
| 输入序列 | 完整序列（含GT） | 只有[START] |
| 生成方式 | 并行（Teacher Forcing） | 自回归（逐token生成） |
| 输出 | 所有层的logits | 最终生成的序列 |
| 目标 | 计算损失 | 预测道路 |

---

## 1. 推理入口

**文件**：`rntr/ar_rntr.py`
**方法**：`predict(batch_inputs_dict, batch_data_samples)`

```python
def predict(self, batch_inputs_dict, batch_data_samples):
    """推理的入口函数"""
    # 提取图像
    img = batch_inputs_dict['img']  # [B, 6, 3, H, W]
    
    # 提取元数据（不含GT，但有相机标定等信息）
    img_metas = [item.metainfo for item in batch_data_samples]
    
    # 调用推理函数
    return self.simple_test(img_metas, img)
```

---

## 2. 推理主流程

**方法**：`simple_test(img_metas, img)`

```python
def simple_test(self, img_metas, img):
    """推理的主流程"""
    # 1. 提取BEV特征（和训练时完全一样）
    bev_feats = self.extract_feat(img, img_metas)
    # [B, 256, 200, 200]
    
    # 2. 自回归生成序列
    results = self.simple_test_pts(bev_feats, img_metas)
    
    return results
```

---

## 3. 自回归生成详解

**方法**：`simple_test_pts(pts_feats, img_metas)`

这是推理的**核心函数**！

### 3.1 初始化

```python
def simple_test_pts(self, pts_feats, img_metas):
    # 获取配置
    n_control = img_metas[0]['n_control']  # 3
    num_coeff = n_control - 2              # 1
    clause_length = 4 + num_coeff * 2      # 6
    
    device = pts_feats[0].device
    B = len(img_metas)
    
    # 初始化输入序列：只有[START]
    input_seqs = torch.ones(B, 1, device=device) * self.start
    # input_seqs = [[574]]  (假设batch=1)
```

### 3.2 解码器头的推理模式

**文件**：`rntr/ar_rntr_head.py`
**方法**：`ARRNTRHead.forward()` 的 else 分支

```python
def forward(self, mlvl_feats, input_seqs, img_metas):
    # ... 前面的BEV处理一样 ...
    
    if not self.training:  # 推理模式
        values = []
        
        # 自回归循环：max_iteration = max_center_len - 1 = 600
        for step in range(self.max_iteration):
            # 1. 嵌入当前序列
            tgt = self.embedding(input_seqs.long())  # [B, T, 256]
            query_embed = self.embedding.position_embeddings.weight
            
            # 2. Transformer解码
            outs_dec, _ = self.transformer(tgt, x, masks, query_embed, pos_embed)
            # [num_layers, B, T, 256]
            
            # 3. 只取最后一层、最后一个时间步
            outs_dec = outs_dec[-1, :, -1, :]  # [B, 256]
            
            # 4. 词表投影
            out = self.vocab_embed(outs_dec)  # [B, 576]
            
            # 5. Softmax + Top-1采样
            out = out.softmax(-1)
            value, extra_seq = out.topk(dim=-1, k=1)  # [B, 1]
            
            # 6. 追加到输入序列
            input_seqs = torch.cat([input_seqs, extra_seq], dim=-1)
            # input_seqs: [B, T] → [B, T+1]
            
            values.append(value)
        
        # 返回生成的序列和置信度
        values = torch.cat(values, dim=-1)
        return input_seqs, values
```

**逐步示例**：
```
Step 0: input_seqs = [574]
         ↓ 解码器
        预测: token=10 (x坐标)
        input_seqs = [574, 10]

Step 1: input_seqs = [574, 10]
         ↓ 解码器
        预测: token=20 (y坐标)
        input_seqs = [574, 10, 20]

Step 2: input_seqs = [574, 10, 20]
         ↓ 解码器
        预测: token=200 (起点)
        input_seqs = [574, 10, 20, 200]

... 循环600次 ...
```

### 3.3 后处理

回到 `simple_test_pts()`：

```python
def simple_test_pts(self, pts_feats, img_metas):
    # ... 初始化 ...
    
    # 调用解码器头（自回归生成）
    output_seqs, values = self.pts_bbox_head(pts_feats, input_seqs, img_metas)
    # output_seqs: [B, 1+600]（[START] + 生成的600个token）
    # values: [B, 600]（每个token的置信度）
    
    line_results = []
    
    # 遍历batch
    for bi in range(output_seqs.shape[0]):
        pred_line_seq = output_seqs[bi]
        
        # --- 1. 去掉[START] ---
        pred_line_seq = pred_line_seq[1:]  # [600]
        
        # --- 2. 找到[END]并截断 ---
        if self.end in pred_line_seq:
            # 找到第一个[END]的位置
            stop_idx = (pred_line_seq == self.end).nonzero()[0][0]
        else:
            # 如果没有[END]，就用全长
            stop_idx = len(pred_line_seq)
        
        # 对齐到子句边界
        stop_idx = stop_idx // clause_length * clause_length
        pred_line_seq = pred_line_seq[:stop_idx]
        
        # --- 3. Token ID 还原到语义空间 ---
        # 类别: 200-203 → 0-3
        pred_line_seq[2::clause_length] -= self.category_start
        
        # 连接: 250-... → 0-...
        pred_line_seq[3::clause_length] -= self.connect_start
        
        # 系数: 350-... → 0-...
        for k in range(4, clause_length):
            pred_line_seq[k::clause_length] -= self.coeff_start
        
        # --- 4. 合法性检查与修正 ---
        try:
            # 4.1 坐标裁剪到BEV网格范围
            xbound = self.view_transformers.grid_conf['xbound']
            ybound = self.view_transformers.grid_conf['ybound']
            NX = int((xbound[1] - xbound[0]) / xbound[2])  # 192
            NY = int((ybound[1] - ybound[0]) / ybound[2])  # 128
            
            pred_line_seq[0::clause_length] = pred_line_seq[0::clause_length].clamp(0, NX-1)
            pred_line_seq[1::clause_length] = pred_line_seq[1::clause_length].clamp(0, NY-1)
            
            # 4.2 类别裁剪到[0,3]
            pred_line_seq[2::clause_length] = pred_line_seq[2::clause_length].clamp(0, 3)
            
            # 4.3 系数裁剪到[0,199]
            for k in range(4, clause_length):
                pred_line_seq[k::clause_length] = pred_line_seq[k::clause_length].clamp(0, 199)
            
            # 4.4 连接合法性：必须指向前面的节点
            num_nodes = pred_line_seq.numel() // clause_length
            for i in range(num_nodes):
                conn_pos = 3 + i * clause_length
                
                if i == 0:
                    # 第一个节点连到自己
                    pred_line_seq[conn_pos] = 0
                else:
                    # 其他节点必须连到前面的节点
                    conn_idx = int(pred_line_seq[conn_pos].item())
                    conn_idx = max(0, min(conn_idx, i-1))
                    pred_line_seq[conn_pos] = conn_idx
        
        except Exception:
            pass  # 出错就跳过后处理
        
        # --- 5. 保存结果 ---
        line_results.append(pred_line_seq)
    
    return line_results
```

---

## 4. 推理流程图

```
输入图像 [B,6,3,H,W]
    ↓
extract_feat (BEV特征提取)
    ↓
BEV特征 [B,256,200,200]
    ↓
初始化 input_seqs = [[START]]
    ↓
┌──────────────────────┐
│  自回归循环 (600次)   │
│                      │
│  1. 嵌入 input_seqs  │
│  2. Transformer解码  │
│  3. 词表投影         │
│  4. Top-1采样        │
│  5. 追加到序列       │
└──────────────────────┘
    ↓
生成序列 [B, 1+600]
    ↓
后处理:
  - 去掉[START]
  - 截断到[END]
  - Token ID还原
  - 合法性修正
    ↓
输出序列 [N_nodes * clause_length]
```

---

## 5. 示例：一个完整的推理过程

假设生成了如下序列（已还原到语义空间）：

```
原始token序列（子句长度=6）:
[10, 20, 0, 0, 5, 8,    # 节点0: (10,20), 起点, 连到0, 系数(5,8)
 15, 25, 1, 0, 7, 9,    # 节点1: (15,25), 继续, 连到0, 系数(7,9)
 20, 30, 2, 1, 9, 11,   # 节点2: (20,30), 分叉, 连到1, 系数(9,11)
 25, 35, 1, 1, 10, 12]  # 节点3: (25,35), 继续, 连到1, 系数(10,12)
```

**解析成图结构**：
```
节点0 (10,20, 起点)
  ↓ (系数5,8)
节点1 (15,25, 继续)
  ↓ (系数7,9)          ↘ (系数9,11)
节点2 (20,30, 分叉)      节点3 (25,35, 继续, 系数10,12)
```

---

## 6. 推理的关键点

### 6.1 为什么用自回归？
- **原因**：道路是有序的，后面的节点依赖前面的节点
- **好处**：可以保证连接关系的因果性（connect < 当前索引）

### 6.2 什么时候停止？
- 遇到[END] token
- 达到最大长度（600）

### 6.3 如何保证合法性？
- **坐标**：裁剪到BEV网格范围
- **类别**：裁剪到[0,3]
- **连接**：强制指向前面的节点
- **系数**：裁剪到训练范围

### 6.4 推理速度
- **慢**：每个token都要跑一次Transformer（600次前向）
- **优化方向**：
  - 减小max_iteration
  - 使用更小的模型
  - 并行解码（非自回归模型）

---

## 7. 与训练的对比

| 操作 | 训练 | 推理 |
|-----|------|------|
| 输入序列 | `[START] + GT序列` | `[START]` |
| 解码方式 | Teacher Forcing（一次性） | 自回归（逐token） |
| 监督信号 | 所有位置都有GT | 无GT |
| 输出 | logits（用于计算loss） | 最终序列 |
| 速度 | 快（并行） | 慢（串行） |

---

下一步：开始逐行注释核心代码！
