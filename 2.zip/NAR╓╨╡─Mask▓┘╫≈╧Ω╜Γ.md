# NAR中的Mask操作详解：从原理到实现

> 本文档深入解析NAR-RNTR中的mask机制，包括训练时的MLM mask和推理时的迭代mask，适合理解mask操作的技术细节。

---

## 目录
1. [Mask机制概述](#1-mask机制概述)
2. [训练时的MLM Mask](#2-训练时的mlm-mask)
3. [推理时的迭代Mask](#3-推理时的迭代mask)
4. [特殊Token处理](#4-特殊token处理)
5. [Mask操作的具体实现](#5-mask操作的具体实现)
6. [Mask策略对比](#6-mask策略对比)
7. [实际运行示例](#7-实际运行示例)
8. [常见问题解答](#8-常见问题解答)

---

## 1. Mask机制概述

### 1.1 什么是Mask？

在NAR中，mask是一种**选择性隐藏**机制：
- **训练时**：随机隐藏部分token，让模型学习预测被隐藏的内容
- **推理时**：基于置信度隐藏不确定的预测，逐步优化生成质量

### 1.2 Mask的核心思想

```python
# Mask的基本概念
original_sequence = [START, x1, y1, lbl1, conn1, cx1, cy1, ...]
masked_sequence  = [START, MASK, y1, MASK, conn1, MASK, cy1, ...]
#                    ↑      ↑     ↑     ↑      ↑      ↑     ↑
#                   保留   隐藏   保留   隐藏   保留   隐藏   保留
```

### 1.3 两种Mask类型

| 类型 | 目的 | 策略 | 频率 |
|------|------|------|------|
| **MLM Mask** | 学习并行预测 | 随机mask 90% | 每个训练step |
| **迭代Mask** | 逐步优化质量 | 基于置信度mask | 每次推理迭代 |

---

## 2. 训练时的MLM Mask

### 2.1 MLM Mask流程

```python
def mlm_mask_process(input_seqs, output_seqs, mask_ratio=0.9):
    """
    MLM Mask处理流程
    """
    B, T = input_seqs.shape
    tail_len = T - 1  # 除了START token的长度
    
    # 步骤1：识别有效token
    valid_tail = (output_seqs[:, :-1] != NO_KNOWN)
    
    # 步骤2：生成随机mask
    rand_tail = torch.rand(B, tail_len, device=device)
    mask_tail = (rand_tail < mask_ratio) & valid_tail
    
    # 步骤3：确保至少一个mask
    ensure_minimum_mask(mask_tail, valid_tail)
    
    # 步骤4：应用mask
    masked_input = apply_input_mask(input_seqs, mask_tail)
    filtered_output = apply_output_filter(output_seqs, mask_tail)
    
    return masked_input, filtered_output
```

### 2.2 详细实现步骤

#### **步骤1：识别有效Token**

```python
# 只对真实的路网token进行mask，不mask NO_KNOWN
valid_tail = (output_seqs[:, :-1] != self.no_known)
```

**示例**：
```python
output_seqs = [START, x1, y1, lbl1, NO_KNOWN, NO_KNOWN, END]
valid_tail = [True, True, True, True, False, False]  # 只mask前4个位置
```

#### **步骤2：随机生成Mask**

```python
# 生成[0,1)之间的随机数
rand_tail = torch.rand(B, tail_len, device=device)
# 基于mask_ratio决定是否mask
mask_tail = (rand_tail < nar_mask_ratio) & valid_tail
```

**示例**（mask_ratio=0.9）：
```python
rand_tail = [0.1, 0.8, 0.95, 0.3, 0.7, 0.2]
mask_tail = [True, False, True, True, False, True]  # < 0.9的位置被mask
```

#### **步骤3：确保最小Mask**

```python
# 确保每个样本至少有一个masked token
no_any = (~mask_tail.any(dim=1)) & (valid_tail.any(dim=1))
if no_any.any():
    idxs = torch.nonzero(no_any, as_tuple=False).view(-1)
    for bi in idxs.tolist():
        vidx = torch.nonzero(valid_tail[bi], as_tuple=False).view(-1)
        if vidx.numel() > 0:
            # 随机选择一个有效位置进行mask
            j = int(vidx[torch.randint(0, vidx.numel(), (1,), device=device)])
            mask_tail[bi, j] = True
```

**为什么需要这个步骤？**
- 如果某个样本没有mask任何token，就没有学习目标
- 保证每个样本都有至少一个预测任务

#### **步骤4：应用输入Mask**

```python
# 保持START token不变，只mask后面的token
tail_in = input_seqs[:, 1:]
input_seqs = torch.cat([
    input_seqs[:, :1],  # START token保持不变
    torch.where(mask_tail, 
                torch.full_like(tail_in, self.no_known),  # 被mask的位置
                tail_in)  # 未被mask的位置
], dim=1)
```

**示例**：
```python
# 原始输入
input_seqs = [START, x1, y1, lbl1, conn1, cx1, cy1]
mask_tail = [True, False, True, False, True, False]

# Mask后
masked_input = [START, NO_KNOWN, y1, NO_KNOWN, conn1, NO_KNOWN, cy1]
#                ↑      ↑        ↑     ↑        ↑      ↑        ↑
#               保留    mask     保留   mask     保留   mask     保留
```

#### **步骤5：过滤输出标签**

```python
# 只对被mask的位置计算损失
tail_lbl = output_seqs[:, :-1]
tail_lbl = torch.where(mask_tail, 
                      tail_lbl,  # 被mask的位置保留真实标签
                      torch.full_like(tail_lbl, self.no_known))  # 未mask位置设为NO_KNOWN
output_seqs = torch.cat([tail_lbl, output_seqs[:, -1:]], dim=1)
```

**示例**：
```python
# 原始输出
output_seqs = [START, x1, y1, lbl1, conn1, cx1, cy1, END]
mask_tail = [True, False, True, False, True, False]

# 过滤后
filtered_output = [START, x1, NO_KNOWN, lbl1, NO_KNOWN, cx1, NO_KNOWN, END]
#                   ↑     ↑     ↑        ↑     ↑        ↑     ↑        ↑
#                  保留   保留   mask     保留   mask     保留   mask     保留
```

### 2.3 MLM Mask的关键特点

1. **高Mask比例**：90%的token被mask，迫使模型学习强上下文理解
2. **随机性**：每次训练都不同，提高模型鲁棒性
3. **有效性保证**：只mask真实token，确保学习目标明确
4. **最小保证**：每个样本至少有一个mask，避免无学习目标

---

## 3. 推理时的迭代Mask

### 3.1 迭代Mask流程

```python
def iterative_mask_inference(model, max_iters=3):
    """
    迭代Mask推理流程
    """
    # 初始化：全mask序列
    seq = initialize_with_start_and_mask()
    
    for iteration in range(max_iters):
        # 1. 预测所有token
        predictions, confidences = model.predict(seq)
        
        # 2. 基于置信度决定保留策略
        keep_mask = compute_keep_mask(confidences)
        
        # 3. 更新序列
        if iteration == max_iters - 1:
            # 最后一次：接受所有预测
            seq = predictions
        else:
            # 中间迭代：保留高置信度，重新mask低置信度
            seq = update_sequence_with_mask(seq, predictions, keep_mask)
    
    return seq
```

### 3.2 详细实现步骤

#### **步骤1：初始化**

```python
# 初始化：[START] + [NO_KNOWN]
seq = torch.full((B, T), int(self.no_known), device=x.device, dtype=torch.long)
seq[:, 0] = int(self.start)  # 第一个位置设为START
```

**示例**：
```python
# 初始序列
seq = [START, NO_KNOWN, NO_KNOWN, NO_KNOWN, NO_KNOWN, NO_KNOWN, NO_KNOWN]
#       ↑      ↑        ↑        ↑        ↑        ↑        ↑
#      START   mask     mask     mask     mask     mask     mask
```

#### **步骤2：预测和置信度计算**

```python
# 编码当前序列
tgt = self.embedding(seq.long())

# 使用零mask（完全并行）
tgt_mask_zero = torch.zeros(T, T, device=tgt.device)

# 通过Transformer预测
outs_dec, _ = self.transformer(tgt, x, tgt_mask_zero, masks, query_embed, pos_embed)
logits = self.vocab_embed(outs_dec)
probs = logits.softmax(-1)
values_i, tokens = probs.max(dim=-1)
seq_pred = tokens[-1]
last_values = values_i[-1]  # 置信度 [B, T]
```

**示例**：
```python
# 预测结果
seq_pred = [START, pred_x1, pred_y1, pred_lbl1, pred_conn1, pred_cx1, pred_cy1]
# 置信度
confidences = [1.0, 0.3, 0.8, 0.2, 0.7, 0.1, 0.9]
#              ↑    ↑    ↑    ↑    ↑    ↑    ↑
#             START 低   高   低   高   低   高
```

#### **步骤3：置信度策略**

**阈值策略**：
```python
conf = last_values  # [B, T]
keep_mask = (conf >= float(getattr(self, 'nar_conf_thresh', 0.5)))
```

**Top-K策略**：
```python
kr = float(getattr(self, 'nar_keep_ratio', 0.0))
if kr > 0.0 and T > 1:
    k_top = max(1, int(round((T - 1) * kr)))
    conf_tail = conf[:, 1:]  # 排除START token
    topk_vals, topk_idx = torch.topk(conf_tail, k=k_top, dim=-1)
    keep_topk = torch.zeros_like(conf_tail, dtype=torch.bool)
    gather = torch.arange(keep_topk.shape[0], device=keep_topk.device).unsqueeze(-1)
    keep_topk[gather, topk_idx] = True
    # 与阈值策略结合
    keep_tail = keep_mask[:, 1:] | keep_topk
    keep_mask = torch.cat([keep_mask[:, :1], keep_tail], dim=1)
```

**示例**（conf_thresh=0.5, keep_ratio=0.2）：
```python
confidences = [1.0, 0.3, 0.8, 0.2, 0.7, 0.1, 0.9]
# 阈值策略
threshold_mask = [True, False, True, False, True, False, True]
# Top-K策略 (k=1, 选择最高置信度)
topk_mask = [True, False, False, False, False, False, True]
# 结合策略
keep_mask = [True, False, True, False, True, False, True]
```

#### **步骤4：应用Mask**

```python
# 总是保留START token
keep_mask[:, 0] = True

# 应用masking：保留高置信度，重新mask低置信度
remask = torch.full_like(seq_pred, int(self.no_known))
seq = torch.where(keep_mask, seq_pred, remask)
```

**示例**：
```python
# 当前序列
seq = [START, NO_KNOWN, NO_KNOWN, NO_KNOWN, NO_KNOWN, NO_KNOWN, NO_KNOWN]
# 预测结果
seq_pred = [START, pred_x1, pred_y1, pred_lbl1, pred_conn1, pred_cx1, pred_cy1]
# 保留mask
keep_mask = [True, False, True, False, True, False, True]

# 更新后序列
seq = [START, NO_KNOWN, pred_y1, NO_KNOWN, pred_conn1, NO_KNOWN, pred_cy1]
#        ↑      ↑        ↑        ↑        ↑        ↑        ↑
#       保留    mask     保留     mask     保留     mask     保留
```

#### **步骤5：最后一次迭代**

```python
# 最后一次迭代：接受所有预测
if it == iters - 1:
    seq = seq_pred
    break
```

**示例**：
```python
# 最终序列
seq = [START, pred_x1, pred_y1, pred_lbl1, pred_conn1, pred_cx1, pred_cy1]
#        ↑      ↑        ↑        ↑        ↑        ↑        ↑
#       保留    接受     接受     接受     接受     接受     接受
```

### 3.3 迭代Mask的关键特点

1. **逐步优化**：每次迭代都提高预测质量
2. **置信度驱动**：基于模型自身的置信度决定保留策略
3. **完全并行**：使用零mask实现完全并行计算
4. **最终接受**：最后一次迭代接受所有预测

---

## 4. 特殊Token处理

### 4.1 特殊Token定义

```python
# 特殊token ID定义
self.no_known = 575  # padding/unknown token
self.start = 574     # START token  
self.end = 573       # END token
```

### 4.2 各Token的Mask行为

| Token | 训练时 | 推理时 | 说明 |
|-------|--------|--------|------|
| **START** | 从不mask | 总是保留 | 序列开始标志 |
| **END** | 正常处理 | 序列结束标志 | 序列结束标志 |
| **NO_KNOWN** | 用作mask占位符 | 用作低置信度占位符 | 表示未知/待预测 |

### 4.3 START Token的特殊处理

```python
# 训练时：保持START token不变
input_seqs = torch.cat([
    input_seqs[:, :1],  # START token
    torch.where(mask_tail, torch.full_like(tail_in, self.no_known), tail_in)
], dim=1)

# 推理时：总是保留START token
seq_pred[:, 0] = int(self.start)
keep_mask[:, 0] = True
```

### 4.4 NO_KNOWN Token的作用

**训练时**：
```python
# 作为mask的占位符
masked_input = [START, NO_KNOWN, y1, NO_KNOWN, conn1, ...]
#                ↑      ↑        ↑     ↑        ↑
#               保留    mask     保留   mask     保留
```

**推理时**：
```python
# 作为低置信度预测的占位符
seq = [START, NO_KNOWN, pred_y1, NO_KNOWN, pred_conn1, ...]
#        ↑      ↑        ↑        ↑        ↑
#       保留    mask     保留     mask     保留
```

---

## 5. Mask操作的具体实现

### 5.1 核心Mask函数

```python
def apply_input_mask(input_seqs, mask_tail):
    """
    应用输入mask
    """
    tail_in = input_seqs[:, 1:]  # 除了START token
    masked_tail = torch.where(
        mask_tail, 
        torch.full_like(tail_in, self.no_known),  # 被mask的位置
        tail_in  # 未被mask的位置
    )
    return torch.cat([input_seqs[:, :1], masked_tail], dim=1)

def apply_output_filter(output_seqs, mask_tail):
    """
    过滤输出标签
    """
    tail_lbl = output_seqs[:, :-1]  # 除了END token
    filtered_tail = torch.where(
        mask_tail,
        tail_lbl,  # 被mask的位置保留真实标签
        torch.full_like(tail_lbl, self.no_known)  # 未mask位置设为NO_KNOWN
    )
    return torch.cat([filtered_tail, output_seqs[:, -1:]], dim=1)

def compute_keep_mask(confidences, conf_thresh=0.5, keep_ratio=0.0):
    """
    计算保留mask
    """
    # 阈值策略
    keep_mask = (confidences >= conf_thresh)
    
    # Top-K策略
    if keep_ratio > 0.0:
        T = confidences.shape[1]
        k_top = max(1, int(round((T - 1) * keep_ratio)))
        conf_tail = confidences[:, 1:]  # 排除START
        topk_vals, topk_idx = torch.topk(conf_tail, k=k_top, dim=-1)
        keep_topk = torch.zeros_like(conf_tail, dtype=torch.bool)
        gather = torch.arange(keep_topk.shape[0], device=keep_topk.device).unsqueeze(-1)
        keep_topk[gather, topk_idx] = True
        keep_tail = keep_mask[:, 1:] | keep_topk
        keep_mask = torch.cat([keep_mask[:, :1], keep_tail], dim=1)
    
    # 总是保留START
    keep_mask[:, 0] = True
    
    return keep_mask
```

### 5.2 Mask操作的数学表示

**训练时MLM**：
```
L_MLM = -∑_{i∈M} log P(x_i | x_{¬M})
```
其中：
- M：被mask的位置集合
- x_i：第i个token的真实值
- x_{¬M}：未被mask的token

**推理时迭代**：
```
x^{(t+1)}_i = {
    x^{(t)}_i,     if conf_i ≥ θ
    MASK,         if conf_i < θ
}
```
其中：
- x^{(t)}_i：第t次迭代第i个token的预测
- conf_i：第i个token的置信度
- θ：置信度阈值

---

## 6. Mask策略对比

### 6.1 训练vs推理对比

| 方面 | MLM Mask (训练) | 迭代Mask (推理) |
|------|----------------|----------------|
| **目的** | 学习并行预测 | 逐步优化质量 |
| **策略** | 随机mask | 置信度驱动 |
| **比例** | 90% | 动态调整 |
| **频率** | 每个step | 每次迭代 |
| **保留** | START token | START + 高置信度 |
| **目标** | 预测被mask的token | 优化所有token |

### 6.2 不同置信度阈值的效果

| 阈值 | 保留比例 | 质量 | 速度 | 适用场景 |
|------|----------|------|------|----------|
| 0.3 | 高 | 一般 | 快 | 快速推理 |
| 0.5 | 中等 | 好 | 中等 | 平衡模式 |
| 0.7 | 低 | 很好 | 慢 | 高质量需求 |

### 6.3 不同迭代次数的影响

| 迭代次数 | 质量提升 | 速度影响 | 推荐场景 |
|----------|----------|----------|----------|
| 1 | 基础 | 最快 | 实时应用 |
| 3 | 显著 | 中等 | 平衡模式 |
| 5+ | 很好 | 较慢 | 离线处理 |

---

## 7. 实际运行示例

### 7.1 训练时MLM示例

```python
# 原始数据
input_seqs = [START, x1, y1, lbl1, conn1, cx1, cy1, x2, y2, lbl2, conn2, cx2, cy2]
output_seqs = [START, x1, y1, lbl1, conn1, cx1, cy1, x2, y2, lbl2, conn2, cx2, cy2, END]

# 随机mask (mask_ratio=0.9)
mask_tail = [True, False, True, False, True, False, True, True, False, True, False, True]

# Mask后输入
masked_input = [START, NO_KNOWN, y1, NO_KNOWN, conn1, NO_KNOWN, cy1, NO_KNOWN, y2, NO_KNOWN, conn2, NO_KNOWN]

# 过滤后输出
filtered_output = [START, x1, NO_KNOWN, lbl1, NO_KNOWN, cx1, NO_KNOWN, x2, NO_KNOWN, lbl2, NO_KNOWN, cx2, NO_KNOWN, END]

# 模型学习：根据上下文预测被mask的token
```

### 7.2 推理时迭代示例

```python
# 迭代1：全mask初始化
seq_1 = [START, NO_KNOWN, NO_KNOWN, NO_KNOWN, NO_KNOWN, NO_KNOWN, NO_KNOWN]
# 预测结果
pred_1 = [START, pred_x1, pred_y1, pred_lbl1, pred_conn1, pred_cx1, pred_cy1]
conf_1 = [1.0, 0.3, 0.8, 0.2, 0.7, 0.1, 0.9]
# 保留高置信度
seq_2 = [START, NO_KNOWN, pred_y1, NO_KNOWN, pred_conn1, NO_KNOWN, pred_cy1]

# 迭代2：基于部分预测
pred_2 = [START, pred_x1_new, pred_y1, pred_lbl1_new, pred_conn1, pred_cx1_new, pred_cy1]
conf_2 = [1.0, 0.6, 0.9, 0.5, 0.8, 0.4, 0.95]
# 保留更多高置信度
seq_3 = [START, pred_x1_new, pred_y1, NO_KNOWN, pred_conn1, NO_KNOWN, pred_cy1]

# 迭代3：最终接受所有预测
final_seq = [START, pred_x1_new, pred_y1, pred_lbl1_new, pred_conn1, pred_cx1_new, pred_cy1]
```

---

## 8. 常见问题解答

### Q1: 为什么训练时mask 90%而不是50%？
**A**: 
- 90%的高mask比例迫使模型学习更强的上下文理解
- 遵循BERT的成功经验，证明有效
- 提高模型对部分信息的鲁棒性

### Q2: 如何选择置信度阈值？
**A**: 
- **0.3-0.4**：激进，保留更多预测，速度快
- **0.5-0.6**：平衡，推荐设置
- **0.7+**：保守，只保留高置信度，质量好但速度慢

### Q3: Top-K策略和阈值策略如何结合？
**A**: 
- 两种策略取并集：`keep_mask = threshold_mask | topk_mask`
- Top-K确保保留一定数量的预测
- 阈值确保保留高质量的预测

### Q4: 为什么START token从不被mask？
**A**: 
- START token提供序列开始的上下文信息
- 保持序列结构的完整性
- 避免模型失去序列起始的参考点

### Q5: 如何处理mask后的序列长度不一致？
**A**: 
- 使用NO_KNOWN token作为占位符
- 保持序列长度不变
- 在损失计算时忽略NO_KNOWN位置

### Q6: 迭代次数越多越好吗？
**A**: 
- 不是，通常3-5次迭代就足够
- 更多迭代会带来边际收益递减
- 需要平衡质量和速度

### Q7: 如何调试mask操作？
**A**: 
```python
# 添加调试信息
print(f"Mask ratio: {mask_ratio}")
print(f"Valid tokens: {valid_tail.sum()}")
print(f"Masked tokens: {mask_tail.sum()}")
print(f"Confidence range: {confidences.min():.3f} - {confidences.max():.3f}")
```

---

## 总结

NAR中的mask机制是连接训练和推理的关键技术：

1. **训练时MLM Mask**：随机mask 90%的token，学习并行预测能力
2. **推理时迭代Mask**：基于置信度逐步优化，提高生成质量
3. **特殊Token处理**：START保留，NO_KNOWN作为占位符
4. **策略组合**：阈值+Top-K策略平衡质量和速度

这种mask机制确保了NAR既能学习并行预测，又能在推理时逐步优化，是实现高效非自回归生成的核心技术。

---

*本文档详细解释了NAR中mask操作的每个细节，帮助读者深入理解mask机制的设计原理和实现方法。*
