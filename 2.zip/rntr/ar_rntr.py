# ====================================================================================
# 文件说明：ar_rntr.py
# 功能：AR-RNTR 模型的主文件，定义了自回归（AutoRegressive）道路网络Transformer
# 作者：RoadNetwork项目组
# ====================================================================================

# 导入标准库
import os        # 中文：操作系统接口，用于文件路径操作
import cv2       # 中文：OpenCV图像处理库，用于可视化
import torch     # 中文：PyTorch深度学习框架
import torch.nn as nn  # 中文：PyTorch神经网络模块
import torch.nn.functional as F  # 中文：PyTorch函数式API
from mmengine.structures import InstanceData  # 中文：mmengine的实例数据结构
import numpy as np  # 中文：NumPy科学计算库
import time      # 中文：时间处理模块
import torch.distributed as dist  # 中文：PyTorch分布式训练模块

# 可选：SwanLab实时实验跟踪（用于可视化训练过程）
try:
    import swanlab  # 中文：SwanLab实验管理库（pip install swanlab）
    _SWANLAB_AVAILABLE = True  # 中文：标记SwanLab是否可用
except Exception:
    swanlab = None  # 中文：如果导入失败，设为None
    _SWANLAB_AVAILABLE = False  # 中文：标记为不可用

# 从mmdet3d导入基类和工具
from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector  # 中文：多视图两阶段检测器基类
from mmdet3d.registry import MODELS  # 中文：模型注册器，用于注册自定义模型
from mmdet3d.structures.ops import bbox3d2result  # 中文：3D边界框转结果的工具函数

# 从本地模块导入
from .grid_mask import GridMask  # 中文：GridMask数据增强（训练时随机遮挡图像网格）
from .LiftSplatShoot import LiftSplatShootEgo  # 中文：LSS模块，将多视图图像投影到BEV（鸟瞰图）
from .core import seq2nodelist, seq2bznodelist, seq2plbznodelist, av2seq2bznodelist  # 中文：序列与节点列表转换工具


@MODELS.register_module()  # 中文：将AR_RNTR注册到mmdet3d的模型注册器中，使其可以通过配置文件实例化
class AR_RNTR(MVXTwoStageDetector):  # 中文：AR_RNTR类，继承自多视图两阶段检测器基类
    """AR-RNTR: AutoRegressive Road Network Transformer
    
    中文说明：
    这是一个自回归的道路网络Transformer模型。
    
    核心思想：
    - 将道路图结构表示为一维token序列
    - 使用Transformer逐token生成道路序列
    - 每个节点表示为一个"子句"：[x坐标, y坐标, 节点类型, 连接关系, 贝塞尔系数]
    
    主要功能：
    1. 训练模式：给定GT序列，计算预测损失
    2. 推理模式：从[START]开始，自回归生成完整道路序列
    """
    def __init__(self,
                 # === 数据增强参数 ===
                 use_grid_mask=False,  # 中文：是否使用GridMask数据增强（随机遮挡图像网格）
                 # === 点云相关参数（本模型不使用点云，保留兼容性） ===
                 pts_voxel_layer=None,  # 中文：点云体素化层（本模型不用）
                 pts_middle_encoder=None,  # 中文：点云中间编码器（本模型不用）
                 pts_fusion_layer=None,  # 中文：点云融合层（本模型不用）
                 # === 图像骨干网络 ===
                 img_backbone=None,  # 中文：图像骨干网络（如ResNet50），用于提取图像特征
                 pts_backbone=None,  # 中文：点云骨干网络（本模型不用）
                 # === 特征金字塔网络 ===
                 img_neck=None,  # 中文：图像颈部网络（如FPN），用于融合多尺度特征
                 pts_neck=None,  # 中文：点云颈部网络（本模型不用）
                 # === LSS与BEV配置 ===
                 lss_cfg=None,  # 中文：LSS（Lift-Splat-Shoot）配置，用于图像到BEV的投影
                 grid_conf=None,  # 中文：BEV网格配置（范围、分辨率等）
                 data_aug_conf=None,  # 中文：数据增强配置（图像大小、裁剪等）
                 # === 检测头 ===
                 pts_bbox_head=None,  # 中文：序列解码器头（ARRNTRHead），核心模块
                 img_roi_head=None,  # 中文：图像ROI头（本模型不用）
                 img_rpn_head=None,  # 中文：图像RPN头（本模型不用）
                 # === 训练与测试配置 ===
                 train_cfg=None,  # 中文：训练配置
                 test_cfg=None,  # 中文：测试配置
                 pretrained=None,  # 中文：预训练权重路径
                 # === 可视化配置 ===
                 vis_cfg=None,  # 中文：可视化配置（保存路径等）
                 # === 其他参数 ===
                 freeze_pretrain=True,  # 中文：是否冻结预训练权重（backbone、neck、LSS）
                 bev_scale=1.0,  # 中文：BEV特征图的缩放比例
                 epsilon=2,  # 中文：用于某些数值稳定性处理的epsilon值
                 max_box_num=100,  # 中文：最大节点数（训练时会填充到这个数量）
                 init_cfg=None,  # 中文：初始化配置
                 data_preprocessor=None,  # 中文：数据预处理器
                 # === SwanLab可选参数（实验跟踪）===
                 swanlab_enable=False,  # 中文：是否启用SwanLab实验跟踪
                 swanlab_project='RoadNet',  # 中文：SwanLab项目名称
                 swanlab_run_name=None,  # 中文：SwanLab运行名称
                 swanlab_log_interval=50,  # 中文：SwanLab日志记录间隔（每N个iter记录一次）
                 swanlab_image_interval=200,  # 中文：SwanLab图像记录间隔（每N个iter记录一次可视化图像）
                 # === TIT拓扑继承训练配置 ===
                 tit_cfg=None,  # 中文：TIT（Topology-Inherited Training）配置，用于拓扑邻域软监督
                 # === 教师BEV直通（用于蒸馏）===
                 use_bev_teacher_input=False,  # 中文：是否直接使用教师模型的BEV特征（跳过LSS）
                 ):
        # 中文：调用父类（MVXTwoStageDetector）的初始化函数，传入所有基础模块
        super(AR_RNTR, self).__init__(pts_voxel_layer, pts_middle_encoder,
                                                        pts_fusion_layer, img_backbone, pts_backbone,
                                                        img_neck, pts_neck, pts_bbox_head, img_roi_head,
                                                        img_rpn_head, train_cfg, test_cfg, init_cfg,
                                                        data_preprocessor)
        # 中文：初始化GridMask数据增强模块（训练时随机遮挡图像的网格区域，增强鲁棒性）
        self.grid_mask = GridMask(True, True, rotate=1, offset=False, ratio=0.5, mode=1, prob=0.7)
        # 中文：保存是否使用GridMask的标志
        self.use_grid_mask = use_grid_mask
        # data_aug_conf = {
        #     'final_dim': (128, 352),
        #     'H': 900, 'W': 1600,
        # }
        # self.up = Up(512, 256, scale_factor=2)
        # view_transformers = []
        # view_transformers.append(
        #     LiftSplatShoot(grid_conf, data_aug_conf, downsample=16, d_in=256, d_out=256, return_bev=True))
        # self.view_transformers = nn.ModuleList(view_transformers)
        # self.view_transformers = LiftSplatShoot(grid_conf, data_aug_conf, downsample=16, d_in=256, d_out=256, return_bev=True)
        # 中文：初始化LSS（Lift-Splat-Shoot）模块，用于将多视图图像特征投影到BEV平面
        # LSS原理：Lift（预测深度）→ Splat（投影到3D）→ Shoot（俯视得到BEV）
        self.view_transformers = LiftSplatShootEgo(grid_conf, data_aug_conf, return_bev=True, **lss_cfg)
        # 中文：保存下采样倍数（例如16表示特征图相对原图缩小16倍）
        self.downsample = lss_cfg['downsample']
        # 中文：保存最终图像尺寸（经过resize后的尺寸，如(128, 352)）
        self.final_dim = data_aug_conf['final_dim']

        # === 词表（Vocabulary）定义 ===
        # 中文：词表总大小=576，包含所有可能的token ID（0-575）
        self.num_center_classes = 576
        # 中文：BEV坐标范围上限（坐标token的取值范围是0-199）
        self.box_range = 200
        # 中文：贝塞尔系数范围上限（系数token的取值范围是0-199）
        self.coeff_range = 200
        # 中文：节点类型数量=4（起点、继续、分叉、合并）
        self.num_classes=4
        # 中文：类别token的起始ID=200（类别0-3映射到token 200-203）
        self.category_start = 200
        # 中文：连接token的起始ID=250（连接到节点i映射到token 250+i）
        self.connect_start = 250
        # 中文：系数token的起始ID=350（系数值c映射到token 350+c）
        self.coeff_start = 350
        self.no_known = 575  # n/a and padding share the same label to be eliminated from loss calculation
        # 中文注释：no_known=575 表示“未知/填充”标记，所有等于该ID的监督会在loss前被过滤掉，不纳入损失。
        self.start = 574
        # 中文注释：start=574 是解码起始标记，训练/推理时作为序列第一个token输入。
        self.end = 573
        # 中文注释：end=573 是序列结束标记，用于截断监督/推理结果（不参与解码子句内部）。
        self.noise_connect = 572
        # 中文注释：noise_connect=572 仅用于“负样本子句”中的connect位，作为噪声引导，不参与正样本的监督。
        self.noise_label = 571
        # 中文注释：noise_label=571 仅用于“负样本子句”中的label位，作为困难负样本标签，提升分类鲁棒性。
        self.noise_coeff = 570
        # 中文注释：noise_coeff=570 仅用于“负样本子句”中的Bezier系数位，代表占位/不纳入监督。
        self.vis_cfg = vis_cfg
        self.bev_scale = bev_scale
        self.epsilon = epsilon
        self.max_box_num = max_box_num
        # Topology-Inherited Training (TIT) config (disabled by default)
        self.tit_cfg = tit_cfg or {}
        self.tit_enable = bool(self.tit_cfg.get('enable', False))
        self.tit_k = int(self.tit_cfg.get('k', 4))              # top-K nearest neighbors
        self.tit_alpha = float(self.tit_cfg.get('alpha', 0.3))  # neighbor smoothing weight
        self.tit_weight = float(self.tit_cfg.get('weight', 1.0))
        # Distillation (stage-2) controls
        self.tit_distill = bool(self.tit_cfg.get('distill', False))
        self.tit_distill_only = bool(self.tit_cfg.get('distill_only', False))
        self.tit_distill_weight = float(self.tit_cfg.get('distill_weight', 1.0))
        # Stage-1: use LiDAR BEV (teacher) as direct BEV input
        self.use_bev_teacher_input = bool(use_bev_teacher_input)

        # SwanLab runtime config (only active when enabled and package available)
        self.swanlab_enable = bool(swanlab_enable) or (os.getenv('SWANLAB_ENABLE', '0').lower() in ('1', 'true', 'yes'))
        self.swanlab_project = swanlab_project
        self.swanlab_run_name = swanlab_run_name
        self.swanlab_log_interval = max(1, int(swanlab_log_interval))
        self.swanlab_image_interval = max(1, int(swanlab_image_interval))
        self._swanlab_ready = False
        self._global_step = 0
        self._swanlab_img_step = 0

        if freeze_pretrain:
            self.freeze_pretrain()
    
    def freeze_pretrain(self):
        for m in self.img_backbone.parameters():
            m.requires_grad=False
        for m in self.img_neck.parameters():
            m.requires_grad=False
        for m in self.view_transformers.parameters():
            m.requires_grad=False

    # ---------------------- SwanLab utils ----------------------
    def _is_main_process(self):
        try:
            if not dist.is_available() or not dist.is_initialized():
                return True
            return dist.get_rank() == 0
        except Exception:
            return True

    def _init_swanlab(self, cfg: dict = None):
        if self._swanlab_ready:
            return
        if not self.swanlab_enable or not _SWANLAB_AVAILABLE:
            return
        if not self._is_main_process():
            return
        run_name = self.swanlab_run_name or f'AR_RNTR_{int(time.time())}'
        try:
            swanlab.init(project=self.swanlab_project,
                         experiment_name=run_name,
                         config=cfg or {})
            self._swanlab_ready = True
        except Exception:
            # Fail-safe: do not crash training if init fails
            self._swanlab_ready = False

    @staticmethod
    def _to_float(value):
        try:
            if isinstance(value, (list, tuple)):
                vals = []
                for v in value:
                    if torch.is_tensor(v):
                        vals.append(v.detach().float().mean().item())
                    else:
                        try:
                            vals.append(float(v))
                        except Exception:
                            pass
                return sum(vals) / len(vals) if len(vals) > 0 else None
            if torch.is_tensor(value):
                return value.detach().float().mean().item()
            return float(value)
        except Exception:
            return None

    def _render_bev_overlay(self, gt_coords_sample, pred_tokens_sample, clause_length, canvas_size=200):
        try:
            # Prepare canvas
            H = W = int(canvas_size)
            canvas = np.zeros((H, W, 3), dtype=np.uint8)
            # GT coords
            gt = np.array(gt_coords_sample, dtype=np.int32)
            if gt.ndim == 1:
                gt = gt.reshape(-1, 2)
            # Draw GT points (green)
            for (x, y) in gt:
                if 0 <= x < W and 0 <= y < H:
                    cv2.circle(canvas, (int(x), int(y)), 1, (0, 255, 0), -1)
            # Pred coords from tokens
            pred_xy = []
            T = int(pred_tokens_sample.shape[0])
            max_nodes = T // clause_length
            for i in range(max_nodes):
                idx_x = i * clause_length + 0
                idx_y = i * clause_length + 1
                if idx_y >= T:
                    break
                x = int(pred_tokens_sample[idx_x].item())
                y = int(pred_tokens_sample[idx_y].item())
                x = max(0, min(W - 1, x))
                y = max(0, min(H - 1, y))
                pred_xy.append((x, y))
            # Draw Pred points (red)
            for (x, y) in pred_xy:
                cv2.circle(canvas, (x, y), 1, (0, 0, 255), -1)
            # Put legend
            cv2.rectangle(canvas, (0, 0), (110, 28), (32, 32, 32), -1)
            cv2.putText(canvas, 'GT: green', (4, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)
            cv2.putText(canvas, 'Pred: red', (4, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 255), 1, cv2.LINE_AA)
            return canvas
        except Exception:
            return None

    def _swanlab_log_image(self, name: str, img: np.ndarray, step: int):
        if not (self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process() and self._swanlab_ready):
            return
        try:
            # Convert BGR->RGB
            rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            # Try different SwanLab image logging APIs for compatibility
            if hasattr(swanlab, 'Image'):
                try:
                    im = swanlab.Image(rgb)
                    swanlab.log({name: im}, step=step)
                    return
                except Exception:
                    pass
            if hasattr(swanlab, 'log_image'):
                try:
                    swanlab.log_image(name, rgb, step=step)
                    return
                except Exception:
                    pass
            # Fallback: save temp file and log its path as text
            tmp_dir = '/tmp/swanlab_vis'
            os.makedirs(tmp_dir, exist_ok=True)
            tmp_path = os.path.join(tmp_dir, f'{name.replace("/", "_")}_{step}.png')
            cv2.imwrite(tmp_path, img)
            try:
                swanlab.log({f'{name}_path': tmp_path}, step=step)
            except Exception:
                pass
        except Exception:
            pass

    def extract_img_feat(self, img, img_metas):
        """Extract features of images."""
        # print(img[0].size())
        if isinstance(img, list):
            img = torch.stack(img, dim=0)

        B = img.size(0)
        if img is not None:
            input_shape = img.shape[-2:]
            # update real input shape of each single img
            for img_meta in img_metas:
                img_meta.update(input_shape=input_shape)
            if img.dim() == 5:
                if img.size(0) == 1 and img.size(1) != 1:
                    img.squeeze_()
                else:
                    B, N, C, H, W = img.size()
                    img = img.view(B * N, C, H, W)
            if self.use_grid_mask:
                img = self.grid_mask(img)
            img_feats = self.img_backbone(img)
            if isinstance(img_feats, dict):
                img_feats = list(img_feats.values())
        else:
            return None
        if self.with_img_neck:
            img_feats = self.img_neck(img_feats)
        img_feats_reshaped = []
        for img_feat in img_feats:
            BN, C, H, W = img_feat.size()
            img_feats_reshaped.append(img_feat.view(B, int(BN / B), C, H, W))
        return img_feats_reshaped

    def extract_feat(self, img, img_metas):
        """Extract BEV features; optionally bypass with teacher BEV."""
        # 中文注释：特征提取（两种路径）
        # 1）教师BEV直通：当 use_bev_teacher_input=True 时，跳过图像->BEV投影，直接使用外部提供的教师BEV作为输入。
        # 2）常规LSS路径：多视角图像 -> 图像骨干与FPN -> LSS投影至BEV特征。
        # 说明：该分支多用于蒸馏或分阶段训练，不改变后续解码器逻辑。
        # Stage-1 bypass: use teacher BEV directly as input BEV
        if self.use_bev_teacher_input:
            if len(img_metas) == 0 or 'bev_teacher' not in img_metas[0]:
                raise ValueError("use_bev_teacher_input=True but 'bev_teacher' not found in img_metas")
            bev_list = []
            for m in img_metas:
                bev_np = m.get('bev_teacher', None)
                if bev_np is None:
                    bev_np = img_metas[0]['bev_teacher']
                # expect [C,H,W]
                bev_t = torch.from_numpy(bev_np).to(self.img_backbone.conv1.weight.device).float()
                bev_list.append(bev_t)
            bev_feats = torch.stack(bev_list, dim=0)  # [B,C,H,W]
            return bev_feats
        # Normal LSS path（常规LSS特征路径）
        img_feats = self.extract_img_feat(img, img_metas)
        largest_feat_shape = img_feats[0].shape[3]
        down_level = int(np.log2(self.downsample // (self.final_dim[0] // largest_feat_shape)))
        bev_feats = self.view_transformers(img_feats[down_level], img_metas)
        return bev_feats

    def forward_pts_train(self,
                          bev_feats,
                          gt_lines_coords,
                          gt_lines_labels,
                          gt_lines_connects,
                          gt_lines_coeffs,
                          img_metas,
                          num_coeff, ):
        """Forward function for point cloud branch.
        Args:
            pts_feats (list[torch.Tensor]): Features of point cloud branch
            gt_bboxes_3d (list[:obj:`BaseInstance3DBoxes`]): Ground truth
                boxes for each sample.
            gt_labels_3d (list[torch.Tensor]): Ground truth labels for
                boxes of each sampole
            img_metas (list[dict]): Meta information of samples.
            gt_bboxes_ignore (list[torch.Tensor], optional): Ground truth
                boxes to be ignored. Defaults to None.
        Returns:
            dict: Losses of each branch.
        """
        device = bev_feats[0].device
        box_labels = []
        input_seqs = []
        output_seqs = []
        max_box = max([len(target) for target in gt_lines_coords])
        num_box = max(max_box + 2, self.max_box_num)  # 100
        coeff_dim = num_coeff * 2
        for bi in range(len(gt_lines_coords)):
            # 中文注释：将GT节点转为“子句（clause）”形式：[x, y, label, connect, coeffs...]
            # 其中 x,y, label(类别0-3), connect(父节点索引), coeffs(Beizer控制点，长度=2*num_coeff)
            box = torch.tensor(gt_lines_coords[bi], device=device).long()
            box = box.reshape(-1,2)
            # 中文注释：标签偏移到词表区间（类别起始ID=200）
            label = torch.tensor(gt_lines_labels[bi], device=device).long() + self.category_start  # [8,1]
            label = label.reshape(-1,1)
            # 中文注释：连接（父索引）偏移到词表区间（连接起始ID=250）
            connect = torch.tensor(gt_lines_connects[bi], device=device).long() + self.connect_start  # [8,1]
            connect = connect.reshape(-1,1)
            # 中文注释：Bezier系数偏移到词表区间（系数起始ID=350）
            coeff = torch.tensor(gt_lines_coeffs[bi], device=device).long() + self.coeff_start  # [8,1]
            coeff = coeff.reshape(-1, coeff_dim)
            box_label = torch.cat([box, label, connect, coeff], dim=-1)  # [8, 5]

            # 中文注释：采样负样本子句（用于困难负样本训练）。坐标/连接/系数用随机值，标签用随机类别。
            random_box = torch.rand(num_box - box_label.shape[0], 2).to(device)
            random_box = (random_box * (self.box_range - 1)).int()
            random_label = torch.randint(0, self.num_classes, (num_box - box_label.shape[0], 1)).to(label)
            random_label = random_label + self.category_start
            random_connect = torch.randint(0, num_box, (num_box - box_label.shape[0], 1)).to(label)
            random_connect = random_connect + self.connect_start
            random_coeff = torch.rand(num_box - box_label.shape[0], coeff_dim).to(device)
            random_coeff = (random_coeff * (self.coeff_range - 1)).int()
            random_coeff = random_coeff + self.coeff_start
            random_box_label = torch.cat([random_box, random_label.int(), random_connect.int(), random_coeff.int()], dim=-1)  # [92, 5]

            # 中文注释：解码器输入序列 input_seq = [START] + [正样本子句 + 负样本子句]（扁平化）
            input_seq = torch.cat([box_label, random_box_label], dim=0)
            input_seq = torch.cat([torch.ones(1).to(box_label) * self.start, input_seq.flatten()])  # [1 + num_box*clause_length]
            input_seqs.append(input_seq.unsqueeze(0))

            # 中文注释：构造监督序列中的“负样本子句”（与子句对齐）：
            # - 坐标x,y：填充 no_known（不计入坐标loss）
            # - 标签label：填充 noise_label（制造困难负样本，参与分类loss）
            # - 连接/系数：填充 no_known（不计入loss）
            output_na_x = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known
            output_na_y = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known
            output_noise_label = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.noise_label
            output_noise_connect = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known
            output_noise_coeff = torch.ones(num_box - box_label.shape[0], coeff_dim).to(input_seq) * self.no_known
            # Note: do NOT place END token inside a clause; keep END only as a standalone token if needed
            output_seq = torch.cat(
                [output_na_x, output_na_y, output_noise_label, output_noise_connect, output_noise_coeff], dim=-1
            )

            # 中文注释：监督序列 output_seq = [正样本子句] + [END] + [负样本子句]（扁平化）。
            output_seq = torch.cat([box_label.flatten(), torch.ones(1).to(box_label) * self.end, output_seq.flatten()])
            output_seqs.append(output_seq.unsqueeze(0))
        input_seqs = torch.cat(input_seqs, dim=0)  # [B, 1 + num_box*clause_length]
        output_seqs = torch.cat(output_seqs, dim=0)  # [B, 1 + (pos + neg)*clause_length]
        # 中文注释：解码器前向获得所有层的logits，取最后一层，且去掉最后一个位置（与对齐处理一致）。
        outputs_logits = self.pts_bbox_head(bev_feats, input_seqs, img_metas)[-1, :, :-1, :]  # [B, T-1, V]

        clause_length = 4 + coeff_dim
        all_outputs_pos, all_inputs_pos = [], []
        all_outputs_cls, all_inputs_cls = [], []
        all_outputs_connects, all_inputs_connects = [], []
        all_outputs_coeffs, all_inputs_coeffs = [], []
        # TIT accumulators
        tit_loss_total = outputs_logits.new_tensor(0.0)
        tit_count = 0

        for bi in range(outputs_logits.shape[0]):
            labels_i = output_seqs[bi, :-1]  # [T-1]
            preds_i = outputs_logits[bi]     # [T-1, V]
            # 中文注释：移除监督序列中的单个 END 位置，避免影响子句切片。
            end_mask = (labels_i == self.end)
            if end_mask.any():
                keep = ~end_mask
                labels_i = labels_i[keep]
                preds_i = preds_i[keep]
            # 中文注释：长度对齐到子句长度的整数倍（确保后续 0::clause_length 切片安全）。
            valid_len = (labels_i.numel() // clause_length) * clause_length
            labels_i = labels_i[:valid_len]
            preds_i = preds_i[:valid_len]

            # slice by clause
            # 中文注释：按子句位置切分各分量的logits与标签：坐标(x,y)、类别(label)、连接(connect)、系数(coeffs...)
            pos_x_logits = preds_i[0::clause_length, :]
            pos_y_logits = preds_i[1::clause_length, :]
            outputs_pos_i = torch.cat([pos_x_logits, pos_y_logits], dim=0)
            inputs_pos_i = torch.cat([labels_i[0::clause_length], labels_i[1::clause_length]], dim=0)

            outputs_cls_i = preds_i[2::clause_length, :]
            inputs_cls_i = labels_i[2::clause_length]

            outputs_conn_i = preds_i[3::clause_length, :]
            inputs_conn_i = labels_i[3::clause_length]

            coeff_logits_list, coeff_labels_list = [], []
            for k in range(4, clause_length):
                coeff_logits_list.append(preds_i[k::clause_length, :])
                coeff_labels_list.append(labels_i[k::clause_length])
            outputs_coeffs_i = torch.cat(coeff_logits_list, dim=0) if coeff_logits_list else preds_i.new_zeros((0, preds_i.shape[-1]))
            inputs_coeffs_i = torch.cat(coeff_labels_list, dim=0) if coeff_labels_list else labels_i.new_zeros((0,), dtype=labels_i.dtype)

            # filter out no_known targets
            # 中文注释：过滤掉 no_known（=575）目标，确保只对有效目标计算对应loss；
            # 分类的负样本子句会保留 noise_label 用于提升判别能力。
            mask_pos = (inputs_pos_i != self.no_known)
            mask_cls = (inputs_cls_i != self.no_known)
            mask_conn = (inputs_conn_i != self.no_known)
            mask_coeff = (inputs_coeffs_i != self.no_known)

            # TIT: distance-aware soft supervision on connect logits
            # 中文注释（可选TIT）：在连接预测上对GT父子关系的附近邻域做软监督（KL散度），提升拓扑鲁棒性。
            if self.tit_enable and mask_conn.sum().item() > 1:
                try:
                    # Valid connect logits/labels for positives only
                    logits_conn_valid = outputs_conn_i[mask_conn]  # [P, V]
                    labels_conn_valid = inputs_conn_i[mask_conn]   # [P]
                    # Build KNN neighbors from GT coords
                    gt_coords_sample = torch.tensor(gt_lines_coords[bi], device=preds_i.device).long().view(-1, 2).float()
                    P = logits_conn_valid.shape[0]
                    V = logits_conn_valid.shape[-1]
                    if gt_coords_sample.shape[0] >= 2 and P >= 2:
                        # Pairwise distances
                        dmat = torch.cdist(gt_coords_sample, gt_coords_sample, p=2)  # [N,N]
                        # Avoid self
                        diag_idx = torch.arange(dmat.shape[0], device=dmat.device)
                        dmat[diag_idx, diag_idx] = 1e6
                        K = int(min(max(self.tit_k, 1), max(1, dmat.shape[0] - 1)))
                        log_probs = F.log_softmax(logits_conn_valid, dim=-1)
                        for r in range(P):
                            gt_token = int(labels_conn_valid[r].item())
                            # Ensure target is a valid connect token
                            if gt_token < self.connect_start or gt_token >= self.connect_start + gt_coords_sample.shape[0]:
                                continue
                            gt_j = gt_token - self.connect_start
                            # KNN neighbors around GT target node gt_j
                            neigh_idx = torch.topk(dmat[gt_j], k=K, largest=False).indices.tolist()
                            # Exclude GT to avoid double counting in smoothing
                            neigh_idx = [n for n in neigh_idx if n != gt_j]
                            q = logits_conn_valid.new_zeros((V,))
                            alpha = float(self.tit_alpha)
                            q[self.connect_start + gt_j] = 1.0 - alpha
                            if len(neigh_idx) > 0 and alpha > 0:
                                share = alpha / float(len(neigh_idx))
                                for n in neigh_idx:
                                    q[self.connect_start + int(n)] += share
                            # KL divergence between predicted log-probs and soft target q
                            tit_loss_total = tit_loss_total + F.kl_div(log_probs[r], q, reduction='batchmean')
                            tit_count += 1
                except Exception:
                    # TIT is best-effort; never break training
                    pass

            all_outputs_pos.append(outputs_pos_i[mask_pos])
            all_inputs_pos.append(inputs_pos_i[mask_pos])

            all_outputs_cls.append(outputs_cls_i[mask_cls])
            all_inputs_cls.append(inputs_cls_i[mask_cls])

            all_outputs_connects.append(outputs_conn_i[mask_conn])
            all_inputs_connects.append(inputs_conn_i[mask_conn])

            all_outputs_coeffs.append(outputs_coeffs_i[mask_coeff])
            all_inputs_coeffs.append(inputs_coeffs_i[mask_coeff])

        # concat across batch
        # 中文注释：拼接batch维度后，交由 head.loss_by_feat 统一计算四类CE损失。
        outputs_pos = torch.cat(all_outputs_pos, dim=0) if len(all_outputs_pos) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_pos = torch.cat(all_inputs_pos, dim=0) if len(all_inputs_pos) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        outputs_cls = torch.cat(all_outputs_cls, dim=0) if len(all_outputs_cls) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_cls = torch.cat(all_inputs_cls, dim=0) if len(all_inputs_cls) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        outputs_connects = torch.cat(all_outputs_connects, dim=0) if len(all_outputs_connects) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_connects = torch.cat(all_inputs_connects, dim=0) if len(all_inputs_connects) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        outputs_coeffs = torch.cat(all_outputs_coeffs, dim=0) if len(all_outputs_coeffs) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_coeffs = torch.cat(all_inputs_coeffs, dim=0) if len(all_inputs_coeffs) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        gt_coords = [inputs_pos.long()]
        gt_labels = [inputs_cls.long()]
        gt_connects = [inputs_connects.long()]
        gt_coeffs = [inputs_coeffs.long()]
        
        preds_dicts = dict(
            preds_coords=[outputs_pos],
            preds_labels=[outputs_cls],
            preds_connects=[outputs_connects],
            preds_coeffs=[outputs_coeffs]
        )

        loss_inputs = [gt_coords, gt_labels, gt_connects, gt_coeffs, preds_dicts]
        losses = self.pts_bbox_head.loss_by_feat(*loss_inputs)
        # Append TIT loss if enabled
        if self.tit_enable and tit_count > 0:
            losses['loss_tit'] = tit_loss_total / float(tit_count) * self.tit_weight

        # SwanLab logging (rank-0 only, optional)
        try:
            if self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process():
                if not self._swanlab_ready:
                    self._init_swanlab(cfg=dict(model='AR_RNTR', n_control=num_coeff + 2))
                self._global_step += 1
                if (self._global_step % self.swanlab_log_interval) == 0:
                    metrics = {}
                    for k, v in losses.items():
                        val = self._to_float(v)
                        if val is not None:
                            metrics[k] = val
                    # Optionally log sequence stats
                    metrics['seq_max_box'] = float(max_box)
                    metrics['seq_num_box'] = float(num_box)
                    if len(metrics) > 0:
                        swanlab.log(metrics, step=self._global_step)
                # Periodically log BEV overlay (first sample)
                if (self._global_step % self.swanlab_image_interval) == 0:
                    try:
                        pred_tokens0 = outputs_logits[0].detach().argmax(dim=-1)
                        bev_img = self._render_bev_overlay(gt_lines_coords[0], pred_tokens0, clause_length=clause_length, canvas_size=self.box_range)
                        if bev_img is not None:
                            self._swanlab_log_image('vis/bev_overlay', bev_img, step=self._global_step)
                    except Exception:
                        pass
        except Exception:
            pass  # never break training due to logging

        return losses
    
    def loss(self,
             inputs=None,
             data_samples=None,**kwargs):

        img = inputs['img']
        img_metas = [ds.metainfo for ds in data_samples]

        bev_feats = self.extract_feat(img=img, img_metas=img_metas)
        if self.bev_scale != 1.0:
            b, c, h, w = bev_feats.shape
            bev_feats = F.interpolate(bev_feats, (int(h * self.bev_scale), int(w * self.bev_scale)))
        losses = dict()
        # Optional BEV distillation (TIT stage-2)
        if hasattr(self, 'tit_distill') and self.tit_distill:
            if 'bev_teacher' not in img_metas[0]:
                raise ValueError("tit_distill=True but 'bev_teacher' not found in img_metas")
            teacher_list = []
            for m in img_metas:
                bev_np = m.get('bev_teacher', None)
                if bev_np is None:
                    bev_np = img_metas[0]['bev_teacher']
                teacher_list.append(torch.from_numpy(bev_np).to(bev_feats.device).float())
            bev_teacher = torch.stack(teacher_list, dim=0)
            if bev_teacher.shape[-2:] != bev_feats.shape[-2:]:
                bev_teacher = F.interpolate(bev_teacher, size=bev_feats.shape[-2:], mode='bilinear', align_corners=False)
            losses['loss_distill'] = F.l1_loss(bev_feats, bev_teacher) * float(getattr(self, 'tit_distill_weight', 1.0))
            if getattr(self, 'tit_distill_only', False):
                return losses
        gt_lines_coords = [img_meta['centerline_coord'] for img_meta in img_metas]
        gt_lines_labels = [img_meta['centerline_label'] for img_meta in img_metas]
        gt_lines_connects = [img_meta['centerline_connect'] for img_meta in img_metas]
        gt_lines_coeffs = [img_meta['centerline_coeff'] for img_meta in img_metas]
        n_control = img_metas[0]['n_control']
        num_coeff = n_control - 2
        losses_pts = self.forward_pts_train(bev_feats, gt_lines_coords, gt_lines_labels, 
                                            gt_lines_connects, gt_lines_coeffs,
                                            img_metas, num_coeff)
        losses.update(losses_pts)
        return losses
    
    def predict(self, batch_inputs_dict, batch_data_samples, **kwargs):
        """Forward of testing.

        Args:
            batch_inputs_dict (dict): The model input dict which include
                'points' keys.

                - points (list[torch.Tensor]): Point cloud of each sample.
            batch_data_samples (List[:obj:`Det3DDataSample`]): The Data
                Samples. It usually includes information such as
                `gt_instance_3d`.

        Returns:
            list[:obj:`Det3DDataSample`]: Detection results of the
            input sample. Each Det3DDataSample usually contain
            'pred_instances_3d'. And the ``pred_instances_3d`` usually
            contains following keys.

            - scores_3d (Tensor): Classification scores, has a shape
                (num_instances, )
            - labels_3d (Tensor): Labels of bboxes, has a shape
                (num_instances, ).
            - bbox_3d (:obj:`BaseInstance3DBoxes`): Prediction of bboxes,
                contains a tensor with shape (num_instances, 7).
        """
        batch_input_metas = [item.metainfo for item in batch_data_samples]
        batch_input_imgs = batch_inputs_dict['img']
        # Run inference on the full batch instead of slicing to the first sample
        return self.simple_test(batch_input_metas, batch_input_imgs)

    def simple_test_pts(self, pts_feats, img_metas):
        """Test function of point cloud branch."""
        n_control = img_metas[0]['n_control']
        num_coeff = n_control - 2
        clause_length = 4 + num_coeff * 2
        # gt_node_list = self.seq2nodelist(gt_lines_seqs[0])
        # self.vis_from_nodelist(gt_node_list, img_metas[0], self.vis_cfg['path'], 'gt')
        device = pts_feats[0].device
        B = len(img_metas)
        # 中文注释：自回归推理从 [START] 开始，逐步扩展一个token。
        input_seqs = (torch.ones(B, 1, device=device) * self.start).long()
        outs = self.pts_bbox_head(pts_feats, input_seqs, img_metas)
        output_seqs, values = outs
        line_results = []
        for bi in range(output_seqs.shape[0]):
            pred_line_seq = output_seqs[bi]
            pred_line_seq = pred_line_seq[1:]
            # 中文注释：遇到 END 则截断；若未出现则取满长。
            if self.end in pred_line_seq:
                stop_idx = (pred_line_seq == self.end).nonzero(as_tuple=True)[0][0]
            else:
                stop_idx = len(pred_line_seq)
            stop_idx = stop_idx // clause_length * clause_length
            pred_line_seq = pred_line_seq[:stop_idx]
            # 中文注释：把预测token从词表区间还原到语义区间（类别/连接/系数减去各自起始ID）。
            pred_line_seq[2::clause_length] = pred_line_seq[2::clause_length] - self.category_start
            pred_line_seq[3::clause_length] = pred_line_seq[3::clause_length] - self.connect_start
            for k in range(4, clause_length):
                pred_line_seq[k::clause_length] = pred_line_seq[k::clause_length] - self.coeff_start
            # Safety sanitation to reduce invalid long-cross links and OOB coeffs
            try:
                # Clamp coordinate tokens to BEV grid range
                xbound = self.view_transformers.grid_conf['xbound']
                ybound = self.view_transformers.grid_conf['ybound']
                NX = int((xbound[1] - xbound[0]) / xbound[2])
                NY = int((ybound[1] - ybound[0]) / ybound[2])
                # 中文注释：坐标裁剪到BEV网格范围内，避免越界。
                pred_line_seq[0::clause_length] = pred_line_seq[0::clause_length].clamp(0, NX - 1)
                pred_line_seq[1::clause_length] = pred_line_seq[1::clause_length].clamp(0, NY - 1)

                # Clamp class token to valid range [0..num_classes-1]
                # 中文注释：类别裁剪到 [0, num_classes-1]
                pred_line_seq[2::clause_length] = pred_line_seq[2::clause_length].clamp(0, self.num_classes - 1)

                # Clamp Bezier control coeff tokens to training range [0..coeff_range-1]
                # Note: coeffs are interleaved as (cx, cy, cx, cy, ...)
                if self.coeff_range is not None and self.coeff_range > 0:
                    for k in range(4, clause_length):
                        # 中文注释：Bezier控制点系数裁剪到训练区间。
                        pred_line_seq[k::clause_length] = pred_line_seq[k::clause_length].clamp(0, self.coeff_range - 1)

                # Enforce connect indices to reference only prior nodes
                # Sequence is grouped by clauses; connect index must be < current node idx
                num_nodes = pred_line_seq.numel() // clause_length
                if num_nodes > 0:
                    # Work on a clone to avoid dtype/device issues when assigning Python ints
                    seq_clone = pred_line_seq.clone()
                    for i in range(num_nodes):
                        # 中文注释：连边约束——连接只能指向当前之前的节点（自回归因果约束）。
                        lbl = int(seq_clone[2 + i * clause_length].item())  # 0:start,1:continue,2:fork,3:merge
                        conn_pos = 3 + i * clause_length
                        if i == 0:
                            # First node should be start; set connect to 0
                            seq_clone[conn_pos] = 0
                            continue
                        conn_idx = int(seq_clone[conn_pos].item())
                        # valid connect must point to a previous node [0..i-1]
                        conn_idx = max(0, min(conn_idx, i - 1))
                        # For continue, strongly prefer linking to immediate previous node
                        if lbl == 1:
                            conn_idx = i - 1
                        seq_clone[conn_pos] = conn_idx
                    pred_line_seq = seq_clone
            except Exception:
                # Never break inference due to sanitation
                pass
            pred_node_list = av2seq2bznodelist(pred_line_seq.detach().cpu().numpy(), n_control, self.epsilon)

            line_results.append(dict(
                line_seqs = pred_line_seq.detach().cpu(),
                pred_node_lists = pred_node_list
            ))
        return line_results

    def simple_test(self, img_metas, img=None):
        """Test function without augmentaiton."""
        bev_feats = self.extract_feat(img=img, img_metas=img_metas)
        bbox_list = [dict() for i in range(len(img_metas))]
        line_results = self.simple_test_pts(
            bev_feats, img_metas)
        for result_dict, line_result, img_meta in zip(bbox_list, line_results, img_metas):
            result_dict['line_results'] = line_result
            result_dict['token'] = img_meta['token']
        # Optionally log validation BEV overlay (first sample)
        try:
            if self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process():
                if not self._swanlab_ready:
                    self._init_swanlab(cfg=dict(model='AR_RNTR', phase='val'))
                self._swanlab_img_step += 1
                if (self._swanlab_img_step % self.swanlab_image_interval) == 0:
                    try:
                        n_control = img_metas[0].get('n_control', 3)
                        clause_length = 4 + (int(n_control) - 2) * 2
                        pred_tokens0 = line_results[0]['line_seqs']
                        gt_coords0 = img_metas[0].get('centerline_coord', None)
                        bev_img = self._render_bev_overlay(gt_coords0 if gt_coords0 is not None else [],
                                                           pred_tokens0,
                                                           clause_length=clause_length,
                                                           canvas_size=self.box_range)
                        if bev_img is not None:
                            self._swanlab_log_image('vis/val_bev_overlay', bev_img, step=self._swanlab_img_step)
                    except Exception:
                        pass
        except Exception:
            pass
        return bbox_list