import os
import time
from typing import Any, Dict

import torch
import torch.distributed as dist
from mmengine.hooks import Hook
from mmengine.registry import HOOKS

# Optional import: SwanLab
try:
    import swanlab  # pip install swanlab
    _SWANLAB_AVAILABLE = True
except Exception:
    swanlab = None
    _SWANLAB_AVAILABLE = False


def _is_main_process() -> bool:
    try:
        if not dist.is_available() or not dist.is_initialized():
            return True
        return dist.get_rank() == 0
    except Exception:
        return True


def _flatten_dict(d: Dict[str, Any], parent_key: str = '', sep: str = '/') -> Dict[str, Any]:
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else str(k)
        if isinstance(v, dict):
            items.extend(_flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


@HOOKS.register_module()
class SwanLabLoggerHook(Hook):
    """
    Log training/validation info to SwanLab.

    Features:
    - before_optimizer_step: compute pre-clip grad norm (2-norm) on rank-0
    - after_train_iter: log learning rates (per param group + mean) and pre-clip grad_norm
    - after_val_epoch: log all metrics returned by evaluator

    Args:
        enable (bool): whether to enable logging (can be overridden by env SWANLAB_ENABLE)
        project (str): swanlab project name
        run_name (str|None): experiment name; default uses timestamp
        log_interval (int): steps between train log writes
        prefix_val (str): prefix for validation metrics keys
    """

    def __init__(self,
                 enable: bool = True,
                 project: str = 'RoadNet',
                 run_name: str = None,
                 log_interval: int = 50,
                 prefix_val: str = 'val') -> None:
        self.enable = bool(enable) or (os.getenv('SWANLAB_ENABLE', '0').lower() in ('1', 'true', 'yes'))
        self.project = project
        self.run_name = run_name
        self.log_interval = max(1, int(log_interval))
        self.prefix_val = prefix_val.rstrip('/')
        self._ready = False
        self._latest_grad_norm_preclip = None  # preferred value (matches console logging semantics)
        self._latest_grad_norm = None          # kept for backward compatibility if needed

    # Priority: run early for grad-norm before optimizer.step is called by the runner
    priority = 'NORMAL'

    def _init_swanlab(self) -> None:
        if self._ready:
            return
        if not self.enable or not _SWANLAB_AVAILABLE:
            return
        if not _is_main_process():
            return
        name = self.run_name or f"run_{int(time.time())}"
        try:
            # avoid re-init in case model already initialized SwanLab
            if os.getenv('SWANLAB_INITIALIZED', '0') in ('1', 'true', 'yes'):
                self._ready = True
                return
            swanlab.init(project=self.project, experiment_name=name, config={})
            os.environ['SWANLAB_INITIALIZED'] = '1'
            self._ready = True
        except Exception:
            self._ready = False

    def before_train(self, runner) -> None:
        self._init_swanlab()

    def before_optimizer_step(self, runner, optimizer) -> None:
        """Compute pre-clip grad norm (2-norm) before optimizer.step when grads are available."""
        if not (self.enable and _SWANLAB_AVAILABLE and _is_main_process()):
            return
        # Compute 2-norm across all trainable params that have grads
        total_norm_sq = 0.0
        has_grad = False
        try:
            model = runner.model
            for p in model.parameters():
                if p is not None and p.grad is not None:
                    # use fp32 for stability
                    grad = p.grad.detach()
                    if torch.isfinite(grad).all():
                        param_norm = grad.data.float().norm(2)
                        total_norm_sq += float(param_norm.item() ** 2)
                        has_grad = True
            if has_grad:
                preclip = total_norm_sq ** 0.5
                self._latest_grad_norm_preclip = preclip
                self._latest_grad_norm = preclip
            else:
                self._latest_grad_norm_preclip = None
                self._latest_grad_norm = None
        except Exception:
            self._latest_grad_norm_preclip = None
            self._latest_grad_norm = None

    def after_train_iter(self, runner, batch_idx: int, data_batch=None, outputs=None) -> None:
        if not (self.enable and _SWANLAB_AVAILABLE and _is_main_process()):
            return
        if (runner.iter + 1) % self.log_interval != 0:
            return
        self._init_swanlab()
        if not self._ready:
            return
        # Learning rates per param group
        metrics = {}
        try:
            opt = runner.optim_wrapper.optimizer
            lrs = []
            for i, g in enumerate(opt.param_groups):
                lr = float(g.get('lr', 0.0))
                metrics[f'lr/pg{i}'] = lr
                lrs.append(lr)
            if lrs:
                metrics['lr/mean'] = float(sum(lrs) / len(lrs))
        except Exception:
            pass
        # Gradient norm (prefer pre-clip from message hub if available; fallback to stored pre-clip)
        preclip_val = None
        try:
            mh = getattr(runner, 'message_hub', None)
            if mh is not None:
                # Try common keys used by mmengine to store grad norm
                if hasattr(mh, 'get_scalar'):
                    scalar = mh.get_scalar('train/grad_norm') or mh.get_scalar('grad_norm')
                    if scalar is not None:
                        try:
                            # mmengine Scalar has .current() in recent versions
                            preclip_val = float(scalar.current())
                        except Exception:
                            try:
                                data = getattr(scalar, 'data', None)
                                if isinstance(data, (list, tuple)) and len(data) > 0:
                                    preclip_val = float(data[-1])
                            except Exception:
                                preclip_val = None
        except Exception:
            preclip_val = None
        if preclip_val is None:
            preclip_val = self._latest_grad_norm_preclip
        if preclip_val is not None:
            metrics['grad_norm'] = float(preclip_val)
        # You can also forward any losses from outputs if provided (optional)
        if isinstance(outputs, dict):
            for k, v in outputs.items():
                if isinstance(v, (int, float)):
                    metrics[f'loss/{k}'] = float(v)
                elif torch.is_tensor(v):
                    metrics[f'loss/{k}'] = float(v.detach().float().mean().item())
        if metrics:
            try:
                swanlab.log(metrics, step=runner.iter + 1)
            except Exception:
                pass

    def after_val_epoch(self, runner, metrics: Dict[str, Any] = None) -> None:
        if not (self.enable and _SWANLAB_AVAILABLE and _is_main_process()):
            return
        self._init_swanlab()
        if not self._ready:
            return
        if not isinstance(metrics, dict):
            return
        try:
            flat = _flatten_dict(metrics)
            # Prefix all keys with 'val/' to distinguish from training logs
            prefixed = {f'{self.prefix_val}/{k}': v for k, v in flat.items()}
            # Convert tensors to floats if needed
            clean = {}
            for k, v in prefixed.items():
                if torch.is_tensor(v):
                    clean[k] = float(v.detach().float().mean().item())
                elif isinstance(v, (int, float)):
                    clean[k] = float(v)
                else:
                    # skip non-numeric
                    continue
            if clean:
                swanlab.log(clean, step=runner.iter + 1)
        except Exception:
            pass
