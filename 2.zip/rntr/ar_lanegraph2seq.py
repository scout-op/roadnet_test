# ------------------------------------------------------------------------
# Copyright (c) 2022 megvii-model. All Rights Reserved.
# ------------------------------------------------------------------------
# Modified from DETR3D (https://github.com/WangYueFt/detr3d)
# Copyright (c) 2021 Wang, Yue
# ------------------------------------------------------------------------
# Modified from mmdetection3d (https://github.com/open-mmlab/mmdetection3d)
# Copyright (c) OpenMMLab. All rights reserved.
# ------------------------------------------------------------------------

import os
import cv2
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmengine.structures import InstanceData
import numpy as np
import torch.distributed as dist
import time

# Optional: SwanLab real-time experiment tracking
try:
    import swanlab  # pip install swanlab
    _SWANLAB_AVAILABLE = True
except Exception:
    swanlab = None
    _SWANLAB_AVAILABLE = False

from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector
from mmdet3d.registry import MODELS
from mmdet3d.structures.ops import bbox3d2result
from .grid_mask import GridMask
from .LiftSplatShoot import LiftSplatShootEgo
from .core import seq2nodelist, seq2bznodelist, seq2plbznodelist, av2seq2bznodelist


@MODELS.register_module()
class AR_LG2Seq(MVXTwoStageDetector):
    """Petr3D. nan for all token except label"""
    def __init__(self,
                 use_grid_mask=False,
                 pts_voxel_layer=None,
                 pts_middle_encoder=None,
                 pts_fusion_layer=None,
                 img_backbone=None,
                 pts_backbone=None,
                 img_neck=None,
                 pts_neck=None,
                 lss_cfg=None,
                 grid_conf=None,
                 bz_grid_conf=None,
                 data_aug_conf=None,
                 pts_bbox_head=None,
                 img_roi_head=None,
                 img_rpn_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 vis_cfg=None,
                 freeze_pretrain=True,
                 bev_scale=1.0,
                 epsilon=2,
                 max_vertex_num=50,
                 max_edge_len=500,
                 init_cfg=None,
                 data_preprocessor=None,
                 # SwanLab optional params
                 swanlab_enable=False,
                 swanlab_project='RoadNet',
                 swanlab_run_name=None,
                 swanlab_log_interval=50,
                 swanlab_image_interval=400,
                 # AR inference options
                 use_cf_guidance=False,
                 guidance_scale=2.0,
                 top_p=0.9,
                 ):
        super(AR_LG2Seq, self).__init__(pts_voxel_layer, pts_middle_encoder,
                                                        pts_fusion_layer, img_backbone, pts_backbone,
                                                        img_neck, pts_neck, pts_bbox_head, img_roi_head,
                                                        img_rpn_head, train_cfg, test_cfg, init_cfg,
                                                        data_preprocessor)
        self.grid_mask = GridMask(True, True, rotate=1, offset=False, ratio=0.5, mode=1, prob=0.7)
        self.use_grid_mask = use_grid_mask
        # data_aug_conf = {
        #     'final_dim': (128, 352),
        #     'H': 900, 'W': 1600,
        # }
        # self.up = Up(512, 256, scale_factor=2)
        # view_transformers = []
        # view_transformers.append(
        #     LiftSplatShoot(grid_conf, data_aug_conf, downsample=16, d_in=256, d_out=256, return_bev=True))
        # self.view_transformers = nn.ModuleList(view_transformers)
        # self.view_transformers = LiftSplatShoot(grid_conf, data_aug_conf, downsample=16, d_in=256, d_out=256, return_bev=True)
        self.view_transformers = LiftSplatShootEgo(grid_conf, data_aug_conf, return_bev=True, **lss_cfg)
        self.downsample = lss_cfg['downsample']
        self.final_dim = data_aug_conf['final_dim']
        self.bz_grid_conf = bz_grid_conf
        # SwanLab runtime config (align with AR_RNTR)
        self.swanlab_enable = bool(swanlab_enable) or (os.getenv('SWANLAB_ENABLE', '0').lower() in ('1', 'true', 'yes'))
        self.swanlab_project = swanlab_project
        self.swanlab_run_name = swanlab_run_name
        self.swanlab_log_interval = max(1, int(swanlab_log_interval))
        self.swanlab_image_interval = max(1, int(swanlab_image_interval))
        self._swanlab_ready = False
        self._global_step = 0
        self._swanlab_img_step = 0
        self.use_cf_guidance = use_cf_guidance
        self.guidance_scale = guidance_scale
        self.top_p = top_p

        self.num_center_classes = 576
        self.box_range = 200
        self.coeff_range = 200
        self.vertex_id_start = 200
        self.connect_start = 250
        self.coeff_start = 300
        self.no_known = 575  # n/a and padding share the same label to be eliminated from loss calculation
        self.start = 574
        self.end_v = 573
        self.end_e = 572
        self.vis_cfg = vis_cfg
        self.bev_scale = bev_scale
        self.epsilon = epsilon
        self.max_vertex_num = max_vertex_num
        self.max_edge_len = max_edge_len

        if freeze_pretrain:
            self.freeze_pretrain()
    
    # ---------------------- SwanLab utils (aligned with AR_RNTR) ----------------------
    def _is_main_process(self):
        try:
            if not dist.is_available() or not dist.is_initialized():
                return True
            return dist.get_rank() == 0
        except Exception:
            return True

    def _init_swanlab(self, cfg: dict = None):
        if self._swanlab_ready:
            return
        if not self.swanlab_enable or not _SWANLAB_AVAILABLE:
            return
        if not self._is_main_process():
            return
        run_name = self.swanlab_run_name or f'AR_LG2Seq_{int(time.time())}'
        try:
            swanlab.init(project=self.swanlab_project,
                         experiment_name=run_name,
                         config=cfg or {})
            self._swanlab_ready = True
        except Exception:
            self._swanlab_ready = False

    @staticmethod
    def _to_float(value):
        try:
            if isinstance(value, (list, tuple)):
                vals = []
                for v in value:
                    if torch.is_tensor(v):
                        vals.append(v.detach().float().mean().item())
                    else:
                        try:
                            vals.append(float(v))
                        except Exception:
                            pass
                return sum(vals) / len(vals) if len(vals) > 0 else None
            if torch.is_tensor(value):
                return value.detach().float().mean().item()
            return float(value)
        except Exception:
            return None

    def _render_bev_overlay_lane(self, gt_vert_sentence, pred_tokens, canvas_size=200):
        """Render overlay of GT vertices and predicted vertices (until end_v).
        - gt_vert_sentence: list[int] length 2*Nv (x0,y0,...)
        - pred_tokens: 1D LongTensor of tokens including vertices then end_v
        """
        try:
            H = W = int(canvas_size)
            canvas = np.zeros((H, W, 3), dtype=np.uint8)
            # Draw GT points (green)
            try:
                if gt_vert_sentence is not None and len(gt_vert_sentence) >= 2:
                    gt = np.array(gt_vert_sentence, dtype=np.int32).reshape(-1, 2)
                    for (x, y) in gt:
                        if 0 <= x < W and 0 <= y < H:
                            cv2.circle(canvas, (int(x), int(y)), 1, (0, 255, 0), -1)
            except Exception:
                pass
            # Pred vertices until end_v (blue/red)
            toks = pred_tokens.detach().cpu().long().tolist()
            if len(toks) > 0 and toks[0] == int(self.start):
                toks = toks[1:]
            try:
                idx_end_v = toks.index(int(self.end_v))
            except ValueError:
                idx_end_v = len(toks)
            verts = toks[: (idx_end_v // 2) * 2]
            for i in range(0, len(verts), 2):
                x = max(0, min(W - 1, int(verts[i])))
                y = max(0, min(H - 1, int(verts[i + 1])))
                cv2.circle(canvas, (x, y), 1, (0, 0, 255), -1)
            # Legend
            cv2.rectangle(canvas, (0, 0), (140, 30), (32, 32, 32), -1)
            cv2.putText(canvas, 'GT: green', (4, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1, cv2.LINE_AA)
            cv2.putText(canvas, 'Pred: red', (4, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1, cv2.LINE_AA)
            return canvas
        except Exception:
            return None

    def _swanlab_log_image(self, name: str, img: np.ndarray, step: int):
        if not (self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process() and self._swanlab_ready):
            return
        try:
            rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            if hasattr(swanlab, 'Image'):
                try:
                    im = swanlab.Image(rgb)
                    swanlab.log({name: im}, step=step)
                    return
                except Exception:
                    pass
            if hasattr(swanlab, 'log_image'):
                try:
                    swanlab.log_image(name, rgb, step=step)
                    return
                except Exception:
                    pass
            # Fallback: save tmp and log path
            tmp_dir = '/tmp/swanlab_vis'
            os.makedirs(tmp_dir, exist_ok=True)
            tmp_path = os.path.join(tmp_dir, f'{name.replace("/", "_")}_{step}.png')
            cv2.imwrite(tmp_path, img)
            try:
                swanlab.log({f'{name}_path': tmp_path}, step=step)
            except Exception:
                pass
        except Exception:
            pass
    
    def freeze_pretrain(self):
        for m in self.img_backbone.parameters():
            m.requires_grad=False
        for m in self.img_neck.parameters():
            m.requires_grad=False
        for m in self.view_transformers.parameters():
            m.requires_grad=False

    def extract_img_feat(self, img, img_metas):
        """Extract features of images."""
        # print(img[0].size())
        if isinstance(img, list):
            img = torch.stack(img, dim=0)

        B = img.size(0)
        if img is not None:
            input_shape = img.shape[-2:]
            # update real input shape of each single img
            for img_meta in img_metas:
                img_meta.update(input_shape=input_shape)
            if img.dim() == 5:
                if img.size(0) == 1 and img.size(1) != 1:
                    img.squeeze_()
                else:
                    B, N, C, H, W = img.size()
                    img = img.view(B * N, C, H, W)
            if self.use_grid_mask:
                img = self.grid_mask(img)
            img_feats = self.img_backbone(img)
            if isinstance(img_feats, dict):
                img_feats = list(img_feats.values())
        else:
            return None
        if self.with_img_neck:
            img_feats = self.img_neck(img_feats)
        img_feats_reshaped = []
        for img_feat in img_feats:
            BN, C, H, W = img_feat.size()
            img_feats_reshaped.append(img_feat.view(B, int(BN / B), C, H, W))
        return img_feats_reshaped

    def extract_feat(self, img, img_metas):
        """Extract features from images and points."""
        img_feats = self.extract_img_feat(img, img_metas)
        largest_feat_shape = img_feats[0].shape[3]
        down_level = int(np.log2(self.downsample // (self.final_dim[0] // largest_feat_shape)))
        bev_feats = self.view_transformers(img_feats[down_level], img_metas)
        return bev_feats

    def forward_pts_train(self,
                          bev_feats,
                          gt_vert_sentences, 
                          gt_edge_sentences,
                          img_metas,
                          num_coeff, ):
        """Forward function for point cloud branch.
        Args:
            pts_feats (list[torch.Tensor]): Features of point cloud branch
            gt_bboxes_3d (list[:obj:`BaseInstance3DBoxes`]): Ground truth
                boxes for each sample.
            gt_labels_3d (list[torch.Tensor]): Ground truth labels for
                boxes of each sampole
            img_metas (list[dict]): Meta information of samples.
            gt_bboxes_ignore (list[torch.Tensor], optional): Ground truth
                boxes to be ignored. Defaults to None.
        Returns:
            dict: Losses of each branch.
        """
        bs = len(gt_vert_sentences)
        device = bev_feats[0].device
        box_labels = []
        input_seqs = []
        output_seqs = []
        num_vertex = max([len(gt_vert_sentence) // 2 for gt_vert_sentence in gt_vert_sentences])
        max_vertex = max(num_vertex, self.max_vertex_num)  # 100
        edge_len = max([len(gt_edge_sentence) for gt_edge_sentence in gt_edge_sentences])
        max_edge_len = max(edge_len, self.max_edge_len)
        for bi in range(bs):
            vert = torch.tensor(gt_vert_sentences[bi], device=device).long()
            edge = torch.tensor(gt_edge_sentences[bi], device=device).long()

            random_vert = torch.rand(max_vertex - len(vert)//2, 2).to(device)
            random_vert = (random_vert * (self.box_range - 1)).long().flatten()
            random_edge = torch.rand(max_edge_len - len(edge)).to(device)
            random_edge = (random_edge * (self.coeff_range - 1)).long().flatten() + self.vertex_id_start
            in_vert_seq = torch.cat([torch.ones(1).to(vert) * self.start, vert, random_vert])
            in_edge_seq = torch.cat([torch.ones(1).to(edge) * self.end_v, edge, random_edge])

            na_vert = torch.ones(max_vertex*2 - len(vert)).to(device).long() * self.no_known
            na_edge = torch.ones(max_edge_len - len(edge)).to(device).long() * self.no_known
            out_vert_seq = torch.cat([vert, torch.ones(1).to(vert) * self.end_v, na_vert])
            out_edge_seq = torch.cat([edge, torch.ones(1).to(edge) * self.end_e, na_edge])

            input_seq = torch.cat([in_vert_seq, in_edge_seq])
            input_seqs.append(input_seq.unsqueeze(0))
            output_seq = torch.cat([out_vert_seq, out_edge_seq])
            output_seqs.append(output_seq.unsqueeze(0))
        input_seqs = torch.cat(input_seqs, dim=0)  # [8,501]
        output_seqs = torch.cat(output_seqs, dim=0)  # [8,501]
        outputs = self.pts_bbox_head(bev_feats, input_seqs, img_metas)[-1]

        # outputs = outputs[-1]
        # for bi in range(pts_feats[0].shape[0]):
        #     line_seqs = outputs[bi].argmax(dim=-1)
        #     if self.end in line_seqs:
        #         stop_idx = (line_seqs == self.end).nonzero(as_tuple=True)[0][0]
        #     else:
        #         stop_idx = len(line_seqs)
        #     stop_idx = stop_idx // 3 * 3
        #     line_seqs = line_seqs[:stop_idx]
        #     line_seqs = line_seqs.reshape(-1, 3)
        #     pred_points = line_seqs[:, :2].clip(0, 200).float()  # [100,2]
        #     pred_labels = line_seqs[:, 2].unsqueeze(-1) - 1500
        #     self.vis_linepts(pred_points.detach().cpu().numpy(), pred_labels.detach().cpu().numpy(), img_metas[bi], 'train_200', 'pred')
        #     self.vis_linepts(gt_lines_coords[bi], gt_lines_labels[bi], img_metas[bi], 'train_200', 'gt')
        gt_seq = output_seqs[output_seqs != self.no_known].long()
        
        preds_dicts = dict(
            pred_seq=outputs[output_seqs != self.no_known],
        )

        loss_inputs = [gt_seq, preds_dicts]
        losses = self.pts_bbox_head.loss_by_feat(*loss_inputs)

        # SwanLab logging (rank-0 only, optional) — align with AR_RNTR
        try:
            if self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process():
                if not self._swanlab_ready:
                    self._init_swanlab(cfg=dict(model='AR_LG2Seq', n_control=num_coeff + 2))
                self._global_step += 1
                if (self._global_step % self.swanlab_log_interval) == 0:
                    metrics = {}
                    for k, v in losses.items():
                        val = self._to_float(v)
                        if val is not None:
                            metrics[k] = val
                    metrics['seq_max_vertex'] = float(max_vertex)
                    metrics['seq_max_edge_len'] = float(max_edge_len)
                    if len(metrics) > 0:
                        swanlab.log(metrics, step=self._global_step)
                # Periodically log BEV overlay (training, first sample)
                if (self._global_step % self.swanlab_image_interval) == 0:
                    try:
                        pred_tokens0 = outputs[0].detach().argmax(dim=-1)  # [T]
                        gt_vert0 = gt_vert_sentences[0] if len(gt_vert_sentences) > 0 else []
                        bev_img = self._render_bev_overlay_lane(gt_vert0, pred_tokens0, canvas_size=self.box_range)
                        if bev_img is not None:
                            self._swanlab_log_image('vis/train_lane_bev_overlay', bev_img, step=self._global_step)
                    except Exception:
                        pass
        except Exception:
            pass

        return losses
    
    def loss(self,
             inputs=None,
             data_samples=None,**kwargs):

        img = inputs['img']
        img_metas = [ds.metainfo for ds in data_samples]

        bev_feats = self.extract_feat(img=img, img_metas=img_metas)
        if self.bev_scale != 1.0:
            b, c, h, w = bev_feats.shape
            bev_feats = F.interpolate(bev_feats, (int(h * self.bev_scale), int(w * self.bev_scale)))
        losses = dict()
        gt_vert_sentence = [img_meta['vert_sentence'] for img_meta in img_metas]
        gt_edge_sentence = [img_meta['edge_sentence'] for img_meta in img_metas]
        n_control = img_metas[0]['n_control']
        num_coeff = n_control - 2
        losses_pts = self.forward_pts_train(bev_feats, gt_vert_sentence, gt_edge_sentence, img_metas, num_coeff)
        losses.update(losses_pts)
        return losses
        
    def predict(self, batch_inputs_dict, batch_data_samples, **kwargs):
        """Predict override to adapt MVXTwoStageDetector API.

        MVXTwoStageDetector passes a dict like {'img': imgs, ...}. Our
        extract_feat expects raw image tensors and metas. We unwrap here and
        call simple_test.
        """
        batch_input_metas = [item.metainfo for item in batch_data_samples]
        batch_input_imgs = batch_inputs_dict['img']
        return self.simple_test(batch_input_metas, batch_input_imgs)


    def forward_test(self, img_metas, img=None, **kwargs):
        for var, name in [(img_metas, 'img_metas')]:
            if not isinstance(var, list):
                raise TypeError('{} must be a list, but got {}'.format(
                    name, type(var)))
        img = [img] if img is None else img
        return self.simple_test(img_metas[0], img[0], **kwargs)

    def vis_linepts(self, pred_points, pred_labels, img_meta, path, aux_name):
        import cv2
        
        # label_color = [[128, 64, 128], [244, 35, 232], [70, 70, 70], [102, 102, 156],
        #        [190, 153, 153], [153, 153, 153], [250, 170, 30], [220, 220, 0],
        #        [107, 142, 35], [152, 251, 152], [70, 130, 180], [220, 20, 60],
        #        [255, 0, 0], [0, 0, 142], [0, 0, 70], [0, 60, 100],
        #        [0, 80, 100], [0, 0, 230], [119, 11, 32]]
        label_color = [[255, 0, 0], [0, 0, 230], [35, 244, 232], [70, 70, 70], [102, 102, 156],
               [190, 153, 153], [153, 153, 153], [250, 170, 30], [220, 220, 0],
               [107, 142, 35], [152, 251, 152], [70, 130, 180], [220, 20, 60],
               [255, 0, 0], [0, 0, 142], [0, 0, 70], [0, 60, 100],
               [0, 80, 100],  [119, 11, 32]]
        bev_img = np.zeros((200, 200, 3), np.uint8)
        for i in range(len(pred_points)):
            try:
                bev_img = cv2.circle(bev_img, (int(pred_points[i][0]), int(pred_points[i][1])), 1, label_color[int(pred_labels[i])], 2)
            except:
                pass
        # for i in range(len(pred_points) // 3):
        #     pt1 = (int(pred_points[i * 3][0]), int(pred_points[i * 3][1]))
        #     pt2 = (int(pred_points[i * 3 + 1][0]), int(pred_points[i * 3 + 1][1]))
        #     pt3 = (int(pred_points[i * 3 + 2][0]), int(pred_points[i * 3 + 2][1]))
        #     bev_img = cv2.line(bev_img, pt1, pt2, (0, 255, 0), 1)
        #     bev_img = cv2.line(bev_img, pt2, pt3, (0, 255, 0), 1)
        name = img_meta['filename'][0].split('/')[-1].split('.jpg')[0]
        save_dir = f"vis/{path}/"
        if not os.path.exists(save_dir):
            os.mkdir(save_dir)
        cv2.imwrite(os.path.join(save_dir, f"{name}_{aux_name}.png"), bev_img)
        return
    
    def vis_from_nodelist(self, nodelist, img_meta, path, aux_name):
        Map_size = [(-50, 50), (-50, 50)]
        Map_resolution = 0.5
        image = np.zeros([200, 200, 3])
        point_color_map = {"start": (0, 0, 255), 'fork': (0, 255, 0), "continue": (0, 255, 255), "merge": (255, 0, 0)}

        for idx, node in enumerate(nodelist):
            if node['sque_type'] == 'start':
                cv2.circle(image, node['coord'], 1, color=point_color_map['start'], thickness=2)
            elif node['sque_type'] == 'continue':
                cv2.circle(image, node['coord'], 1, color=point_color_map['continue'], thickness=2)
                # cv2.polylines(image, [subgraphs_points_in_between_nodes[(node.sque_index-1, node.sque_index)]], False, color=point_color_map['continue'], thickness=1)
                cv2.arrowedLine(image, nodelist[idx - 1]['coord'], node['coord'], color=point_color_map['continue'],
                                thickness=1, tipLength=0.1)
            elif node['sque_type'] == 'fork':
                if node['fork_from'] > idx or node['fork_from'] < 0:
                    continue
                cv2.circle(image, node['coord'], 1, color=point_color_map['fork'], thickness=2)
                cv2.arrowedLine(image, nodelist[node['fork_from'] - 1]['coord'], node['coord'],
                                color=point_color_map['fork'],
                                thickness=1, tipLength=0.1)
            elif node['sque_type'] == 'merge':
                if node['merge_with'] > idx or node['merge_with'] < 0:
                    continue
                cv2.circle(image, node['coord'], 1, color=point_color_map['merge'], thickness=2)
                cv2.arrowedLine(image, nodelist[node['merge_with'] - 1]['coord'], node['coord'],
                                color=point_color_map['merge'], thickness=1, tipLength=0.1)

        name = img_meta['filename'][0].split('/')[-1].split('.jpg')[0]
        save_dir = f"vis/{path}/"
        if not os.path.exists(save_dir):
            os.mkdir(save_dir)
        cv2.imwrite(os.path.join(save_dir, f"{name}_{aux_name}.png"), image)

    def simple_test_pts(self, pts_feats, img_metas, rescale=False):
        """Test function of point cloud branch."""
        # Note: LG2Seq pipeline (TransformLaneGraph) produces vert+edge sequences.
        # We decode them into a node list compatible with EvalMapBzGraph.
        device = pts_feats[0].device
        # Determine BEV canvas size for clipping
        NX = NY = 200
        try:
            xbound = self.view_transformers.grid_conf['xbound']
            ybound = self.view_transformers.grid_conf['ybound']
            NX = int((xbound[1] - xbound[0]) / xbound[2])
            NY = int((ybound[1] - ybound[0]) / ybound[2])
        except Exception:
            pass

        # Determine Bezier grid size for coefficient clamp/midpoint
        BZ_NX = NX
        BZ_NY = NY
        try:
            if self.bz_grid_conf is not None:
                bx = self.bz_grid_conf['xbound']
                by = self.bz_grid_conf['ybound']
                BZ_NX = int((bx[1] - bx[0]) / bx[2])
                BZ_NY = int((by[1] - by[0]) / by[2])
        except Exception:
            pass

        def decode_vert_edge(tokens: torch.Tensor):
            # tokens: 1D tensor after removing the START token
            toks = tokens.detach().cpu().long().tolist()
            # find split points
            try:
                idx_end_v = toks.index(self.end_v)
            except ValueError:
                idx_end_v = len(toks)
            try:
                idx_end_e = toks.index(self.end_e)
            except ValueError:
                idx_end_e = len(toks)
            if idx_end_e < idx_end_v:
                idx_end_e = len(toks)

            # vertices: x,y pairs
            vert_toks = toks[:idx_end_v]
            Nv = len(vert_toks) // 2
            vert_toks = vert_toks[: Nv * 2]
            vertices = []
            for i in range(Nv):
                x = int(vert_toks[2 * i])
                y = int(vert_toks[2 * i + 1])
                x = max(0, min(NX - 1, x))
                y = max(0, min(NY - 1, y))
                vertices.append([x, y])

            # edges: triples per parent group, separated by connect_start sentinel
            edge_toks = toks[idx_end_v + 1: idx_end_e]
            groups = []
            cur = []
            for t in edge_toks:
                if t == self.connect_start:
                    groups.append(cur)
                    cur = []
                else:
                    cur.append(int(t))
            if cur:
                groups.append(cur)
            if len(groups) < Nv:
                groups.extend([[] for _ in range(Nv - len(groups))])
            elif len(groups) > Nv:
                groups = groups[:Nv]

            # build adjacency and parent lists
            adj = {i: [] for i in range(Nv)}  # parent -> list[(child, [cx, cy])]
            parents_of = {i: [] for i in range(Nv)}
            coeff_from_parent = {}
            for i, g in enumerate(groups):
                tri = len(g) // 3
                for j in range(tri):
                    raw_child = g[3 * j]
                    cx_raw = g[3 * j + 1]
                    cy_raw = g[3 * j + 2]
                    child = raw_child - self.vertex_id_start
                    cx = cx_raw - self.coeff_start
                    cy = cy_raw - self.coeff_start
                    if child < 0 or child >= Nv:
                        continue
                    cx = max(0, min(BZ_NX - 1, int(cx)))
                    cy = max(0, min(BZ_NY - 1, int(cy)))
                    coeff = [cx, cy]
                    adj[i].append((child, coeff))
                    parents_of[child].append(i)
                    coeff_from_parent[(i, child)] = coeff

            # synthesize node list
            nodelist = []
            def midpoint_coeff(pa_idx, ch_idx):
                px, py = vertices[pa_idx]
                cx, cy = vertices[ch_idx]
                mx = max(0, min(BZ_NX - 1, int(round((px + cx) / 2))))
                my = max(0, min(BZ_NY - 1, int(round((py + cy) / 2))))
                # Domain note: these are BEV indices; convert_coeff_coord will further map.
                return [mx, my]

            for i in range(Nv):
                coord = [int(vertices[i][0]), int(vertices[i][1])]
                parents = sorted(list(set(parents_of[i])))
                if len(parents) == 0:
                    # start node for any vertex with no parents
                    nodelist.append(dict(
                        sque_index=i + 1,
                        sque_type='start',
                        fork_from=None,
                        merge_with=None,
                        coord=coord,
                        coeff=[],
                    ))
                # add continue only if sequential parent exists
                if i > 0 and (i - 1, i) in coeff_from_parent:
                    cont_coeff = coeff_from_parent[(i - 1, i)]
                    nodelist.append(dict(
                        sque_index=i + 1,
                        sque_type='continue',
                        fork_from=None,
                        merge_with=None,
                        coord=coord,
                        coeff=cont_coeff,
                    ))
                # add merges for extra parents not equal to i-1
                for p in parents:
                    if p == i - 1:
                        continue
                    m_coeff = coeff_from_parent.get((p, i), midpoint_coeff(p, i))
                    nodelist.append(dict(
                        sque_index=i + 1,
                        sque_type='merge',
                        fork_from=None,
                        merge_with=p + 1,
                        coord=coord,
                        coeff=m_coeff,
                    ))
            # forks for non-sequential children
            for p in range(Nv):
                for child, coeff in adj.get(p, []):
                    if child == p + 1:
                        continue  # already encoded as continue
                    f_coeff = coeff if isinstance(coeff, (list, tuple)) and len(coeff) == 2 else midpoint_coeff(p, child)
                    nodelist.append(dict(
                        sque_index=child + 1,
                        sque_type='fork',
                        fork_from=p + 1,
                        merge_with=None,
                        coord=[int(vertices[child][0]), int(vertices[child][1])],
                        coeff=f_coeff,
                    ))
            # Ensure EvalMapBzGraph sees last item with max sque_index to allocate correctly
            # and that parents (smaller indices) appear before children.
            nodelist.sort(key=lambda x: x['sque_index'])
            return nodelist

        def mask_logits_with_allowed(logits: torch.Tensor, allowed: torch.Tensor):
            # logits: [V], allowed: bool mask [V]
            mask = ~allowed
            logits = logits.clone()
            logits[mask] = -1e9
            return logits

        def build_allowed_vertex_mask(V: int):
            allowed = torch.zeros(V, dtype=torch.bool, device=device)
            allowed[: self.box_range] = True  # 0..199 for coord bins
            allowed[self.end_v] = True
            return allowed

        def build_allowed_edge_mask(V: int, stage: str, Nv: int, tri_mod: int, groups_done: int):
            # stage: 'pre' when groups_done < Nv; 'post' when groups_done == Nv
            allowed = torch.zeros(V, dtype=torch.bool, device=device)
            if stage == 'post':
                allowed[self.end_e] = True
                return allowed
            # within group decoding
            if tri_mod == 0:
                # child id or connect_start
                start = self.vertex_id_start
                end = self.vertex_id_start + max(Nv, 0)
                allowed[start:end] = True
                allowed[self.connect_start] = True
            elif tri_mod == 1:
                # coeff x
                start = self.coeff_start
                end = self.coeff_start + BZ_NX
                allowed[start:end] = True
            else:  # tri_mod == 2
                # coeff y
                start = self.coeff_start
                end = self.coeff_start + BZ_NY
                allowed[start:end] = True
            return allowed

        def top_p_sample_from_logits(logits: torch.Tensor, top_p: float):
            # logits: [V]
            probs = torch.softmax(logits, dim=-1)
            if top_p is None or top_p >= 1.0:
                return torch.multinomial(probs, num_samples=1).item()
            # sort
            sorted_probs, sorted_idx = torch.sort(probs, descending=True)
            cum = torch.cumsum(sorted_probs, dim=-1)
            cutoff = (cum > top_p).nonzero(as_tuple=True)[0]
            if cutoff.numel() > 0:
                k = cutoff[0].item() + 1
                keep_idx = sorted_idx[:k]
                keep_mask = torch.zeros_like(probs, dtype=torch.bool)
                keep_mask[keep_idx] = True
                filtered = torch.where(keep_mask, probs, torch.zeros_like(probs))
                if filtered.sum() <= 0:
                    # fallback greedy
                    return torch.argmax(probs).item()
                filtered = filtered / filtered.sum()
                return torch.multinomial(filtered, num_samples=1).item()
            else:
                return torch.argmax(probs).item()

        def generate_for_sample(feats_i: torch.Tensor, meta_i: dict):
            V = self.num_center_classes
            # 1) generate vertex sequence greedily until end_v
            seq = [int(self.start)]
            max_vertex_tokens = self.max_vertex_num * 2 + 1  # x,y pairs plus end_v
            allowed_v = build_allowed_vertex_mask(V)
            for _ in range(max_vertex_tokens):
                inp = torch.tensor([seq], device=device, dtype=torch.long)
                logits = self.pts_bbox_head.next_token_logits(feats_i, inp, [meta_i])  # [1,V]
                logits = logits[0]
                logits = mask_logits_with_allowed(logits, allowed_v)
                nxt = torch.argmax(logits).item()
                seq.append(nxt)
                if nxt == self.end_v:
                    break
            # ensure end_v present
            if seq[-1] != self.end_v:
                seq.append(int(self.end_v))

            # parse Nv from seq
            seq_wo_start = seq[1:]
            try:
                idx_end_v = seq_wo_start.index(self.end_v)
            except ValueError:
                idx_end_v = len(seq_wo_start)
            Nv = idx_end_v // 2

            # 2) generate edge sequence: CF guidance + top-p
            edge_tokens = []
            groups_done = 0
            count_in_group = 0  # not counting connect_start
            max_steps = self.max_edge_len
            if not self.use_cf_guidance:
                # fallback: greedy using token constraints
                for _ in range(max_steps):
                    stage = 'post' if groups_done >= Nv else 'pre'
                    tri_mod = 0 if count_in_group == 0 else (count_in_group % 3)
                    allowed = build_allowed_edge_mask(V, stage, Nv, tri_mod, groups_done)
                    inp = torch.tensor([seq + edge_tokens], device=device, dtype=torch.long)
                    logits = self.pts_bbox_head.next_token_logits(feats_i, inp, [meta_i])[0]
                    logits = mask_logits_with_allowed(logits, allowed)
                    nxt = torch.argmax(logits).item()
                    if stage == 'post':
                        # must be end_e
                        edge_tokens.append(nxt)
                        break
                    if nxt == self.connect_start:
                        groups_done += 1
                        count_in_group = 0
                    else:
                        count_in_group += 1
                    edge_tokens.append(nxt)
                    if groups_done >= Nv:
                        # now expect end_e at next
                        continue
                # safety: ensure end_e
                if len(edge_tokens) == 0 or edge_tokens[-1] != self.end_e:
                    edge_tokens.append(int(self.end_e))
            else:
                # CF guidance path
                while len(edge_tokens) < max_steps:
                    stage = 'post' if groups_done >= Nv else 'pre'
                    tri_mod = 0 if count_in_group == 0 else (count_in_group % 3)
                    allowed = build_allowed_edge_mask(V, stage, Nv, tri_mod, groups_done)
                    # build cond/uncond prefixes
                    vert_prefix = seq[1:idx_end_v + 1]  # vertices + end_v
                    masked_vert = [int(self.no_known)] * len(vert_prefix)
                    cond_prefix = [int(self.start)] + vert_prefix + edge_tokens
                    uncond_prefix = [int(self.start)] + masked_vert + edge_tokens
                    inp = torch.tensor([cond_prefix, uncond_prefix], device=device, dtype=torch.long)
                    feats_b = feats_i.repeat(2, 1, 1, 1)
                    metas_b = [meta_i, meta_i]
                    logits_b = self.pts_bbox_head.next_token_logits(feats_b, inp, metas_b)  # [2,V]
                    logits_cond = logits_b[0]
                    logits_uncond = logits_b[1]
                    logits = logits_uncond + self.guidance_scale * (logits_cond - logits_uncond)
                    logits = mask_logits_with_allowed(logits, allowed)
                    # sample with top-p
                    nxt = top_p_sample_from_logits(logits, self.top_p)
                    edge_tokens.append(nxt)
                    if stage == 'post':
                        break  # should be end_e
                    if nxt == self.connect_start:
                        groups_done += 1
                        count_in_group = 0
                    else:
                        count_in_group += 1
                    if groups_done >= Nv:
                        # next step will be end_e
                        pass
                # safety: ensure end_e
                if len(edge_tokens) == 0 or edge_tokens[-1] != self.end_e:
                    edge_tokens.append(int(self.end_e))

            full_seq = torch.tensor(seq + edge_tokens, device=device, dtype=torch.long)
            return full_seq

        # Generate per-sample
        B = pts_feats.shape[0]
        line_results = []
        for bi in range(B):
            feats_i = pts_feats[bi:bi+1]
            meta_i = img_metas[bi]
            seq = generate_for_sample(feats_i, meta_i)
            # drop START for decoding
            pred_node_list = decode_vert_edge(seq[1:])
            line_results.append(dict(
                line_seqs=seq[1:].detach().cpu(),
                pred_node_lists=pred_node_list
            ))
        return line_results

    def simple_test(self, img_metas, img=None, rescale=False):
        """Test function without augmentaiton."""
        bev_feats = self.extract_feat(img=img, img_metas=img_metas)
        

        bbox_list = [dict() for i in range(len(img_metas))]
        line_results = self.simple_test_pts(
            bev_feats, img_metas, rescale=rescale)
        for result_dict, line_result, img_meta in zip(bbox_list, line_results, img_metas):
            result_dict['line_results'] = line_result
            if 'token' in img_meta:
                result_dict['token'] = img_meta['token']
        # Optionally log validation BEV overlay (first sample) — aligned with AR_RNTR
        try:
            if self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process():
                if not self._swanlab_ready:
                    self._init_swanlab(cfg=dict(model='AR_LG2Seq', phase='val'))
                self._swanlab_img_step += 1
                if (self._swanlab_img_step % self.swanlab_image_interval) == 0 and len(line_results) > 0:
                    try:
                        pred_tokens0 = line_results[0]['line_seqs']  # 1D tensor without START
                        gt_vert0 = img_metas[0].get('vert_sentence', None)
                        bev_img = self._render_bev_overlay_lane(gt_vert0, pred_tokens0, canvas_size=self.box_range)
                        if bev_img is not None:
                            self._swanlab_log_image('vis/val_lane_bev_overlay', bev_img, step=self._swanlab_img_step)
                    except Exception:
                        pass
        except Exception:
            pass
        return bbox_list

    def aug_test_pts(self, feats, img_metas, rescale=False):
        feats_list = []
        for j in range(len(feats[0])):
            feats_list_level = []
            for i in range(len(feats)):
                feats_list_level.append(feats[i][j])
            feats_list.append(torch.stack(feats_list_level, -1).mean(-1))
        outs = self.pts_bbox_head(feats_list, img_metas)
        bbox_list = self.pts_bbox_head.get_bboxes(
            outs, img_metas, rescale=rescale)
        bbox_results = [
            bbox3d2result(bboxes, scores, labels)
            for bboxes, scores, labels in bbox_list
        ]
        return bbox_results

    def aug_test(self, img_metas, imgs=None, rescale=False):
        """Test function with augmentaiton."""
        img_feats = self.extract_feats(img_metas, imgs)
        img_metas = img_metas[0]
        bbox_list = [dict() for i in range(len(img_metas))]
        bbox_pts = self.aug_test_pts(img_feats, img_metas, rescale)
        for result_dict, pts_bbox in zip(bbox_list, bbox_pts):
            result_dict['pts_bbox'] = pts_bbox
        return bbox_list
