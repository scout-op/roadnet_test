import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector
from mmdet3d.registry import MODELS
from .grid_mask import GridMask
from .LiftSplatShoot import LiftSplatShootEgo


@MODELS.register_module()
class DEC_RNTR(MVXTwoStageDetector):
    """Decoupled-Sequence RNTR: token-level LM over vertex/edge flat sequence.

    It consumes `dec_flat_seq` provided by `TransformDecoupledBzLane2Seq` in
    img_metas for supervision.
    """

    def __init__(self,
                 use_grid_mask=False,
                 img_backbone=None,
                 img_neck=None,
                 lss_cfg=None,
                 grid_conf=None,
                 data_aug_conf=None,
                 pts_bbox_head=None,  # actually our token head
                 train_cfg=None,
                 test_cfg=None,
                 init_cfg=None,
                 data_preprocessor=None,
                 bev_scale=1.0,
                 ):
        super().__init__(None, None, None, img_backbone, None,
                         img_neck, None, pts_bbox_head, None,
                         None, train_cfg, test_cfg, init_cfg,
                         data_preprocessor)
        self.grid_mask = GridMask(True, True, rotate=1, offset=False, ratio=0.5, mode=1, prob=0.7)
        self.use_grid_mask = use_grid_mask
        self.view_transformers = LiftSplatShootEgo(grid_conf, data_aug_conf, return_bev=True, **lss_cfg)
        self.downsample = lss_cfg['downsample']
        self.final_dim = data_aug_conf['final_dim']
        self.bev_scale = bev_scale

    def freeze_pretrain(self):
        for m in self.img_backbone.parameters():
            m.requires_grad = False
        for m in self.img_neck.parameters():
            m.requires_grad = False
        for m in self.view_transformers.parameters():
            m.requires_grad = False

    def extract_img_feat(self, img, img_metas):
        if isinstance(img, list):
            img = torch.stack(img, dim=0)
        B = img.size(0)
        if img is not None:
            input_shape = img.shape[-2:]
            for img_meta in img_metas:
                img_meta.update(input_shape=input_shape)
            if img.dim() == 5:
                if img.size(0) == 1 and img.size(1) != 1:
                    img.squeeze_()
                else:
                    B, N, C, H, W = img.size()
                    img = img.view(B * N, C, H, W)
            if self.use_grid_mask:
                img = self.grid_mask(img)
            img_feats = self.img_backbone(img)
            if isinstance(img_feats, dict):
                img_feats = list(img_feats.values())
        else:
            return None
        if self.with_img_neck:
            img_feats = self.img_neck(img_feats)
        img_feats_reshaped = []
        for img_feat in img_feats:
            BN, C, H, W = img_feat.size()
            img_feats_reshaped.append(img_feat.view(B, int(BN / B), C, H, W))
        return img_feats_reshaped

    def extract_feat(self, img, img_metas):
        img_feats = self.extract_img_feat(img, img_metas)
        largest_feat_shape = img_feats[0].shape[3]
        down_level = int(torch.log2(torch.tensor(self.downsample // (self.final_dim[0] // largest_feat_shape))).item())
        bev_feats = self.view_transformers(img_feats[down_level], img_metas)
        return bev_feats

    def loss(self, inputs=None, data_samples=None, **kwargs):
        img = inputs['img']
        img_metas = [ds.metainfo for ds in data_samples]
        bev_feats = self.extract_feat(img=img, img_metas=img_metas)
        if self.bev_scale != 1.0:
            b, c, h, w = bev_feats.shape
            bev_feats = F.interpolate(bev_feats, (int(h * self.bev_scale), int(w * self.bev_scale)))
        # build input/target tokens
        flat_list = [m['dec_flat_seq'] for m in img_metas]
        max_len = max(len(seq) for seq in flat_list)
        B = len(flat_list)
        device = bev_feats.device
        pad_id = 575  # no_known
        tokens = torch.full((B, max_len), pad_id, device=device, dtype=torch.long)
        for i, arr in enumerate(flat_list):
            l = len(arr)
            tokens[i, :l] = torch.as_tensor(arr, device=device, dtype=torch.long)
        # language modeling: predict next token
        input_tokens = tokens[:, :-1]
        target_tokens = tokens[:, 1:]
        logits = self.pts_bbox_head(bev_feats, input_tokens, img_metas)
        losses = self.pts_bbox_head.loss_by_token(logits, target_tokens)
        return losses

    @torch.no_grad()
    def simple_test(self, img_metas, img=None):
        bev_feats = self.extract_feat(img=img, img_metas=img_metas)
        start_id, end_id = 574, 568  # <START>, <EOE>
        seq, vals = self.pts_bbox_head.greedy_decode(bev_feats, img_metas, start_id, end_id, max_len=1200)
        
        # Import parser for evaluation compatibility
        from .core import dec_seq_to_bznodelist
        
        out = []
        for i, m in enumerate(img_metas):
            dec_seq_cpu = seq[i].detach().cpu().numpy()
            n_control = m.get('n_control', 3)
            epsilon = 0.01  # tolerance for coordinate matching
            
            # Parse decoupled sequence to node list for evaluation
            pred_node_list = dec_seq_to_bznodelist(dec_seq_cpu, n_control, epsilon)
            
            # Build result dict compatible with NuScenesReachMetric
            line_result = dict(
                line_seqs=seq[i].detach().cpu(),
                pred_node_lists=pred_node_list
            )
            out.append(dict(
                line_results=line_result,  # For NuScenesReachMetric.process()
                token=m['token']
            ))
        return out

    def predict(self, batch_inputs_dict, batch_data_samples, **kwargs):
        batch_input_metas = [item.metainfo for item in batch_data_samples]
        batch_input_imgs = batch_inputs_dict['img']
        return self.simple_test(batch_input_metas, batch_input_imgs)
