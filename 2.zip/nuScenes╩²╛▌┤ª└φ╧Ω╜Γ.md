# nuScenes数据处理详解：从原始数据到训练Token

> 本文档详细解释nuScenes数据集如何被处理成RoadNetTransformer (RNTR)训练所需的序列格式。  
> 适合初学者理解整个数据流水线。

---

## 目录
1. [什么是nuScenes数据集？](#1-什么是nuscenes数据集)
2. [原始数据长什么样？](#2-原始数据长什么样)
3. [数据处理的整体流程](#3-数据处理的整体流程)
4. [第一步：数据加载](#4-第一步数据加载)
5. [第二步：中心线处理](#5-第二步中心线处理)
6. [第三步：图结构构建](#6-第三步图结构构建)
7. [第四步：序列化](#7-第四步序列化)
8. [第五步：SAR分组](#8-第五步sar分组)
9. [最终训练格式](#9-最终训练格式)
10. [完整代码调用链](#10-完整代码调用链)
11. [常见问题解答](#11-常见问题解答)

---

## 1. 什么是nuScenes数据集？

### 1.1 数据集简介
nuScenes是一个大型自动驾驶数据集，包含：
- **多视角相机图像**（6个相机：前、后、左前、右前、左后、右后）
- **LiDAR点云数据**
- **地图标注**：包括车道线、道路边界、人行横道等
- **3D物体标注**：车辆、行人等

### 1.2 道路网络标注
在nuScenes中，道路网络通过**中心线（centerlines）**来表示：
- 每条中心线是一系列连续的3D坐标点
- 中心线之间有连接关系（拓扑结构）
- 这些连接关系描述了道路的分叉、合并等结构

---

## 2. 原始数据长什么样？

### 2.1 原始center_lines格式
```python
# 一个场景的原始center_lines数据
{
    'centerline_ids': [1001, 1002, 1003, 1004],           # 每条中心线的唯一ID
    'centerlines': [                                       # 每条中心线的坐标点列表
        [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [2.0, 0.0, 0.0]],  # 中心线1：3个点
        [[2.0, 0.0, 0.0], [3.0, 0.0, 0.0], [4.0, 0.0, 0.0]],  # 中心线2：3个点
        [[2.0, 0.0, 0.0], [2.0, 1.0, 0.0], [2.0, 2.0, 0.0]],  # 中心线3：3个点
        [[4.0, 0.0, 0.0], [4.0, 1.0, 0.0], [4.0, 2.0, 0.0]]   # 中心线4：3个点
    ],
    'incoming_ids': [[], [1001], [1002], [1002]],         # 每条中心线的前驱（哪些线连到它）
    'outgoing_ids': [[1002], [1003, 1004], [], []],       # 每条中心线的后继（它连到哪些线）
    'start_point_idxs': [0, 0, 0, 0],                     # 每条线的起点索引
    'end_point_idxs': [2, 2, 2, 2]                        # 每条线的终点索引
}
```

### 2.2 数据含义解释
- **centerline_ids**: 每条中心线的唯一标识符
- **centerlines**: 每条中心线由多个3D坐标点组成 `[x, y, z]`
- **incoming_ids**: 哪些中心线连接到当前中心线（前驱）
- **outgoing_ids**: 当前中心线连接到哪些中心线（后继）
- **start_point_idxs**: 每条中心线的起点在坐标列表中的索引
- **end_point_idxs**: 每条中心线的终点在坐标列表中的索引

### 2.3 拓扑关系示例
```
中心线1: [0,0,0] → [1,0,0] → [2,0,0]
中心线2: [2,0,0] → [3,0,0] → [4,0,0]  ← 从中心线1的终点开始
中心线3: [2,0,0] → [2,1,0] → [2,2,0]  ← 从中心线1的终点分叉
中心线4: [4,0,0] → [4,1,0] → [4,2,0]  ← 从中心线2的终点分叉
```

---

## 3. 数据处理的整体流程

### 3.1 处理流程图
```
原始center_lines数据
        ↓
    数据加载阶段
        ↓
    中心线处理阶段
        ↓
    图结构构建阶段
        ↓
    序列化阶段
        ↓
    SAR分组阶段
        ↓
    最终训练格式
```

### 3.2 各阶段目标
1. **数据加载**：从pkl文件读取原始数据
2. **中心线处理**：坐标转换、BEV过滤、图构建
3. **图结构构建**：构建节点和邻接矩阵
4. **序列化**：将图转换为6整数序列
5. **SAR分组**：为SAR模型分配组ID
6. **最终格式**：生成训练所需的token序列

---

## 4. 第一步：数据加载

### 4.1 数据集类
```python
@DATASETS.register_module()
class CenterlineNuScenesDataset(BaseDataset):
    def __init__(self, ann_file, pipeline, ...):
        # ann_file: 预处理好的pkl文件路径
        # pipeline: 数据增强流水线
        super().__init__(ann_file=ann_file, pipeline=pipeline, ...)
```

### 4.2 加载标注文件
```python
def load_data_list(self) -> List[dict]:
    # 从pkl文件加载所有场景的标注
    annotations = load(self.ann_file)  # {'infos': [...], 'metadata': {...}}
    
    data_list = []
    for raw_data_info in annotations['infos']:
        data_info = self.parse_data_info(raw_data_info)
        data_list.append(data_info)
    
    return data_list
```

### 4.3 解析单个样本
```python
def parse_data_info(self, info: dict) -> dict:
    input_dict = {
        'token': info['token'],                # 场景唯一标识
        'img_filename': image_paths,           # 6张相机图像路径
        'lidar2img': lidar2img_rts,           # LiDAR到图像的投影矩阵
        'center_lines': info['center_lines']   # ← 道路中心线标注（原始格式）
    }
    return input_dict
```

**此时 `center_lines` 还是原始格式**（密集坐标点 + 拓扑信息）。

---

## 5. 第二步：中心线处理

### 5.1 数据增强Pipeline
在配置文件中定义处理流水线：
```python
train_pipeline = [
    dict(type='LoadMultiViewImageFromFiles', ...),          # 加载图像
    dict(type='LoadNusOrderedBzCenterline', ...),           # ← 处理中心线
    dict(type='TransformOrderedBzLane2GraphSAR', ...),      # ← 转为序列 + SAR分组
    dict(type='Pack3DCenterlineInputs', ...)                # 打包为训练输入
]
```

### 5.2 LoadNusOrderedBzCenterline处理
```python
@TRANSFORMS.register_module()
class LoadNusOrderedBzCenterline(object):
    def __init__(self, grid_conf, bz_grid_conf):
        self.grid_conf = grid_conf      # 主网格配置
        self.bz_grid_conf = bz_grid_conf # 贝塞尔网格配置

    def __call__(self, results):
        # 将原始center_lines转换为处理后的格式
        results['center_lines'] = NusOrederedBzCenterLine(
            results['center_lines'], 
            self.grid_conf, 
            self.bz_grid_conf
        )
        return results
```

### 5.3 NusOrederedBzCenterLine核心处理

#### 5.3.1 初始化
```python
class NusOrederedBzCenterLine(object):
    def __init__(self, centerlines, grid_conf, bz_grid_conf):
        # 复制原始数据
        self.types = copy.deepcopy(centerlines['type'])
        self.centerline_ids = copy.deepcopy(centerlines['centerline_ids'])
        self.incoming_ids = copy.deepcopy(centerlines['incoming_ids'])
        self.outgoing_ids = copy.deepcopy(centerlines['outgoing_ids'])
        self.start_point_idxs = copy.deepcopy(centerlines['start_point_idxs'])
        self.end_point_idxs = copy.deepcopy(centerlines['end_point_idxs'])
        self.centerlines = copy.deepcopy(centerlines['centerlines'])
        
        # 计算网格参数
        dx, bx, nx = self.gen_dx_bx(grid_conf['xbound'], grid_conf['ybound'], grid_conf['zbound'])
        self.dx = dx  # 网格分辨率
        self.bx = bx  # 网格起始点
        self.nx = nx  # 网格数量
        self.pc_range = np.concatenate((self.bx - self.dx / 2., self.bx - self.dx / 2. + self.nx * self.dx))
        
        # 贝塞尔网格参数
        bz_dx, bz_bx, bz_nx = self.gen_dx_bx(bz_grid_conf['xbound'], bz_grid_conf['ybound'], bz_grid_conf['zbound'])
        self.bz_dx = bz_dx
        self.bz_bx = bz_bx
        self.bz_nx = bz_nx
        self.bz_pc_range = np.concatenate((bz_bx - bz_dx / 2., bz_bx - bz_dx / 2. + bz_nx * bz_dx))
        
        # 执行BEV过滤
        self.filter_bev()
```

#### 5.3.2 BEV过滤
```python
def filter_bev(self):
    """过滤掉BEV范围外的中心线"""
    aug_centerlines = []
    for i in range(len(self.centerlines)):
        centerline = self.centerlines[i]
        
        # 检查哪些点在BEV范围内
        in_bev_x = np.logical_and(centerline[:, 0] < self.pc_range[3], 
                                 centerline[:, 0] >= self.pc_range[0])
        in_bev_y = np.logical_and(centerline[:, 1] <= self.pc_range[4], 
                                 centerline[:, 1] >= self.pc_range[1])
        in_bev_xy = np.logical_and(in_bev_x, in_bev_y)
        
        # 如果没有任何点在BEV范围内，跳过这条中心线
        if not np.max(in_bev_xy):
            continue
            
        # 如果所有点都在BEV范围内，直接保留
        if np.min(in_bev_xy):
            aug_centerlines.append(centerline)
            continue
            
        # 部分点在BEV范围内，截取有效部分
        aug_centerline = centerline[in_bev_xy, :]
        aug_centerlines.append(aug_centerline)
    
    self.centerlines = aug_centerlines
```

---

## 6. 第三步：图结构构建

### 6.1 节点和邻接矩阵构建
```python
def export_node_adj(self):
    # 构建原始节点和邻接矩阵
    self.construct_nodes_adj_raw_and_raw_points()
    # 合并相同位置的节点
    self.nodes_merge()
    return self.all_nodes, self.adj
```

### 6.2 原始节点构建
```python
def construct_nodes_adj_raw_and_raw_points(self):
    """为每条中心线创建起点和终点节点"""
    self.all_nodes_raw = []
    self.raw_points_in_between = {}
    self.adj_raw = np.zeros((2 * len(self.centerlines), 2 * len(self.centerlines)), dtype=np.int8)
    
    for idx, centerline in enumerate(self.centerlines):
        # 创建起点节点
        start_node = BzNode(centerline[self.start_point_idxs[idx]])
        self.all_nodes_raw.append(start_node)
        
        # 创建终点节点
        end_node = BzNode(centerline[self.end_point_idxs[idx]])
        self.all_nodes_raw.append(end_node)
        
        # 起点到终点的连接
        self.adj_raw[2 * idx, 2 * idx + 1] = 1      # 起点 → 终点
        self.adj_raw[2 * idx + 1, 2 * idx] = -1     # 终点 → 起点
        
        # 保存中心线上的所有点
        self.raw_points_in_between[(2 * idx, 2 * idx + 1)] = centerline[
            self.start_point_idxs[idx]:self.end_point_idxs[idx]+1]
```

### 6.3 节点合并
```python
def nodes_merge(self):
    """合并位置相同的节点"""
    self.all_nodes = []
    nodes_raw_nodes_map = [None for i in self.all_nodes_raw]
    picked_raw_nodes = []
    
    for idx, node in enumerate(self.all_nodes_raw):
        if idx in picked_raw_nodes:
            continue
            
        # 添加新节点
        self.all_nodes.append(self.all_nodes_raw[idx])
        nodes_raw_nodes_map[idx] = idx
        picked_raw_nodes.append(idx)
        
        # 查找位置相同的节点
        for idx_j in range(idx + 1, len(self.all_nodes_raw)):
            if self.all_nodes_raw[idx] == self.all_nodes_raw[idx_j]:
                picked_raw_nodes.append(idx_j)
                nodes_raw_nodes_map[idx_j] = idx  # 映射到同一个节点
    
    # 构建最终的邻接矩阵
    self.adj = np.zeros((len(self.all_nodes), len(self.all_nodes)), dtype=np.int64)
    for i, j in self.points_in_between_nodes.keys():
        self.adj[i][j] = 1
        self.adj[j][i] = -1
```

### 6.4 子图分割
```python
def sub_graph_split(self):
    """将连通图分割为多个子图"""
    def dfs(index, visited, subgraph_nodes, adj):
        if visited[index]:
            return
        visited[index] = True
        subgraph_nodes.append(index)
        for idx, i in enumerate(adj[index]):
            if adj[index][idx] == 1 or adj[index][idx] == -1:
                dfs(idx, visited, subgraph_nodes, adj)
    
    # 对每个连通分量进行DFS
    subgraph_count = 0
    visited = [False for i in self.all_nodes]
    subgraphs_nodes = []
    
    for idx, node in enumerate(self.all_nodes):
        if not visited[idx]:
            subgraph_nodes = []
            dfs(idx, visited, subgraph_nodes, self.adj)
            if len(subgraph_nodes) > 1:  # 只保留有多个节点的子图
                subgraphs_nodes.append(subgraph_nodes)
    
    # 为每个子图构建邻接矩阵
    self.subgraphs_nodes = []
    self.subgraphs_adj = []
    for sub_nodes in subgraphs_nodes:
        subgraph_adj = np.zeros((len(sub_nodes), len(sub_nodes)), dtype=np.int64)
        for i in range(len(sub_nodes) - 1):
            for j in range(i + 1, len(sub_nodes)):
                subgraph_adj[i][j] = self.adj[sub_nodes[i]][sub_nodes[j]]
                subgraph_adj[j][i] = -subgraph_adj[i][j]
        
        self.subgraphs_nodes.append([self.all_nodes[i] for i in sub_nodes])
        self.subgraphs_adj.append(subgraph_adj)
```

---

## 7. 第四步：序列化

### 7.1 图到序列的转换
```python
@TRANSFORMS.register_module()
class TransformOrderedBzLane2GraphSAR(object):
    def __init__(self, n_control=3, orderedDFS=True):
        self.n_control = n_control      # 贝塞尔控制点数量
        self.order = orderedDFS         # 是否使用有序DFS

    def __call__(self, results):
        centerlines = results['center_lines']
        
        # 构建场景图
        scene_graph = OrderedBzSceneGraph(
            centerlines.subgraphs_nodes, 
            centerlines.subgraphs_adj, 
            centerlines.subgraphs_points_in_between_nodes, 
            self.n_control
        )
        
        # 序列化
        scene_sentance, scene_sentance_list = scene_graph.sequelize_new(orderedDFS=self.order)
        
        # 转换为序列格式
        centerline_sequence = sentance2bzseq(
            scene_sentance_list,
            centerlines.pc_range, 
            centerlines.dx, 
            centerlines.bz_pc_range, 
            centerlines.bz_nx
        )
        
        # 切分为不同字段
        clause_length = 4 + 2 * (self.n_control - 2)
        centerline_coord = np.stack([centerline_sequence[::clause_length], 
                                   centerline_sequence[1::clause_length]], axis=1)
        centerline_label = centerline_sequence[2::clause_length]
        centerline_connect = centerline_sequence[3::clause_length]
        centerline_coeff = np.stack([centerline_sequence[k::clause_length] 
                                   for k in range(4, clause_length)], axis=1)
        
        results['centerline_sequence'] = centerline_sequence
        results['centerline_coord'] = centerline_coord
        results['centerline_label'] = centerline_label
        results['centerline_connect'] = centerline_connect
        results['centerline_coeff'] = centerline_coeff
        results['n_control'] = self.n_control
        
        return results
```

### 7.2 序列化核心函数
```python
def sentance2bzseq(sentance, pc_range, dx, bz_pc_range, bz_nx):
    """将场景句子转换为贝塞尔序列"""
    type_idx_map = {'start':0, 'continue':1, 'fork':2, 'merge':3}
    seq = []
    
    for idx, sub_sent in enumerate(sentance):
        for node in sub_sent:
            # 坐标转换：米制 → 网格
            node.position = (node.position - pc_range[:3]) / dx
            
            # 更新序列索引
            if idx == 0:
                node.sque_index += 1
            else:
                node.sque_index = node.sque_index + sentance[idx-1][-1].sque_index + 1
            
            # 添加坐标
            seq += node.position[:2].astype(int).tolist()  # x, y
            
            # 添加类型
            seq.append(type_idx_map[node.sque_type])
            
            # 添加连接索引
            if node.sque_type == "fork":
                if idx == 0:
                    node.fork_from_index += 1
                else:
                    node.fork_from_index = node.fork_from_index + sentance[idx - 1][-1].sque_index + 1
                seq.append(node.fork_from_index)
            elif node.sque_type == "merge":
                if idx == 0:
                    node.merge_with_index += 1
                else:
                    node.merge_with_index = node.merge_with_index + sentance[idx - 1][-1].sque_index + 1
                seq.append(node.merge_with_index)
            else:
                seq.append(0)
            
            # 添加贝塞尔系数
            if len(node.coeff):
                node.coeff = (node.coeff - bz_pc_range[:2]) / dx[:2]
                node.coeff[0] = np.clip(node.coeff[0], 0, bz_nx[0]-1)
                node.coeff[1] = np.clip(node.coeff[1], 0, bz_nx[1]-1)
                node.coeff = node.coeff.astype(int)
                seq.append(node.coeff[0])
                seq.append(node.coeff[1])
            else:
                seq.append(0)
                seq.append(0)
    
    return seq
```

### 7.3 6整数表示法
每个节点用6个整数表示：
```python
# 对于n_control=3的情况
clause = [x, y, label, connect, coeff_x, coeff_y]
# x, y: 节点坐标（网格单位）
# label: 节点类型（0=start, 1=continue, 2=fork, 3=merge）
# connect: 连接索引（fork/merge时指向其他节点，否则为0）
# coeff_x, coeff_y: 贝塞尔控制点坐标
```

---

## 8. 第五步：SAR分组

### 8.1 SAR分组策略
```python
def __call__(self, results):
    # ... 前面的序列化代码 ...
    
    # SAR分组：每个子图分配一个组ID
    group_ids_tokens = []
    for gid, sub_sent in enumerate(scene_sentance_list, start=1):
        for node in sub_sent:
            # 该clause的所有token都属于gid组
            group_ids_tokens.extend([gid] * clause_length)
    
    results['sar_group_ids_pos'] = group_ids_tokens
    return results
```

### 8.2 分组示例
```python
# 假设有2个子图，每个子图有2个节点
# 子图1: 节点A, 节点B
# 子图2: 节点C, 节点D

# 序列: [A的6个token, B的6个token, C的6个token, D的6个token]
# 组ID: [1,1,1,1,1,1, 1,1,1,1,1,1, 2,2,2,2,2,2, 2,2,2,2,2,2]
#       ↑子图1的节点A    ↑子图1的节点B    ↑子图2的节点C    ↑子图2的节点D
```

---

## 9. 最终训练格式

### 9.1 训练样本结构
```python
# 经过完整pipeline处理后的样本
{
    'token': '场景ID',
    'img': Tensor,  # 6视角图像 [6, 3, H, W]
    'lidar2img': [...],
    
    # ========== 道路网络标注 ==========
    'centerline_sequence': [574, x1, y1, lbl1, conn1, cx1, cy1, ...],  # 完整序列（含特殊token）
    'centerline_coord': [[x1, y1], [x2, y2], ...],      # N × 2
    'centerline_label': [0, 1, 2, ...],                 # N (类型)
    'centerline_connect': [0, 0, 2, ...],               # N (连接索引)
    'centerline_coeff': [[cx1, cy1], ...],              # N × 2 (控制点)
    'n_control': 3,                                      # 贝塞尔控制点数
    
    # ========== SAR专属 ==========
    'sar_group_ids_pos': [1,1,1,1,1,1, 1,1,1,1,1,1, 2,2,2,2,2,2, ...],  # 每个token的组ID
}
```

### 9.2 训练时的处理
```python
# 在SAR_RNTR.forward_pts_train()中
def forward_pts_train(self, ...):
    # 1. 构建输入序列（加[START]，填充负样本）
    input_seqs = []
    for bi in range(B):
        box_label = torch.cat([coord, label, connect, coeff], dim=-1)  # 真实节点
        random_box_label = ...  # 随机填充的负样本
        input_seq = torch.cat([
            torch.ones(1) * self.start,    # [START] token
            box_label.flatten(),           # 真实节点序列
            random_box_label.flatten()     # 负样本序列
        ])
        input_seqs.append(input_seq)
    input_seqs = torch.cat(input_seqs, dim=0)  # [B, T]
    
    # 2. 调用head（带SAR mask）
    outs = self.pts_bbox_head(
        bev_feats, 
        input_seqs, 
        img_metas,  # ← 包含sar_group_ids_pos
        gt_targets
    )
```

---

## 10. 完整代码调用链

### 10.1 数据加载阶段
```
CenterlineNuScenesDataset.load_data_list()
  ↓
parse_data_info(info)  # 提取center_lines（原始格式）
  ↓
Pipeline[0]: LoadMultiViewImageFromFiles()  # 加载图像
  ↓
Pipeline[1]: LoadNusOrderedBzCenterline()   # 中心线 → 图结构
  ↓ (调用)
NusOrederedBzCenterLine(center_lines, grid_conf, bz_grid_conf)
  ├─ 坐标转换（米 → 网格）
  ├─ 密集点 → 稀疏节点
  └─ 构建图（nodes + adjacency + subgraphs）
  ↓
Pipeline[2]: TransformOrderedBzLane2GraphSAR()  # 图 → 序列 + SAR分组
  ↓ (调用)
OrderedBzSceneGraph.sequelize_new(orderedDFS=True)
  ├─ DFS遍历每个子图
  └─ 展平为序列，记录每个token的group_id
  ↓
results = {
    'centerline_sequence': [...],
    'centerline_coord': [...],
    'centerline_label': [...],
    'centerline_connect': [...],
    'centerline_coeff': [...],
    'sar_group_ids_pos': [...]  # ← SAR分组信息
}
  ↓
Pipeline[3]: Pack3DCenterlineInputs()  # 打包为DataContainer
```

### 10.2 训练阶段
```
SAR_RNTR.forward_pts_train(bev_feats, gt_lines_coords, ..., img_metas)
  ├─ 构建input_seqs = [START] + 真实节点 + 随机负样本  # [B, T]
  ├─ 构建output_seqs = 真实节点 + [END] + padding       # [B, T]
  └─ 调用head
        ↓
SARRNTRHead.forward(bev_feats, input_seqs, img_metas, ...)
  ├─ tgt = embedding(input_seqs)  # [B, T, D]
  ├─ 从img_metas提取sar_group_ids_pos
  ├─ 为每个样本构建分组掩码tgt_mask[bi]  # [T, T]
  └─ tgt_mask = torch.stack(masks_bt, dim=0)  # [B, T, T]
        ↓
LssSARPrmSeqLineTransformer.forward(..., tgt_mask=[B,T,T], ...)
  ├─ tgt = tgt.transpose(0, 1)  # [T, B, D]
  └─ decoder(tgt, memory, attn_masks=[tgt_mask, None])
        ↓
PlPryLineTransformerDecoderLayer._forward(...)
  ├─ self_attn: 使用tgt_mask（组内并行、组间因果）
  └─ cross_attn: 使用None（可见所有BEV特征）
        ↓
RNTR2MultiheadAttention.forward(..., attn_mask=tgt_mask)
```

---

## 11. 常见问题解答

### Q1: 为什么要将米制坐标转换为网格坐标？
**A**: 因为神经网络无法直接处理连续坐标，需要将坐标离散化为网格索引。这样可以：
- 减少坐标的数值范围
- 提高训练稳定性
- 便于后续的注意力计算

### Q2: 什么是BEV过滤？
**A**: BEV（Bird's Eye View）过滤是指只保留在特定范围内的中心线。通常过滤掉：
- 距离车辆太远的中心线
- 超出感知范围的中心线
- 不相关的道路信息

### Q3: 为什么要进行子图分割？
**A**: 子图分割的目的是：
- 将复杂的道路网络分解为简单的连通子图
- 每个子图可以独立处理
- 便于SAR模型的并行生成

### Q4: 6整数表示法是什么意思？
**A**: 每个道路节点用6个整数表示：
- `x, y`: 节点在网格中的坐标
- `label`: 节点类型（起点、继续、分叉、合并）
- `connect`: 连接关系（指向其他节点的索引）
- `coeff_x, coeff_y`: 贝塞尔控制点坐标

### Q5: SAR分组的作用是什么？
**A**: SAR分组用于实现半自回归生成：
- 组内可以并行生成（提高效率）
- 组间保持因果顺序（保证正确性）
- 平衡了生成速度和准确性

### Q6: 如何处理连接关系？
**A**: 连接关系通过索引来表示：
- `fork`节点：指向分叉的源节点
- `merge`节点：指向合并的目标节点
- 其他节点：连接索引为0

### Q7: 贝塞尔系数的作用是什么？
**A**: 贝塞尔系数用于描述道路的弯曲形状：
- 提供更精确的道路几何信息
- 支持平滑的道路表示
- 便于后续的路径规划

---

## 总结

nuScenes数据处理流程是一个复杂但逻辑清晰的过程：

1. **原始数据**：密集的3D坐标点 + 拓扑关系
2. **坐标转换**：米制 → 网格坐标
3. **图构建**：节点 + 邻接矩阵
4. **子图分割**：连通分量分解
5. **序列化**：6整数表示法
6. **SAR分组**：半自回归生成支持
7. **训练格式**：Token序列 + 组ID

整个流程确保了从原始地图数据到可训练序列的完整转换，为RoadNetTransformer提供了高质量的输入数据。

---

*本文档详细解释了nuScenes数据处理的每个步骤，帮助读者理解从原始数据到训练token的完整转换过程。*
