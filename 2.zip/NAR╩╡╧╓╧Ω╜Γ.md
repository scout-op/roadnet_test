# NAR (Non-Autoregressive) 实现详解：从论文到代码

> 本文档详细解释NAR-RNTR的实现，结合论文理论和代码实践，适合初学者理解非自回归生成机制。

---

## 目录
1. [什么是NAR？](#1-什么是nar)
2. [论文中的NAR理论](#2-论文中的nar理论)
3. [NAR训练策略：MLM](#3-nar训练策略mlm)
4. [NAR推理策略：迭代优化](#4-nar推理策略迭代优化)
5. [代码实现详解](#5-代码实现详解)
6. [配置和训练流程](#6-配置和训练流程)
7. [性能分析](#7-性能分析)
8. [常见问题解答](#8-常见问题解答)

---

## 1. 什么是NAR？

### 1.1 自回归 vs 非自回归

#### **自回归 (AR)**
- **生成方式**：逐个token生成，每个token依赖前面的所有token
- **时间复杂度**：O(n)，其中n是序列长度
- **优点**：生成质量高，逻辑连贯
- **缺点**：推理速度慢，无法并行

```python
# AR生成示例
for i in range(sequence_length):
    next_token = model.predict(previous_tokens)  # 依赖前面所有token
    sequence.append(next_token)
```

#### **非自回归 (NAR)**
- **生成方式**：一次性生成整个序列，所有token并行预测
- **时间复杂度**：O(1)，理论上可以完全并行
- **优点**：推理速度快，可以并行计算
- **缺点**：生成质量可能不如AR，需要特殊训练策略

```python
# NAR生成示例
all_tokens = model.predict_parallel()  # 一次性预测所有token
```

### 1.2 NAR的挑战
1. **多模态问题**：同一个输入可能对应多个有效输出
2. **训练困难**：缺乏明确的生成顺序
3. **质量保证**：如何确保生成序列的连贯性

---

## 2. 论文中的NAR理论

### 2.1 NAR-RNTR目标函数

根据论文，NAR-RNTR的目标是：

$$\max \sum_{i=1}^M \sum_{j=1}^L P(y_{i, j}\ |\ \hat{y}, \mathcal{F}, \mathcal{V}_{kp})$$

其中：
- $M$：子序列数量
- $L$：每个子序列的最大长度
- $y_{i,j}$：第i个子序列的第j个token
- $\hat{y}$：上一次迭代的预测结果
- $\mathcal{F}$：BEV特征
- $\mathcal{V}_{kp}$：关键点特征

### 2.2 迭代优化策略

NAR-RNTR使用迭代优化来模拟自回归生成：

1. **初始预测**：从全mask序列开始
2. **迭代优化**：基于置信度重新mask低置信度token
3. **逐步细化**：每次迭代都提高预测质量

### 2.3 效率分析

**时间复杂度**：
$$\mathcal{O}(\alpha |\mathcal{V}_{kp}|(N_{iter}+1)\cdot \mathcal{T}_s)$$

**加速比**：
$$\frac{|\mathcal{E}| / |\mathcal{V}_{kp}|+1}{N_{iter} + 1}$$

其中 $N_{iter} \ll |\mathcal{E}| / |\mathcal{V}_{kp}|$

---

## 3. NAR训练策略：MLM

### 3.1 Masked Language Modeling (MLM)

NAR使用BERT风格的MLM训练策略：

```python
# MLM训练流程
def mlm_training_step(sequence, mask_ratio=0.9):
    # 1. 随机mask 90%的token
    masked_sequence = mask_tokens(sequence, mask_ratio)
    
    # 2. 预测被mask的token
    predictions = model(masked_sequence)
    
    # 3. 计算损失（只对被mask的位置）
    loss = compute_loss(predictions, original_sequence, mask_positions)
    
    return loss
```

### 3.2 代码实现

```python
# 在SAR_RNTR.forward_pts_train()中
if nar_mlm_train and input_seqs.shape[1] > 1 and nar_mask_ratio > 0.0:
    B, T = input_seqs.shape
    tail_len = T - 1
    
    # 只对有效token进行mask
    valid_tail = (output_seqs[:, :-1] != self.no_known)
    rand_tail = torch.rand(B, tail_len, device=device)
    mask_tail = (rand_tail < nar_mask_ratio) & valid_tail
    
    # 确保每个样本至少有一个masked token
    no_any = (~mask_tail.any(dim=1)) & (valid_tail.any(dim=1))
    if no_any.any():
        idxs = torch.nonzero(no_any, as_tuple=False).view(-1)
        for bi in idxs.tolist():
            vidx = torch.nonzero(valid_tail[bi], as_tuple=False).view(-1)
            if vidx.numel() > 0:
                j = int(vidx[torch.randint(0, vidx.numel(), (1,), device=device)])
                mask_tail[bi, j] = True
    
    # 应用masking（保持START token）
    tail_in = input_seqs[:, 1:]
    input_seqs = torch.cat([
        input_seqs[:, :1], 
        torch.where(mask_tail, torch.full_like(tail_in, self.no_known), tail_in)
    ], dim=1)
    
    # 只对被mask的位置计算损失
    tail_lbl = output_seqs[:, :-1]
    tail_lbl = torch.where(mask_tail, tail_lbl, torch.full_like(tail_lbl, self.no_known))
    output_seqs = torch.cat([tail_lbl, output_seqs[:, -1:]], dim=1)
```

### 3.3 MLM的优势

1. **并行训练**：可以同时训练所有位置
2. **鲁棒性**：提高模型对部分信息的处理能力
3. **效率**：比自回归训练更快

---

## 4. NAR推理策略：迭代优化

### 4.1 迭代推理流程

```python
def nar_iterative_inference(model, initial_sequence, max_iters=3):
    sequence = initial_sequence  # 初始全mask序列
    
    for iteration in range(max_iters):
        # 1. 预测所有token
        predictions = model(sequence)
        confidences = predictions.softmax(-1).max(dim=-1)[0]
        
        # 2. 基于置信度决定保留哪些预测
        keep_mask = (confidences >= confidence_threshold)
        
        # 3. 更新序列：保留高置信度，重新mask低置信度
        sequence = update_sequence(sequence, predictions, keep_mask)
        
        # 4. 最后一次迭代：接受所有预测
        if iteration == max_iters - 1:
            sequence = predictions.argmax(-1)
    
    return sequence
```

### 4.2 代码实现详解

```python
# 在SARRNTRHead.forward()中
if getattr(self, 'nar_infer', False):
    B = input_seqs.shape[0]
    T = 1 + int(getattr(self, 'max_iteration', 0))
    
    # 初始化：[START] + [NO_KNOWN]
    seq = torch.full((B, T), int(self.no_known), device=x.device, dtype=torch.long)
    seq[:, 0] = int(self.start)
    
    # 迭代优化
    for it in range(iters):
        # 1. 编码当前序列
        tgt = self.embedding(seq.long())
        if kp_bias is not None:
            tgt = tgt + kp_bias.unsqueeze(1)
        
        # 2. 使用零mask（完全并行）
        tgt_mask_zero = torch.zeros(T, T, device=tgt.device)
        
        # 3. 通过Transformer预测
        outs_dec, _ = self.transformer(tgt, x, tgt_mask_zero, masks, query_embed, pos_embed)
        outs_dec = torch.nan_to_num(outs_dec)
        logits = self.vocab_embed(outs_dec)
        probs = logits.softmax(-1)
        values_i, tokens = probs.max(dim=-1)
        seq_pred = tokens[-1]
        seq_pred[:, 0] = int(self.start)  # 保持START token
        last_values = values_i[-1]
        
        # 4. 最后一次迭代：接受所有预测
        if it == iters - 1:
            seq = seq_pred
            break
        
        # 5. 基于置信度重新mask
        conf = last_values  # [B, T]
        keep_mask = (conf >= float(getattr(self, 'nar_conf_thresh', 0.5)))
        
        # 6. 可选的top-k保留策略
        kr = float(getattr(self, 'nar_keep_ratio', 0.0))
        if kr > 0.0 and T > 1:
            k_top = max(1, int(round((T - 1) * kr)))
            conf_tail = conf[:, 1:]
            topk_vals, topk_idx = torch.topk(conf_tail, k=k_top, dim=-1)
            keep_topk = torch.zeros_like(conf_tail, dtype=torch.bool)
            gather = torch.arange(keep_topk.shape[0], device=keep_topk.device).unsqueeze(-1)
            keep_topk[gather, topk_idx] = True
            keep_tail = keep_mask[:, 1:] | keep_topk
            keep_mask = torch.cat([keep_mask[:, :1], keep_tail], dim=1)
        
        # 7. 总是保留START token
        keep_mask[:, 0] = True
        
        # 8. 应用masking：保留高置信度，重新mask低置信度
        remask = torch.full_like(seq_pred, int(self.no_known))
        seq = torch.where(keep_mask, seq_pred, remask)
    
    return seq, last_values
```

### 4.3 置信度策略

#### **阈值策略**
```python
keep_mask = (confidence >= confidence_threshold)
```
- 保留置信度高于阈值的预测
- 重新mask低置信度的预测

#### **Top-K策略**
```python
if keep_ratio > 0.0:
    k_top = int(round(sequence_length * keep_ratio))
    topk_indices = torch.topk(confidence, k=k_top).indices
    keep_mask[topk_indices] = True
```
- 保留置信度最高的K个预测
- 与阈值策略结合使用

---

## 5. 代码实现详解

### 5.1 核心类结构

```python
@MODELS.register_module()
class SARRNTRHead(ARRNTRHead):
    def __init__(self,
                 # NAR推理控制
                 nar_infer: bool = False,
                 nar_max_len: int = None,
                 # NAR-MLM训练控制
                 nar_mlm_train: bool = False,
                 nar_mask_ratio: float = 0.9,
                 nar_iters: int = 1,
                 nar_conf_thresh: float = 0.5,
                 nar_keep_ratio: float = 0.0,
                 **kwargs):
        
        # NAR控制参数
        self.nar_infer = bool(nar_infer)
        self.nar_max_len = None if nar_max_len is None else int(nar_max_len)
        self.nar_mlm_train = bool(nar_mlm_train)
        self.nar_mask_ratio = float(nar_mask_ratio)
        self.nar_iters = max(1, int(nar_iters))
        self.nar_conf_thresh = float(nar_conf_thresh)
        self.nar_keep_ratio = float(nar_keep_ratio)
        
        # 特殊token
        self.no_known = 575  # padding/unknown token
        self.start = 574     # START token
        self.end = 573       # END token
```

### 5.2 训练时的MLM处理

```python
# 在SAR_RNTR.forward_pts_train()中
def forward_pts_train(self, bev_feats, gt_lines_coords, ...):
    # 构建输入和输出序列
    input_seqs = build_input_sequences(gt_lines_coords, ...)
    output_seqs = build_output_sequences(gt_lines_coords, ...)
    
    # NAR-MLM训练
    if self.nar_mlm_train:
        input_seqs, output_seqs = apply_mlm_masking(
            input_seqs, output_seqs, 
            mask_ratio=self.nar_mask_ratio
        )
    
    # 前向传播
    outputs_logits = self.pts_bbox_head(bev_feats, input_seqs, img_metas)
    
    # 计算损失
    losses = compute_losses(outputs_logits, output_seqs)
    
    return losses
```

### 5.3 推理时的迭代优化

```python
# 在SARRNTRHead.forward()中
def forward(self, mlvl_feats, input_seqs, img_metas):
    if self.training:
        # 训练模式：使用MLM
        return self._forward_training(mlvl_feats, input_seqs, img_metas)
    else:
        # 推理模式：使用NAR迭代优化
        if self.nar_infer:
            return self._forward_nar_inference(mlvl_feats, input_seqs, img_metas)
        else:
            return self._forward_ar_inference(mlvl_feats, input_seqs, img_metas)
```

---

## 6. 配置和训练流程

### 6.1 两阶段训练策略

#### **阶段1：SAR预训练**
```python
# configs/rntr_sar_roadseq/lss_sar_pretrain_for_nar.py
model = dict(
    pts_bbox_head=dict(
        nar_mlm_train=False,   # 纯SAR训练
        nar_infer=False,       # 使用AR推理
    )
)
max_epochs = 300
```

#### **阶段2：NAR微调**
```python
# configs/rntr_sar_roadseq/lss_nar_finetune_from_sar.py
model = dict(
    pts_bbox_head=dict(
        nar_mlm_train=True,      # 启用NAR-MLM训练
        nar_mask_ratio=0.9,      # 90% mask比例
        nar_infer=True,          # 使用NAR推理
        nar_iters=3,             # 3次迭代
        nar_conf_thresh=0.55,    # 置信度阈值
        nar_keep_ratio=0.2,      # Top-K保留比例
    )
)
max_epochs = 500
load_from = 'work_dirs/sar_pretrain/latest.pth'  # 必须加载SAR权重
```

### 6.2 训练命令

```bash
# 阶段1：SAR预训练
python tools/train.py configs/rntr_sar_roadseq/lss_sar_pretrain_for_nar.py

# 阶段2：NAR微调
python tools/train.py configs/rntr_sar_roadseq/lss_nar_finetune_from_sar.py \
    --cfg-options load_from='work_dirs/sar_pretrain/latest.pth'
```

### 6.3 配置参数详解

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `nar_mlm_train` | False | 是否启用MLM训练 |
| `nar_mask_ratio` | 0.9 | MLM mask比例 |
| `nar_infer` | False | 是否使用NAR推理 |
| `nar_iters` | 1 | 迭代次数 |
| `nar_conf_thresh` | 0.5 | 置信度阈值 |
| `nar_keep_ratio` | 0.0 | Top-K保留比例 |

---

## 7. 性能分析

### 7.1 时间复杂度对比

| 方法 | 时间复杂度 | 并行度 | 推理速度 |
|------|------------|--------|----------|
| AR | O(n) | 无 | 慢 |
| SAR | O(αn) | 部分 | 中等 |
| NAR | O(α·N_iter) | 完全 | 快 |

其中：
- n：序列长度
- α：GPU并行加速比
- N_iter：迭代次数（通常3-5次）

### 7.2 加速比分析

根据论文，NAR的加速比为：
$$\frac{|\mathcal{E}| / |\mathcal{V}_{kp}|+1}{N_{iter} + 1}$$

假设：
- |E| = 1000（边数）
- |V_kp| = 50（关键点数）
- N_iter = 3

则加速比 = (1000/50 + 1) / (3 + 1) = 21/4 ≈ 5.25x

### 7.3 质量vs速度权衡

```python
# 不同配置的性能权衡
configs = {
    'high_quality': {
        'nar_iters': 5,
        'nar_conf_thresh': 0.7,
        'nar_keep_ratio': 0.3
    },
    'balanced': {
        'nar_iters': 3,
        'nar_conf_thresh': 0.5,
        'nar_keep_ratio': 0.2
    },
    'high_speed': {
        'nar_iters': 1,
        'nar_conf_thresh': 0.3,
        'nar_keep_ratio': 0.1
    }
}
```

---

## 8. 常见问题解答

### Q1: 为什么需要两阶段训练？
**A**: 
- **阶段1**：学习基本的序列生成能力（SAR）
- **阶段2**：学习并行预测和迭代优化（NAR）
- 直接训练NAR很困难，需要先有好的基础模型

### Q2: MLM的mask比例为什么是90%？
**A**: 
- 遵循BERT的设置，证明有效
- 高mask比例迫使模型学习更强的上下文理解
- 提高模型对部分信息的鲁棒性

### Q3: 迭代次数如何选择？
**A**: 
- **1-2次**：快速推理，质量一般
- **3-5次**：平衡质量和速度（推荐）
- **5+次**：高质量，但速度提升有限

### Q4: 置信度阈值如何调优？
**A**: 
- **0.3-0.4**：激进，保留更多预测
- **0.5-0.6**：平衡（推荐）
- **0.7+**：保守，只保留高置信度预测

### Q5: NAR比SAR快多少？
**A**: 
- 理论上：完全并行，速度提升显著
- 实际中：受GPU并行度限制
- 典型提升：3-10倍，取决于序列长度

### Q6: 如何处理生成质量下降？
**A**: 
1. 增加迭代次数
2. 提高置信度阈值
3. 使用更大的模型
4. 改进训练策略

### Q7: 可以只用NAR不用SAR吗？
**A**: 
- 理论上可以，但效果通常较差
- SAR提供了重要的中间表示
- 两阶段训练更稳定

---

## 总结

NAR-RNTR通过以下创新实现了高效的道路网络生成：

1. **MLM训练**：学习并行预测能力
2. **迭代优化**：模拟自回归的逐步细化
3. **置信度策略**：平衡质量和速度
4. **两阶段训练**：稳定的训练流程

NAR在保持生成质量的同时，显著提升了推理速度，是自动驾驶场景中道路网络生成的重要技术突破。

---

*本文档详细解释了NAR-RNTR的理论基础和代码实现，帮助读者理解非自回归生成在道路网络建模中的应用。*
