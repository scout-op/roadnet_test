# AR-RNTR 文件调用关系图

## 1. 训练时的文件调用顺序

```
1. 配置文件
   configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py
   └─ 定义模型、数据集、pipeline

2. 训练启动（mmdetection3d框架）
   tools/train.py
   └─ 读取配置
   └─ 初始化模型 AR_RNTR

3. 数据加载
   rntr/centerline_nuscenes_dataset.py
   └─ CenterlineNuScenesDataset.__init__()
      └─ load_annotations() 读取.pkl文件
   └─ CenterlineNuScenesDataset.__getitem__()
      └─ 应用 pipeline

4. Pipeline 处理
   rntr/transforms/loading.py
   ├─ OrgLoadMultiViewImageFromFiles  # 加载6张图像
   ├─ ResizeCropFlipImage             # 图像预处理
   ├─ LoadNusOrderedBzCenterline      # 加载中心线
   ├─ CenterlineFlip                  # 数据增强
   ├─ CenterlineRotateScale           # 数据增强
   └─ TransformOrderedBzLane2Graph    # 图→序列转换 ⭐

5. 批量加载
   PyTorch DataLoader
   └─ 组装 batch

6. 模型前向
   rntr/ar_rntr.py
   └─ AR_RNTR.loss(inputs, data_samples)
      ├─ extract_feat(img, img_metas)
      │  ├─ extract_img_feat()
      │  │  ├─ img_backbone (ResNet50)
      │  │  └─ img_neck (FPN)
      │  └─ view_transformers (LiftSplatShootEgo) ⭐
      │     └─ rntr/LiftSplatShoot.py
      │
      └─ forward_pts_train() ⭐
         ├─ 构造训练序列（正负样本）
         ├─ pts_bbox_head.forward()
         │  └─ rntr/ar_rntr_head.py
         │     └─ ARRNTRHead.forward()
         │        ├─ embedding (token嵌入)
         │        ├─ transformer (解码器)
         │        │  └─ rntr/transformer/
         │        └─ vocab_embed (词表投影)
         │
         ├─ 按子句切片logits
         ├─ 过滤no_known
         └─ pts_bbox_head.loss_by_feat()
            └─ 计算4个CE损失

7. 反向传播
   PyTorch Autograd
   └─ loss.backward()

8. 优化器更新
   AdamW
   └─ optimizer.step()
```

## 2. 推理时的文件调用顺序

```
1. 推理启动
   tools/test.py
   └─ 加载模型权重

2. 模型推理
   rntr/ar_rntr.py
   └─ AR_RNTR.predict(batch_inputs_dict, batch_data_samples)
      └─ simple_test(img_metas, img)
         ├─ extract_feat() # 同训练
         │
         └─ simple_test_pts(bev_feats, img_metas) ⭐
            ├─ 初始化 input_seqs = [[START]]
            │
            ├─ pts_bbox_head.forward() # 推理模式
            │  └─ rntr/ar_rntr_head.py
            │     └─ ARRNTRHead.forward() (else分支)
            │        └─ 自回归循环 (600次)
            │           ├─ embedding
            │           ├─ transformer
            │           ├─ vocab_embed
            │           ├─ softmax + top-1
            │           └─ 追加到序列
            │
            └─ 后处理
               ├─ 去掉[START]
               ├─ 截断到[END]
               ├─ Token ID还原
               └─ 合法性修正

3. 结果保存/评估
   rntr/nuscenes_reach_metric.py
   └─ 计算评估指标
```

## 3. 核心文件详解

### 3.1 模型文件

| 文件 | 类/函数 | 作用 |
|------|---------|------|
| `rntr/ar_rntr.py` | `AR_RNTR` | 主模型类，组装各个模块 |
| | `extract_feat()` | BEV特征提取 |
| | `forward_pts_train()` | 训练前向（构造序列+计算loss） |
| | `simple_test_pts()` | 推理（自回归生成+后处理） |
| `rntr/ar_rntr_head.py` | `ARRNTRHead` | 解码器头 |
| | `forward()` | 训练/推理的Transformer解码 |
| | `loss_by_feat()` | 计算4个CE损失 |
| `rntr/LiftSplatShoot.py` | `LiftSplatShootEgo` | 图像→BEV投影 |

### 3.2 数据文件

| 文件 | 类/函数 | 作用 |
|------|---------|------|
| `rntr/centerline_nuscenes_dataset.py` | `CenterlineNuScenesDataset` | 数据集类 |
| `rntr/transforms/loading.py` | `LoadNusOrderedBzCenterline` | 加载中心线 |
| | `TransformOrderedBzLane2Graph` | 图→序列转换 |
| | `LoadSDMapSeqPrompt` | 加载SD-Map提示（AR不用） |

### 3.3 配置文件

| 文件 | 作用 |
|------|------|
| `configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py` | AR模型配置 |
| `configs/_base_/datasets/nus-3d.py` | nuScenes数据集基础配置 |
| `configs/_base_/default_runtime.py` | 训练运行时配置 |

### 3.4 Transformer 文件

| 文件 | 类 | 作用 |
|------|-----|------|
| `rntr/transformer/lss_seq_line_transformer.py` | `LssSeqLineTransformer` | AR解码器 |
| `rntr/transformer/petr_transformer.py` | `PETRTransformerLineDecoder` | Transformer层堆叠 |
| `rntr/transformer/petr_transformer.py` | `PETRLineTransformerDecoderLayer` | 单层Transformer |

## 4. 数据流图（可视化）

```mermaid
graph TD
    A[配置文件] --> B[数据集]
    B --> C[Pipeline]
    C --> D[DataLoader]
    D --> E[AR_RNTR]
    E --> F[extract_feat]
    F --> G[BEV特征]
    G --> H[forward_pts_train]
    H --> I[ARRNTRHead]
    I --> J[Transformer]
    J --> K[Logits]
    K --> L[Loss计算]
    L --> M[反向传播]
```

## 5. 重要函数的输入输出

### 5.1 extract_feat
```python
输入:
  img: [B, 6, 3, 128, 352]
  img_metas: list of dict

输出:
  bev_feats: [B, 256, 200, 200]
```

### 5.2 forward_pts_train
```python
输入:
  bev_feats: [B, 256, 200, 200]
  gt_lines_coords: list of list (每个样本的坐标)
  gt_lines_labels: list of list (每个样本的标签)
  gt_lines_connects: list of list (每个样本的连接)
  gt_lines_coeffs: list of list (每个样本的系数)
  img_metas: list of dict
  num_coeff: int (=1 when n_control=3)

输出:
  losses: dict {
    'loss_coords': Tensor,
    'loss_labels': Tensor,
    'loss_connects': Tensor,
    'loss_coeffs': Tensor
  }
```

### 5.3 ARRNTRHead.forward (训练)
```python
输入:
  mlvl_feats: [B, 256, 200, 200]
  input_seqs: [B, T]
  img_metas: list of dict

输出:
  out: [num_layers, B, T, 576]
```

### 5.4 ARRNTRHead.forward (推理)
```python
输入:
  mlvl_feats: [B, 256, 200, 200]
  input_seqs: [B, 1] (只有[START])
  img_metas: list of dict

输出:
  input_seqs: [B, 1+600] (生成的序列)
  values: [B, 600] (置信度)
```

### 5.5 simple_test_pts
```python
输入:
  pts_feats: [B, 256, 200, 200]
  img_metas: list of dict

输出:
  line_results: list of Tensor
    每个Tensor: [N_nodes * clause_length]
```

---

## 6. 关键变量说明

| 变量名 | 含义 | 典型值 |
|--------|------|--------|
| `B` | Batch大小 | 2 |
| `T` | 序列长度 | 训练:301, 推理:1→601 |
| `D` / `embed_dims` | 特征维度 | 256 |
| `H, W` | BEV高度/宽度 | 200, 200 |
| `V` / `num_center_classes` | 词表大小 | 576 |
| `clause_length` | 子句长度 | 6 (当n_control=3) |
| `num_coeff` | 系数数量 | 1 (n_control-2) |
| `coeff_dim` | 系数维度 | 2 (num_coeff*2) |
| `n_control` | 贝塞尔控制点数 | 3 |
| `max_iteration` | 推理最大步数 | 600 |

---

下一步：开始逐行注释代码！
