# AR-RNTR 潜在问题全面分析与建议

根据你的训练配置与代码审查，本文档列出所有潜在问题、已修复的改进、以及训练建议。

---

## 训练配置分析

你的训练命令：
```bash
SWANLAB_ENABLE=1 ./tools/dist_train.sh \
  ./projects/RoadNetwork/configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py 8 \
  --work-dir ./work_dirs/arrntr_new \
  --train_dataloader.batch_size=20 \
  --train_dataloader.num_workers=8
```

- **8 卡分布式训练** + **batch_size=20** → 每卡约 2.5 个样本（20/8 = 2.5）
- **AMP (FP16)** 启用：`AmpOptimWrapper` + `loss_scale='dynamic'`
- **freeze_pretrain=False**：所有参数都会训练
- **SwanLab 实时可视化** 启用

---

## ✅ 已修复的问题（刚才的改动）

### 1. 分布式训练的调试打印混乱
**问题**: 8 个进程同时打印会导致日志交错、难以阅读。

**修复**: 所有 DEBUG 打印现在只在 rank 0 （主进程）执行：
- `rntr/ar_rntr.py` → 使用 `self._is_main_process()` 判断
- `rntr/ar_rntr_head.py` → 使用 `dist.get_rank() == 0` 判断

**影响**: 现在日志清晰、可读，方便定位问题。

---

## ⚠️ 核心潜在问题（需关注）

### 问题 1: AMP 溢出导致 NaN（高概率）

**现象**: 
- `loss = 0.0000` + `grad_norm = nan`
- 很可能是 FP16 混合精度训练时数值溢出

**证据**:
- 配置使用 `AmpOptimWrapper(loss_scale='dynamic')`
- `ARRNTRHead.forward()` 中有 `torch.nan_to_num(outs_dec)`（line 452, 462）
- 损失计算后也做了 `torch.nan_to_num(loss_*)`（line 582-585）

**为何导致全0**:
1. Transformer 前向计算时产生 NaN/Inf（FP16 表示范围有限）
2. `nan_to_num` 把 NaN 变成 0，导致 logits 失效
3. CrossEntropy 对全0/常数 logits 返回 NaN
4. 再次 `nan_to_num` 变成 0
5. 梯度中仍含 NaN，所以 `grad_norm = nan`

**验证方法**:
- 看 DEBUG 3 输出的 `finite ratio`，若 < 1.0 则确认是 AMP 问题

**解决方案**:
1. **临时禁用 AMP**（推荐第一步）：
   - 在配置中修改：
     ```python
     optim_wrapper = dict(
         type='OptimWrapper',  # 从 AmpOptimWrapper 改为 OptimWrapper
         optimizer=dict(type='AdamW', lr=2e-4, weight_decay=0.01),
         clip_grad=dict(max_norm=35, norm_type=2)
     )
     ```
   - 训练几百个 iter 验证 loss 是否恢复正常

2. **若必须用 AMP**（显存受限）：
   - 降低学习率：`lr=2e-4 → 1e-4`
   - 添加梯度裁剪保护（已有 `clip_grad`，但对 NaN 无效）
   - 检查 BEV 特征的数值范围，可能需要归一化

---

### 问题 2: 空监督分支导致 NaN

**现象**: 某些 batch 中所有样本都没有正节点（sparse 数据集常见）

**后果**:
- `coords/connects/coeffs` 分支过滤后为空
- CrossEntropy 对空张量返回 NaN
- `nan_to_num` 变成 0

**期望**:
- 即使 coords/connects/coeffs 为空，`labels` 分支必须有监督（来自负样本的 `noise_label=571`）
- 若 `labels` 也为空 → **代码逻辑错误**

**验证方法**:
- 看 DEBUG 5 是否有 "labels branch is EMPTY" 警告
- 若有，检查 DEBUG 4 的 `mask_cls sum`（应该 > 0）

**可能原因**:
- `self.no_known=575` 与 `self.noise_label=571` 未正确初始化
- 切分逻辑错误，`inputs_cls_i` 全被标记为 `no_known`
- `valid_len` 计算错误导致长度为 0

**修复**:
- 若 `labels` 确实为空，添加保护逻辑：
  ```python
  if outputs_cls.numel() == 0:
      # 为避免 NaN，返回一个小的默认 loss
      loss_labels = outputs_logits.new_tensor(0.0)
  else:
      loss_labels = self.loss_labels(outputs_cls, inputs_cls)
  ```
- 但根本解决是找出为何 `noise_label` 没有进入 `mask_cls`

---

### 问题 3: `nan_to_num` 掩盖真实问题

**现状**:
- `ARRNTRHead.forward()` line 452: `outs_dec = torch.nan_to_num(outs_dec)`
- `ARRNTRHead.loss_by_feat_single()` line 582-585: 对四个 loss 都做 `nan_to_num`

**后果**:
- NaN 被静默转为 0，训练继续但无意义
- 日志显示 `loss=0`，但不知道是"空监督"还是"NaN 被掩盖"
- 梯度中的 NaN 无法被清理，导致 `grad_norm=nan`

**建议**:
1. **调试阶段暂时注释掉 `nan_to_num`**（让它快速失败，直接报错指向问题）
2. **生产阶段改为显式空检查**：
   ```python
   if preds_coords.numel() == 0 or gt_coords.numel() == 0:
       loss_coords = preds_coords.new_tensor(0.0)
   else:
       loss_coords = self.loss_coords(preds_coords, gt_coords)
       if torch.isnan(loss_coords):
           # 记录警告但不中断
           print(f"WARNING: loss_coords is NaN! preds shape={preds_coords.shape}, gt shape={gt_coords.shape}")
           loss_coords = preds_coords.new_tensor(0.0)
   ```

---

### 问题 4: 序列长度与配置不匹配

**配置**:
- `max_center_len=601`（序列最大长度）
- `max_box_num=100`（代码中）
- `n_control=3`（数据 pipeline），对应 `num_coeff=1`
- `clause_length = 4 + num_coeff*2 = 6`

**计算**:
- 每个节点占 6 个 token
- 100 个节点 → 600 个 token
- 加上 START/END → 602 个 token
- **超过 `max_center_len=601`！**

**后果**:
- `ARRNTRHead` 的 `embedding` 只支持 601 位置
- 若序列长度 > 601，位置编码会越界或截断
- 可能导致训练不稳定

**修复**:
- 要么增大 `max_center_len` 到 610
- 要么减小 `max_box_num` 到 95（95*6 + 1(START) + 1(END) = 572 < 601）

**推荐**:
```python
# configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py
pts_bbox_head=dict(
    type='ARRNTRHead',
    max_center_len=610,  # 从 601 改为 610
    # 或者在 ar_rntr.py 中把 max_box_num 从 100 改为 95
)
```

---

### 问题 5: 大 batch_size 与小样本数

**配置**: `batch_size=20`，8 卡分布式 → 每卡 2.5 个样本

**问题**:
- 若某些样本没有 GT（数据缺失），实际每卡样本数可能 < 2
- 小 batch 下 BatchNorm/LayerNorm 的统计不稳定
- 梯度累积不足，更新频繁但噪声大

**建议**:
- 若显存充足，改为每卡 4 个样本：`batch_size=32`（8*4）
- 或保持 `batch_size=20`，但启用梯度累积（每 2 步更新一次）

**梯度累积配置**（可选）:
```python
optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='AdamW', lr=2e-4, weight_decay=0.01),
    clip_grad=dict(max_norm=35, norm_type=2),
    accumulative_counts=2  # 累积 2 步后才更新
)
```

---

### 问题 6: END token 检测的稳健性

**当前代码** (`rntr/ar_rntr.py` line 635):
```python
if self.end in pred_line_seq:
    stop_idx = (pred_line_seq == self.end).nonzero(as_tuple=True)[0][0]
```

**问题**:
- `self.end in pred_line_seq` 依赖 Python 对 Tensor 的成员检测
- 部分 PyTorch 版本可能不稳定（返回标量 Tensor 而非 bool）

**推荐改法**:
```python
if (pred_line_seq == self.end).any():
    stop_idx = (pred_line_seq == self.end).nonzero(as_tuple=True)[0][0]
```

**影响**: 推理时更稳定，避免 END 检测失败导致的序列过长。

---

## 🔧 代码改进建议（非紧急）

### 建议 1: 推理时的 token 约束

**当前**: 推理时没有"位置型允许 token 子集"约束，任何位置都可能生成任何 token。

**改进**: 参考 `rntr/ar_lanegraph2seq.py` 的 `build_allowed_*_mask()` 思路，在统一序列上实现：
- 第 `0,6,12,...` 位（x 坐标）只允许 `[0..199]`
- 第 `1,7,13,...` 位（y 坐标）只允许 `[0..199]`
- 第 `2,8,14,...` 位（类别）只允许 `[200..203]`
- 第 `3,9,15,...` 位（连接）只允许 `[250..250+当前节点数]` 或 END
- 第 `4,5,10,11,...` 位（系数）只允许 `[350..549]`

**好处**: 减少非法 token，提高推理鲁棒性。

**代价**: 实现略复杂，需要在 `ARRNTRHead.forward(infer)` 中动态构建 mask。

---

### 建议 2: 提前终止推理循环

**当前**: `ARRNTRHead.forward(infer)` 固定循环 `max_iteration=600` 次。

**改进**: 检测到 END 后立即 break：
```python
for i in range(self.max_iteration):
    tgt = self.embedding(input_seqs.long())
    query_embed = self.embedding.position_embeddings.weight
    outs_dec, _ = self.transformer(tgt, x, masks, query_embed, pos_embed)
    outs_dec = torch.nan_to_num(outs_dec)[-1, :, -1, :]
    out = self.vocab_embed(outs_dec)
    out = out.softmax(-1)
    value, extra_seq = out.topk(dim=-1, k=1)
    
    # 提前终止检查
    if (extra_seq == self.end).any():
        input_seqs = torch.cat([input_seqs, extra_seq], dim=-1)
        break
    
    input_seqs = torch.cat([input_seqs, extra_seq], dim=-1)
    values.append(value)
```

**好处**: 节省推理时间（尤其是短序列场景）。

---

### 建议 3: 更详细的训练日志

**当前**: 只在固定步数打印。

**改进**: 在 SwanLab 中记录更多统计信息（已有部分）：
- `seq_max_box`: 当前 batch 最大节点数
- `seq_avg_box`: 平均节点数
- `mask_*_ratio`: 各分支的有效监督占比
- `logits_finite_ratio`: logits 有限值比例（监控 AMP 稳定性）

---

## 📋 训练前检查清单

在运行训练前，请确认：

- [ ] **禁用 AMP**（至少前几百个 iter）：
  - 将配置中 `AmpOptimWrapper` 改为 `OptimWrapper`
  
- [ ] **修复序列长度溢出**：
  - `max_center_len=610` 或 `max_box_num=95`
  
- [ ] **验证数据 pipeline**：
  - 运行一个 batch，检查 `gt_lines_coords` 是否有数据
  - 确认 `TransformOrderedBzLane2Graph` 输出正确
  
- [ ] **检查预训练权重加载**：
  - `load_from='ckpts/lss_roadseg_48x32_b4x8_resnet_adam_24e_clean.pth'`
  - 确认该权重存在且与当前模型架构兼容
  
- [ ] **确认分布式环境**：
  - 8 卡可见：`CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7`
  - `dist_train.sh` 脚本正确配置

---

## 🚀 推荐的训练流程

### 阶段 1: 快速验证（禁用 AMP，小规模）

```bash
# 配置修改：
# - optim_wrapper.type = 'OptimWrapper'
# - train_dataloader.batch_size = 8  # 每卡 1 个样本
# - max_center_len = 610

SWANLAB_ENABLE=1 ./tools/dist_train.sh \
  ./projects/RoadNetwork/configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py 8 \
  --work-dir ./work_dirs/arrntr_debug \
  --cfg-options train_cfg.max_epochs=1 train_cfg.val_interval=500
```

**目标**: 
- 运行 10~20 个 iter，查看 DEBUG 输出
- 确认 `finite ratio=1.0` 且 `loss > 0`
- 若成功，继续阶段 2

### 阶段 2: 正常训练（可选开启 AMP）

```bash
# 若阶段 1 成功，恢复 AmpOptimWrapper 和正常 batch_size

SWANLAB_ENABLE=1 ./tools/dist_train.sh \
  ./projects/RoadNetwork/configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py 8 \
  --work-dir ./work_dirs/arrntr_new \
  --cfg-options train_dataloader.batch_size=20
```

**目标**: 正常训练 60 epochs

---

## 🔍 调试时的关键日志

运行阶段 1 后，重点关注以下输出：

### 正常情况示例：
```
[AR-RNTR DEBUG] Step 3: Model Output
outputs_logits finite ratio: 1.0000          ← 必须是 1.0
outputs_logits min/max: -12.34 / 8.76        ← 合理范围

[AR-RNTR DEBUG] Step 5: Batch-wide Supervision Counts
  labels: preds=torch.Size([200, 576]), targets=torch.Size([200])  ← 非空
  (无 EMPTY 警告)

[ARRNTRHead DEBUG] Step 8: Raw Loss (before nan_to_num)
  loss_labels: 1.234567, isnan=False          ← 必须 False
```

### 异常情况（需修复）：
```
[AR-RNTR DEBUG] Step 3: Model Output
outputs_logits finite ratio: 0.8523          ← AMP 溢出！
  WARNING: outputs_logits contains NaN!

[AR-RNTR DEBUG] Step 5: Batch-wide Supervision Counts
    labels branch is EMPTY                    ← 逻辑错误！

[ARRNTRHead DEBUG] Step 8: Raw Loss (before nan_to_num)
  loss_labels: nan, isnan=True                ← 上游问题或空监督
```

---

## 📊 预期训练曲线

正常情况下（修复 AMP 后），你应该看到：

- **前 100 iter**: 
  - loss 从随机初始值（~6.0）快速下降到 ~3.0
  - grad_norm 稳定在 10~50 范围
  
- **前 1000 iter**:
  - loss 持续下降到 ~1.5
  - 各分支 loss 比例：`labels > coords > coeffs > connects`
  
- **收敛**:
  - 最终 loss 应在 0.5~1.0（取决于数据集难度）
  - 若 loss 卡在 >2.0，检查数据增强、学习率、或模型容量

---

## 💡 最终建议优先级

按紧急程度排序：

1. **🔴 立即修复**: 
   - 禁用 AMP（改用 FP32 验证）
   - 修复 `max_center_len` 溢出

2. **🟡 尽快修复**:
   - 检查 `labels` 分支是否真的有监督（看 DEBUG 5）
   - 改进 END token 检测（用 `.any()` 而非 `in`）

3. **🟢 可选改进**:
   - 添加推理 token 约束
   - 提前终止推理循环
   - 注释掉 `nan_to_num`（调试阶段）

---

## 📞 如果仍有问题

运行阶段 1 训练后，请提供：
1. **前 2~3 个 iteration 的完整 DEBUG 输出**（8 个调试块）
2. **mmengine 日志**中的 loss/grad_norm
3. **任何报错信息**

我会根据实际输出精准定位问题。祝训练顺利！
