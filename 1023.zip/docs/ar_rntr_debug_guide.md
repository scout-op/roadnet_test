# AR-RNTR 全流程调试指南

本文档说明为 AR-RNTR 训练流程添加的调试打印点，以及如何解读输出来定位"loss全为0、grad_norm=nan"的根因。

---

## 添加的调试点概览

已在以下两个文件中添加 **8 个调试检查点**：

### 文件 1: `rntr/ar_rntr.py` → `AR_RNTR.forward_pts_train()`

- **DEBUG 1: GT 输入数据检查**
  - 打印每个样本的 GT 节点数量（coords/labels/connects/coeffs）
  - 展示第一个坐标/标签值
  - 显示关键 token 常量（start/end/no_known/noise_label）

- **DEBUG 2: 序列构造检查**
  - 打印 `input_seqs`、`output_seqs` 的形状与前10个token
  - 检查 END token 在监督序列中的位置
  - 显示 max_box、num_box、clause_length

- **DEBUG 3: 模型输出检查**
  - 打印 Transformer 输出 `outputs_logits` 的形状
  - **关键指标**: finite ratio（有限值比例）、min/max
  - 检测 NaN/Inf（若有，说明前向传播已产生非法值）

- **DEBUG 4: 单样本监督切分检查**（仅第一个样本）
  - 展示 END 移除后、clause 对齐后的长度
  - 打印四个分支（coords/labels/connects/coeffs）的监督数量
  - **关键**: 打印各分支 mask 后的有效样本数（`mask_*` sum）
  - 显示 `inputs_cls_i` 的 unique 值（确认是否含噪声标签571）

- **DEBUG 5: 全局监督拼接检查**
  - 打印 batch 内所有样本拼接后的监督数量
  - **关键判断**: 若某分支 `numel()==0`，会明确警告"EMPTY"
  - 显示 `inputs_cls` 的范围与 unique（确认不为空）

- **DEBUG 6: 最终损失值**
  - 打印 `loss_by_feat` 返回的各分支损失
  - 显示每个损失是否 finite

### 文件 2: `rntr/ar_rntr_head.py` → `ARRNTRHead.loss_by_feat_single()`

- **DEBUG 7: Loss 计算前的输入检查**
  - 打印传入 CE 的 preds 和 targets 形状
  - 检查 preds 是否 finite（若不是，说明 logits 已含 NaN）
  - 显示 targets 的范围与 unique

- **DEBUG 8: 原始损失（nan_to_num 前后对比）**
  - **关键**: 打印 CE 输出的原始 loss，标记是否为 NaN/Inf
  - 对比 `nan_to_num` 前后的值
  - **若原始 loss 为 NaN**，说明是"空监督"或"targets 超出词表范围"

---

## 如何使用调试输出定位问题

运行训练后，查看打印的 8 个调试块，按以下逻辑排查：

### 步骤 1: 检查 DEBUG 1（GT 输入）
- **期望**: 每个样本至少有几个节点（coords/labels/connects/coeffs 长度 > 0）
- **异常**: 若全为 0，说明数据 pipeline（`LoadNusOrderedBzCenterline` / `TransformOrderedBzLane2Graph`）没有输出有效 GT

### 步骤 2: 检查 DEBUG 2（序列构造）
- **期望**: 
  - `input_seqs` 第一个元素是 `start=574`
  - `output_seqs` 在正样本后应有一个 `end=573`
  - END token 位置应在 `[len(正样本clauses)]` 左右
- **异常**: 若 END 位置不对或缺失，检查 `forward_pts_train()` 中的拼接逻辑

### 步骤 3: 检查 DEBUG 3（模型输出）
- **期望**: 
  - `finite ratio = 1.0000`（所有 logits 都是有限值）
  - min/max 在合理范围（如 -50 ~ +50）
- **异常**: 
  - `finite ratio < 1.0` → **模型前向已产生 NaN/Inf**，多见于 AMP 溢出
  - 此时无论监督是否正确，梯度都会是 NaN

### 步骤 4: 检查 DEBUG 4（单样本切分）
- **关键字段**: `mask_* sum`（每个分支的有效监督数）
- **期望**:
  - `mask_pos sum` 可能为 0（若当前样本没有正节点）
  - `mask_cls sum` **必须 > 0**（因为负样本用 `noise_label=571`，不等于 `no_known=575`）
  - `mask_conn sum` 可能为 0（负样本的 connect 是 `no_known`）
  - `mask_coeff sum` 可能为 0（同理）
- **异常**:
  - 若 `mask_cls sum = 0`，说明 `inputs_cls_i` 被错误地标记为 `no_known=575`，或切分逻辑有误
  - 查看 `inputs_cls_i unique`，应该包含 `[200~203, 571]`（类别 + 噪声标签）

### 步骤 5: 检查 DEBUG 5（全局拼接）
- **关键**: 是否有"EMPTY"警告
- **期望**: `labels branch` 不应为空（即使所有样本都没有正节点，负样本的 noise_label 仍会提供监督）
- **异常**:
  - 若 `labels branch is EMPTY` → 说明所有样本的 `mask_cls` 都是 0，需回到 DEBUG 4 逐样本检查

### 步骤 6: 检查 DEBUG 8（原始损失 vs nan_to_num 后）
- **关键**: 对比"before nan_to_num"与"After nan_to_num"
- **期望**: 
  - 若某分支监督为空（如 `coords branch is EMPTY`），原始 loss 为 `nan`，清理后为 `0.0000` → **这是正常的**
  - 但 `loss_labels` 原始值应该 > 0（因为有负样本噪声标签）
- **异常**:
  - 若 `loss_labels` 也是 `nan → 0`，说明：
    - 要么 `inputs_cls` 为空（见 DEBUG 5）
    - 要么 `inputs_cls` 值超出词表范围 `[0, 575]`（CE 会报错或返回 NaN）
    - 要么 `preds_labels` 已经是 NaN（见 DEBUG 7）

---

## 常见问题与对策

### 问题 1: DEBUG 3 显示 `finite ratio < 1.0`（模型输出含 NaN）
- **原因**: AMP 溢出、BEV 特征异常、Transformer 内部梯度爆炸
- **对策**:
  1. **禁用 AMP**：在配置中把 `AmpOptimWrapper` 改为 `OptimWrapper`，重新训练几百个 iter
  2. 检查 BEV 特征：在 `extract_feat()` 后打印 `bev_feats` 的统计信息
  3. 降低学习率（如 `2e-4 → 1e-4`）

### 问题 2: DEBUG 5 显示 `labels branch is EMPTY`
- **原因**: 切分/掩码逻辑错误，导致 `mask_cls` 全为 0
- **对策**:
  1. 检查 `self.no_known=575` 与 `self.noise_label=571` 是否正确初始化
  2. 打印 `inputs_cls_i` 的所有值，确认是否有 571（噪声标签）
  3. 确认 `valid_len = (labels_i.numel() // clause_length) * clause_length` 不会变成 0

### 问题 3: DEBUG 8 显示 `loss_labels` 原始值为 NaN
- **原因**: 
  - `inputs_cls` 包含超出词表 `[0, 575]` 的值
  - 或 `preds_labels` 已经是 NaN
- **对策**:
  1. 在 DEBUG 7 检查 `gt_labels unique`，确保所有值在 `[0, 575]`
  2. 检查 `preds_labels finite` 是否为 True
  3. 若 `preds_labels` 不 finite，回到问题 1（AMP 溢出）

### 问题 4: 所有分支原始 loss 都是 NaN
- **原因**: `outputs_logits` 本身全是 NaN（见 DEBUG 3）
- **对策**: 这是上游问题，按问题 1 处理

---

## 快速诊断流程图

```
开始
  │
  ├─> DEBUG 3: finite ratio < 1.0?
  │     └─> YES → AMP 溢出/模型输出异常 → 禁用 AMP 重试
  │     └─> NO  → 继续
  │
  ├─> DEBUG 5: labels branch EMPTY?
  │     └─> YES → 切分逻辑错误/掩码问题 → 检查 mask_cls 与 noise_label
  │     └─> NO  → 继续
  │
  ├─> DEBUG 8: loss_labels 原始值 NaN?
  │     └─> YES → targets 超范围 或 preds 异常 → 检查 DEBUG 7
  │     └─> NO  → 继续
  │
  └─> 其他分支 loss=0 但 labels>0
        └─> 正常：coords/connects/coeffs 在无正样本时为空
            → 检查数据集是否有足够正样本（DEBUG 1）
```

---

## 临时调试选项（可选）

### A. 暂时禁用 `nan_to_num`（仅调试用）
在 `rntr/ar_rntr_head.py` → `loss_by_feat_single()` 中，注释掉：
```python
# loss_coords = torch.nan_to_num(loss_coords)
# loss_labels = torch.nan_to_num(loss_labels)
# loss_connects = torch.nan_to_num(loss_connects)
# loss_coeffs = torch.nan_to_num(loss_coeffs)
```
这样训练会在第一次遇到 NaN 时立即崩溃，并报错指向具体分支。

### B. 添加梯度检查钩子
在 `rntr/ar_rntr.py` → `AR_RNTR.__init__()` 末尾添加：
```python
def check_grad_hook(module, grad_input, grad_output):
    for i, g in enumerate(grad_output):
        if g is not None and not torch.isfinite(g).all():
            print(f"[GRAD NaN] {module.__class__.__name__} grad_output[{i}] contains NaN/Inf")
            
self.pts_bbox_head.register_full_backward_hook(check_grad_hook)
```
这会在反向传播时定位哪个模块首先产生 NaN 梯度。

---

## 预期的正常输出示例

当训练正常时，DEBUG 输出应类似：

```
================================================================================
[AR-RNTR DEBUG] Step 1: GT Input Data
================================================================================
Batch size: 2
  Sample 0: coords=24, labels=12, connects=12, coeffs=12
    First coord: [45, 67], First label: 1
  Sample 1: coords=18, labels=9, connects=9, coeffs=9
    First coord: [52, 81], First label: 0
num_coeff: 1
Token constants: start=574, end=573, no_known=575, noise_label=571

================================================================================
[AR-RNTR DEBUG] Step 2: Sequence Construction
================================================================================
max_box: 12, num_box: 100, coeff_dim: 2
clause_length: 6
input_seqs shape: torch.Size([2, 601])
output_seqs shape: torch.Size([2, 601])
input_seqs[0][:10]: [574, 45, 67, 201, 250, 350, ...]
output_seqs[0][:10]: [45, 67, 201, 250, 350, 351, ...]
  Sample 0: END token at positions [73]
  Sample 1: END token at positions [55]

================================================================================
[AR-RNTR DEBUG] Step 3: Model Output
================================================================================
outputs_logits shape: torch.Size([2, 600, 576])
outputs_logits finite ratio: 1.0000
outputs_logits min/max: -12.3456 / 8.7654

================================================================================
[AR-RNTR DEBUG] Step 4: Sample 0 Supervision Slicing
================================================================================
  labels_i numel (after END removal): 600
  valid_len (aligned to clause): 600
  clause_length: 6
  num_clauses: 100
  inputs_pos_i: numel=200, unique=[45, 67, 52, 81, ..., 575, 575, ...]
  inputs_cls_i: numel=100, unique=[200, 201, 202, 571, 571, ...]
  inputs_conn_i: numel=100, unique=[250, 251, ..., 575, 575, ...]
  inputs_coeffs_i: numel=200
  mask_pos sum: 24    # 12个正节点 * 2坐标
  mask_cls sum: 100   # 12正 + 88负（噪声标签571）
  mask_conn sum: 12   # 只有正节点的连接
  mask_coeff sum: 24  # 12正 * 2系数

================================================================================
[AR-RNTR DEBUG] Step 5: Batch-wide Supervision Counts
================================================================================
  coords: preds=torch.Size([42, 576]), targets=torch.Size([42])
  labels: preds=torch.Size([200, 576]), targets=torch.Size([200])
  connects: preds=torch.Size([21, 576]), targets=torch.Size([21])
  coeffs: preds=torch.Size([42, 576]), targets=torch.Size([42])
  inputs_cls range: min=200, max=571
  inputs_cls unique (first 20): [200, 201, 202, 571]

  Checking for empty branches (will cause NaN):
  (无输出 → 所有分支非空)

================================================================================
[AR-RNTR DEBUG] Step 6: Final Losses
================================================================================
  loss_coords: 2.345678 (finite=True)
  loss_labels: 1.234567 (finite=True)
  loss_connects: 3.456789 (finite=True)
  loss_coeffs: 2.987654 (finite=True)
```

---

## 下一步行动

1. **运行训练**，观察前几个 iteration 的 DEBUG 输出
2. **对照上述"快速诊断流程图"**，定位具体问题点
3. **根据对策建议修复**（优先禁用 AMP 验证）
4. 修复后可选择性**注释掉调试打印**（或设置环境变量控制），避免日志过多

---

## 补充说明

- 所有调试打印都在主训练循环的 `forward_pts_train()` 和 `loss_by_feat_single()` 中，每个 iteration 都会触发
- 若日志量过大，可在代码中添加步数判断：`if self._global_step % 10 == 0: print(...)`
- 调试完成后，建议保留 DEBUG 1/3/5/8（最关键的4个），移除其他细节打印

祝调试顺利！若发现新问题，请提供 DEBUG 输出的前几个 iteration 日志以便进一步分析。
