# AR-RNTR 潜在问题全面审查报告

**审查日期：** 2024-10-22 23:04  
**审查范围：** 深度检查可能被忽略的潜在问题

---

## 🔴 严重问题（Critical - 需立即修复）

### ❌ 问题1：num_center_classes 硬编码不一致（严重！）

**位置：** `ar_rntr.py` 行92

**代码：**
```python
self.num_center_classes = 576  # ❌ 硬编码为576
```

**问题分析：**

1. **配置文件已改为574：**
   ```python
   # configs/*.py
   num_center_classes = 574  # Aligned with paper Table (0-573)
   ```

2. **模型Layer实际也是574：**
   ```python
   # ar_rntr_head.py
   self.embedding = PryDecoderEmbeddings(num_center_classes, ...)  # 574
   self.vocab_embed = MLP(..., num_center_classes, ...)  # 574
   ```

3. **但AR_RNTR自己硬编码了576：**
   ```python
   # ar_rntr.py 行92
   self.num_center_classes = 576  # ❌ 不一致！
   ```

**影响范围：**

搜索代码中使用 `self.num_center_classes` 的地方：
```python
# ar_rntr.py 行602-612（损失计算中的fallback tensor）
outputs_pos = torch.cat(...) if len(...) else outputs_logits.new_zeros((0, self.num_center_classes))
outputs_cls = torch.cat(...) if len(...) else outputs_logits.new_zeros((0, self.num_center_classes))
outputs_connects = torch.cat(...) if len(...) else outputs_logits.new_zeros((0, self.num_center_classes))
outputs_coeffs = torch.cat(...) if len(...) else outputs_logits.new_zeros((0, self.num_center_classes))
#                                                                              ↑ 如果走到这里，会创建576列的tensor
#                                                                              但实际vocab只有574！
```

**潜在后果：**
- ⚠️ 如果某个batch的某个slot为空（极端情况），会创建 `(0, 576)` 的tensor
- ⚠️ 与Head输出的 `(N, 574)` 维度不匹配
- ⚠️ 可能导致 `shape mismatch` 错误或隐藏的维度错误

**严重程度：🔴 高**  
**发生概率：🟡 中等**（只有在特定batch出现空slot时才触发）

**建议修复：**
```python
# 方案A：从配置读取（推荐）
def __init__(self, ..., num_center_classes=None, ...):
    # ...
    # 从pts_bbox_head获取实际的词表大小
    if num_center_classes is not None:
        self.num_center_classes = int(num_center_classes)
    else:
        # fallback
        self.num_center_classes = 576

# 方案B：从embedding层推断
# 在init末尾
if hasattr(self, 'pts_bbox_head') and hasattr(self.pts_bbox_head, 'embedding'):
    self.num_center_classes = int(self.pts_bbox_head.embedding.num_embeddings)
```

---

## 🟡 中等问题（Medium - 建议修复）

### ⚠️ 问题2：随机噪声token的范围可能不正确

**位置：** `ar_rntr.py` 行414-425

**代码：**
```python
# 生成随机噪声padding
random_box = torch.rand(num_box - box_label.shape[0], 2).to(device)
random_box = (random_box * (self.box_range - 1)).int()  # [0, 199]

random_label = torch.randint(0, self.num_classes, (...)).to(label)
random_label = random_label + self.category_start  # [200, 203]

random_connect = torch.randint(0, num_box, (...)).to(label)
random_connect = random_connect + self.connect_start  # [250, 250+num_box]

random_coeff = torch.randint(0, self.coeff_range, (...)).to(label)
random_coeff = random_coeff + self.coeff_start  # [350, 350+coeff_range]
```

**问题分析：**

1. **坐标范围正确：** `[0, 199]` ✅
2. **类别范围正确：** `[200, 203]` ✅
3. **连接范围可能过大：** ❌
   ```python
   random_connect = torch.randint(0, num_box, ...)
   # num_box 可能是180（max_box_num）
   # 加上 connect_start=250 后 → [250, 429]
   # 但论文Table中connect应该是 [250, 349]（100个值）
   ```

4. **系数范围正确：** `[350, 569]`（如果coeff_range=220）✅

**潜在问题：**
- 随机噪声的connect token可能超出论文定义的范围
- 这些噪声token应该是"无意义"的，但范围不一致可能影响模型学习

**建议修复：**
```python
# 方案A：限制connect范围与论文一致
random_connect = torch.randint(0, 100, (...)).to(label)  # [0, 99]
random_connect = random_connect + self.connect_start      # [250, 349]

# 方案B：使用noise token
random_connect = torch.ones((...)).to(label) * self.noise_connect  # 全部用noise token
```

**严重程度：🟡 中等**  
**影响：** 训练时噪声token范围不完全符合论文，但不影响核心功能

---

### ⚠️ 问题3：nan_to_num 掩盖训练异常（已知问题，未修复）

**位置：** `ar_rntr_head.py` 行645-648

**代码：**
```python
loss_coords = torch.nan_to_num(loss_coords)
loss_labels = torch.nan_to_num(loss_labels)
loss_connects = torch.nan_to_num(loss_connects)
loss_coeffs = torch.nan_to_num(loss_coeffs)
```

**问题：**
- NaN loss被静默转换为0
- 隐藏了潜在的数值不稳定问题
- 论文未提及这种处理

**建议改进：**
```python
# 方案A：改为警告+early stop
if torch.isnan(loss_coords).any():
    logger.warning("NaN detected in loss_coords! This may indicate numerical instability.")
    # 可选：触发early stopping或调试模式
    
# 方案B：添加配置开关
if self.nan_handling == 'zero':
    loss_coords = torch.nan_to_num(loss_coords)
elif self.nan_handling == 'stop':
    assert not torch.isnan(loss_coords).any(), "NaN in loss_coords"
```

**严重程度：🟡 中等**  
**影响：** 可能掩盖训练问题，但目前训练稳定

---

## 🟢 轻微问题（Minor - 可选优化）

### 💡 问题4：epsilon 参数未从配置传入

**位置：** `ar_rntr.py` 行122, 951

**代码：**
```python
# __init__
self.epsilon = epsilon  # 默认值 epsilon=2

# simple_test_pts
pred_node_list = av2seq2bznodelist(pred_line_seq.detach().cpu().numpy(), 
                                   n_control, self.epsilon)
```

**问题：**
- epsilon 用于判断fork节点是否为split（行754）
- 硬编码为默认值，无法从配置调整

**建议：**
```python
# 在配置文件中添加
model = dict(
    type='AR_RNTR',
    epsilon=2.0,  # 明确指定
    # ...
)
```

**严重程度：🟢 低**  
**影响：** 不影响功能，只是缺乏灵活性

---

### 💡 问题5：SwanLab可视化代码的兼容性问题

**位置：** `ar_rntr.py` 行274-299

**代码：**
```python
def _log_swanlab_image(self, img, name, step):
    if swanlab is None:
        return
    try:
        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        # 多种API尝试
        if hasattr(swanlab, 'Image'):
            try:
                swanlab.log({name: swanlab.Image(rgb)}, step=step)
                return
            except Exception:
                pass
        # ... 多个fallback
```

**问题：**
- 兼容性代码过多，可能是不同版本的SwanLab导致
- 使用临时文件作为fallback，可能造成磁盘占用

**建议：**
- 统一SwanLab版本
- 或者添加版本检测

**严重程度：🟢 低**  
**影响：** 只影响可视化，不影响核心训练

---

### 💡 问题6：TIT相关代码的文档不足

**位置：** `ar_rntr.py` 行547-593

**代码：**
```python
# TIT: distance-aware soft supervision on connect logits
if self.tit_enable and mask_conn.sum().item() > 1:
    # ... 复杂的TIT逻辑 ...
```

**问题：**
- TIT (Topology-Inherited Training) 是重要特性
- 但代码注释较少，理解困难
- 论文审查范围不包括TIT，所以未深入检查

**建议：**
- 添加详细的docstring
- 或者参考论文添加公式注释

**严重程度：🟢 低**  
**影响：** 只影响代码可读性

---

## 🔍 其他观察

### ℹ️ 观察1：头部传播slot常量的逻辑

**位置：** `ar_rntr.py` 行136-151

**代码：**
```python
# Propagate slot constants to head for constrained decoding
try:
    if hasattr(self, 'pts_bbox_head') and self.pts_bbox_head is not None:
        if hasattr(self.pts_bbox_head, 'category_start'):
            self.pts_bbox_head.category_start = int(self.category_start)
        # ...
except Exception:
    pass  # 静默失败
```

**观察：**
- 这个传播逻辑是为了让Head知道slot的起始位置
- 但使用了try-except且静默失败
- 可能在某些初始化顺序下失败

**建议：**
```python
# 添加日志
except Exception as e:
    logger.warning(f"Failed to propagate slot constants to head: {e}")
```

---

### ℹ️ 观察2：配置文件中的注释掉的约束

**位置：** 配置文件

**代码：**
```python
label_class_weight[201] = 0.2
# connect_class_weight[250] = 0.2  # FIXED: Token 250 is connect_start+0...
```

**观察：**
- connect权重被注释掉了
- 与论文描述不完全一致
- 审查报告中已提及（问题4）

---

## 📊 问题优先级总结

| 优先级 | 问题 | 严重程度 | 修复难度 | 建议 |
|--------|------|---------|---------|------|
| **P0** 🔴 | num_center_classes硬编码576 | 高 | 简单 | **立即修复** |
| **P1** 🟡 | 随机噪声connect范围过大 | 中 | 简单 | 建议修复 |
| **P2** 🟡 | nan_to_num掩盖异常 | 中 | 中等 | 可选改进 |
| **P3** 🟢 | epsilon未配置化 | 低 | 简单 | 可选优化 |
| **P4** 🟢 | SwanLab兼容性 | 低 | 中等 | 不紧急 |
| **P5** 🟢 | TIT文档不足 | 低 | 简单 | 不紧急 |

---

## 🎯 立即行动建议

### 必须修复（P0）

**修复 num_center_classes 硬编码：**

```python
# ar_rntr.py __init__ 方法
def __init__(self, 
             ...
             num_center_classes=574,  # 添加参数
             ...):
    # ...
    
    # 修改行92
    self.num_center_classes = int(num_center_classes)  # 从参数读取
    
    # 或者在init末尾从head推断
    if hasattr(self, 'pts_bbox_head') and self.pts_bbox_head is not None:
        if hasattr(self.pts_bbox_head, 'embedding'):
            actual_vocab_size = self.pts_bbox_head.embedding.num_embeddings
            if actual_vocab_size != self.num_center_classes:
                logger.warning(f"vocab size mismatch: {self.num_center_classes} vs {actual_vocab_size}, using {actual_vocab_size}")
                self.num_center_classes = int(actual_vocab_size)
```

**配置文件中确保传入：**
```python
model = dict(
    type='AR_RNTR',
    num_center_classes=num_center_classes,  # 574
    # ...
)
```

---

### 建议修复（P1）

**限制随机噪声的connect范围：**

```python
# ar_rntr.py 行418-419
# 修改前：
random_connect = torch.randint(0, num_box, (...)).to(label)

# 修改后（方案A - 限制范围）：
random_connect = torch.randint(0, 100, (...)).to(label)  # 与论文一致

# 或修改后（方案B - 使用noise token）：
random_connect = torch.ones((...)).to(label).long() * (self.noise_connect - self.connect_start)
# 然后统一加 connect_start
```

---

## 🧪 验证建议

修复后请验证：

```python
# 1. 检查vocab size一致性
print(f"AR_RNTR.num_center_classes: {model.num_center_classes}")
print(f"Head.embedding.num_embeddings: {model.pts_bbox_head.embedding.num_embeddings}")
assert model.num_center_classes == model.pts_bbox_head.embedding.num_embeddings

# 2. 检查随机噪声范围
# 在训练时打印一次
print(f"Random connect range: [{random_connect.min()}, {random_connect.max()}]")
# 应该在 [250, 349]
```

---

## 📝 总结

### 新发现的关键问题

1. **🔴 P0：num_center_classes 硬编码不一致**
   - 代码576 vs 配置574
   - 可能导致维度不匹配
   - **必须立即修复**

2. **🟡 P1：随机噪声token范围过大**
   - 与论文定义不完全一致
   - 建议修复以提高一致性

3. **🟡 P2：nan_to_num掩盖问题**
   - 已知问题，未修复
   - 可选改进

### 之前已知的问题（已修复）

- ✅ Token定义对齐（已修复）
- ✅ 推理约束配置化（已实现）
- ✅ 可视化坐标系统（已修复）

### 整体代码质量

| 方面 | 评分 | 说明 |
|------|------|------|
| 核心算法 | 95% | 基本正确，有少量不一致 |
| 工程质量 | 90% | 代码结构好，但有硬编码 |
| 与论文一致性 | 92% | 主要逻辑一致，细节有偏差 |
| 鲁棒性 | 85% | 有防御性编程，但nan处理需改进 |
| 可维护性 | 88% | DEBUG完善，但部分文档不足 |

**最终建议：** 优先修复 P0 问题（num_center_classes），其他问题按优先级逐步改进。

---

**审查完成时间：** 2024-10-22 23:04  
**审查深度：** 全面深度审查  
**新发现问题数：** 6个（1个严重，2个中等，3个轻微）
