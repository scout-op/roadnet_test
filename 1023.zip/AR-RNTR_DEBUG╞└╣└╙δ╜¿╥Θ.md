# AR-RNTR DEBUG 打印评估与改进建议

## 📊 当前 DEBUG 打印情况

### ✅ 训练阶段（forward_pts_train）- 已经很详细

代码中已经有 **8 个 DEBUG 检查点**：

| 位置 | DEBUG 点 | 内容 | 状态 |
|------|---------|------|------|
| ar_rntr.py:383 | DEBUG 1 | GT 输入数据（batch size, coords/labels/connects/coeffs 数量） | ✅ 足够 |
| ar_rntr.py:452 | DEBUG 2 | 序列构造（input_seqs, output_seqs shape, END token 位置） | ✅ 足够 |
| ar_rntr.py:470 | DEBUG 3 | 模型输出（logits shape, 数值范围, NaN/Inf 检查） | ✅ 足够 |
| ar_rntr.py:531 | DEBUG 4 | 单个样本监督切分（各 slot 的 mask 统计） | ✅ 足够 |
| ar_rntr.py:628 | DEBUG 5 | 批次级监督统计（coords/labels/connects/coeffs 数量） | ✅ 足够 |
| ar_rntr.py:656 | DEBUG 6 | 最终损失值（每个 loss 的数值和 finite 状态） | ✅ 足够 |
| ar_rntr_head.py:619 | DEBUG 7 | Loss 计算输入（preds/gt 的 shape 和范围） | ✅ 足够 |
| ar_rntr_head.py:637 | DEBUG 8 | 原始 Loss（nan_to_num 前后对比） | ✅ 足够 |

**评价：** 训练阶段的 DEBUG 打印已经**非常完善**，覆盖了从数据输入到损失计算的全流程。

---

### ⚠️ 推理阶段（simple_test_pts）- 缺少关键信息

**当前情况：** 推理代码中**几乎没有 DEBUG 打印**！

**缺失的关键信息：**
1. ❌ 自回归生成的每步状态（token 预测、置信度）
2. ❌ 推理约束的应用情况（哪些被 clamp 了）
3. ❌ EOS 停止条件触发情况
4. ❌ 生成序列的 token 范围检查
5. ❌ 最终生成的节点数量和拓扑结构
6. ❌ 推理速度（每个样本的生成时间）

---

## 🎯 建议添加的 DEBUG 打印

### 推理阶段关键打印点

#### DEBUG INF-1: 推理开始（BEV 特征）
```python
# 位置：simple_test_pts 开始处
if self._is_main_process():
    print("\n" + "="*80)
    print("[AR-RNTR INFERENCE DEBUG] Step INF-1: Start Inference")
    print("="*80)
    print(f"Batch size: {len(img_metas)}")
    print(f"BEV features shape: {pts_feats.shape}")
    print(f"n_control: {n_control}, num_coeff: {num_coeff}")
    print(f"clause_length: {clause_length}")
    print(f"Inference constraints: {self.inference_constraints}")
```

#### DEBUG INF-2: 自回归生成过程（采样统计）
```python
# 位置：自回归循环中（每 N 步打印一次）
if step % 50 == 0 and self._is_main_process():
    print(f"\n[AR-RNTR INFERENCE DEBUG] Step INF-2: Generation Progress (Sample {bi})")
    print(f"  Current step: {step}/{max_step}")
    print(f"  Generated tokens: {len(pred_line_seq)}")
    print(f"  Current nodes: {len(pred_line_seq) // clause_length}")
    print(f"  Last 10 tokens: {pred_line_seq[-10:].tolist()}")
    print(f"  Top-3 logits: {torch.topk(logits_t, 3).indices.tolist()}")
    print(f"  Top-3 probs: {torch.topk(logits_t, 3).values.tolist()}")
```

#### DEBUG INF-3: 推理约束应用情况
```python
# 位置：推理约束应用后
if self._is_main_process():
    print("\n" + "="*80)
    print(f"[AR-RNTR INFERENCE DEBUG] Step INF-3: Constraint Application (Sample {bi})")
    print("="*80)
    
    # 统计有多少 token 被 clamp 了
    if self.inference_constraints.get('clamp_coords', True):
        before_clamp = pred_line_seq[0::clause_length].clone()
        # ... clamp ...
        clamped_count = (before_clamp != pred_line_seq[0::clause_length]).sum().item()
        print(f"  Coords clamped: {clamped_count} tokens")
    
    if self.inference_constraints.get('force_lineal_prev', True):
        print(f"  Lineal nodes forced to i-1: {lineal_forced_count}")
    
    print(f"  Final sequence length: {len(pred_line_seq)}")
    print(f"  Final node count: {len(pred_line_seq) // clause_length}")
```

#### DEBUG INF-4: Token 范围检查
```python
# 位置：约束应用后
if self._is_main_process():
    print(f"\n[AR-RNTR INFERENCE DEBUG] Step INF-4: Token Range Validation (Sample {bi})")
    coords_tokens = pred_line_seq[0::clause_length]
    labels_tokens = pred_line_seq[2::clause_length]
    connect_tokens = pred_line_seq[3::clause_length]
    coeff_tokens = pred_line_seq[4::clause_length]
    
    print(f"  Coords range: [{coords_tokens.min().item()}, {coords_tokens.max().item()}] (expected: [0, {NX-1}])")
    print(f"  Labels range: [{labels_tokens.min().item()}, {labels_tokens.max().item()}] (expected: [0, {self.num_classes-1}])")
    print(f"  Connect range: [{connect_tokens.min().item()}, {connect_tokens.max().item()}]")
    print(f"  Coeff range: [{coeff_tokens.min().item()}, {coeff_tokens.max().item()}] (expected: [0, {self.coeff_range-1}])")
    
    # 检查是否有超出范围的 token（如果有，说明约束没生效）
    if coords_tokens.max() >= NX or coords_tokens.min() < 0:
        print(f"  ⚠️ WARNING: Coords out of range!")
    if labels_tokens.max() >= self.num_classes or labels_tokens.min() < 0:
        print(f"  ⚠️ WARNING: Labels out of range!")
```

#### DEBUG INF-5: 拓扑结构检查
```python
# 位置：序列解码后
if self._is_main_process():
    print(f"\n[AR-RNTR INFERENCE DEBUG] Step INF-5: Topology Validation (Sample {bi})")
    num_nodes = len(pred_line_seq) // clause_length
    
    # 统计各类别节点数量
    label_counts = {}
    for i in range(num_nodes):
        lbl = int(pred_line_seq[2 + i * clause_length].item())
        label_counts[lbl] = label_counts.get(lbl, 0) + 1
    
    print(f"  Total nodes: {num_nodes}")
    print(f"  Node types: Ancestor={label_counts.get(0, 0)}, Lineal={label_counts.get(1, 0)}, "
          f"Offshoot={label_counts.get(2, 0)}, Clone={label_counts.get(3, 0)}")
    
    # 检查连接合法性
    invalid_connections = 0
    for i in range(1, num_nodes):
        conn = int(pred_line_seq[3 + i * clause_length].item())
        if conn >= i:
            invalid_connections += 1
    
    if invalid_connections > 0:
        print(f"  ⚠️ WARNING: {invalid_connections} invalid connections (forward/self loops)!")
    else:
        print(f"  ✅ All connections valid (DAG topology preserved)")
```

#### DEBUG INF-6: 性能统计
```python
# 位置：所有样本推理结束后
if self._is_main_process():
    print("\n" + "="*80)
    print("[AR-RNTR INFERENCE DEBUG] Step INF-6: Performance Summary")
    print("="*80)
    print(f"  Total samples: {len(img_metas)}")
    print(f"  Average inference time: {avg_time:.4f}s per sample")
    print(f"  Average nodes generated: {avg_nodes:.1f}")
    print(f"  Average sequence length: {avg_seq_len:.1f}")
    print(f"  EOS triggered: {eos_count}/{len(img_metas)}")
    print(f"  Max length reached: {max_len_count}/{len(img_metas)}")
```

---

## 📝 完整的推理 DEBUG 代码建议

以下是可以直接添加到 `ar_rntr.py` 的 `simple_test_pts` 方法中的完整 DEBUG 代码：

```python
def simple_test_pts(self, pts_feats, img_metas):
    """Test function of point cloud branch."""
    n_control = img_metas[0]['n_control']
    num_coeff = n_control - 2
    coeff_dim = num_coeff * 2
    clause_length = 4 + coeff_dim
    max_step = 1201
    line_results = []
    
    # ============ DEBUG INF-1: 推理开始 ============
    if self._is_main_process():
        print("\n" + "="*80)
        print("[AR-RNTR INFERENCE DEBUG] Step INF-1: Start Inference")
        print("="*80)
        print(f"Batch size: {len(img_metas)}")
        print(f"BEV features shape: {pts_feats.shape}")
        print(f"n_control: {n_control}, num_coeff: {num_coeff}, coeff_dim: {coeff_dim}")
        print(f"clause_length: {clause_length}, max_step: {max_step}")
        print(f"Inference constraints: {self.inference_constraints}")
        print(f"Token constants: start={self.start}, end={self.end}, no_known={self.no_known}")
    
    import time
    inference_stats = []
    
    for bi in range(len(img_metas)):
        start_time = time.time()
        
        # ... 原有的自回归生成代码 ...
        # 在自回归循环中添加：
        
        # ============ DEBUG INF-2: 生成进度（每 50 步） ============
        if step % 50 == 0 and self._is_main_process() and bi == 0:  # 只打印第一个样本
            print(f"\n[AR-RNTR INFERENCE DEBUG] Step INF-2: Generation Progress (Sample {bi}, Step {step})")
            print(f"  Generated tokens: {len(pred_line_seq)}, Nodes: {len(pred_line_seq) // clause_length}")
            if len(pred_line_seq) >= 10:
                print(f"  Last 10 tokens: {pred_line_seq[-10:].tolist()}")
        
        # ... 在推理约束应用前记录 ...
        
        # ============ DEBUG INF-3: 推理约束应用 ============
        if self._is_main_process() and bi == 0:
            coords_before = pred_line_seq[0::clause_length].clone() if self.inference_constraints.get('clamp_coords') else None
            labels_before = pred_line_seq[2::clause_length].clone() if self.inference_constraints.get('clamp_classes') else None
        
        # ... 应用约束的代码 ...
        
        if self._is_main_process() and bi == 0:
            print("\n" + "="*80)
            print(f"[AR-RNTR INFERENCE DEBUG] Step INF-3: Constraint Application")
            print("="*80)
            
            if coords_before is not None:
                coords_clamped = (coords_before != pred_line_seq[0::clause_length]).sum().item()
                print(f"  Coords clamped: {coords_clamped} tokens")
            
            if labels_before is not None:
                labels_clamped = (labels_before != pred_line_seq[2::clause_length]).sum().item()
                print(f"  Labels clamped: {labels_clamped} tokens")
            
            # 统计 Lineal 强制修正数量
            if self.inference_constraints.get('force_lineal_prev', True):
                num_nodes = len(pred_line_seq) // clause_length
                lineal_count = 0
                for i in range(num_nodes):
                    if int(pred_line_seq[2 + i * clause_length].item()) == 1:  # Lineal
                        lineal_count += 1
                print(f"  Lineal nodes (forced to i-1): {lineal_count}")
        
        # ============ DEBUG INF-4: Token 范围检查 ============
        if self._is_main_process() and bi == 0:
            print(f"\n[AR-RNTR INFERENCE DEBUG] Step INF-4: Token Range Validation")
            
            xbound = self.view_transformers.grid_conf['xbound']
            ybound = self.view_transformers.grid_conf['ybound']
            NX = int((xbound[1] - xbound[0]) / xbound[2])
            NY = int((ybound[1] - ybound[0]) / ybound[2])
            
            coords_x = pred_line_seq[0::clause_length]
            coords_y = pred_line_seq[1::clause_length]
            labels = pred_line_seq[2::clause_length]
            connects = pred_line_seq[3::clause_length]
            
            print(f"  Coords X: [{coords_x.min().item()}, {coords_x.max().item()}] (expected: [0, {NX-1}])")
            print(f"  Coords Y: [{coords_y.min().item()}, {coords_y.max().item()}] (expected: [0, {NY-1}])")
            print(f"  Labels: [{labels.min().item()}, {labels.max().item()}] (expected: [0, 3])")
            print(f"  Connects: [{connects.min().item()}, {connects.max().item()}]")
            
            if coeff_dim > 0:
                coeffs = pred_line_seq[4::clause_length]
                print(f"  Coeffs: [{coeffs.min().item()}, {coeffs.max().item()}] (expected: [0, {self.coeff_range-1}])")
            
            # 检查异常
            if coords_x.max() >= NX or coords_x.min() < 0:
                print(f"  ⚠️ WARNING: Coords X out of range!")
            if coords_y.max() >= NY or coords_y.min() < 0:
                print(f"  ⚠️ WARNING: Coords Y out of range!")
        
        # ============ DEBUG INF-5: 拓扑结构检查 ============
        if self._is_main_process() and bi == 0:
            print(f"\n[AR-RNTR INFERENCE DEBUG] Step INF-5: Topology Validation")
            
            num_nodes = len(pred_line_seq) // clause_length
            label_counts = {0: 0, 1: 0, 2: 0, 3: 0}
            
            invalid_connections = 0
            for i in range(num_nodes):
                lbl = int(pred_line_seq[2 + i * clause_length].item())
                if lbl in label_counts:
                    label_counts[lbl] += 1
                
                if i > 0:
                    conn = int(pred_line_seq[3 + i * clause_length].item())
                    if conn >= i:
                        invalid_connections += 1
            
            print(f"  Total nodes: {num_nodes}")
            print(f"  Ancestor: {label_counts[0]}, Lineal: {label_counts[1]}, "
                  f"Offshoot: {label_counts[2]}, Clone: {label_counts[3]}")
            
            if invalid_connections > 0:
                print(f"  ⚠️ WARNING: {invalid_connections} invalid connections (forward/self loops)!")
            else:
                print(f"  ✅ All connections valid (DAG topology)")
        
        # 记录统计信息
        inference_time = time.time() - start_time
        inference_stats.append({
            'time': inference_time,
            'nodes': len(pred_line_seq) // clause_length,
            'seq_len': len(pred_line_seq),
        })
        
        # ... 原有的结果保存代码 ...
    
    # ============ DEBUG INF-6: 性能统计 ============
    if self._is_main_process() and len(inference_stats) > 0:
        print("\n" + "="*80)
        print("[AR-RNTR INFERENCE DEBUG] Step INF-6: Performance Summary")
        print("="*80)
        avg_time = sum(s['time'] for s in inference_stats) / len(inference_stats)
        avg_nodes = sum(s['nodes'] for s in inference_stats) / len(inference_stats)
        avg_seq_len = sum(s['seq_len'] for s in inference_stats) / len(inference_stats)
        
        print(f"  Total samples: {len(inference_stats)}")
        print(f"  Average inference time: {avg_time:.4f}s per sample")
        print(f"  Average nodes generated: {avg_nodes:.1f}")
        print(f"  Average sequence length: {avg_seq_len:.1f}")
        print("="*80 + "\n")
    
    return line_results
```

---

## 🎯 最终建议

### 当前状态
- ✅ **训练阶段**：DEBUG 打印**非常完善**，无需修改
- ⚠️ **推理阶段**：缺少关键 DEBUG 信息

### 建议行动

**优先级 P0（强烈建议）：**
1. ✅ 添加 **DEBUG INF-1**（推理开始）- 了解输入配置
2. ✅ 添加 **DEBUG INF-4**（Token 范围检查）- 验证约束生效
3. ✅ 添加 **DEBUG INF-5**（拓扑检查）- 验证 DAG 合法性

**优先级 P1（推荐）：**
4. ✅ 添加 **DEBUG INF-3**（约束应用统计）- 了解约束影响
5. ✅ 添加 **DEBUG INF-6**（性能统计）- 评估推理效率

**优先级 P2（可选）：**
6. ⚠️ 添加 **DEBUG INF-2**（生成进度）- 详细观察每步预测（可能输出量大）

---

## 📋 实施清单

- [ ] 在 `ar_rntr.py` 的 `simple_test_pts` 开头添加 DEBUG INF-1
- [ ] 在推理约束应用处添加 DEBUG INF-3 和 INF-4
- [ ] 在序列解码后添加 DEBUG INF-5
- [ ] 在所有样本推理完成后添加 DEBUG INF-6
- [ ] （可选）在自回归循环中添加 DEBUG INF-2

**预计工作量：** 20-30 分钟  
**代码行数：** 约 100-150 行  
**输出量增加：** 推理时每个 batch 约增加 50-100 行日志

---

## 💡 使用建议

### 训练时
```bash
# 已有足够的 DEBUG，直接运行即可
python tools/train.py configs/xxx.py
```

### 推理/测试时
```bash
# 添加 DEBUG 后运行
python tools/test.py configs/xxx.py checkpoints/xxx.pth

# 建议重定向到文件以便分析
python tools/test.py configs/xxx.py checkpoints/xxx.pth 2>&1 | tee inference_debug.log
```

### 分析 DEBUG 输出
```bash
# 提取关键信息
grep "INFERENCE DEBUG" inference_debug.log

# 查看 Token 范围
grep "Token Range" inference_debug.log

# 查看拓扑问题
grep "WARNING" inference_debug.log
```

---

**总结：** 训练阶段的 DEBUG 已经很完善，但**推理阶段需要补充关键的 DEBUG 信息**，特别是约束应用、Token 范围和拓扑检查。建议优先添加 INF-1, INF-4, INF-5 三个关键检查点。
