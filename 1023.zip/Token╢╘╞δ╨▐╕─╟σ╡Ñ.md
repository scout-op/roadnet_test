# Token定义对齐修改清单

## 📊 对齐方案

### 当前代码 → 论文对齐

| Token | 当前值 | 论文值 | 需要改动 |
|-------|--------|--------|----------|
| noise_coeff | 570 | 570 | ✅ 无需改动 |
| noise_label | 571 | - | ⚠️ 论文未提及 |
| noise_connect | 572 | - | ⚠️ 论文未提及 |
| end (EOS) | 573 | 571 | ❌ -2 |
| start | 574 | 572 | ❌ -2 |
| no_known (n/a) | 575 | 573 | ❌ -2 |
| **num_center_classes** | **576** | **574** | ❌ -2 |

---

## ✅ 需要修改的文件（共10处）

### 1️⃣ 核心模型文件（3处 - 关键）

#### 文件：`rntr/ar_rntr.py` 行110-118
```python
# 修改前
self.no_known = 575
self.start = 574
self.end = 573
self.noise_connect = 572
self.noise_label = 571
self.noise_coeff = 570

# 修改后
self.no_known = 573      # 575 → 573 (n/a)
self.start = 572         # 574 → 572 (Start)
self.end = 571           # 573 → 571 (EOS)
self.noise_connect = 570 # 572 → 570 (与noise_coeff合并)
self.noise_label = 570   # 571 → 570 (与noise_coeff合并)
self.noise_coeff = 570   # 保持不变
```

#### 文件：`rntr/sar_rntr.py` 行139-147
```python
# 同样的修改
self.no_known = 573
self.start = 572
self.end = 571
self.noise_connect = 570
self.noise_label = 570
self.noise_coeff = 570
```

#### 文件：`rntr/transforms/loading.py` 行1128-1136
```python
# 同样的修改（这是数据预处理中的定义）
self.no_known = 573
self.start = 572
self.end = 571
self.noise_connect = 570
self.noise_label = 570
self.noise_coeff = 570
```

---

### 2️⃣ 配置文件（7处 - 简单查找替换）

所有配置文件中的 `num_center_classes = 576` 需要改为 `574`

**需要修改的配置文件列表：**

1. `configs/road_seg/lss_roadseg_48x32_b4x8_resnet_adam_24e.py` 行14
2. `configs/rntr_tit/stage1_lidar_bev_teacher.py` 行13
3. `configs/rntr_tit/stage2_img_bev_distill.py` 行13
4. `configs/rntr_tit/stage3_assemble_finetune.py` 行13
5. `configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py` 行15
6. `configs/rntr_ar_roadseq/lss_ar_rntr_debug_fp32.py` 行29
7. `configs/rntr_sar_roadseq/*.py` (多个文件)

**修改命令（批量替换）：**
```python
# 在所有配置文件中查找替换
num_center_classes = 576  →  num_center_classes = 574
```

---

### 3️⃣ SAR Head文件（1处 - 如果使用SAR）

#### 文件：`rntr/sar_rntr_head.py` 行238-240
```python
# 修改前
self.no_known = 575
self.start = 574
self.end = 573

# 修改后
self.no_known = 573
self.start = 572
self.end = 571
```

---

## 🎯 修改步骤（推荐顺序）

### 步骤1：修改核心模型定义（最关键）
```bash
# 编辑这3个文件
rntr/ar_rntr.py          # 行110-118
rntr/sar_rntr.py         # 行139-147
rntr/transforms/loading.py  # 行1128-1136
```

### 步骤2：批量修改配置文件
```bash
# 使用编辑器的查找替换功能
# 在 configs/ 目录下所有 .py 文件中
查找：num_center_classes = 576
替换：num_center_classes = 574
```

### 步骤3：修改embedding层权重（如果从checkpoint恢复）
```python
# 如果从旧checkpoint加载，需要处理embedding权重
# 在模型加载时添加以下代码：

def adapt_checkpoint_tokens(checkpoint):
    """将576维embedding适配到574维"""
    # 方案1：直接截断（推荐）
    if 'embedding.token_embeddings.weight' in checkpoint:
        old_weight = checkpoint['embedding.token_embeddings.weight']
        if old_weight.shape[0] == 576:
            checkpoint['embedding.token_embeddings.weight'] = old_weight[:574]
    
    # 方案2：重新映射（保留旧token的含义）
    # 将token 573,574,575 重新映射到 571,572,573
    # (更复杂，但保留训练好的权重)
    
    return checkpoint
```

---

## ⚠️ 关键注意事项

### 1. Embedding Size变化的影响
- **旧模型：** 576维embedding (token 0-575)
- **新模型：** 574维embedding (token 0-573)
- **影响：** 需要重新训练，或者适配checkpoint

### 2. 已训练模型的处理
如果有已训练的checkpoint：

**方案A（推荐）：从头训练**
- 优点：干净，无兼容性问题
- 缺点：耗时

**方案B：适配checkpoint**
```python
# 在加载checkpoint时
state_dict = torch.load(checkpoint_path)

# 截断embedding权重
for key in state_dict.keys():
    if 'embedding' in key and state_dict[key].shape[0] == 576:
        state_dict[key] = state_dict[key][:574]
    elif 'vocab_embed' in key and state_dict[key].shape[-1] == 576:
        state_dict[key] = state_dict[key][..., :574]

model.load_state_dict(state_dict, strict=False)
```

### 3. 不会影响的部分 ✅
- ✅ **数据预处理逻辑** - 因为使用变量引用 `self.start`
- ✅ **序列构造逻辑** - 同样使用变量
- ✅ **损失计算** - 通过变量动态获取
- ✅ **推理流程** - 所有地方都用 `self.end` 判断停止

---

## 🧪 验证清单

修改完成后，运行以下验证：

### 1. 静态检查
```bash
cd RoadNetwork

# 检查所有token定义是否一致
grep -r "self.no_known = " rntr/
grep -r "self.start = " rntr/
grep -r "self.end = " rntr/

# 检查所有num_center_classes
grep -r "num_center_classes = " configs/

# 预期结果：
# self.no_known = 573 (所有位置)
# self.start = 572 (所有位置)
# self.end = 571 (所有位置)
# num_center_classes = 574 (所有配置文件)
```

### 2. 代码测试
```python
# 创建测试脚本：test_token_alignment.py
import torch
from rntr.ar_rntr import AR_RNTR

# 创建模型
model = AR_RNTR(...)

# 验证token定义
assert model.no_known == 573, f"no_known should be 573, got {model.no_known}"
assert model.start == 572, f"start should be 572, got {model.start}"
assert model.end == 571, f"end should be 571, got {model.end}"

# 验证embedding size
assert model.pts_bbox_head.embedding.num_embeddings == 574, \
    f"Embedding size should be 574, got {model.pts_bbox_head.embedding.num_embeddings}"

print("✅ All token definitions aligned with paper!")
```

### 3. 训练测试
```bash
# 启动一个epoch的训练，确保没有错误
python tools/train.py configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py \
    --work-dir work_dirs/token_test \
    --cfg-options train_dataloader.dataset.indices=0:10
```

---

## 📈 修改影响评估

### 代码修改量
- **核心文件：** 3个文件 × 6行 = 18行
- **配置文件：** 7个文件 × 1行 = 7行
- **总计：** 约25行代码

### 风险评估
| 风险类别 | 风险等级 | 说明 |
|---------|---------|------|
| 语法错误 | 🟢 极低 | 只改数字，不改结构 |
| 逻辑错误 | 🟢 极低 | 使用变量引用，改定义即可 |
| 兼容性 | 🟡 中等 | 旧checkpoint需要适配 |
| 训练效果 | 🟢 极低 | 理论上无影响（仅改token编号） |

### 时间估算
- **修改代码：** 10-15分钟
- **验证测试：** 5-10分钟
- **重新训练：** 取决于是否需要（如有checkpoint可能不需要）

---

## 💡 建议

### 立即执行（P0）
1. ✅ 修改3个核心文件的token定义
2. ✅ 批量修改配置文件的num_center_classes

### 可选执行（P1）
3. ⚠️ 如果有checkpoint，添加适配代码
4. ⚠️ 运行验证脚本确认修改正确

### 长期维护（P2）
5. 📝 添加单元测试防止token定义漂移
6. 📝 在代码注释中引用论文Table

---

## 🎉 修改后效果

修改完成后，代码将完全符合论文Table定义：

```
✅ v_x, v_y:       0~199
✅ v_c:            200~249
✅ v_d:            250~349
✅ e_px, e_py:     350~569
✅ noise category: 570
✅ EOS:            571
✅ Start:          572
✅ n/a:            573
✅ Vocabulary:     0~573 (574 tokens)
```

这将显著提升代码的可复现性和与论文的一致性！
