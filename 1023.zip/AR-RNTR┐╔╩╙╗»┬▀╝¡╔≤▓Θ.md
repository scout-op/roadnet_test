# AR-RNTR 可视化逻辑审查报告

## 📊 审查结论

**总体评价：✅ 可视化逻辑基本正确，但存在几个需要注意的细节问题**

---

## 🔍 可视化流程分析

### 整体架构

```
推理输出序列
    ↓
av2seq2bznodelist() 转换为 nodelist
    ↓
vis_from_nodelist() 绘制拓扑图
    ↓
保存到 vis/{path}/{filename}_{aux_name}.png
```

---

## ✅ 正确的部分

### 1. 序列到节点列表的转换（av2seq2bznodelist）

**位置：** `rntr/core/centerline/structures/ljc_bz_centerline.py:709`

**逻辑正确性：** ✅

```python
def av2seq2bznodelist(seq, n_control, epsilon=0.1):
    # 输入格式：[vx, vy, vc, vd, e_px, e_py, ...]
    length = 4 + 2*(n_control-2)  # clause_length
    seq = np.array(seq).reshape(-1, length)
    
    # 类型映射
    idx_type_map = {0: 'start', 1: 'continue', 2: "fork", 3: 'merge'}
    
    for i in range(len(seq)):
        label = int(seq[i][2])  # 类别
        
        # ✅ 强制第一个节点为 'start'（鲁棒性）
        if i == 0:
            label = 0
        
        # ✅ 边界检查
        if label > 3 or label < 0:
            label = 1
        
        # ✅ 坐标提取
        node['coord'] = [seq[i][0], seq[i][1]]
        
        # ✅ Bezier系数提取
        node['coeff'] = np.array([seq[i][j] for j in range(4, length)])
        
        # ✅ 连接索引裁剪到合法范围
        conn = int(seq[i][3])
        conn = max(0, min(conn, idx))
```

**评价：** 
- ✅ 边界检查完善
- ✅ 强制第一个节点为 'start'（防御性编程）
- ✅ 连接索引裁剪到已存在节点

---

### 2. 拓扑绘制（vis_from_nodelist）

**位置：** `ar_rntr.py:1046`

**逻辑正确性：** ✅

```python
def vis_from_nodelist(self, nodelist, img_meta, path, aux_name):
    # 图像尺寸：200×200（与 Map_size=[-50,50]×[-50,50], resolution=0.5 对应）
    image = np.zeros([200, 200, 3])
    
    # ✅ 颜色映射清晰
    point_color_map = {
        "start": (0, 0, 255),      # Red
        'fork': (0, 255, 0),       # Green
        "continue": (0, 255, 255), # Yellow
        "merge": (255, 0, 0)       # Blue
    }
    
    for idx, node in enumerate(nodelist):
        if node['sque_type'] == 'start':
            cv2.circle(image, node['coord'], 1, color=..., thickness=2)
        
        elif node['sque_type'] == 'continue':
            # ✅ 从前一个节点画箭头
            cv2.arrowedLine(image, nodelist[idx - 1]['coord'], node['coord'], ...)
        
        elif node['sque_type'] == 'fork':
            # ✅ 安全检查：防止越界
            if node['fork_from'] > idx or node['fork_from'] < 0:
                continue
            # ✅ 从指定的源节点画箭头
            cv2.arrowedLine(image, nodelist[node['fork_from'] - 1]['coord'], ...)
        
        elif node['sque_type'] == 'merge':
            # ✅ 安全检查
            if node['merge_with'] > idx or node['merge_with'] < 0:
                continue
            cv2.arrowedLine(image, nodelist[node['merge_with'] - 1]['coord'], ...)
```

**评价：**
- ✅ 颜色映射合理
- ✅ 拓扑连接正确（箭头指向正确）
- ✅ 越界保护

---

### 3. GT 数据转换（_build_gt_nodelist）

**位置：** `ar_rntr.py:976`

**逻辑正确性：** ✅

```python
def _build_gt_nodelist(self, img_meta, n_control):
    # ✅ 提取 GT 数据
    gt_coords = np.array(img_meta['centerline_coord'])
    gt_labels = np.array(img_meta['centerline_label'])
    gt_connects = np.array(img_meta['centerline_connect'])
    gt_coeffs = np.array(img_meta['centerline_coeff'])
    
    # ✅ 构造与模型输出相同格式的序列
    for i in range(len(gt_coords)):
        node_seq = [
            gt_coords[i][0],      # x
            gt_coords[i][1],      # y
            gt_labels[i],         # category
            gt_connects[i],       # connection
        ]
        node_seq.extend(gt_coeffs[i])
    
    # ✅ 使用相同的转换函数
    gt_node_list = av2seq2bznodelist(gt_seq_array, n_control, self.epsilon)
```

**评价：**
- ✅ 使用相同的转换函数确保一致性
- ✅ 格式对齐

---

## ⚠️ 需要注意的问题

### 问题1：坐标系统不一致（中等严重）

**位置：** `vis_from_nodelist` 行1064-1066

```python
Map_size = [(-50, 50), (-50, 50)]  # 世界坐标：-50m 到 +50m
Map_resolution = 0.5                # 分辨率：0.5m/像素
image = np.zeros([200, 200, 3])     # 图像：200×200像素
```

**问题分析：**

实际的 BEV 配置（从config）：
```python
grid_conf = dict(
    xbound=[-48.0, 48.0, 0.5],  # X: -48 到 +48，192格
    ybound=[-32.0, 32.0, 0.5],  # Y: -32 到 +32，128格
)
```

**不一致之处：**
| 参数 | 可视化代码 | 实际BEV配置 | 状态 |
|------|-----------|------------|------|
| X范围 | [-50, 50] | [-48, 48] | ⚠️ 不匹配 |
| Y范围 | [-50, 50] | [-32, 32] | ❌ **严重不匹配** |
| 图像尺寸 | 200×200 | 192×128 | ⚠️ 不匹配 |

**影响：**
- ⚠️ 可视化图像的纵横比不正确（正方形 vs 矩形）
- ⚠️ Y方向显示的范围比实际BEV大（-50~50 vs -32~32）
- ⚠️ 坐标可能显示在错误位置

**建议修复：**
```python
# 方案A：从 grid_conf 动态读取
xbound = self.view_transformers.grid_conf['xbound']
ybound = self.view_transformers.grid_conf['ybound']
NX = int((xbound[1] - xbound[0]) / xbound[2])  # 192
NY = int((ybound[1] - ybound[0]) / ybound[2])  # 128
image = np.zeros([NY, NX, 3])

# 方案B：保持正方形但标注正确范围
Map_size = [(-48, 48), (-32, 32)]  # 与实际BEV一致
```

---

### 问题2：连接索引的潜在越界（轻微）

**位置：** `vis_from_nodelist` 行1088, 1096

```python
# fork
cv2.arrowedLine(image, nodelist[node['fork_from'] - 1]['coord'], ...)
#                                                     ↑ 减1

# merge
cv2.arrowedLine(image, nodelist[node['merge_with'] - 1]['coord'], ...)
#                                                      ↑ 减1
```

**问题分析：**

在 `av2seq2bznodelist` 中：
```python
# 连接索引是直接存储的（0-based）
conn = int(seq[i][3])
conn = max(0, min(conn, idx))  # idx 是当前节点的 sque_index
node['fork_from'] = conn       # 直接存储
node['merge_with'] = conn
```

但是在绘制时：
```python
nodelist[node['fork_from'] - 1]['coord']  # 为什么要 -1？
```

**分析：**
- 如果 `fork_from=0`（连接到第一个节点），则访问 `nodelist[-1]`（最后一个节点）❌
- 这会导致错误的连接

**可能的原因：**
- 代码假设连接索引是 1-based（从1开始）
- 但实际存储是 0-based（从0开始）

**验证需要：**
需要检查 `sque_index` 的编号方式：
- 如果 `sque_index` 从1开始，则 `-1` 正确
- 如果 `sque_index` 从0开始，则 `-1` 错误

**查看代码：**
```python
# av2seq2bznodelist 中
idx = 0  # 初始为0
node['sque_index'] = idx  # 第一个节点 sque_index=0

# continue/fork 时
idx = idx + 1
node['sque_index'] = idx  # 递增
```

**结论：** 
- `sque_index` 从0开始
- `fork_from`/`merge_with` 存储的是 `sque_index`（0-based）
- 但绘制时用 `-1`，这可能导致错误！

**建议修复：**
```python
# 正确的访问方式：
# 找到 sque_index == fork_from 的节点
target_node = None
for n in nodelist:
    if n['sque_index'] == node['fork_from']:
        target_node = n
        break
if target_node:
    cv2.arrowedLine(image, target_node['coord'], node['coord'], ...)
```

或者，如果确认 `fork_from` 就是 nodelist 的索引：
```python
# 直接访问（不减1）
if 0 <= node['fork_from'] < len(nodelist):
    cv2.arrowedLine(image, nodelist[node['fork_from']]['coord'], ...)
```

---

### 问题3：图像坐标转换未明确（轻微）

**位置：** `vis_from_nodelist` 行1076-1097

```python
cv2.circle(image, node['coord'], ...)
```

**问题：**
- `node['coord']` 是**网格坐标**（例如 [0-191, 0-127]）
- 直接作为 `cv2.circle` 的坐标使用
- **假设图像大小与网格大小一致**

**当前情况：**
- 图像：200×200
- 网格：192×128（实际BEV）
- ❌ 尺寸不匹配！

**可能的后果：**
- 坐标超出图像范围会被自动裁剪（OpenCV 行为）
- 但显示位置不正确

**建议：**
```python
# 明确坐标转换
def grid_to_image_coord(grid_x, grid_y, NX, NY, img_h, img_w):
    """将网格坐标转换为图像坐标"""
    img_x = int(grid_x * img_w / NX)
    img_y = int(grid_y * img_h / NY)
    return (img_x, img_y)

# 或者直接匹配图像大小到网格大小
image = np.zeros([NY, NX, 3])  # 128×192
```

---

### 问题4：可视化配置硬编码（轻微）

**位置：** `vis_from_nodelist` 行1064-1066

```python
Map_size = [(-50, 50), (-50, 50)]  # 硬编码
Map_resolution = 0.5                # 硬编码
image = np.zeros([200, 200, 3])     # 硬编码
```

**问题：**
- 无法根据实际配置动态调整
- 与 `grid_conf` 不同步

**建议：**
```python
def vis_from_nodelist(self, nodelist, img_meta, path, aux_name):
    # 从配置读取
    xbound = self.view_transformers.grid_conf['xbound']
    ybound = self.view_transformers.grid_conf['ybound']
    NX = int((xbound[1] - xbound[0]) / xbound[2])
    NY = int((ybound[1] - ybound[0]) / ybound[2])
    
    # 创建匹配的图像
    image = np.zeros([NY, NX, 3], dtype=np.uint8)
    
    # 后续坐标直接使用，无需转换
```

---

## 📋 问题优先级总结

| 优先级 | 问题 | 严重程度 | 影响 | 建议 |
|--------|------|---------|------|------|
| **P0** | Y范围不匹配 | 🔴 高 | 可视化显示范围错误 | 立即修复 |
| **P1** | 图像尺寸不匹配 | 🟡 中 | 纵横比失真 | 建议修复 |
| **P2** | 连接索引 -1 | 🟡 中 | 可能导致错误连接 | 需验证 |
| **P3** | 硬编码配置 | 🟢 低 | 不灵活 | 可选优化 |

---

## ✅ 修复建议代码

### 修复1：动态读取配置

```python
def vis_from_nodelist(self, nodelist, img_meta, path, aux_name):
    """
    Visualize road network topology from node list.
    """
    import cv2
    
    # ✅ 从配置动态读取
    try:
        xbound = self.view_transformers.grid_conf['xbound']
        ybound = self.view_transformers.grid_conf['ybound']
        NX = int((xbound[1] - xbound[0]) / xbound[2])  # 192
        NY = int((ybound[1] - ybound[0]) / ybound[2])  # 128
        print(f"[VIS DEBUG] Grid size: {NX}×{NY}")
    except:
        # Fallback
        NX, NY = 200, 200
    
    # ✅ 创建匹配尺寸的图像
    image = np.zeros([NY, NX, 3], dtype=np.uint8)
    
    point_color_map = {
        "start": (0, 0, 255),
        'fork': (0, 255, 0),
        "continue": (0, 255, 255),
        "merge": (255, 0, 0)
    }
    
    for idx, node in enumerate(nodelist):
        # ✅ 坐标边界检查
        coord = node['coord']
        if not (0 <= coord[0] < NX and 0 <= coord[1] < NY):
            print(f"[VIS WARNING] Coord out of bounds: {coord}")
            continue
        
        coord_tuple = (int(coord[0]), int(coord[1]))
        
        if node['sque_type'] == 'start':
            cv2.circle(image, coord_tuple, 1, color=point_color_map['start'], thickness=2)
        
        elif node['sque_type'] == 'continue':
            if idx > 0:
                prev_coord = nodelist[idx - 1]['coord']
                prev_tuple = (int(prev_coord[0]), int(prev_coord[1]))
                cv2.circle(image, coord_tuple, 1, color=point_color_map['continue'], thickness=2)
                cv2.arrowedLine(image, prev_tuple, coord_tuple, 
                              color=point_color_map['continue'], thickness=1, tipLength=0.1)
        
        elif node['sque_type'] == 'fork':
            fork_from = node.get('fork_from')
            if fork_from is None or fork_from < 0 or fork_from >= len(nodelist):
                continue
            
            # ✅ 修复：直接使用 fork_from 作为索引（不减1）
            # 或者根据 sque_index 查找
            source_node = None
            for n in nodelist[:idx]:  # 只在历史节点中查找
                if n['sque_index'] == fork_from:
                    source_node = n
                    break
            
            if source_node:
                src_tuple = (int(source_node['coord'][0]), int(source_node['coord'][1]))
                cv2.circle(image, coord_tuple, 1, color=point_color_map['fork'], thickness=2)
                cv2.arrowedLine(image, src_tuple, coord_tuple,
                              color=point_color_map['fork'], thickness=1, tipLength=0.1)
        
        elif node['sque_type'] == 'merge':
            merge_with = node.get('merge_with')
            if merge_with is None or merge_with < 0 or merge_with >= len(nodelist):
                continue
            
            # ✅ 同样修复 merge
            target_node = None
            for n in nodelist[:idx]:
                if n['sque_index'] == merge_with:
                    target_node = n
                    break
            
            if target_node:
                tgt_tuple = (int(target_node['coord'][0]), int(target_node['coord'][1]))
                cv2.circle(image, coord_tuple, 1, color=point_color_map['merge'], thickness=2)
                cv2.arrowedLine(image, tgt_tuple, coord_tuple,
                              color=point_color_map['merge'], thickness=1, tipLength=0.1)
    
    # 保存
    name = img_meta['filename'][0].split('/')[-1].split('.jpg')[0]
    save_dir = f"vis/{path}/"
    os.makedirs(save_dir, exist_ok=True)
    cv2.imwrite(os.path.join(save_dir, f"{name}_{aux_name}.png"), image)
```

---

## 🎯 最终评价

### 核心逻辑

| 方面 | 评价 | 分数 |
|------|------|------|
| 序列转换 | ✅ 正确 | 95% |
| 拓扑绘制 | ✅ 基本正确 | 85% |
| GT转换 | ✅ 正确 | 95% |
| 坐标系统 | ⚠️ 需修复 | 60% |

**总体：** ✅ **80% 正确，需要修复坐标系统不一致问题**

### 关键建议

1. **P0（立即）：** 修复图像尺寸与BEV配置不匹配
2. **P1（重要）：** 验证并修复连接索引的 -1 问题
3. **P2（可选）：** 动态读取配置而非硬编码

---

## 📝 验证清单

修复后请验证：

- [ ] 可视化图像尺寸与BEV配置一致（192×128）
- [ ] 坐标显示在正确位置
- [ ] Fork/Merge 连接指向正确的源节点
- [ ] 边界坐标不会越界或错位
- [ ] GT 和 Pred 在同一坐标系下对比
