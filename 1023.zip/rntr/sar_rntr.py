# Centerline utils for graph/Bezier rendering (as in tools/vis.py)
try:
    from projects.RoadNetwork.rntr.core.centerline import EvalMapBzGraph, convert_coeff_coord, seq2bznodelist
except Exception:
    try:
        from rntr.core.centerline import EvalMapBzGraph, convert_coeff_coord, seq2bznodelist
    except Exception:
        EvalMapBzGraph = None
        convert_coeff_coord = None
        seq2bznodelist = None
import os
import cv2
import random
from collections import defaultdict
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmengine.structures import InstanceData
import numpy as np
import time
import torch.distributed as dist

# Optional: SwanLab real-time experiment tracking
try:
    import swanlab  # pip install swanlab
    _SWANLAB_AVAILABLE = True
except Exception:
    swanlab = None
    _SWANLAB_AVAILABLE = False

from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector
from mmdet3d.registry import MODELS
from mmdet3d.structures.ops import bbox3d2result
from .grid_mask import GridMask
from .LiftSplatShoot import LiftSplatShootEgo
from .core import seq2nodelist, seq2bznodelist, seq2plbznodelist, av2seq2bznodelist
# Import registry for assigners (prefer TASK_UTILS for MMDet/MMDet3D 3.x)
KP_ASSIGNERS = None
try:
    from mmdet.registry import TASK_UTILS as _MMDET_TASK_UTILS
    KP_ASSIGNERS = _MMDET_TASK_UTILS
except Exception:
    try:
        from mmdet3d.registry import TASK_UTILS as _MMDET3D_TASK_UTILS
        KP_ASSIGNERS = _MMDET3D_TASK_UTILS
    except Exception:
        try:
            from mmdet.registry import MODELS as _MMDET_MODELS
            KP_ASSIGNERS = _MMDET_MODELS
        except Exception:
            try:
                from mmdet.core.bbox.builder import BBOX_ASSIGNERS as _LEGACY_ASSIGNERS
                KP_ASSIGNERS = _LEGACY_ASSIGNERS
            except Exception:
                KP_ASSIGNERS = None


@MODELS.register_module()
class SAR_RNTR(MVXTwoStageDetector):
    """Semi-Autoregressive RoadNetTransformer.

    Training uses block-causal masking inside SARRNTRHead to enable
    intra-block parallel decoding, while keeping end-to-end pipeline
    and tokenization compatible with AR_RNTR.
    """
    def __init__(self,
                 use_grid_mask=False,
                 pts_voxel_layer=None,
                 pts_middle_encoder=None,
                 pts_fusion_layer=None,
                 img_backbone=None,
                 pts_backbone=None,
                 img_neck=None,
                 pts_neck=None,
                 lss_cfg=None,
                 grid_conf=None,
                 bz_grid_conf=None,
                 data_aug_conf=None,
                 pts_bbox_head=None,
                 img_roi_head=None,
                 img_rpn_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 vis_cfg=None,
                 freeze_pretrain=True,
                 bev_scale=1.0,
                 epsilon=2,
                 max_box_num=100,
                 init_cfg=None,
                 data_preprocessor=None,
                 # SwanLab optional params
                 swanlab_enable=False,
                 swanlab_project='RoadNet',
                 swanlab_run_name=None,
                 swanlab_log_interval=50,
                 swanlab_image_interval=200,
                 swanlab_rand_vis_per_epoch=10,
                 tit_cfg=None,
                 # Keypoint branch controls
                 kp_enable=True,
                 kp_weights=None,
                 # Inference post-processing toggle
                 inference_sanitation=True,
                 ):
        super(SAR_RNTR, self).__init__(pts_voxel_layer, pts_middle_encoder,
                                                        pts_fusion_layer, img_backbone, pts_backbone,
                                                        img_neck, pts_neck, pts_bbox_head, img_roi_head,
                                                        img_rpn_head, train_cfg, test_cfg, init_cfg,
                                                        data_preprocessor)
        self.grid_mask = GridMask(True, True, rotate=1, offset=False, ratio=0.5, mode=1, prob=0.7)
        self.use_grid_mask = use_grid_mask
        self.view_transformers = LiftSplatShootEgo(grid_conf, data_aug_conf, return_bev=True, **lss_cfg)
        self.downsample = lss_cfg['downsample']
        self.final_dim = data_aug_conf['final_dim']
        # Toggle for AR-style inference sanitation
        self.inference_sanitation = bool(inference_sanitation)
        # Keep grid confs for visualization (bezier coeff conversion uses both)
        self.grid_conf = grid_conf
        self.bz_grid_conf = bz_grid_conf if bz_grid_conf is not None else grid_conf

        # Unified vocabulary constants (same as AR_RNTR)
        self.num_center_classes = 576
        self.box_range = 200
        # Align coefficient token range to Bezier grid resolution to avoid truncation
        try:
            bx = self.bz_grid_conf['xbound']
            by = self.bz_grid_conf['ybound']
            # Use X-axis bins (assumed square grid, so X==Y); floor to int
            self.coeff_range = int(np.floor((bx[1] - bx[0]) / bx[2]))
            # Safety: if y-axis differs, take the min to stay in-range
            coeff_range_y = int(np.floor((by[1] - by[0]) / by[2]))
            self.coeff_range = int(min(self.coeff_range, coeff_range_y))
            if self.coeff_range <= 0:
                self.coeff_range = 200
        except Exception:
            self.coeff_range = 200
        self.num_classes=4
        self.category_start = 200
        self.connect_start = 250
        self.coeff_start = 350
        self.no_known = 573  # n/a (aligned with paper Table)
        self.start = 572     # Start token (aligned with paper Table)
        self.end = 571       # EOS token (aligned with paper Table)
        self.noise_connect = 570  # noise token for connect slot
        self.noise_label = 570    # noise token for label slot (same as noise_coeff)
        self.noise_coeff = 570    # noise category token (aligned with paper Table)
        self.vis_cfg = vis_cfg
        self.bev_scale = bev_scale
        self.epsilon = epsilon
        self.max_box_num = max_box_num
        # Topology-Inherited Training (TIT) config (disabled by default)
        self.tit_cfg = tit_cfg or {}
        self.tit_enable = bool(self.tit_cfg.get('enable', False))
        self.tit_k = int(self.tit_cfg.get('k', 4))              # top-K nearest neighbors
        self.tit_alpha = float(self.tit_cfg.get('alpha', 0.3))  # neighbor smoothing weight
        self.tit_weight = float(self.tit_cfg.get('weight', 1.0))

        # SwanLab runtime config (only active when enabled and package available)
        self.swanlab_enable = bool(swanlab_enable) or (os.getenv('SWANLAB_ENABLE', '0').lower() in ('1', 'true', 'yes'))
        self.swanlab_project = swanlab_project
        self.swanlab_run_name = swanlab_run_name
        self.swanlab_log_interval = max(1, int(swanlab_log_interval))
        self.swanlab_image_interval = max(1, int(swanlab_image_interval))
        self._swanlab_ready = False
        self._global_step = 0
        self._swanlab_img_step = 0
        # Random visualization budget per validation epoch
        self._swanlab_rand_vis_left = 0
        self.swanlab_rand_vis_per_epoch = int(swanlab_rand_vis_per_epoch)

        if freeze_pretrain:
            self.freeze_pretrain()
        # KP loss enable/weights
        self.kp_enable = bool(kp_enable)
        self.kp_weights = kp_weights or {'cls': 1.0, 'reg': 1.0}
        # ---------- Keypoint branch losses/assigner ----------
        # Default configs (can be customized via config by setattr before training if needed)
        try:
            self.kp_loss_cls = MODELS.build(dict(type='mmdet.CrossEntropyLoss'))
        except Exception:
            # fallback without namescope
            self.kp_loss_cls = MODELS.build(dict(type='CrossEntropyLoss'))
        try:
            self.kp_loss_reg = MODELS.build(dict(type='mmdet.L1Loss'))
        except Exception:
            self.kp_loss_reg = MODELS.build(dict(type='L1Loss'))
        self.kp_assigner = KP_ASSIGNERS.build(dict(
            type='HungarianAssigner_KP',
            cls_cost=dict(type='ClassificationCost', weight=1.0),
            reg_cost=dict(type='BBoxL1Cost', weight=5.0),
            iou_cost=dict(type='IoUCost', iou_mode='giou', weight=0.0)
        ))
    
    def freeze_pretrain(self):
        for m in self.img_backbone.parameters():
            m.requires_grad=False
        for m in self.img_neck.parameters():
            m.requires_grad=False
        for m in self.view_transformers.parameters():
            m.requires_grad=False

    # ---------------------- SwanLab utils ----------------------
    def _is_main_process(self):
        try:
            if not dist.is_available() or not dist.is_initialized():
                return True
            return dist.get_rank() == 0
        except Exception:
            return True

    def _init_swanlab(self, cfg: dict = None):
        if self._swanlab_ready:
            return
        if not self.swanlab_enable or not _SWANLAB_AVAILABLE:
            return
        if not self._is_main_process():
            return
        run_name = self.swanlab_run_name or f'SAR_RNTR_{int(time.time())}'
        try:
            swanlab.init(project=self.swanlab_project,
                         experiment_name=run_name,
                         config=cfg or {})
            self._swanlab_ready = True
        except Exception:
            self._swanlab_ready = False

    @staticmethod
    def _to_float(value):
        try:
            if isinstance(value, (list, tuple)):
                vals = []
                for v in value:
                    if torch.is_tensor(v):
                        vals.append(v.detach().float().mean().item())
                    else:
                        try:
                            vals.append(float(v))
                        except Exception:
                            pass
                return sum(vals) / len(vals) if len(vals) > 0 else None
            if torch.is_tensor(value):
                return value.detach().float().mean().item()
            return float(value)
        except Exception:
            return None

    @staticmethod
    def _gen_dx_bx(xbound, ybound, zbound):
        dx = np.array([row[2] for row in [xbound, ybound, zbound]])
        bx = np.array([row[0] + row[2] / 2.0 for row in [xbound, ybound, zbound]])
        nx = np.floor(np.array([(row[1] - row[0]) / row[2] for row in [xbound, ybound, zbound]]))
        return dx, bx, nx

    def _get_ranges(self):
        try:
            dx, bx, nx = self._gen_dx_bx(self.grid_conf['xbound'], self.grid_conf['ybound'], self.grid_conf['zbound'])
            pc_range = np.concatenate((bx - dx / 2., bx - dx / 2. + nx * dx))
            bz_dx, bz_bx, bz_nx = self._gen_dx_bx(self.bz_grid_conf['xbound'], self.bz_grid_conf['ybound'], self.bz_grid_conf['zbound'])
            bz_pc_range = np.concatenate((bz_bx - bz_dx / 2., bz_bx - bz_dx / 2. + bz_nx * bz_dx))
            return dx, bx, nx, pc_range, bz_dx, bz_bx, bz_nx, bz_pc_range
        except Exception:
            # Fallback to square canvas
            nx = np.array([self.box_range, self.box_range, 1])
            dx = np.array([1.0, 1.0, 1.0])
            pc_range = np.array([-self.box_range/2, -self.box_range/2, -10, self.box_range/2, self.box_range/2, 10])
            return dx, None, nx, pc_range, dx, None, nx, pc_range

    @staticmethod
    def _quadratic_bezier_points(p0, c, p1, num=50):
        t = np.linspace(0.0, 1.0, num).reshape(-1, 1)
        p0 = np.asarray(p0).reshape(1, 2)
        c = np.asarray(c).reshape(1, 2)
        p1 = np.asarray(p1).reshape(1, 2)
        pts = (1 - t) ** 2 * p0 + 2 * (1 - t) * t * c + (t ** 2) * p1
        return pts.astype(np.int32)

    def _render_topology_overlay_graph(self, img_meta: dict, pred_node_list, n_control: int, scale: int = 10,
                                       highlight_boundary: bool = False, clip_control_margin: int = 0):
        try:
            # Compute grid sizes
            dx, bx, nx, pc_range, bz_dx, bz_bx, bz_nx, bz_pc_range = self._get_ranges()
            H = int(nx[1]) * scale
            W = int(nx[0]) * scale
            canvas = np.zeros((H, W, 3), dtype=np.uint8)

            # Build GT graph if available
            gt_graph = None
            try:
                if seq2bznodelist is not None and 'centerline_sequence' in img_meta:
                    gt_seq = np.array(img_meta['centerline_sequence'])
                    gt_nodes = seq2bznodelist(gt_seq, n_control)
                    if convert_coeff_coord is not None:
                        gt_nodes = convert_coeff_coord(gt_nodes, pc_range, dx, bz_pc_range, bz_dx)
                    if EvalMapBzGraph is not None:
                        gt_graph = EvalMapBzGraph(img_meta.get('token', 'gt'), gt_nodes)
            except Exception:
                gt_graph = None

            # Build Pred graph from node list
            pred_graph = None
            try:
                nodes_pred = pred_node_list
                if convert_coeff_coord is not None:
                    nodes_pred = convert_coeff_coord(nodes_pred, pc_range, dx, bz_pc_range, bz_dx)
                if EvalMapBzGraph is not None:
                    pred_graph = EvalMapBzGraph(img_meta.get('token', 'pred'), nodes_pred)
            except Exception:
                pred_graph = None

            # Colors (BGR)
            gt_node_col = (60, 200, 60)
            gt_edge_cont = (60, 220, 60)
            gt_edge_fork = (80, 180, 80)
            pred_node_col = (60, 60, 220)
            pred_edge_cont = (40, 40, 240)
            pred_edge_fork = (120, 120, 255)
            boundary_col = (180, 180, 180)

            def is_boundary_grid(pt_grid):
                x, y = int(pt_grid[0]), int(pt_grid[1])
                max_x = int(nx[0]) - 1
                max_y = int(nx[1]) - 1
                return (x <= 0) or (x >= max_x) or (y <= 0) or (y >= max_y)

            def draw_graph(graph, node_col, edge_cont, edge_fork, thick=3):
                if graph is None:
                    return
                # nodes
                for node in graph.graph_nodelist:
                    if node is None:
                        continue
                    coord_grid = np.array(node.coord)
                    coord = (coord_grid * scale).astype(np.int32)
                    col = node_col
                    if highlight_boundary and is_boundary_grid(coord_grid):
                        col = boundary_col
                    cv2.circle(canvas, (int(coord[0]), int(coord[1])), max(2, int(scale ** 1.2)), col, thickness=-1)
                    cv2.circle(canvas, (int(coord[0]), int(coord[1])), max(2, int(scale ** 1.2)), (0, 0, 0), thickness=2)
                # edges
                for node in graph.graph_nodelist:
                    if node is None:
                        continue
                    p0_grid = np.array(node.coord)
                    p0 = (p0_grid * scale).astype(np.int32)
                    for cnode, coeff in node.childs:
                        p1_grid = np.array(cnode.coord)
                        p1 = (p1_grid * scale).astype(np.int32)
                        c_grid = np.array(coeff)
                        if clip_control_margin > 0:
                            c_grid[0] = np.clip(c_grid[0], clip_control_margin, int(nx[0]) - 1 - clip_control_margin)
                            c_grid[1] = np.clip(c_grid[1], clip_control_margin, int(nx[1]) - 1 - clip_control_margin)
                        cpt = (c_grid * scale).astype(np.int32)
                        base_color = edge_cont if (len(node.childs) == 1 and len(cnode.parents) == 1) else edge_fork
                        col = base_color
                        if highlight_boundary and (is_boundary_grid(p0_grid) or is_boundary_grid(p1_grid)):
                            col = boundary_col
                        pts = self._quadratic_bezier_points(p0, cpt, p1, num=50)
                        if pts.shape[0] >= 2:
                            cv2.polylines(canvas, [pts], False, color=col, thickness=thick)

            # Draw GT then Pred
            draw_graph(gt_graph, gt_node_col, gt_edge_cont, gt_edge_fork, thick=4)
            draw_graph(pred_graph, pred_node_col, pred_edge_cont, pred_edge_fork, thick=3)

            # Annotate
            cv2.putText(canvas, f"Token: {img_meta.get('token','')}", (20, H - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (220, 220, 220), 2, cv2.LINE_AA)
            return canvas
        except Exception:
            return None

    def _render_kp_overlay(self, gt_coords_sample, kp_coords_norm_sample, nx, ny, canvas_size=200):
        try:
            H = W = int(canvas_size)
            canvas = np.zeros((H, W, 3), dtype=np.uint8)
            # draw GT
            gt = np.array(gt_coords_sample, dtype=np.int32)
            if gt.ndim == 1:
                gt = gt.reshape(-1, 2)
            for (x, y) in gt:
                if 0 <= x < nx and 0 <= y < ny:
                    px = int(x * (W - 1) / max(nx - 1, 1))
                    py = int(y * (H - 1) / max(ny - 1, 1))
                    cv2.circle(canvas, (px, py), 1, (0, 255, 0), -1)
            # draw predicted KP
            kps = kp_coords_norm_sample
            if isinstance(kps, torch.Tensor):
                kps = kps.detach().cpu().numpy()
            if kps.ndim == 2 and kps.shape[1] >= 2:
                xs = (kps[:, 1] * (nx - 1)).astype(np.int32)
                ys = (kps[:, 0] * (ny - 1)).astype(np.int32)
                for x, y in zip(xs, ys):
                    px = int(x * (W - 1) / max(nx - 1, 1))
                    py = int(y * (H - 1) / max(ny - 1, 1))
                    if 0 <= px < W and 0 <= py < H:
                        cv2.circle(canvas, (px, py), 2, (255, 0, 0), -1)
            cv2.rectangle(canvas, (0, 0), (154, 28), (32, 32, 32), -1)
            cv2.putText(canvas, 'GT: green', (4, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)
            cv2.putText(canvas, 'KP: blue', (4, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 0, 0), 1, cv2.LINE_AA)
            return canvas
        except Exception:
            return None

    def _render_bev_overlay(self, gt_coords_sample, pred_tokens_sample, clause_length, canvas_size=200):
        try:
            H = W = int(canvas_size)
            canvas = np.zeros((H, W, 3), dtype=np.uint8)
            # Get BEV grid size
            try:
                xbound = self.view_transformers.grid_conf['xbound']
                ybound = self.view_transformers.grid_conf['ybound']
                NX = int((xbound[1] - xbound[0]) / xbound[2])
                NY = int((ybound[1] - ybound[0]) / ybound[2])
            except Exception:
                NX = NY = int(self.box_range)

            def to_px_py(x, y):
                px = int(max(0, min(NX - 1, x)) * (W - 1) / max(NX - 1, 1))
                py = int(max(0, min(NY - 1, y)) * (H - 1) / max(NY - 1, 1))
                return px, py

            # Draw GT points (green) after scaling from grid to canvas
            gt = np.array(gt_coords_sample, dtype=np.int32)
            if gt.ndim == 1:
                gt = gt.reshape(-1, 2)
            for (x, y) in gt:
                px, py = to_px_py(int(x), int(y))
                cv2.circle(canvas, (px, py), 1, (0, 255, 0), -1)

            # Draw Pred points (red) with proper scaling
            pred_xy = []
            T = int(pred_tokens_sample.shape[0])
            max_nodes = T // clause_length
            for i in range(max_nodes):
                idx_x = i * clause_length + 0
                idx_y = i * clause_length + 1
                if idx_y >= T:
                    break
                x = int(pred_tokens_sample[idx_x].item())
                y = int(pred_tokens_sample[idx_y].item())
                px, py = to_px_py(x, y)
                pred_xy.append((px, py))
            for (px, py) in pred_xy:
                cv2.circle(canvas, (px, py), 1, (0, 0, 255), -1)
            cv2.rectangle(canvas, (0, 0), (110, 28), (32, 32, 32), -1)
            cv2.putText(canvas, 'GT: green', (4, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)
            cv2.putText(canvas, 'Pred: red', (4, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 255), 1, cv2.LINE_AA)
            return canvas
        except Exception:
            return None

    def _render_topology_overlay(self, gt_coords_sample, gt_conns_sample, gt_labels_sample, gt_group_ids_pos, pred_tokens_sample, clause_length, canvas_size=200):
        """Render GT and Pred topology (nodes + edges) onto a BEV canvas.
        - GT nodes/edges: green
        - Pred nodes: red; Pred edges colored by label: continue(blue), fork(yellow), merge(orange), start(gray)
        """
        try:
            H = W = int(canvas_size)
            canvas = np.zeros((H, W, 3), dtype=np.uint8)
            # Grid size for coordinate scaling
            try:
                xbound = self.view_transformers.grid_conf['xbound']
                ybound = self.view_transformers.grid_conf['ybound']
                NX = int((xbound[1] - xbound[0]) / xbound[2])
                NY = int((ybound[1] - ybound[0]) / ybound[2])
            except Exception:
                NX = NY = int(self.box_range)

            def to_px_py(x, y):
                px = int(max(0, min(NX - 1, x)) * (W - 1) / max(NX - 1, 1))
                py = int(max(0, min(NY - 1, y)) * (H - 1) / max(NY - 1, 1))
                return px, py

            # Draw GT nodes and edges (green)
            if gt_coords_sample is not None:
                gt = np.array(gt_coords_sample, dtype=np.int32).reshape(-1, 2)
                # nodes
                for (x, y) in gt:
                    px, py = to_px_py(int(x), int(y))
                    cv2.circle(canvas, (px, py), 1, (0, 255, 0), -1)
                # edges (interpret connect semantics correctly)
                if gt_conns_sample is not None:
                    conns = np.array(gt_conns_sample, dtype=np.int32).reshape(-1)
                    labels = np.array(gt_labels_sample, dtype=np.int32).reshape(-1) if gt_labels_sample is not None else None
                    # group ids per node: take every clause_length step from per-token ids
                    gids_nodes = None
                    if gt_group_ids_pos is not None:
                        gids_tokens = np.array(gt_group_ids_pos, dtype=np.int64).reshape(-1)
                        gids_nodes = gids_tokens[0::clause_length]
                    # precompute indices per group for intra-group absolute mapping of 1-based vd
                    group_to_indices = defaultdict(list)
                    if gids_nodes is not None:
                        for idx, gid in enumerate(gids_nodes):
                            group_to_indices[int(gid)].append(idx)

                    N = min(len(gt), len(conns))
                    for i in range(N):
                        j_global = None
                        vd = int(conns[i])
                        lbl = int(labels[i]) if labels is not None else 0
                        # labels: 0=start, 1=continue, 2=fork, 3=merge
                        if lbl == 0:
                            # start: no incoming edge
                            j_global = None
                        elif lbl == 1:
                            # continue: connect to immediate previous node in the same group if possible
                            if i - 1 >= 0:
                                if gids_nodes is None or gids_nodes[i] == gids_nodes[i - 1]:
                                    j_global = i - 1
                        else:
                            # fork/merge: vd is 1-based index inside the same sub-graph
                            if vd > 0 and gids_nodes is not None:
                                gid = int(gids_nodes[i])
                                indices = group_to_indices.get(gid, [])
                                if 0 <= (vd - 1) < len(indices):
                                    j_global = indices[vd - 1]
                        if j_global is not None and 0 <= j_global < N and j_global != i:
                            x1, y1 = gt[i]
                            x2, y2 = gt[j_global]
                            p1 = to_px_py(int(x1), int(y1))
                            p2 = to_px_py(int(x2), int(y2))
                            cv2.line(canvas, p1, p2, (0, 200, 0), 1, cv2.LINE_AA)

            # Parse Pred tokens to nodes, labels, connects
            preds = pred_tokens_sample
            if isinstance(preds, torch.Tensor):
                preds = preds.detach().cpu().numpy()
            T = int(preds.shape[0])
            num_nodes = T // int(clause_length)
            xs, ys, lbls, conns = [], [], [], []
            for i in range(num_nodes):
                idx = i * clause_length
                x = int(preds[idx + 0])
                y = int(preds[idx + 1])
                l = int(preds[idx + 2])
                c = int(preds[idx + 3])
                xs.append(x)
                ys.append(y)
                lbls.append(l)
                conns.append(c)

            # Draw Pred nodes (red)
            for x, y in zip(xs, ys):
                px, py = to_px_py(x, y)
                cv2.circle(canvas, (px, py), 1, (0, 0, 255), -1)

            # Draw Pred edges by label color
            # BGR colors
            color_map = {
                0: (180, 180, 180),  # start
                1: (255, 0, 0),      # continue -> blue
                2: (0, 255, 255),    # fork -> yellow
                3: (0, 165, 255),    # merge -> orange
            }
            for i in range(num_nodes):
                j = int(conns[i])
                if 0 <= j < num_nodes and j != i:
                    x1, y1 = xs[i], ys[i]
                    x2, y2 = xs[j], ys[j]
                    p1 = to_px_py(x1, y1)
                    p2 = to_px_py(x2, y2)
                    col = color_map.get(int(lbls[i]), (255, 255, 255))
                    cv2.line(canvas, p1, p2, col, 1, cv2.LINE_AA)

            # Legend
            cv2.rectangle(canvas, (0, 0), (220, 48), (32, 32, 32), -1)
            cv2.putText(canvas, 'GT nodes/edges: green', (4, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 255, 0), 1, cv2.LINE_AA)
            cv2.putText(canvas, 'Pred nodes: red; edges by type', (4, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (200, 200, 200), 1, cv2.LINE_AA)
            cv2.putText(canvas, 'C:blue F:yellow M:orange', (4, 36), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (200, 200, 200), 1, cv2.LINE_AA)
            return canvas
        except Exception:
            return None

    def _swanlab_log_image(self, name: str, img: np.ndarray, step: int):
        if not (self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process() and self._swanlab_ready):
            return
        try:
            rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            if hasattr(swanlab, 'Image'):
                try:
                    im = swanlab.Image(rgb)
                    swanlab.log({name: im}, step=step)
                    return
                except Exception:
                    pass
            if hasattr(swanlab, 'log_image'):
                try:
                    swanlab.log_image(name, rgb, step=step)
                    return
                except Exception:
                    pass
            tmp_dir = '/tmp/swanlab_vis'
            os.makedirs(tmp_dir, exist_ok=True)
            tmp_path = os.path.join(tmp_dir, f'{name.replace("/", "_")}_{step}.png')
            cv2.imwrite(tmp_path, img)
            try:
                swanlab.log({f'{name}_path': tmp_path}, step=step)
            except Exception:
                pass
        except Exception:
            pass

    def extract_img_feat(self, img, img_metas):
        if isinstance(img, list):
            img = torch.stack(img, dim=0)
        B = img.size(0)
        if img is not None:
            input_shape = img.shape[-2:]
            for img_meta in img_metas:
                img_meta.update(input_shape=input_shape)
            if img.dim() == 5:
                if img.size(0) == 1 and img.size(1) != 1:
                    img.squeeze_()
                else:
                    B, N, C, H, W = img.size()
                    img = img.view(B * N, C, H, W)
            if self.use_grid_mask:
                img = self.grid_mask(img)
            img_feats = self.img_backbone(img)
            if isinstance(img_feats, dict):
                img_feats = list(img_feats.values())
        else:
            return None
        if self.with_img_neck:
            img_feats = self.img_neck(img_feats)
        img_feats_reshaped = []
        for img_feat in img_feats:
            BN, C, H, W = img_feat.size()
            img_feats_reshaped.append(img_feat.view(B, int(BN / B), C, H, W))
        return img_feats_reshaped

    def extract_feat(self, img, img_metas):
        img_feats = self.extract_img_feat(img, img_metas)
        largest_feat_shape = img_feats[0].shape[3]
        down_level = int(np.log2(self.downsample // (self.final_dim[0] // largest_feat_shape)))
        bev_feats = self.view_transformers(img_feats[down_level], img_metas)
        return bev_feats

    def forward_pts_train(self,
                          bev_feats,
                          gt_lines_coords,
                          gt_lines_labels,
                          gt_lines_connects,
                          gt_lines_coeffs,
                          img_metas,
                          num_coeff, ):
        device = bev_feats[0].device
        # Compute BEV grid size for normalization
        try:
            xbound = self.view_transformers.grid_conf['xbound']
            ybound = self.view_transformers.grid_conf['ybound']
            NX = int((xbound[1] - xbound[0]) / xbound[2])
            NY = int((ybound[1] - ybound[0]) / ybound[2])
        except Exception:
            NX = NY = int(self.box_range)
        input_seqs = []
        output_seqs = []
        max_box = max([len(target) for target in gt_lines_coords])
        num_box = max(max_box + 2, self.max_box_num)
        coeff_dim = num_coeff * 2
        for bi in range(len(gt_lines_coords)):
            box = torch.tensor(gt_lines_coords[bi], device=device).long().reshape(-1, 2)
            label = torch.tensor(gt_lines_labels[bi], device=device).long().reshape(-1, 1) + self.category_start
            connect = torch.tensor(gt_lines_connects[bi], device=device).long().reshape(-1, 1) + self.connect_start
            coeff = torch.tensor(gt_lines_coeffs[bi], device=device).long().reshape(-1, coeff_dim) + self.coeff_start
            box_label = torch.cat([box, label, connect, coeff], dim=-1)

            random_box = (torch.rand(num_box - box_label.shape[0], 2).to(device) * (self.box_range - 1)).int()
            random_label = (torch.randint(0, self.num_classes, (num_box - box_label.shape[0], 1)).to(label) + self.category_start)
            random_connect = (torch.randint(0, num_box, (num_box - box_label.shape[0], 1)).to(label) + self.connect_start)
            random_coeff = ((torch.rand(num_box - box_label.shape[0], coeff_dim).to(device) * (self.coeff_range - 1)).int() + self.coeff_start)
            random_box_label = torch.cat([random_box, random_label.int(), random_connect.int(), random_coeff.int()], dim=-1)

            input_seq = torch.cat([box_label, random_box_label], dim=0)
            input_seq = torch.cat([torch.ones(1).to(box_label) * self.start, input_seq.flatten()])
            input_seqs.append(input_seq.unsqueeze(0))

            output_na_x = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known
            output_na_y = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known
            output_noise_label = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.noise_label
            output_noise_connect = torch.ones(num_box - box_label.shape[0], 1).to(input_seq) * self.no_known
            output_noise_coeff = torch.ones(num_box - box_label.shape[0], coeff_dim).to(input_seq) * self.no_known
            output_seq = torch.cat([output_na_x, output_na_y, output_noise_label, output_noise_connect, output_noise_coeff], dim=-1)

            output_seq = torch.cat([box_label.flatten(), torch.ones(1).to(box_label) * self.end, output_seq.flatten()])
            output_seqs.append(output_seq.unsqueeze(0))
        input_seqs = torch.cat(input_seqs, dim=0)
        output_seqs = torch.cat(output_seqs, dim=0)
        # ---------------- SAR FLOW DEBUG (training prep) ----------------
        try:
            B_dbg = int(input_seqs.shape[0])
            print(f"[SAR FLOW] TrainPrep: B={B_dbg}, NX={NX}, NY={NY}, num_coeff={num_coeff}")
            print(f"[SAR FLOW] TrainPrep: input_seqs.shape={tuple(input_seqs.shape)}, output_seqs.shape={tuple(output_seqs.shape)}")
            if isinstance(img_metas, (list, tuple)):
                for bi in range(min(3, B_dbg)):
                    meta = img_metas[bi] if isinstance(img_metas[bi], dict) else {}
                    n_control_meta = meta.get('n_control', None)
                    gpos = meta.get('sar_group_ids_pos', None)
                    gfull = meta.get('sar_group_ids', None)
                    gpos_len = int(len(gpos)) if gpos is not None else None
                    gfull_len = int(len(gfull)) if gfull is not None else None
                    print(f"[SAR FLOW] TrainPrep: meta[{bi}] n_control={n_control_meta}, sar_group_ids_pos_len={gpos_len}, sar_group_ids_len={gfull_len}")
                # Prompt availability across batch
                try:
                    Bm = len(img_metas)
                    n_seq = 0
                    n_pos = 0
                    seq_lens = []
                    pos_lens = []
                    for m in img_metas:
                        md = m if isinstance(m, dict) else {}
                        s = md.get('sd_prompt_seq', None)
                        if s is not None:
                            try:
                                ln = int(len(s))
                            except Exception:
                                ln = None
                            if ln is not None and ln > 0:
                                n_seq += 1
                                seq_lens.append(ln)
                        p = md.get('sd_prompt_pos', None)
                        if p is not None:
                            try:
                                ln2 = int(len(p))
                            except Exception:
                                ln2 = None
                            if ln2 is not None and ln2 > 0:
                                n_pos += 1
                                pos_lens.append(ln2)
                    def _stat(arr):
                        if len(arr) == 0:
                            return 'avg=None min=None max=None'
                        return f"avg={sum(arr)/len(arr):.1f} min={min(arr)} max={max(arr)}"
                    print(f"[SAR FLOW] Prompts: sd_seq={n_seq}/{Bm} ({_stat(seq_lens)}); sd_pos={n_pos}/{Bm} ({_stat(pos_lens)})")
                except Exception as _e:
                    print(f"[SAR FLOW] TrainPrep: prompt stat error: {_e}")
        except Exception as e:
            print(f"[SAR FLOW] TrainPrep: debug print error: {e}")
        # ----------------------------------------------------------------
        # ---------------- NAR-MLM finetuning (optional) ----------------
        # If enabled in head, randomly mask a high ratio of input tokens (excluding [START])
        # and compute loss only on those masked positions by setting non-masked labels to no_known.
        try:
            nar_mlm_train = bool(getattr(self.pts_bbox_head, 'nar_mlm_train', False))
            nar_mask_ratio = float(getattr(self.pts_bbox_head, 'nar_mask_ratio', 0.9))
        except Exception:
            nar_mlm_train = False
            nar_mask_ratio = 0.9
        if nar_mlm_train and input_seqs.shape[1] > 1 and nar_mask_ratio > 0.0:
            B, T = input_seqs.shape
            tail_len = T - 1
            valid_tail = (output_seqs[:, :-1] != self.no_known)
            rand_tail = torch.rand(B, tail_len, device=device)
            mask_tail = (rand_tail < nar_mask_ratio) & valid_tail
            # Ensure at least one masked position per sample when valid exists
            no_any = (~mask_tail.any(dim=1)) & (valid_tail.any(dim=1))
            if no_any.any():
                idxs = torch.nonzero(no_any, as_tuple=False).view(-1)
                for bi in idxs.tolist():
                    vidx = torch.nonzero(valid_tail[bi], as_tuple=False).view(-1)
                    if vidx.numel() > 0:
                        j = int(vidx[torch.randint(0, vidx.numel(), (1,), device=device)])
                        mask_tail[bi, j] = True
            # Apply input masking (keep START)
            tail_in = input_seqs[:, 1:]
            input_seqs = torch.cat(
                [input_seqs[:, :1], torch.where(mask_tail, torch.full_like(tail_in, self.no_known), tail_in)],
                dim=1
            )
            # Filter labels to only masked positions
            tail_lbl = output_seqs[:, :-1]
            tail_lbl = torch.where(mask_tail, tail_lbl, torch.full_like(tail_lbl, self.no_known))
            output_seqs = torch.cat([tail_lbl, output_seqs[:, -1:]], dim=1)
        outputs_logits = self.pts_bbox_head(bev_feats, input_seqs, img_metas)[-1, :, :-1, :]

        clause_length = 4 + coeff_dim
        all_outputs_pos, all_inputs_pos = [], []
        all_outputs_cls, all_inputs_cls = [], []
        all_outputs_connects, all_inputs_connects = [], []
        all_outputs_coeffs, all_inputs_coeffs = [], []
        tit_loss_total = outputs_logits.new_tensor(0.0)
        tit_count = 0

        for bi in range(outputs_logits.shape[0]):
            labels_i = output_seqs[bi, :-1]
            preds_i = outputs_logits[bi]
            end_mask = (labels_i == self.end)
            if end_mask.any():
                keep = ~end_mask
                labels_i = labels_i[keep]
                preds_i = preds_i[keep]
            valid_len = (labels_i.numel() // clause_length) * clause_length
            labels_i = labels_i[:valid_len]
            preds_i = preds_i[:valid_len]

            pos_x_logits = preds_i[0::clause_length, :]
            pos_y_logits = preds_i[1::clause_length, :]
            outputs_pos_i = torch.cat([pos_x_logits, pos_y_logits], dim=0)
            inputs_pos_i = torch.cat([labels_i[0::clause_length], labels_i[1::clause_length]], dim=0)

            outputs_cls_i = preds_i[2::clause_length, :]
            inputs_cls_i = labels_i[2::clause_length]

            outputs_conn_i = preds_i[3::clause_length, :]
            inputs_conn_i = labels_i[3::clause_length]

            coeff_logits_list, coeff_labels_list = [], []
            for k in range(4, clause_length):
                coeff_logits_list.append(preds_i[k::clause_length, :])
                coeff_labels_list.append(labels_i[k::clause_length])
            outputs_coeffs_i = torch.cat(coeff_logits_list, dim=0) if coeff_logits_list else preds_i.new_zeros((0, preds_i.shape[-1]))
            inputs_coeffs_i = torch.cat(coeff_labels_list, dim=0) if coeff_labels_list else labels_i.new_zeros((0,), dtype=labels_i.dtype)

            mask_pos = (inputs_pos_i != self.no_known)
            mask_cls = (inputs_cls_i != self.no_known)
            mask_conn = (inputs_conn_i != self.no_known)
            mask_coeff = (inputs_coeffs_i != self.no_known)

            if self.tit_enable and mask_conn.sum().item() > 1:
                try:
                    logits_conn_valid = outputs_conn_i[mask_conn]
                    labels_conn_valid = inputs_conn_i[mask_conn]
                    gt_coords_sample = torch.tensor(gt_lines_coords[bi], device=preds_i.device).long().view(-1, 2).float()
                    P = logits_conn_valid.shape[0]
                    V = logits_conn_valid.shape[-1]
                    if gt_coords_sample.shape[0] >= 2 and P >= 2:
                        dmat = torch.cdist(gt_coords_sample, gt_coords_sample, p=2)
                        diag_idx = torch.arange(dmat.shape[0], device=dmat.device)
                        dmat[diag_idx, diag_idx] = 1e6
                        K = int(min(max(self.tit_k, 1), max(1, dmat.shape[0] - 1)))
                        log_probs = F.log_softmax(logits_conn_valid, dim=-1)
                        for r in range(P):
                            gt_token = int(labels_conn_valid[r].item())
                            if gt_token < self.connect_start or gt_token >= self.connect_start + gt_coords_sample.shape[0]:
                                continue
                            gt_j = gt_token - self.connect_start
                            neigh_idx = torch.topk(dmat[gt_j], k=K, largest=False).indices.tolist()
                            neigh_idx = [n for n in neigh_idx if n != gt_j]
                            q = logits_conn_valid.new_zeros((V,))
                            alpha = float(self.tit_alpha)
                            q[self.connect_start + gt_j] = 1.0 - alpha
                            if len(neigh_idx) > 0 and alpha > 0:
                                share = alpha / float(len(neigh_idx))
                                for n in neigh_idx:
                                    q[self.connect_start + int(n)] += share
                            tit_loss_total = tit_loss_total + F.kl_div(log_probs[r], q, reduction='batchmean')
                            tit_count += 1
                except Exception:
                    pass

            all_outputs_pos.append(outputs_pos_i[mask_pos])
            all_inputs_pos.append(inputs_pos_i[mask_pos])
            all_outputs_cls.append(outputs_cls_i[mask_cls])
            all_inputs_cls.append(inputs_cls_i[mask_cls])
            all_outputs_connects.append(outputs_conn_i[mask_conn])
            all_inputs_connects.append(inputs_conn_i[mask_conn])
            all_outputs_coeffs.append(outputs_coeffs_i[mask_coeff])
            all_inputs_coeffs.append(inputs_coeffs_i[mask_coeff])

        outputs_pos = torch.cat(all_outputs_pos, dim=0) if len(all_outputs_pos) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_pos = torch.cat(all_inputs_pos, dim=0) if len(all_inputs_pos) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)
        outputs_cls = torch.cat(all_outputs_cls, dim=0) if len(all_outputs_cls) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_cls = torch.cat(all_inputs_cls, dim=0) if len(all_inputs_cls) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)
        outputs_connects = torch.cat(all_outputs_connects, dim=0) if len(all_outputs_connects) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_connects = torch.cat(all_inputs_connects, dim=0) if len(all_inputs_connects) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)
        outputs_coeffs = torch.cat(all_outputs_coeffs, dim=0) if len(all_outputs_coeffs) else outputs_logits.new_zeros((0, self.num_center_classes))
        inputs_coeffs = torch.cat(all_inputs_coeffs, dim=0) if len(all_inputs_coeffs) else output_seqs.new_zeros((0,), dtype=output_seqs.dtype)

        gt_coords = [inputs_pos.long()]
        gt_labels = [inputs_cls.long()]
        gt_connects = [inputs_connects.long()]
        gt_coeffs = [inputs_coeffs.long()]
        preds_dicts = dict(
            preds_coords=[outputs_pos],
            preds_labels=[outputs_cls],
            preds_connects=[outputs_connects],
            preds_coeffs=[outputs_coeffs]
        )
        losses = self.pts_bbox_head.loss_by_feat(gt_coords, gt_labels, gt_connects, gt_coeffs, preds_dicts)
        
        # -------- Keypoint parallel branch losses (Hungarian assign) --------
        if self.kp_enable:
            try:
                kp_cls_logits, kp_coords_norm = self.pts_bbox_head.forward_keypoints(bev_feats, img_metas)
                loss_kp_cls_total = kp_cls_logits.new_tensor(0.0)
                loss_kp_reg_total = kp_cls_logits.new_tensor(0.0)
                total_pos = 0
                for bi in range(kp_cls_logits.shape[0]):
                    cls_pred_i = kp_cls_logits[bi]  # [Q, C]
                    coord_pred_i = kp_coords_norm[bi]  # [Q, 2] in [0,1]
                    # GT
                    gt_xy_i = torch.tensor(gt_lines_coords[bi], device=cls_pred_i.device).long().view(-1, 2).float()
                    gt_lbl_i = torch.tensor(gt_lines_labels[bi], device=cls_pred_i.device).long().view(-1)
                    # Build a meta with bev canvas size to normalize GT inside assigner
                    meta_i = dict(img_shape=(NY, NX))
                    # Switch GT to (y, x) order to align with img_shape=(H,W) normalization in assigner
                    gt_yx_i = torch.stack([gt_xy_i[:, 1], gt_xy_i[:, 0]], dim=-1)
                    assign_result = self.kp_assigner.assign(coord_pred_i, cls_pred_i, gt_yx_i, gt_lbl_i, meta_i)
                    # Access assigned indices
                    gt_inds_attr = getattr(assign_result, 'gt_inds', None)
                    if gt_inds_attr is None:
                        gt_inds_attr = getattr(assign_result, 'assigned_gt_inds', None)
                    if gt_inds_attr is None:
                        continue
                    pos_mask = (gt_inds_attr > 0)
                    if pos_mask.any():
                        pos_idx = gt_inds_attr[pos_mask] - 1
                        # Classification loss on matched
                        loss_kp_cls_total = loss_kp_cls_total + self.kp_loss_cls(cls_pred_i[pos_mask], gt_lbl_i[pos_idx])
                        # Regression L1 on normalized coords (y_norm, x_norm)
                        gt_y_norm = gt_xy_i[:, 1] / float(max(NY - 1, 1))
                        gt_x_norm = gt_xy_i[:, 0] / float(max(NX - 1, 1))
                        gt_xy_norm = torch.stack([gt_y_norm, gt_x_norm], dim=-1).clamp(0, 1)
                        loss_kp_reg_total = loss_kp_reg_total + self.kp_loss_reg(coord_pred_i[pos_mask], gt_xy_norm[pos_idx])
                        total_pos += int(pos_mask.sum().item())
                if total_pos > 0:
                    losses['loss_kp_cls'] = (loss_kp_cls_total / float(total_pos)) * float(self.kp_weights.get('cls', 1.0))
                    losses['loss_kp_reg'] = (loss_kp_reg_total / float(total_pos)) * float(self.kp_weights.get('reg', 1.0))
            except Exception as e:
                print(f"Keypoint loss calculation failed: {e}")
                pass
        
        if self.tit_enable and tit_count > 0:
            losses['loss_tit'] = tit_loss_total / float(tit_count) * self.tit_weight

        try:
            if self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process():
                if not self._swanlab_ready:
                    self._init_swanlab(cfg=dict(model='SAR_RNTR', n_control=num_coeff + 2))
                self._global_step += 1
                if (self._global_step % self.swanlab_log_interval) == 0:
                    metrics = {}
                    for k, v in losses.items():
                        val = self._to_float(v)
                        if val is not None:
                            metrics[k] = val
                    metrics['seq_max_box'] = float(max_box)
                    metrics['seq_num_box'] = float(num_box)
                    if len(metrics) > 0:
                        swanlab.log(metrics, step=self._global_step)
                if (self._global_step % self.swanlab_image_interval) == 0:
                    try:
                        pred_tokens0 = outputs_logits[0].detach().argmax(dim=-1)
                        bev_img = self._render_bev_overlay(gt_lines_coords[0], pred_tokens0, clause_length=clause_length, canvas_size=self.box_range)
                        if bev_img is not None:
                            self._swanlab_log_image('vis/bev_overlay', bev_img, step=self._global_step)
                        if self.kp_enable:
                            try:
                                kp_cls_logits_v, kp_coords_norm_v = self.pts_bbox_head.forward_keypoints(bev_feats, img_metas)
                                kp_img = self._render_kp_overlay(gt_lines_coords[0], kp_coords_norm_v[0], NX, NY, canvas_size=self.box_range)
                                if kp_img is not None:
                                    self._swanlab_log_image('vis/kp_overlay', kp_img, step=self._global_step)
                            except Exception:
                                pass
                    except Exception:
                        pass
        except Exception:
            pass
        return losses
    
    def loss(self,
             inputs=None,
             data_samples=None,**kwargs):
        img = inputs['img']
        img_metas = [ds.metainfo for ds in data_samples]
        bev_feats = self.extract_feat(img=img, img_metas=img_metas)
        if self.bev_scale != 1.0:
            b, c, h, w = bev_feats.shape
            bev_feats = F.interpolate(bev_feats, (int(h * self.bev_scale), int(w * self.bev_scale)))
        gt_lines_coords = [img_meta['centerline_coord'] for img_meta in img_metas]
        gt_lines_labels = [img_meta['centerline_label'] for img_meta in img_metas]
        gt_lines_connects = [img_meta['centerline_connect'] for img_meta in img_metas]
        gt_lines_coeffs = [img_meta['centerline_coeff'] for img_meta in img_metas]
        n_control = img_metas[0]['n_control']
        num_coeff = n_control - 2
        losses_pts = self.forward_pts_train(bev_feats, gt_lines_coords, gt_lines_labels, 
                                            gt_lines_connects, gt_lines_coeffs,
                                            img_metas, num_coeff)
        return losses_pts
    
    def predict(self, batch_inputs_dict, batch_data_samples, **kwargs):
        batch_input_metas = [item.metainfo for item in batch_data_samples]
        batch_input_imgs = batch_inputs_dict['img']
        return self.simple_test(batch_input_metas, batch_input_imgs)

    def simple_test_pts(self, pts_feats, img_metas):
        n_control = img_metas[0]['n_control']
        num_coeff = n_control - 2
        clause_length = 4 + num_coeff * 2
        device = pts_feats[0].device
        B = len(img_metas)
        input_seqs = (torch.ones(B, 1, device=device) * self.start).long()
        outs = self.pts_bbox_head(pts_feats, input_seqs, img_metas)
        output_seqs, values = outs
        line_results = []
        for bi in range(output_seqs.shape[0]):
            pred_line_seq = output_seqs[bi]
            # Debug: check sequence before processing
            print(f"\n[DEBUG] Sample {bi}:")
            print(f"  Raw sequence length: {len(pred_line_seq)}")
            print(f"  First 20 tokens: {pred_line_seq[:20].tolist()}")
            
            pred_line_seq = pred_line_seq[1:]
            
            # Filter out NO_KNOWN tokens first (NAR may not refine all positions)
            valid_mask = (pred_line_seq != self.no_known)
            # Find first NO_KNOWN or END
            if self.end in pred_line_seq:
                stop_idx = (pred_line_seq == self.end).nonzero(as_tuple=True)[0][0]
                print(f"  Found END token at position {stop_idx}")
            elif (~valid_mask).any():
                # Stop at first NO_KNOWN
                first_unknown = (~valid_mask).nonzero(as_tuple=True)[0][0]
                stop_idx = first_unknown
                print(f"  No END token, stopping at first NO_KNOWN at position {stop_idx}")
            else:
                stop_idx = len(pred_line_seq)
                print(f"  No END or NO_KNOWN, using full length {stop_idx}")
            
            stop_idx = stop_idx // clause_length * clause_length
            pred_line_seq = pred_line_seq[:stop_idx]
            print(f"  After END filtering: {len(pred_line_seq)} tokens, {len(pred_line_seq)//clause_length} nodes")
            print(f"  no_known count: {(pred_line_seq == self.no_known).sum().item()}")
            
            pred_line_seq[2::clause_length] = pred_line_seq[2::clause_length] - self.category_start
            pred_line_seq[3::clause_length] = pred_line_seq[3::clause_length] - self.connect_start
            for k in range(4, clause_length):
                pred_line_seq[k::clause_length] = pred_line_seq[k::clause_length] - self.coeff_start
            try:
                xbound = self.view_transformers.grid_conf['xbound']
                ybound = self.view_transformers.grid_conf['ybound']
                NX = int((xbound[1] - xbound[0]) / xbound[2])
                NY = int((ybound[1] - ybound[0]) / ybound[2])
                pred_line_seq[0::clause_length] = pred_line_seq[0::clause_length].clamp(0, NX - 1)
                pred_line_seq[1::clause_length] = pred_line_seq[1::clause_length].clamp(0, NY - 1)
                if self.inference_sanitation:
                    # Additional sanitation (align with AR_RNTR) to stabilize topology
                    # 1) Clamp class tokens to valid range [0 .. num_classes-1]
                    pred_line_seq[2::clause_length] = pred_line_seq[2::clause_length].clamp(0, self.num_classes - 1)
                    # 2) Clamp Bezier control coefficient tokens to training range [0 .. coeff_range-1]
                    if self.coeff_range is not None and self.coeff_range > 0:
                        for k in range(4, clause_length):
                            pred_line_seq[k::clause_length] = pred_line_seq[k::clause_length].clamp(0, self.coeff_range - 1)
                # 3) Map group-local 1-based connect (vd) to global indices using SAR meta groups
                #    Always run mapping for semantic correctness, independent of sanitation flag.
                try:
                    num_nodes = int(pred_line_seq.numel() // clause_length)
                    if num_nodes > 0:
                        # Expand positive-only group ids to full length [T]
                        def _expand_group_ids_from_pos_full(T: int, clause_len: int, sar_pos_ids):
                            if sar_pos_ids is None:
                                return None
                            if not torch.is_tensor(sar_pos_ids):
                                sar_pos = torch.as_tensor(sar_pos_ids, device=pred_line_seq.device, dtype=torch.long)
                            else:
                                sar_pos = sar_pos_ids.to(pred_line_seq.device).long()
                            gids = torch.zeros((T,), device=pred_line_seq.device, dtype=torch.long)
                            pos_len = int(min(int(sar_pos.numel()), T))
                            max_gid = 0
                            if pos_len > 0:
                                gids[0:pos_len] = sar_pos[:pos_len]
                                max_gid = int(sar_pos[:pos_len].max().item())
                            extra_tokens = T - pos_len
                            if extra_tokens > 0 and clause_len > 0:
                                num_extra_clauses = (extra_tokens + clause_len - 1) // clause_len
                                base = pos_len
                                for ii in range(num_extra_clauses):
                                    s = base + ii * clause_len
                                    e = min(s + clause_len, T)
                                    gids[s:e] = max_gid + 1 + ii
                            return gids

                        T = int(pred_line_seq.numel())
                        meta = img_metas[bi] if isinstance(img_metas, (list, tuple)) else {}
                        sar_pos_ids = meta.get('sar_group_ids_pos', None) if isinstance(meta, dict) else None
                        gids_full = _expand_group_ids_from_pos_full(T, clause_length, sar_pos_ids) if sar_pos_ids is not None else None
                        seq_clone = pred_line_seq.clone()
                        # Build group->node index list from expanded per-token ids
                        group_to_indices = {}
                        if gids_full is not None:
                            gids_nodes = gids_full[0::clause_length]
                            for idx in range(num_nodes):
                                gid = int(gids_nodes[idx].item())
                                group_to_indices.setdefault(gid, []).append(idx)

                        # Diagnostics (validation/inference): only print for first sample to limit verbosity
                        diag = (bi == 0)
                        if diag:
                            num_groups = len(group_to_indices)
                            if num_groups > 0:
                                _sizes = [len(v) for v in group_to_indices.values()]
                                _gmin, _gmax = min(_sizes), max(_sizes)
                                _gavg = float(sum(_sizes)) / float(len(_sizes))
                            else:
                                _gmin = _gmax = 0
                                _gavg = 0.0
                            print(f"  [TopoDiag] gids_full={'None' if gids_full is None else 'OK'} | groups={num_groups} | size(min/avg/max)=({_gmin}/{_gavg:.1f}/{_gmax})")

                        # Whether to use group-based connect mapping (default: False for unified global indexing)
                        use_group_map = bool(getattr(self, 'use_group_connect_mapping', False))
                        if diag:
                            print(f"  [TopoDiag] use_group_map={use_group_map}")

                        # Counters for mapping behavior
                        mapping_cnt = 0
                        fallback_cnt = 0
                        future_fix_cnt = 0
                        fork_merge_cnt = 0
                        continue_cnt = 0
                        conn_pre_min = 1e9
                        conn_pre_max = -1e9
                        post_prev_cnt = 0

                        for i in range(num_nodes):
                            lbl = int(seq_clone[2 + i * clause_length].item())  # 0:start,1:continue,2:fork,3:merge
                            conn_pos = 3 + i * clause_length
                            if i == 0:
                                seq_clone[conn_pos] = 0
                                continue
                            c = int(seq_clone[conn_pos].item())
                            # track pre-mapping connect token range (for diagnostics)
                            if c < conn_pre_min:
                                conn_pre_min = c
                            if c > conn_pre_max:
                                conn_pre_max = c

                            if lbl == 1:
                                # continue: immediate previous
                                continue_cnt += 1
                                j = i - 1
                            elif lbl in (2, 3):
                                fork_merge_cnt += 1
                                if not use_group_map:
                                    # Unified global connect semantics: clamp to [0..i-1]
                                    j = max(0, min(c, i - 1))
                                elif c > 0 and gids_full is not None:
                                    gid = int(gids_full[0 + i * clause_length].item())
                                    lst = group_to_indices.get(gid, [])
                                    # Map 1-based vd to 0-based index within same-group node list
                                    j = lst[c - 1] if 0 <= (c - 1) < len(lst) else (i - 1)
                                    mapping_cnt += 1 if 0 <= (c - 1) < len(lst) else 0
                                    # ensure referencing prior node
                                    if j >= i:
                                        future_fix_cnt += 1
                                        j = i - 1
                                else:
                                    # no mapping available: fallback clamp
                                    fallback_cnt += 1
                                    j = max(0, min(c, i - 1))
                            else:
                                # start or invalid label: fallback clamp
                                j = max(0, min(c, i - 1))

                            if j == i - 1:
                                post_prev_cnt += 1
                            seq_clone[conn_pos] = j
                        if diag:
                            total_non_start = max(0, num_nodes - 1)
                            post_prev_ratio = (post_prev_cnt / float(total_non_start)) if total_non_start > 0 else 0.0
                            _cmin = int(conn_pre_min) if conn_pre_min != 1e9 else 0
                            _cmax = int(conn_pre_max) if conn_pre_max != -1e9 else 0
                            if fork_merge_cnt > 0:
                                used_ratio = mapping_cnt / float(fork_merge_cnt)
                            else:
                                used_ratio = 0.0
                            print(f"  [TopoDiag] cont={continue_cnt}, fork+merge={fork_merge_cnt}, used_group_map={mapping_cnt} ({used_ratio:.1%}), fallback={fallback_cnt}, future_fix={future_fix_cnt}, post_prev_ratio={post_prev_ratio:.2f}, conn_pre[min,max]=({_cmin},{_cmax})")

                        pred_line_seq = seq_clone
                except Exception:
                    # Fallback to conservative clamp behavior
                    num_nodes = int(pred_line_seq.numel() // clause_length)
                    if num_nodes > 0:
                        seq_clone = pred_line_seq.clone()
                        for i in range(num_nodes):
                            conn_pos = 3 + i * clause_length
                            if i == 0:
                                seq_clone[conn_pos] = 0
                            else:
                                j = int(seq_clone[conn_pos].item())
                                seq_clone[conn_pos] = max(0, min(j, i - 1))
                        pred_line_seq = seq_clone
            except Exception as e:
                print(f"  [ERROR] Connect mapping failed: {e}")
                pass
            
            # Parse to node list
            pred_node_list = av2seq2bznodelist(pred_line_seq.detach().cpu().numpy(), n_control, self.epsilon)
            print(f"  Parsed node_list length: {len(pred_node_list)}")
            if len(pred_node_list) > 0:
                print(f"  First node: {pred_node_list[0]}")
                # Check coordinate statistics
                coords = [node['coord'] for node in pred_node_list if node.get('coord') is not None]
                if coords:
                    coords_array = np.array(coords)
                    print(f"  Coord range: x=[{coords_array[:, 0].min():.1f}, {coords_array[:, 0].max():.1f}], "
                          f"y=[{coords_array[:, 1].min():.1f}, {coords_array[:, 1].max():.1f}]")
                    print(f"  Coord mean: x={coords_array[:, 0].mean():.1f}, y={coords_array[:, 1].mean():.1f}")
                # Check node types distribution
                types = [node.get('sque_type', 'unknown') for node in pred_node_list]
                from collections import Counter
                type_counts = Counter(types)
                print(f"  Node types: {dict(type_counts)}")
            else:
                print(f"  [WARNING] Empty node_list! Sequence might be invalid.")
            
            line_results.append(dict(
                line_seqs = pred_line_seq.detach().cpu(),
                pred_node_lists = pred_node_list
            ))
        return line_results

    def _clean_tokens_for_vis(self, pred_tokens_sample, clause_length: int):
        """Visualization-only cleaning for prettier topology overlays.
        This does NOT affect evaluation outputs.

        Rules:
        - start: connect=0
        - continue: connect=i-1
        - fork/merge: if connect invalid (<0 or >=i) fallback to i-1
        """
        try:
            if isinstance(pred_tokens_sample, torch.Tensor):
                seq = pred_tokens_sample.clone()
            else:
                seq = torch.as_tensor(pred_tokens_sample)
            num_nodes = int(seq.numel() // clause_length)
            if num_nodes <= 0:
                return seq
            for i in range(num_nodes):
                lbl = int(seq[2 + i * clause_length].item())  # 0:start,1:continue,2:fork,3:merge
                conn_pos = 3 + i * clause_length
                if i == 0:
                    seq[conn_pos] = 0
                    continue
                if lbl == 1:
                    seq[conn_pos] = i - 1
                else:
                    j = int(seq[conn_pos].item())
                    if j >= i or j < 0:
                        seq[conn_pos] = i - 1
            return seq
        except Exception:
            return pred_tokens_sample

    def simple_test(self, img_metas, img=None):
        bev_feats = self.extract_feat(img=img, img_metas=img_metas)
        bbox_list = [dict() for i in range(len(img_metas))]
        line_results = self.simple_test_pts(
            bev_feats, img_metas)
        for result_dict, line_result, img_meta in zip(bbox_list, line_results, img_metas):
            result_dict['line_results'] = line_result
            result_dict['token'] = img_meta['token']
        try:
            if self.swanlab_enable and _SWANLAB_AVAILABLE and self._is_main_process():
                if not self._swanlab_ready:
                    self._init_swanlab(cfg=dict(model='SAR_RNTR', phase='val'))
                self._swanlab_img_step += 1
                if (self._swanlab_img_step % self.swanlab_image_interval) == 0:
                    try:
                        n_control = img_metas[0].get('n_control', 3)
                        clause_length = 4 + (int(n_control) - 2) * 2
                        pred_tokens0 = line_results[0]['line_seqs']
                        gt_coords0 = img_metas[0].get('centerline_coord', None)
                        bev_img = self._render_bev_overlay(gt_coords0 if gt_coords0 is not None else [],
                                                           pred_tokens0,
                                                           clause_length=clause_length,
                                                           canvas_size=self.box_range)
                        if bev_img is not None:
                            self._swanlab_log_image('vis/bev_overlay', bev_img, step=self._swanlab_img_step)
                    except Exception:
                        pass
                # Random topology visualization: reset budget at start of val (sample_idx==0)
                try:
                    sample_idx0 = int(img_metas[0].get('sample_idx', -1))
                    if sample_idx0 == 0:
                        self._swanlab_rand_vis_left = int(getattr(self, 'swanlab_rand_vis_per_epoch', 10))
                except Exception:
                    pass
                # If budget remains, randomly sample up to budget items from this batch and log topology overlay
                try:
                    if self._swanlab_rand_vis_left > 0:
                        n_control = img_metas[0].get('n_control', 3)
                        clause_length = 4 + (int(n_control) - 2) * 2
                        B = len(line_results)
                        k = max(0, min(self._swanlab_rand_vis_left, B, 10))
                        if k > 0:
                            idxs = random.sample(list(range(B)), k)
                            for idx in idxs:
                                # Preferred: graph-based overlay aligned with tools/vis.py
                                # RAW
                                topo_img_raw = None
                                try:
                                    if 'pred_node_lists' in line_results[idx]:
                                        pred_nodes_i = line_results[idx]['pred_node_lists']
                                        topo_img_raw = self._render_topology_overlay_graph(
                                            img_metas[idx], pred_nodes_i, n_control, scale=10)
                                except Exception:
                                    topo_img_raw = None
                                # Fallback raw: token-based overlay
                                if topo_img_raw is None:
                                    try:
                                        pred_tokens_i = line_results[idx]['line_seqs']
                                        gt_coords_i = img_metas[idx].get('centerline_coord', None)
                                        gt_conns_i = img_metas[idx].get('centerline_connect', None)
                                        gt_labels_i = img_metas[idx].get('centerline_label', None)
                                        gt_group_ids_pos_i = img_metas[idx].get('sar_group_ids_pos', None)
                                        topo_img_raw = self._render_topology_overlay(
                                            gt_coords_i if gt_coords_i is not None else [],
                                            gt_conns_i if gt_conns_i is not None else [],
                                            gt_labels_i if gt_labels_i is not None else [],
                                            gt_group_ids_pos_i if gt_group_ids_pos_i is not None else [],
                                            pred_tokens_i,
                                            clause_length=clause_length,
                                            canvas_size=self.box_range)
                                    except Exception:
                                        topo_img_raw = None
                                if topo_img_raw is not None:
                                    self._swanlab_log_image('vis/topology_overlay_raw', topo_img_raw, step=self._swanlab_img_step)
                                    self._swanlab_rand_vis_left -= 1
                                    if self._swanlab_rand_vis_left <= 0:
                                        break

                                # CLEAN (visualization-only, does not affect outputs)
                                topo_img_clean = None
                                try:
                                    pred_tokens_i = line_results[idx]['line_seqs']
                                    vis_tokens = self._clean_tokens_for_vis(pred_tokens_i, clause_length)
                                    # Prefer graph overlay for cleaned tokens
                                    try:
                                        pred_nodes_clean = av2seq2bznodelist(vis_tokens.detach().cpu().numpy(), n_control, self.epsilon)
                                    except Exception:
                                        pred_nodes_clean = None
                                    if pred_nodes_clean is not None:
                                        topo_img_clean = self._render_topology_overlay_graph(
                                            img_metas[idx], pred_nodes_clean, n_control, scale=10)
                                except Exception:
                                    topo_img_clean = None
                                if topo_img_clean is None:
                                    try:
                                        gt_coords_i = img_metas[idx].get('centerline_coord', None)
                                        gt_conns_i = img_metas[idx].get('centerline_connect', None)
                                        gt_labels_i = img_metas[idx].get('centerline_label', None)
                                        gt_group_ids_pos_i = img_metas[idx].get('sar_group_ids_pos', None)
                                        topo_img_clean = self._render_topology_overlay(
                                            gt_coords_i if gt_coords_i is not None else [],
                                            gt_conns_i if gt_conns_i is not None else [],
                                            gt_labels_i if gt_labels_i is not None else [],
                                            gt_group_ids_pos_i if gt_group_ids_pos_i is not None else [],
                                            vis_tokens,
                                            clause_length=clause_length,
                                            canvas_size=self.box_range)
                                    except Exception:
                                        topo_img_clean = None
                                if topo_img_clean is not None:
                                    self._swanlab_log_image('vis/topology_overlay_clean', topo_img_clean, step=self._swanlab_img_step)
                                    self._swanlab_rand_vis_left -= 1
                                    if self._swanlab_rand_vis_left <= 0:
                                        break
                except Exception:
                    pass
        except Exception:
            pass
        return bbox_list
