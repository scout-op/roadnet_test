"""
Dynamic Loss Weight Scheduling Hook for Two-Stage Training.

Stage 1 (Geometry-focused): Prioritize coords and coeffs
Stage 2 (Balanced): Balance all tasks
"""
from mmengine.hooks import Hook
from mmengine.registry import HOOKS


@HOOKS.register_module()
class DynamicLossWeightHook(Hook):
    """
    Dynamically adjust loss weights during training.
    
    Args:
        stage1_steps (int): Number of steps for Stage 1 (geometry-focused).
        stage2_steps (int): When to start Stage 2 (balanced). If None, use stage1_steps.
        stage1_weights (dict): Loss weights for Stage 1.
        stage2_weights (dict): Loss weights for Stage 2.
        smooth_transition_steps (int): Steps to smoothly transition between stages.
    
    Example config:
        dict(
            type='DynamicLossWeightHook',
            stage1_steps=800,
            stage1_weights=dict(
                loss_coords=1.5,
                loss_coeffs=1.5,
                loss_connects=1.0,
                loss_labels=1.0
            ),
            stage2_weights=dict(
                loss_coords=1.2,
                loss_coeffs=1.8,
                loss_connects=1.3,
                loss_labels=1.0
            ),
            smooth_transition_steps=100,
            priority=40,  # Run early, before training
        )
    """
    
    def __init__(
        self,
        stage1_steps=800,
        stage2_steps=None,
        stage1_weights=None,
        stage2_weights=None,
        smooth_transition_steps=0,
    ):
        self.stage1_steps = stage1_steps
        self.stage2_steps = stage2_steps if stage2_steps is not None else stage1_steps
        self.smooth_transition_steps = smooth_transition_steps
        
        # Default weights if not specified
        self.stage1_weights = stage1_weights or dict(
            loss_coords=1.5,
            loss_coeffs=1.5,
            loss_connects=1.0,
            loss_labels=1.0
        )
        
        self.stage2_weights = stage2_weights or dict(
            loss_coords=1.2,
            loss_coeffs=1.8,
            loss_connects=1.3,
            loss_labels=1.0
        )
        
        self.current_stage = 1
        self._logged_stage_change = False
        
    def before_train(self, runner):
        """Log the weight scheduling plan."""
        runner.logger.info("\n" + "="*80)
        runner.logger.info("[DynamicLossWeight] Two-Stage Training Plan:")
        runner.logger.info("="*80)
        runner.logger.info(f"Stage 1 (0-{self.stage1_steps} steps): Geometry-focused")
        for k, v in self.stage1_weights.items():
            runner.logger.info(f"  {k}: {v}")
        runner.logger.info(f"\nStage 2 ({self.stage2_steps}+ steps): Balanced")
        for k, v in self.stage2_weights.items():
            runner.logger.info(f"  {k}: {v}")
        if self.smooth_transition_steps > 0:
            runner.logger.info(f"\nSmooth transition: {self.smooth_transition_steps} steps")
        runner.logger.info("="*80 + "\n")
    
    def before_train_iter(self, runner, batch_idx, data_batch=None):
        """Adjust loss weights based on current iteration."""
        
        # Get current iteration (global step)
        current_iter = runner.iter
        
        # Determine current stage
        old_stage = self.current_stage
        
        if current_iter < self.stage1_steps:
            self.current_stage = 1
            target_weights = self.stage1_weights
        else:
            self.current_stage = 2
            target_weights = self.stage2_weights
        
        # Log stage change
        if self.current_stage != old_stage and not self._logged_stage_change:
            runner.logger.info("\n" + "🔄"*40)
            runner.logger.info(f"[DynamicLossWeight] Switching to Stage {self.current_stage} at iter {current_iter}")
            runner.logger.info("New weights:")
            for k, v in target_weights.items():
                runner.logger.info(f"  {k}: {v}")
            runner.logger.info("🔄"*40 + "\n")
            self._logged_stage_change = True
        
        # Apply weights with smooth transition
        if self.smooth_transition_steps > 0 and self.current_stage == 2:
            # Calculate interpolation factor
            steps_into_stage2 = current_iter - self.stage2_steps
            if steps_into_stage2 < self.smooth_transition_steps:
                alpha = steps_into_stage2 / self.smooth_transition_steps
                # Interpolate between stage1 and stage2 weights
                weights = {}
                for key in target_weights.keys():
                    w1 = self.stage1_weights.get(key, 1.0)
                    w2 = self.stage2_weights.get(key, 1.0)
                    weights[key] = w1 * (1 - alpha) + w2 * alpha
            else:
                weights = target_weights
        else:
            weights = target_weights
        
        # Apply weights to model's loss configuration
        model = runner.model
        if hasattr(model, 'module'):  # DDP wrapped
            model = model.module
        
        # Update loss weights in pts_bbox_head
        if hasattr(model, 'pts_bbox_head'):
            head = model.pts_bbox_head
            
            # Update each loss weight
            for loss_name, weight in weights.items():
                loss_attr = loss_name  # e.g., 'loss_coords'
                
                if hasattr(head, loss_attr):
                    loss_module = getattr(head, loss_attr)
                    
                    # MMDet loss modules have loss_weight attribute
                    if hasattr(loss_module, 'loss_weight'):
                        old_weight = loss_module.loss_weight
                        loss_module.loss_weight = weight
                        
                        # Log weight change only when significantly different
                        if abs(old_weight - weight) > 0.01 and batch_idx % 100 == 0:
                            runner.logger.info(
                                f"[DynamicLossWeight] {loss_name}: {old_weight:.2f} → {weight:.2f}"
                            )
                    else:
                        # Fallback: try to set as attribute
                        try:
                            setattr(loss_module, 'loss_weight', weight)
                        except:
                            pass  # Skip if can't set


@HOOKS.register_module()
class CurriculumLossWeightHook(Hook):
    """
    Curriculum learning approach: gradually increase task difficulty.
    
    Start with geometry, slowly introduce topology.
    
    Example:
        dict(
            type='CurriculumLossWeightHook',
            warmup_steps=500,
            total_steps=3000,
            initial_weights=dict(
                loss_coords=2.0,
                loss_coeffs=2.0,
                loss_connects=0.5,  # Start low
            ),
            final_weights=dict(
                loss_coords=1.2,
                loss_coeffs=1.8,
                loss_connects=1.5,  # End high
            ),
        )
    """
    
    def __init__(
        self,
        warmup_steps=500,
        total_steps=3000,
        initial_weights=None,
        final_weights=None,
    ):
        self.warmup_steps = warmup_steps
        self.total_steps = total_steps
        
        self.initial_weights = initial_weights or dict(
            loss_coords=2.0,
            loss_coeffs=2.0,
            loss_connects=0.5,
            loss_labels=1.0
        )
        
        self.final_weights = final_weights or dict(
            loss_coords=1.2,
            loss_coeffs=1.8,
            loss_connects=1.5,
            loss_labels=1.0
        )
    
    def before_train(self, runner):
        """Log curriculum plan."""
        runner.logger.info("\n" + "="*80)
        runner.logger.info("[CurriculumLossWeight] Curriculum Learning Plan:")
        runner.logger.info("="*80)
        runner.logger.info(f"Warmup: 0-{self.warmup_steps} steps")
        runner.logger.info(f"Curriculum: {self.warmup_steps}-{self.total_steps} steps")
        runner.logger.info("\nInitial weights:")
        for k, v in self.initial_weights.items():
            runner.logger.info(f"  {k}: {v}")
        runner.logger.info("\nFinal weights:")
        for k, v in self.final_weights.items():
            runner.logger.info(f"  {k}: {v}")
        runner.logger.info("="*80 + "\n")
    
    def before_train_iter(self, runner, batch_idx, data_batch=None):
        """Gradually adjust weights using cosine schedule."""
        current_iter = runner.iter
        
        if current_iter < self.warmup_steps:
            # Warmup phase: use initial weights
            weights = self.initial_weights
        elif current_iter < self.total_steps:
            # Curriculum phase: cosine interpolation
            import math
            progress = (current_iter - self.warmup_steps) / (self.total_steps - self.warmup_steps)
            # Cosine schedule: slow start, fast middle, slow end
            alpha = (1 - math.cos(progress * math.pi)) / 2
            
            weights = {}
            for key in self.initial_weights.keys():
                w_init = self.initial_weights.get(key, 1.0)
                w_final = self.final_weights.get(key, 1.0)
                weights[key] = w_init * (1 - alpha) + w_final * alpha
        else:
            # Final phase: use final weights
            weights = self.final_weights
        
        # Apply weights (same as DynamicLossWeightHook)
        model = runner.model
        if hasattr(model, 'module'):
            model = model.module
        
        if hasattr(model, 'pts_bbox_head'):
            head = model.pts_bbox_head
            for loss_name, weight in weights.items():
                if hasattr(head, loss_name):
                    loss_module = getattr(head, loss_name)
                    if hasattr(loss_module, 'loss_weight'):
                        loss_module.loss_weight = weight
