"""
Custom Hook to monitor AMP loss scaling and detect training anomalies.
"""
import torch
from mmengine.hooks import Hook
from mmengine.registry import HOOKS


@HOOKS.register_module()
class AMPMonitorHook(Hook):
    """
    Monitor AMP loss scale and detect potential issues.
    
    Args:
        log_interval (int): Interval to log AMP scale. Default: 50.
        spike_threshold (float): Threshold to detect loss spikes. Default: 15.0.
    """
    
    def __init__(self, log_interval=50, spike_threshold=15.0):
        self.log_interval = log_interval
        self.spike_threshold = spike_threshold
        self.last_scale = None
        self.scale_history = []
        
    def after_train_iter(self, runner, batch_idx, data_batch=None, outputs=None):
        """Called after every training iteration."""
        
        # Get AMP loss scale if available
        optim_wrapper = runner.optim_wrapper
        loss_scale = None
        
        # Try multiple ways to access scale
        try:
            # Method 1: MMEngine AmpOptimWrapper with fixed scale
            if hasattr(optim_wrapper, 'loss_scale'):
                loss_scale = optim_wrapper.loss_scale
            # Method 2: Check for scaler (GradScaler)
            elif hasattr(optim_wrapper, 'scaler'):
                if hasattr(optim_wrapper.scaler, 'get_scale'):
                    loss_scale = optim_wrapper.scaler.get_scale()
                elif hasattr(optim_wrapper.scaler, '_scale'):
                    loss_scale = optim_wrapper.scaler._scale
            # Method 3: Direct _scale attribute
            elif hasattr(optim_wrapper, '_scale'):
                loss_scale = optim_wrapper._scale
            # Method 4: Check optimizer wrapper type
            elif hasattr(optim_wrapper, '__class__'):
                class_name = optim_wrapper.__class__.__name__
                if 'Amp' in class_name:
                    # AmpOptimWrapper detected but can't read scale
                    # This means it's using fixed scale (which we set to 512.0)
                    loss_scale = 512.0  # Use configured value
        except Exception as e:
            pass  # Fail silently
        
        # Log at intervals
        if batch_idx % self.log_interval == 0:
            if loss_scale is not None:
                runner.logger.info(f"[AMP Monitor] Iter {batch_idx}: loss_scale = {loss_scale}")
                
                # Detect sudden scale changes
                if self.last_scale is not None:
                    scale_change_ratio = loss_scale / self.last_scale
                    if scale_change_ratio < 0.5:
                        runner.logger.warning(
                            f"[AMP Monitor] ⚠️ Loss scale dropped significantly: "
                            f"{self.last_scale} → {loss_scale} (ratio={scale_change_ratio:.2f})"
                        )
                    elif scale_change_ratio > 2.0:
                        runner.logger.warning(
                            f"[AMP Monitor] ⚠️ Loss scale increased significantly: "
                            f"{self.last_scale} → {loss_scale} (ratio={scale_change_ratio:.2f})"
                        )
                
                self.last_scale = loss_scale
                self.scale_history.append((batch_idx, loss_scale))
        
        # Check for loss spikes
        if outputs is not None and 'loss' in outputs:
            total_loss = outputs['loss'].item() if torch.is_tensor(outputs['loss']) else outputs['loss']
            
            if total_loss > self.spike_threshold:
                runner.logger.error(
                    f"\n{'='*80}\n"
                    f"[AMP Monitor] 🔴 LOSS SPIKE DETECTED at iter {batch_idx}!\n"
                    f"  Total Loss: {total_loss:.4f}\n"
                    f"  Current AMP scale: {loss_scale}\n"
                    f"  Last AMP scale: {self.last_scale}\n"
                    f"{'='*80}\n"
                )
                
                # Log detailed loss breakdown
                for key, value in outputs.items():
                    if 'loss' in key and torch.is_tensor(value):
                        runner.logger.error(f"    {key}: {value.item():.4f}")
        
        # Check for NaN/Inf
        if outputs is not None:
            for key, value in outputs.items():
                if torch.is_tensor(value):
                    if torch.isnan(value).any():
                        runner.logger.error(
                            f"[AMP Monitor] 🔴 NaN detected in {key} at iter {batch_idx}!"
                        )
                    if torch.isinf(value).any():
                        runner.logger.error(
                            f"[AMP Monitor] 🔴 Inf detected in {key} at iter {batch_idx}!"
                        )
    
    def after_train_epoch(self, runner):
        """Called after every training epoch."""
        if len(self.scale_history) > 0:
            scales = [s for _, s in self.scale_history]
            runner.logger.info(
                f"[AMP Monitor] Epoch {runner.epoch} summary:\n"
                f"  AMP scale range: [{min(scales):.1f}, {max(scales):.1f}]\n"
                f"  Final scale: {scales[-1]:.1f}"
            )
            # Clear history for next epoch
            self.scale_history = []


@HOOKS.register_module()
class GradientMonitorHook(Hook):
    """
    Monitor gradient norms to detect gradient explosion/vanishing.
    
    Args:
        log_interval (int): Interval to log gradient stats. Default: 50.
        nan_check_interval (int): Interval to check for NaN gradients. Default: 10.
    """
    
    def __init__(self, log_interval=50, nan_check_interval=10):
        self.log_interval = log_interval
        self.nan_check_interval = nan_check_interval
        
    def after_train_iter(self, runner, batch_idx, data_batch=None, outputs=None):
        """Called after every training iteration."""
        
        model = runner.model
        
        # Check for NaN gradients more frequently
        if batch_idx % self.nan_check_interval == 0:
            for name, param in model.named_parameters():
                if param.grad is not None:
                    if torch.isnan(param.grad).any():
                        runner.logger.error(
                            f"[Gradient Monitor] 🔴 NaN gradient in {name} at iter {batch_idx}!"
                        )
                    if torch.isinf(param.grad).any():
                        runner.logger.error(
                            f"[Gradient Monitor] 🔴 Inf gradient in {name} at iter {batch_idx}!"
                        )
        
        # Log gradient statistics
        if batch_idx % self.log_interval == 0:
            grad_norms = []
            max_grad_name = None
            max_grad_norm = 0.0
            
            for name, param in model.named_parameters():
                if param.grad is not None:
                    grad_norm = param.grad.norm().item()
                    grad_norms.append(grad_norm)
                    if grad_norm > max_grad_norm:
                        max_grad_norm = grad_norm
                        max_grad_name = name
            
            if len(grad_norms) > 0:
                import numpy as np
                mean_grad = np.mean(grad_norms)
                std_grad = np.std(grad_norms)
                
                runner.logger.info(
                    f"[Gradient Monitor] Iter {batch_idx}:\n"
                    f"  Mean grad norm: {mean_grad:.4f}\n"
                    f"  Std grad norm: {std_grad:.4f}\n"
                    f"  Max grad norm: {max_grad_norm:.4f} ({max_grad_name})"
                )
                
                # Warn on abnormal gradients
                if max_grad_norm > 100.0:
                    runner.logger.warning(
                        f"[Gradient Monitor] ⚠️ Very large gradient detected: "
                        f"{max_grad_norm:.4f} in {max_grad_name}"
                    )
                elif mean_grad < 1e-6:
                    runner.logger.warning(
                        f"[Gradient Monitor] ⚠️ Very small gradients: mean={mean_grad:.2e}"
                    )
