# AR-RNTR 可视化使用指南

## 已添加的可视化功能

在 `rntr/ar_rntr.py` 中添加了两个可视化函数：

### 1. `vis_linepts()` - 节点点可视化
- **功能**：可视化节点位置（彩色圆点）
- **用途**：快速检查节点定位是否准确
- **适用场景**：调试 Landmark Recall

### 2. `vis_from_nodelist()` - 拓扑图可视化 ⭐
- **功能**：可视化完整拓扑结构（节点+连接箭头）
- **用途**：查看连接关系、发现非法连接、检查拓扑完整性
- **适用场景**：调试 Reachable Recall（推荐！）

**颜色方案**：
- 🔴 **红色节点** → start（起始节点）
- 🟡 **黄色节点 + 黄色箭头** → continue（延续节点）
- 🟢 **绿色节点 + 绿色箭头** → fork（分叉节点）
- 🔵 **蓝色节点 + 蓝色箭头** → merge（合并节点）

---

## 如何启用可视化

### 方法1: 在配置文件中启用（推荐）

修改你的配置文件（例如 `lss_ar_rntr_changeloss_test_fp16_torch2.py`）：

```python
model = dict(
    type='AR_RNTR',
    # ... 其他配置 ...
    
    # ======== 可视化开关 ========
    vis_cfg=dict(
        path='val_ar_rntr_v1'  # 可视化保存路径: vis/val_ar_rntr_v1/
    ),
    # ===========================
    
    # ... 其他配置 ...
)
```

### 方法2: 临时启用（不修改配置文件）

在推理脚本中动态设置：

```python
# 在运行推理前
model.vis_cfg = {'path': 'debug_inference'}
```

---

## 推理时的行为

### 启用可视化后（vis_cfg 不为 None）

```python
# 自动在推理时调用（已添加到 simple_test_pts() 中）
if self.vis_cfg is not None:
    for bi, line_result in enumerate(line_results):
        pred_node_list = line_result['pred_node_lists']
        # 可视化预测拓扑
        self.vis_from_nodelist(pred_node_list, img_metas[bi], 
                               self.vis_cfg['path'], 'pred')
```

**输出位置**：
```
vis/
└── val_ar_rntr_v1/           # vis_cfg['path'] 指定的目录
    ├── scene_001_pred.png     # 预测拓扑图
    ├── scene_002_pred.png
    ├── scene_003_pred.png
    └── ...
```

### 禁用可视化（默认）

```python
model = dict(
    type='AR_RNTR',
    # vis_cfg=None,  # 或者直接注释掉 vis_cfg
    # ...
)
```

不会生成任何可视化文件，不影响推理速度。

---

## 可视化输出详解

### 图像格式
- **尺寸**: 200x200 像素
- **BEV范围**: x, y ∈ [-50m, 50m]
- **分辨率**: 0.5m/像素
- **格式**: PNG 图像

### 节点表示
- **圆点**: 半径1像素，线宽2像素
- **箭头**: 线宽1像素，箭头长度0.1

### 拓扑连接
- **continue**: 黄色箭头从 `nodelist[idx-1]` 指向当前节点
- **fork**: 绿色箭头从 `nodelist[fork_from-1]` 指向当前节点
- **merge**: 蓝色箭头从 `nodelist[merge_with-1]` 指向当前节点
- **start**: 无箭头（新道路起点）

---

## 调试 Reachable Recall 的最佳实践

### 1. 启用可视化
```python
# configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py
vis_cfg=dict(path='debug_reachable_recall'),
```

### 2. 运行验证
```bash
cd /home/subobo/ro/1020/RoadNetwork
python tools/test.py configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py \
    work_dirs/lss_ar_rntr_changeloss_test_fp16_torch2/epoch_60.pth \
    --launcher pytorch
```

### 3. 查看可视化结果
```bash
# 查看生成的图像
ls -lh vis/debug_reachable_recall/

# 用图像查看器打开
# 示例：
eog vis/debug_reachable_recall/scene_001_pred.png  # Linux
# 或
open vis/debug_reachable_recall/scene_001_pred.png  # macOS
```

### 4. 分析问题
查看可视化图像，重点关注：
- ❌ **断链**：某些节点没有连接箭头（非start节点）
- ❌ **错误连接**：箭头指向错误的节点
- ❌ **缺失节点**：GT有的节点，预测中没有
- ❌ **非法箭头**：指向"未来节点"（索引大于当前节点）

---

## 可视化 GT 拓扑（可选）

如果需要对比 GT 和预测结果，可以取消 `simple_test_pts()` 中的注释：

```python
# 在 rntr/ar_rntr.py 第 838-840 行
# Optional visualization (controlled by vis_cfg in config)
if self.vis_cfg is not None:
    for bi, line_result in enumerate(line_results):
        pred_node_list = line_result['pred_node_lists']
        self.vis_from_nodelist(pred_node_list, img_metas[bi], 
                               self.vis_cfg['path'], 'pred')
        
        # 取消下面的注释以可视化 GT
        # if 'centerline_coord' in img_metas[bi]:
        #     gt_node_list = self._build_gt_nodelist(img_metas[bi])
        #     self.vis_from_nodelist(gt_node_list, img_metas[bi], 
        #                            self.vis_cfg['path'], 'gt')
```

**注意**：需要实现 `_build_gt_nodelist()` 函数将 GT 数据转换为 nodelist 格式。

---

## 示例配置

### 训练时不可视化（推荐）
```python
# configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py
model = dict(
    type='AR_RNTR',
    # 训练时不启用可视化（节省时间）
    vis_cfg=None,  # 或注释掉
    # ...
)
```

### 验证时可视化
```python
# 创建一个专门用于验证+可视化的配置文件
# configs/rntr_ar_roadseq/lss_ar_rntr_val_with_vis.py

_base_ = './lss_ar_rntr_changeloss_test_fp16_torch2.py'

model = dict(
    # 只修改可视化配置
    vis_cfg=dict(
        path='val_epoch60_with_fixes'  # 不同epoch可以用不同目录名
    ),
)
```

### 推理少量样本（快速调试）
```python
# 修改 val_dataloader 的 batch_size 和样本数
val_dataloader = dict(
    batch_size=1,  # 每次只推理1个样本
    sampler=dict(
        type='DefaultSampler',
        shuffle=False
    ),
    # 只推理前10个样本
    dataset=dict(
        # ... 其他配置 ...
        indices=range(10),  # 只用前10个样本
    )
)
```

---

## 性能影响

- **禁用可视化** (`vis_cfg=None`): 无任何影响
- **启用可视化**: 
  - 每个场景额外耗时约 **10-50ms**（取决于节点数量）
  - 磁盘占用约 **10-50KB/图像**
  - **建议只在验证时启用，训练时禁用**

---

## 常见问题

### Q1: 运行后没有生成可视化图像？
**A**: 检查：
1. `vis_cfg` 是否为 `None`（默认禁用）
2. `vis/` 目录是否有写入权限
3. 查看终端是否有错误信息

### Q2: 图像全黑，没有节点？
**A**: 可能原因：
1. 推理结果为空（模型没有预测任何节点）
2. 节点坐标超出 [0, 200] 范围
3. 检查 `pred_node_list` 是否为空

### Q3: 箭头方向看起来错误？
**A**: 这可能是真实的连接错误！查看：
1. `fork_from` 和 `merge_with` 索引是否合法
2. 连接是否指向"未来节点"（索引 > 当前索引）
3. 这就是可视化的价值——发现连接问题！

### Q4: 如何同时可视化多个 epoch 的结果？
**A**: 使用不同的 `path` 名称：
```python
# epoch 40
vis_cfg=dict(path='val_epoch40'),

# epoch 60  
vis_cfg=dict(path='val_epoch60'),

# 对比改进效果
vis_cfg=dict(path='val_epoch60_with_fixes'),
```

---

## 总结

✅ **已添加功能**：
- `vis_linepts()` - 节点点可视化
- `vis_from_nodelist()` - 拓扑图可视化
- 推理时自动调用（需在config中启用）

✅ **使用方法**：
1. 配置文件中设置 `vis_cfg=dict(path='目录名')`
2. 运行验证 `python tools/test.py ...`
3. 查看 `vis/目录名/` 下的 PNG 图像

✅ **调试建议**：
- 用于调试 **Reachable Recall**（查看连接问题）
- 训练时禁用，验证时启用
- 对比不同 epoch 的可视化结果

🎯 **下一步**：启用可视化，分析当前 Reachable Recall 低的原因！
