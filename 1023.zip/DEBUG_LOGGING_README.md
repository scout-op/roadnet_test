# DEBUG日志使用说明

## 功能说明

现在训练会生成**两个日志文件**：

### 1. 主训练日志（原有）
- 位置：`work_dirs/{exp_name}/日期_时间.log`
- 内容：标准训练信息（loss、lr、metrics等）
- 格式：mmengine标准格式

### 2. DEBUG详细日志（新增） ✨
- 位置：`work_dirs/debug_logs/ar_rntr_debug_debug.log`
- 内容：所有DEBUG打印信息
  - GT数据统计
  - Label分布
  - Loss spike警告
  - AMP scale变化
  - 梯度监控
  - 权重健康检查

## 文件结构

```
work_dirs/
├── lss_ar_rntr_xxx/          # 训练工作目录
│   ├── 20251023_082000.log   # 主日志
│   └── checkpoints/
└── debug_logs/                # DEBUG日志目录
    └── ar_rntr_debug_debug.log  # DEBUG详细日志 ⭐
```

## DEBUG日志内容示例

```
================================================================================
DEBUG LOG - Training started at 2025-10-23 08:20:00
Config: configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py
================================================================================

================================================================================
Epoch 0, Iter 0 - 2025-10-23 08:20:05
================================================================================
================================================================================
[AR-RNTR DEBUG] Step 1: GT Input Data
================================================================================
Batch size: 16
  Sample 0: coords=46, labels=46, connects=46, coeffs=46
    First coord: [ 0 63], First label: 0
  ...

================================================================================
[GT LABEL DISTRIBUTION] Estimated Epoch 1 - Batches 1 to 10
================================================================================
Total GT nodes (10 batches): 5895
Average nodes per batch: 589.5
  Ancestor   (label=0):   1095 ( 18.6%)
  Lineal     (label=1):   3554 ( 60.3%)
  Offshoot   (label=2):    379 (  6.4%)
  Clone      (label=3):    867 ( 14.7%)
  ...

🔴🔴🔴🔴 [CRITICAL WARNING] LOSS SPIKE DETECTED! 🔴🔴🔴🔴
  Total Loss: 38.4567
  loss_connects: 18.234 ← SPIKE!
  ...
```

## 监控Hooks

### 1. DebugLoggerHookV2
- 创建DEBUG日志文件
- 每10个iter自动flush
- 记录epoch/iter标记

### 2. AMPMonitorHook
- 监控AMP loss_scale
- 检测scale突变（>2x或<0.5x）
- 每50个iter记录

### 3. GradientMonitorHook
- 监控梯度范数
- 检测NaN/Inf
- 每100个iter记录统计
- 每10个iter检查NaN

## 快速验证假设

训练时，实时查看DEBUG日志：

```bash
# 实时监控DEBUG日志（推荐）
tail -f work_dirs/debug_logs/ar_rntr_debug_debug.log

# 筛选关键信息
tail -f work_dirs/debug_logs/ar_rntr_debug_debug.log | grep -E "SPIKE|WARNING|AMP|Gradient"

# 只看GT Label分布
tail -f work_dirs/debug_logs/ar_rntr_debug_debug.log | grep -A 20 "GT LABEL DISTRIBUTION"
```

## 分析Loss Spike

当spike发生时，DEBUG日志会包含：

1. **Spike警告**
   ```
   🔴🔴 [CRITICAL WARNING] LOSS SPIKE DETECTED!
   ```

2. **AMP scale信息**
   ```
   [AMP Monitor] Loss scale: 2048 → 1024 (ratio=0.50)
   ```

3. **权重健康检查**
   ```
   ❌ Parameters with NaN: ['pts_bbox_head.xxx']
   ```

4. **梯度信息**
   ```
   Max grad norm: 234.567 (pts_bbox_head...)
   ```

## 验证我的假设

### 假设1: AMP dynamic scaling导致spike
**验证方法：**
1. 查看spike时刻的AMP scale变化
2. 如果scale突然减半 → 假设成立 ✅

### 假设2: loss_weight=3.0放大问题
**验证方法：**
1. 查看loss_connects是否最严重
2. 对比其他loss的spike幅度

### 假设3: 类别权重不当
**验证方法：**
1. 查看GT Label分布
2. 对比Offshoot/Lineal比例

## 清理日志

```bash
# 删除旧的DEBUG日志
rm -rf work_dirs/debug_logs/*

# 或只保留最近的
cd work_dirs/debug_logs
ls -t | tail -n +5 | xargs rm -f
```

## 注意事项

1. **性能影响**：DEBUG日志每10个iter flush，对性能影响很小
2. **磁盘空间**：每个epoch约10-50MB，注意定期清理
3. **分布式训练**：只有rank 0输出DEBUG信息
4. **失败安全**：所有DEBUG代码都有异常保护，不会影响训练

## 手动运行替换脚本（可选）

如果想将所有print语句改为debug_print：

```bash
python replace_prints.py
```

这会自动替换`rntr/ar_rntr.py`中的所有print语句。
