# 贝塞尔系数 +10 Offset 验证方案

## 一、论文描述回顾

**论文原文（3-method.tex, 行52, 65）：**
> "As a solution, we discretize $e_{px}$ and $e_{py}$ by applying the \texttt{int} function to $(e_{px}+10)$ and $(e_{py}+10)$, respectively, to avoid negative values."

**关键问题：**
代码中未找到显式的 `+10` 操作，需要验证这个offset是如何实现的。

---

## 二、代码实现追踪

### 2.1 关键发现：双重Grid配置

**配置文件：`configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py`**

```python
# 行27-31：主BEV网格（用于坐标离散化）
grid_conf = dict(
    xbound=[-48.0, 48.0, 0.5],  # 96m × 128m × 0.5m = 192格
    ybound=[-32.0, 32.0, 0.5],  # 64m × 128m = 128格
)

# 行32-36：Bezier控制点专用网格
bz_grid_conf = dict(
    xbound=[-55.0, 55.0, 0.5],  # 110m × 0.5m = 220格
    ybound=[-55.0, 55.0, 0.5],  # 110m × 0.5m = 220格
)
```

**关键差异：**
| 网格 | X范围 | Y范围 | 用途 |
|------|-------|-------|------|
| grid_conf | [-48, 48] | [-32, 32] | 节点坐标(vx, vy) |
| bz_grid_conf | [-55, 55] | [-55, 55] | Bezier系数(epx, epy) |

**差值分析：**
- X方向：55 - 48 = **7m** （每侧扩展）
- Y方向：55 - 32 = **23m** （Y方向不对称，但主要保证控制点可能超出BEV范围）

---

### 2.2 系数处理代码

**数据加载：`rntr/transforms/loading.py` 行800-804**

```python
# 关键：使用 bz_pc_range 和 bz_dx（来自bz_grid_conf）
if hasattr(node, 'coeff') and len(node.coeff):
    coeff = (node.coeff - bz_pc_range[:2]) / bz_dx[:2]  # 归一化到bz网格
    cx = int(np.clip(coeff[0], 0, bz_nx[0] - 1))        # 裁剪到[0, 219]
    cy = int(np.clip(coeff[1], 0, bz_nx[1] - 1))
    seq.extend([cx, cy])
```

**训练时添加offset：`ar_rntr.py` 行395**

```python
coeff = torch.tensor(gt_lines_coeffs[bi], device=device).long() + self.coeff_start
# gt_lines_coeffs 已经是 [0, 219] 范围的整数
# 加上 coeff_start=350 后变成 [350, 569]
```

**推理时移除offset：`ar_rntr.py` 行781**

```python
pred_line_seq[k::clause_length] = pred_line_seq[k::clause_length] - self.coeff_start
# 从 [350, 569] 还原到 [0, 219]
```

---

### 2.3 与论文"+10"的关系

**数学推导：**

假设原始控制点在世界坐标 `(cpx, cpy)` (单位：米)：

1. **论文方法（显式+10）：**
   ```python
   # 假设BEV范围 [-48, 48]，分辨率0.5m
   token_x = int((cpx + 10) / 0.5)  # 先加10，再离散化
   ```
   
2. **代码方法（扩大grid范围）：**
   ```python
   # bz_grid范围 [-55, 55]，分辨率0.5m
   token_x = int((cpx - (-55)) / 0.5)
   token_x = int((cpx + 55) / 0.5)  # 等价于先加55，再离散化
   ```

**关键洞察：**
- 论文描述的"+10"是一个**概念性的偏移**，用于避免负值
- 代码通过**扩大Bezier网格的pc_range**实现相同目的
- 具体offset不是10m，而是**55m**（`-bz_pc_range[0] = -(-55) = 55`）

**为什么论文说"+10"？**
可能的原因：
1. 论文简化描述，10是一个示例值
2. 早期实验可能用的是小offset，后来改为更大的grid范围
3. 重点是说明"通过offset避免负值"的思想，而非具体数值

---

## 三、验证方法

### 方法1：直接检查数据范围（推荐⭐⭐⭐）

**目的：** 验证预处理后的系数确实在 [0, 219] 范围内

```python
# 创建测试脚本：test_coeff_range.py
import numpy as np
from mmengine import load

# 加载训练数据
ann_file = 'data/nuscenes/nuscenes_centerline_infos_pon_train.pkl'
data = load(ann_file)

coeff_values = []
for info in data['infos'][:100]:  # 检查前100个样本
    if 'center_lines' in info:
        # 假设预处理后的centerline_coeff字段存在
        # 需要先通过pipeline处理
        pass

# 统计系数范围
print(f"Coeff range: [{np.min(coeff_values)}, {np.max(coeff_values)}]")
print(f"Expected: [0, 219] for bz_grid [-55, 55] with 0.5m resolution")
```

**预期结果：**
- ✅ 如果系数在 [0, 219]：证明使用了bz_grid的范围
- ❌ 如果系数有负值：说明预处理有问题

---

### 方法2：追踪原始数据到token的完整流程

**步骤：**

1. **获取原始控制点坐标（世界坐标系，单位：米）**
   ```python
   # 在 centerline_nuscenes_dataset.py 中打印
   print(f"Raw coeff (world coord): {node.coeff}")
   # 预期：可能包含负值，范围约 [-60, 60] 米
   ```

2. **第一次转换：世界坐标 → bz_grid坐标**
   ```python
   # loading.py:800
   coeff = (node.coeff - bz_pc_range[:2]) / bz_dx[:2]
   # 预期：
   #   输入: [-60, 60] 米
   #   bz_pc_range = [-55, -55]
   #   bz_dx = [0.5, 0.5]
   #   输出: [(-60-(-55))/0.5, (60-(-55))/0.5] = [-10, 230]
   #   经过clip后: [0, 219]
   ```

3. **第二次转换：添加token offset**
   ```python
   # ar_rntr.py:395
   coeff_token = coeff + self.coeff_start  # 350
   # 预期：[350, 569]
   ```

4. **推理解码：移除offset**
   ```python
   # ar_rntr.py:781
   coeff_grid = coeff_token - self.coeff_start
   # 预期：[0, 219]
   ```

5. **最终转换：grid → 世界坐标**
   ```python
   # 需要在评估或可视化代码中
   coeff_world = coeff_grid * bz_dx[:2] + bz_pc_range[:2]
   # 预期：还原到原始范围
   ```

---

### 方法3：对比论文Table与代码token范围

**论文Table（embedding.tex）：**
```
e_px, e_py: 350~569
范围大小：220 tokens
```

**代码token计算：**
```python
coeff_start = 350
bz_grid: [-55, 55] @ 0.5m分辨率
bz_nx = (55 - (-55)) / 0.5 = 220

token范围: [350, 350+220) = [350, 570)
```

**对比：**
| 来源 | 起始 | 结束 | 范围大小 |
|------|------|------|----------|
| 论文 | 350 | 569 | 220 |
| 代码 | 350 | 569 | 220 |

✅ **完全一致！**

---

### 方法4：单元测试（最严格⭐⭐⭐⭐⭐）

```python
# test_bezier_coeff_offset.py
import numpy as np
import torch

def test_coeff_encoding_decoding():
    """测试系数编码和解码的正确性"""
    
    # 模拟配置
    bz_pc_range = np.array([-55.0, -55.0, -10.0, 55.0, 55.0, 10.0])
    bz_dx = np.array([0.5, 0.5, 20.0])
    bz_nx = np.array([220, 220, 1])
    coeff_start = 350
    
    # 测试用例1：控制点在BEV范围内
    world_coeff = np.array([10.0, 20.0])  # 世界坐标
    
    # 编码
    grid_coeff = (world_coeff - bz_pc_range[:2]) / bz_dx[:2]
    grid_coeff_int = np.clip(grid_coeff.astype(int), 0, bz_nx[:2] - 1)
    token_coeff = grid_coeff_int + coeff_start
    
    print(f"World: {world_coeff}")
    print(f"Grid: {grid_coeff_int}")
    print(f"Token: {token_coeff}")
    
    assert token_coeff[0] >= 350 and token_coeff[0] < 570
    assert token_coeff[1] >= 350 and token_coeff[1] < 570
    
    # 解码
    grid_coeff_decoded = token_coeff - coeff_start
    world_coeff_decoded = grid_coeff_decoded * bz_dx[:2] + bz_pc_range[:2]
    
    print(f"Decoded: {world_coeff_decoded}")
    
    # 验证往返误差（最大0.5m，因为离散化损失）
    error = np.abs(world_coeff - world_coeff_decoded)
    print(f"Error: {error}")
    assert np.all(error < 0.5)
    
    # 测试用例2：控制点在BEV范围外（负值）
    world_coeff_neg = np.array([-60.0, -50.0])
    grid_coeff_neg = (world_coeff_neg - bz_pc_range[:2]) / bz_dx[:2]
    grid_coeff_neg_int = np.clip(grid_coeff_neg.astype(int), 0, bz_nx[:2] - 1)
    token_coeff_neg = grid_coeff_neg_int + coeff_start
    
    print(f"\nNegative case:")
    print(f"World: {world_coeff_neg}")
    print(f"Grid (before clip): {grid_coeff_neg}")
    print(f"Grid (after clip): {grid_coeff_neg_int}")
    print(f"Token: {token_coeff_neg}")
    
    # 验证clip是否生效
    assert grid_coeff_neg_int[0] == 0  # -60m被clip到grid最小值0
    assert token_coeff_neg[0] == 350    # token也是最小值
    
    print("\n✅ All tests passed!")

if __name__ == "__main__":
    test_coeff_encoding_decoding()
```

**运行验证：**
```bash
cd RoadNetwork
python test_bezier_coeff_offset.py
```

**预期输出：**
```
World: [10. 20.]
Grid: [130 150]
Token: [480 500]
Decoded: [10. 20.]
Error: [0. 0.]

Negative case:
World: [-60. -50.]
Grid (before clip): [-10.  10.]
Grid (after clip): [ 0 10]
Token: [350 360]

✅ All tests passed!
```

---

## 四、验证结论模板

### 如果验证通过（✅）

**结论：**
1. ✅ 论文"+10"是**概念性描述**，实际通过扩大bz_grid范围实现
2. ✅ 代码使用的offset是**+55m**（来自bz_pc_range起点）
3. ✅ 效果等价：都能处理负坐标的控制点
4. ✅ Token范围与论文Table完全一致：[350, 569]

**不一致但合理：**
- 论文：描述了一般思想（"+10避免负值"）
- 代码：使用更优雅的实现（独立的bz_grid配置）
- 代码方案更灵活，可以通过修改bz_grid_conf调整范围

**建议：**
在代码注释中添加说明：
```python
# 论文中描述的 "+10" offset 通过配置 bz_grid_conf 实现
# bz_grid_conf 范围更大，确保控制点（可能超出BEV范围）能正确离散化
# 实际offset = -bz_pc_range[0] = 55m (而非论文中举例的10m)
```

---

### 如果验证失败（❌）

**可能问题：**
1. ❌ 系数token超出 [350, 569] 范围
2. ❌ 系数值包含负数（说明未正确应用offset）
3. ❌ 往返编码-解码误差过大

**需要修复：**
- 检查数据预处理pipeline是否正确调用了`bz_grid_conf`
- 验证`loading.py`中的归一化公式
- 检查配置文件中的bz_grid_conf是否正确传递

---

## 五、快速验证命令（推荐使用）

### 命令1：检查配置一致性
```bash
cd RoadNetwork
grep -r "bz_grid_conf" configs/ | head -20
```

**预期：** 所有配置文件中bz_grid_conf都是 `[-55, 55] × [-55, 55]`

---

### 命令2：检查数据预处理代码
```bash
cd RoadNetwork
grep -A 5 "bz_pc_range\[:2\]" rntr/transforms/*.py
```

**预期：** 找到 `loading.py:800` 和 `centerline_utils.py:794,851` 中的系数处理代码

---

### 命令3：运行单元测试（创建上述test_bezier_coeff_offset.py后）
```bash
cd RoadNetwork
python test_bezier_coeff_offset.py
```

**预期：** 所有断言通过，输出 "✅ All tests passed!"

---

### 命令4：可视化验证（如果有预训练模型）
```bash
cd RoadNetwork
python tools/vis.py \
    --results-json work_dirs/lss_ar_rntr/results_nusc.json \
    --config configs/rntr_ar_roadseq/lss_ar_rntr_changeloss_test_fp16_torch2.py \
    --tag debug_coeff \
    --max-samples 10
```

**手动检查：**
- 查看 `vis/debug_coeff/` 中的可视化图像
- 验证Bezier曲线是否合理（控制点位置正确）
- 如果曲线异常扭曲，说明系数解码有问题

---

## 六、总结

### 关键发现
1. **论文"+10"是简化描述**，实际代码使用了更通用的双重网格系统
2. **主网格 (grid_conf)** 用于节点坐标，范围 [-48, 48] × [-32, 32]
3. **Bezier网格 (bz_grid_conf)** 用于控制点，范围 [-55, 55] × [-55, 55]
4. **实际offset = 55m**，通过 `coeff - bz_pc_range[:2]` 实现

### 验证步骤优先级
1. **P0（必须）：** 运行单元测试（方法4）
2. **P1（推荐）：** 检查数据范围（方法1）
3. **P2（可选）：** 追踪完整流程（方法2）
4. **P3（验证）：** 可视化检查（命令4）

### 最终判断标准
- ✅ **通过：** 所有测试通过，token范围正确，可视化正常
- ⚠️ **部分通过：** 逻辑正确但offset数值与论文不同（可接受）
- ❌ **失败：** 系数范围错误或解码异常（需要修复）
